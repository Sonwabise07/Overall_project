# App decisions

Technical decisions for the Asset Hub app (Expo SDK 57, Expo Router, NativeWind). Business rules and API decisions are in the API repo's `docs/DECISIONS.md` (DEC-001 to DEC-028). Each entry says what was decided, why, and whether it still needs confirmation.

## APP-001: The app uses the real API only

- **Decision:** Every screen reads and writes through the CtrlFind API. Dummy data and template leftovers were removed:
  - `api-dummy.ts`, `api-test.ts`, `demo.tsx`, the sign-up screen and form, and social connections. The BRD has no self sign-up; accounts come from HR/Oracle.
  - The copied `*.store.ts` files in each feature. Server data lives in React Query; only the session uses zustand.
  - `features/user -legacy` and `features/integrations`. Integrations run server to server, so the app has no screen for them.
  - `table/reactive-row-wrapper.tsx`, replaced by the layout components (APP-005).
- **Why:** One source of truth, and no screen can show figures that are not in the database.
- **Status:** Accepted

## APP-002: Feature module pattern kept

- **Decision:** Each feature keeps the team's structure: `<feature>.types.ts` (DTOs matching the API contract), `<feature>.api.ts` (axios calls) and `<feature>.queries.ts` (React Query hooks). Screens never call axios directly.
- **Shared helpers:**
  - `shared/api/api-client.ts` adds the bearer token and refreshes it once on a 401, sharing one refresh between parallel requests.
  - `api-errors.ts` turns the API error envelope into a readable message.
  - `api-mutation.ts` invalidates the related queries after every change, so lists and dashboards refresh themselves.
- **Status:** Accepted

## APP-003: Sign-in and session

- **Decision:** Sign-in uses `POST auth/login`. The session is kept with zustand `persist`: in `localStorage` on web, and in memory on native until secure storage is added. Routes are guarded with `Stack.Protected`.
- **Deep links:** Web pages are pre-rendered without a session. The root layout therefore waits until the stored session has been read (`useAuthHydrated`), following the Expo Router authentication guide's advice for web: client-side guards with a loading state. Without this, opening or refreshing any page sent the user back to the dashboard.
- **Status:** Accepted. Native secure storage (expo-secure-store) is a follow-up before a mobile release.

## APP-004: Role-aware navigation, rules enforced by the API

- **Decision:** The drawer shows only the sections a role can use (`navigation/drawer.config.ts`). Screens hide actions a role cannot take; for example, only IT Help Desk sees the diagnosis form, and only Fixed Assets sees "Change state". The API stays the authority: every rule (custody agreement, short notice, negligence, approval, scope) is checked server side and its message is shown as returned.
- **Why:** The UI cannot drift from the BRD rules, because it never re-implements them.
- **Status:** Accepted

## APP-005: Shared UI components

- **Decision:** Screens are built from a small set of components, styled after the Asset Hub designs:
  - **Layout:** `Page`, `StatGrid`, `Columns`, `Section`, `PageHeader` with search and notifications.
  - **Data:** `Table` (column based; replaces the earlier `cols`/`span` table), `StatusBadge` (one colour language for every status), `DetailList`, `Callout`, `QueryBoundary` (loading, error and retry).
  - **Forms:** `Field`, `DateField`, `OptionPicker`, `Checkbox`, `FormMessage`, `SubmitButton`; pickers for employees, assets, locations and storerooms; `FileUpload`.
  - **Navigation and charts:** `Tabs`, `BarList`, `ColumnChart`. The charts are plain views, with no chart library.
- **Why:** Consistent screens, less code per screen, and no extra dependencies.
- **Status:** Accepted

## APP-006: Theme

- **Decision:** Colours come from the designs: primary blue `hsl(203 80% 51%)`, purple secondary and a navy sidebar. They are defined once in `global.css` and `lib/theme.ts` and exposed to Tailwind.
- **Status:** Accepted

## APP-007: Asset chosen from another screen

- **Decision:** Buttons such as "Log fault", "Report loss" and "Transfer" on an asset's page open the target screen with `?assetId=`. `usePreselectedAsset` starts the form with that asset and still lets the user change or clear it.
- **Status:** Accepted

## APP-008: Files and photos

- **Decision:** Photos and documents are uploaded with `expo-image-picker` and `expo-document-picker` to `POST assets/{id}/documents`, and the returned document id is passed to the workflow. This covers custody agreements, take-home photos, police reports and data-wipe certificates.
- **Downloads:** Downloads need the bearer token. On web the file is fetched with the token and then opened or saved. On native the address is opened in the system browser, which cannot send the token.
- **Status:** Pending. Native downloads need short-lived signed download links from the API before a mobile release.

## APP-009: Data Assistant screen

- **Decision:** The chat shows everything the API returns:
  - the answer and its evidence line;
  - a chart (bar or monthly columns);
  - a table, whose rows open the asset when the row names one;
  - follow-up suggestions as one-tap questions;
  - a helpful / not helpful rating, sent to `assistant/feedback`.
- **Conversations:** The conversation id is sent with each question, so follow-ups such as "what about Durban?" keep their context. Conversations can be saved, reopened and deleted.
- **Side panel:** The catalogue of supported question types comes from the API, so it always matches what the assistant can answer. Failed requests can be retried.
- **Status:** Accepted

## APP-010: Power BI

- **Decision:** Reports offers the API's Power BI CSV datasets (assets, assignments, incidents, audits, maintenance) for download, for import or scheduled refresh in Power BI. `powerbi-client-react` stays in `package.json` for embedding.
- **Status:** Pending. Embedding needs the Power BI workspace, report ids and an embed-token endpoint.

## APP-011: Repo images were corrupted by `.gitattributes`

- **Finding:** `* text eol=lf` made git treat PNG files as text and strip their carriage-return bytes. Every image in `assets/` was damaged, and `expo export` failed on the favicon.
- **Decision:** The images were restored from the matching Expo SDK 57 template, which is byte-identical apart from the stripped bytes. Image, font and PDF types are now marked `binary` in `.gitattributes`.
- **Action for the team:** Anyone with a local clone should pull and check out `assets/` again after this change.
- **Status:** Accepted

## APP-012: React Compiler safe handlers

- **Decision:** React Compiler is enabled, and it can read values used in event handlers while rendering. Handlers therefore guard optional values (`asset && create.mutate(...)`) instead of using non-null assertions (`asset!.assetId`). The assertion style crashed the Transfers screen before an asset was chosen.
- **Status:** Accepted

## APP-013: Code style

- **Decision:** The project's ESLint rules are followed (`npx expo lint` passes): `T[]` array types, escaped text and no state updates inside effects. TypeScript runs in strict mode (`npx tsc --noEmit` passes).
- **Status:** Accepted

## APP-014: Values mirrored from API configuration

- **Decision:** The Transfers form says up front whether a transfer type needs manager approval. It mirrors `AssetRules:TransferTypesRequiringApproval` (Employee and Department). If that setting changes, update `NEEDS_APPROVAL` in `transfers.tsx`; the API still decides.
- **Status:** Accepted

## APP-015: Mock server

- **Decision:** `mock-server/` (json-server) is left in place, but the app no longer uses it. It can be removed once the team no longer needs it.
- **Status:** For the team to decide

## How this was checked

- `npx tsc --noEmit` and `npx expo lint` pass with no errors or warnings.
- `npx expo export --platform web` builds every route.
- Every screen was opened in a headless browser against mocked API responses. Forms, tabs and actions were opened, and no runtime errors were found. This is not a substitute for running against the real API and seed data (see the API README).
