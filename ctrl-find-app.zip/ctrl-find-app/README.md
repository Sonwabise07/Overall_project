# CTRL + Find Asset Hub app

Expo (SDK 57) app for Asset Hub, the internal asset management and asset tracking system. It runs on web first, and on Android and iOS. All data comes from the CtrlFind API. Technical decisions are recorded in [docs/DECISIONS.md](docs/DECISIONS.md).

## Get started

1. Start the API first (see the API repo's README): migrations applied, seed data loaded, `dotnet run --launch-profile http`.

2. Install dependencies:

   ```bash
   npm install
   ```

3. Start the app on web:

   ```bash
   npx expo start -w
   ```

The app calls the API on `http://localhost:5102`. For a physical device or another address, copy `.env.example` to `.env.local` and set `EXPO_PUBLIC_API_URL`. Use the computer's LAN IP for a phone, or `http://10.0.2.2:5102` for the Android emulator.

## Signing in

Use the seeded development accounts from the API README. For example, `naledi.mokoena@ctrlfind.test` (Fixed Assets) or `tuan.nguyen@ctrlfind.test` (Employee), with the password `AssetHub!2026`. What each user sees depends on their role.

## Screens

| Area | Screens |
|---|---|
| Overview | Dashboard (management overview, or "My assets" for employees, plus self-confirmation requests) |
| Asset register | Asset register, Register asset (single and bulk), Asset details, Asset locations |
| Lifecycle | Onboarding, Take-home requests, Transfers, Emergency swap |
| Operations | Stock & storeroom, Faults & repairs, Warranty |
| Risk & exit | Loss, theft & AOD, Audit & risk, Offboarding, Disposal |
| Insights | Reports (operational, management, Power BI CSV export), Data assistant |

The Data assistant is also one tap away on every screen (the round button at the bottom right).

## Project layout

```text
src/
  app/                 Expo Router routes: (auth) for sign-in, (app) for the signed-in screens
  components/ui/       shadcn-style primitives (button, card, input …)
  components/custom/   Asset Hub components: layout, table, forms, pickers, charts, status
  features/<feature>/  <feature>.types.ts, <feature>.api.ts, <feature>.queries.ts
  shared/api/          axios client with token refresh, error messages, mutation helper
  shared/format/       dates, money (R) and labels
```

## Checks

```bash
npx tsc --noEmit          # types
npx expo lint             # lint rules
npx expo export -p web    # production web build
```
