import { apiClient } from "@/shared/api/api-client";
import { ApiResponse } from "@/shared/api/api-responses.types";
import { CreateOffboardingCaseRequest, OffboardingCaseDto, ResolveOffboardingItemRequest } from "./offboarding.types";

type CaseEnvelope = ApiResponse<OffboardingCaseDto>;

export const getOffboardingCases = async (openOnly = true) =>
  (await apiClient.get<ApiResponse<OffboardingCaseDto[]>>("/offboarding-cases", { params: { openOnly } })).data;

export const createOffboardingCase = async (payload: CreateOffboardingCaseRequest) =>
  (await apiClient.post<CaseEnvelope>("/offboarding-cases", payload)).data;

export const resolveOffboardingItem = async (caseId: string, payload: ResolveOffboardingItemRequest) =>
  (await apiClient.post<CaseEnvelope>(`/offboarding-cases/${caseId}/resolve-item`, payload)).data;

export const completeOffboardingCase = async (caseId: string) =>
  (await apiClient.post<CaseEnvelope>(`/offboarding-cases/${caseId}/complete`)).data;
