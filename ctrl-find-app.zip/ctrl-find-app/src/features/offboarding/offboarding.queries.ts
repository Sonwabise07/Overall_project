import { useQuery } from "@tanstack/react-query";

import { useApiMutation } from "@/shared/api/api-mutation";
import { completeOffboardingCase, createOffboardingCase, getOffboardingCases, resolveOffboardingItem } from "./offboarding.api";
import { CreateOffboardingCaseRequest, ResolveOffboardingItemRequest } from "./offboarding.types";

export const useOffboardingCases = (openOnly = true) =>
  useQuery({ queryKey: ["offboarding", openOnly], queryFn: () => getOffboardingCases(openOnly) });

export const useCreateOffboardingCase = () =>
  useApiMutation((payload: CreateOffboardingCaseRequest) => createOffboardingCase(payload), "offboarding");
export const useResolveOffboardingItem = () =>
  useApiMutation(({ caseId, payload }: { caseId: string; payload: ResolveOffboardingItemRequest }) => resolveOffboardingItem(caseId, payload), "offboarding");
export const useCompleteOffboardingCase = () => useApiMutation((caseId: string) => completeOffboardingCase(caseId), "offboarding");
