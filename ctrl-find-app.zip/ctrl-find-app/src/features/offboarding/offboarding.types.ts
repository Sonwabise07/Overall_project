import { AssetType, CaseStatus, ConditionStatus } from "@/shared/api/api-common.types";

export type OffboardingItemResolution = "Returned" | "HeldForReassignment" | "Escalated" | "AuthorisedException";

export type CreateOffboardingCaseRequest = {
  employeeId: string;
  exitDate: string;
  source: string;
  reason: string;
  notes?: string;
};

export type ResolveOffboardingItemRequest = {
  assetId: string;
  resolution: OffboardingItemResolution;
  conditionStatus?: ConditionStatus;
  returnedDate?: string;
  storeroomId?: string;
  notes?: string;
};

export type OffboardingItemDto = {
  assetId: string;
  assetNo: string;
  assetType: AssetType;
  requiredForCompletion: boolean;
  resolution?: OffboardingItemResolution | null;
  resolvedAt?: string | null;
  make?: string | null;
  model?: string | null;
  notes?: string | null;
};

export type OffboardingCaseDto = {
  caseId: string;
  status: CaseStatus;
  employeeId: string;
  exitDate: string;
  items: OffboardingItemDto[];
  canComplete: boolean;
  blockingReasons: string[];
  request: CreateOffboardingCaseRequest;
  employeeName?: string | null;
  laptopRecovered: boolean;
};
