export type DisposalDto = {
  disposalId: string;
  assetId: string;
  assetNo?: string | null;
  assetDescription?: string | null;
  reason: string;
  method: string;
  dataWipeConfirmed: boolean;
  disposedOn: string;
  recordedByUserId: string;
};

export type PendingDispositionDto = { assetId: string; assetNo: string; assetDescription?: string | null; reason: string; since: string };

export type CreateDisposalRequest = {
  assetId: string;
  reason: string;
  method: string;
  dataWipeConfirmed: boolean;
  certificateDocumentId?: string;
  disposedOn: string;
  notes?: string;
};
