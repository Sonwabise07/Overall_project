import { useQuery } from "@tanstack/react-query";

import { useApiMutation } from "@/shared/api/api-mutation";
import { createDisposal, getDisposals, getPendingDispositions } from "./disposals.api";
import { CreateDisposalRequest } from "./disposals.types";

export const useDisposals = () => useQuery({ queryKey: ["disposals"], queryFn: getDisposals });
export const usePendingDispositions = () => useQuery({ queryKey: ["disposals", "pending"], queryFn: getPendingDispositions });

export const useCreateDisposal = () => useApiMutation((payload: CreateDisposalRequest) => createDisposal(payload), "disposals");
