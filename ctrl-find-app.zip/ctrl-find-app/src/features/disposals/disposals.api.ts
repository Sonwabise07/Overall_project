import { apiClient } from "@/shared/api/api-client";
import { ApiResponse } from "@/shared/api/api-responses.types";
import { CreateDisposalRequest, DisposalDto, PendingDispositionDto } from "./disposals.types";

export const getDisposals = async () => (await apiClient.get<ApiResponse<DisposalDto[]>>("/disposals")).data;

export const getPendingDispositions = async () => (await apiClient.get<ApiResponse<PendingDispositionDto[]>>("/disposals/pending")).data;

export const createDisposal = async (payload: CreateDisposalRequest) =>
  (await apiClient.post<ApiResponse<DisposalDto>>("/disposals", payload)).data;
