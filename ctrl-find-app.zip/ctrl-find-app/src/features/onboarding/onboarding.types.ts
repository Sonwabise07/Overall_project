import { AssetType, CaseStatus } from "@/shared/api/api-common.types";

export type CreateOnboardingCaseRequest = {
  employeeId: string;
  employeeName: string;
  departmentId: string;
  managerEmployeeId?: string;
  startDate: string;
  jobRole: string;
  locationId: string;
  source: "Recruitment" | "Oracle";
  notes?: string;
};

export type OnboardingCaseDto = {
  caseId: string;
  status: CaseStatus;
  employeeId: string;
  employeeName: string;
  jobRole: string;
  departmentId: string;
  locationId: string;
  startDate: string;
  isConfirmed: boolean;
  isShortNotice: boolean;
  readinessState: "Provisional" | "NoKitDefined" | "AwaitingStock" | "ReadyToIssue" | "Issued";
  reservedAssets: { assetId: string; assetType: AssetType; reservationId: string; assetNo?: string | null; issued: boolean }[];
  shortfalls: { assetType: AssetType; quantity: number; neededBy: string }[];
  blockingItems: string[];
  createdAt: string;
  notes?: string | null;
};
