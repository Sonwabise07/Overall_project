import { useQuery } from "@tanstack/react-query";

import { useApiMutation } from "@/shared/api/api-mutation";
import { createOnboardingCase, getOnboardingCases, issueOnboardingAssets, reserveOnboardingStock } from "./onboarding.api";
import { CreateOnboardingCaseRequest } from "./onboarding.types";

export const useOnboardingCases = (openOnly = true) =>
  useQuery({ queryKey: ["onboarding", openOnly], queryFn: () => getOnboardingCases(openOnly) });

export const useCreateOnboardingCase = () =>
  useApiMutation((payload: CreateOnboardingCaseRequest) => createOnboardingCase(payload), "onboarding");
export const useReserveOnboardingStock = () => useApiMutation((caseId: string) => reserveOnboardingStock(caseId), "onboarding");
export const useIssueOnboardingAssets = () =>
  useApiMutation(({ caseId, managerAcknowledged }: { caseId: string; managerAcknowledged?: boolean }) => issueOnboardingAssets(caseId, managerAcknowledged), "onboarding");
