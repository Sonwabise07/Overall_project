import { apiClient } from "@/shared/api/api-client";
import { ApiResponse } from "@/shared/api/api-responses.types";
import { CreateOnboardingCaseRequest, OnboardingCaseDto } from "./onboarding.types";

type CaseEnvelope = ApiResponse<OnboardingCaseDto>;

export const getOnboardingCases = async (openOnly = true) =>
  (await apiClient.get<ApiResponse<OnboardingCaseDto[]>>("/onboarding-cases", { params: { openOnly } })).data;

export const createOnboardingCase = async (payload: CreateOnboardingCaseRequest) =>
  (await apiClient.post<CaseEnvelope>("/onboarding-cases", payload)).data;

export const reserveOnboardingStock = async (caseId: string) =>
  (await apiClient.post<CaseEnvelope>(`/onboarding-cases/${caseId}/reserve-stock`)).data;

export const issueOnboardingAssets = async (caseId: string, managerAcknowledged = false) =>
  (await apiClient.post<CaseEnvelope>(`/onboarding-cases/${caseId}/issue-assets`, { managerAcknowledged })).data;
