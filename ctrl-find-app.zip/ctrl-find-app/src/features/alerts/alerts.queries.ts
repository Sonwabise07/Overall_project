import { useQuery } from "@tanstack/react-query";

import { useApiMutation } from "@/shared/api/api-mutation";
import { getAlerts, getNotifications, markAllNotificationsRead, markNotificationRead } from "./alerts.api";

export const useAlerts = () => useQuery({ queryKey: ["alerts"], queryFn: getAlerts });
export const useNotifications = () => useQuery({ queryKey: ["notifications"], queryFn: getNotifications, refetchInterval: 1000 * 60 });

export const useMarkNotificationRead = () => useApiMutation((notificationId: string) => markNotificationRead(notificationId));
export const useMarkAllNotificationsRead = () => useApiMutation(() => markAllNotificationsRead());
