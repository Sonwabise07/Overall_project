import { apiClient } from "@/shared/api/api-client";
import { AlertDto, NotificationDto } from "@/shared/api/api-common.types";
import { ApiResponse } from "@/shared/api/api-responses.types";

export const getAlerts = async () => (await apiClient.get<ApiResponse<AlertDto[]>>("/alerts")).data;

export const getNotifications = async () => (await apiClient.get<ApiResponse<NotificationDto[]>>("/notifications")).data;

export const markNotificationRead = async (notificationId: string) => (await apiClient.post(`/notifications/${notificationId}/read`)).data;

export const markAllNotificationsRead = async () => (await apiClient.post("/notifications/read-all")).data;
