import {
  AssetType,
  AuditOutcome,
  CaseStatus,
  ConditionStatus,
  LifecycleState,
  LocationDto,
  LocationSubStatus,
  OperationalStatus,
} from "@/shared/api/api-common.types";
import { ApiResponse, PaginatedResponse } from "@/shared/api/api-responses.types";

export type TransferType = "Employee" | "Department" | "Location" | "Desk" | "Storeroom";

export type AssetListItemDto = {
  assetId: string;
  assetNo: string;
  assetTag?: string | null;
  serialNumber?: string | null;
  assetType: AssetType;
  make?: string | null;
  model?: string | null;
  lifecycleState: LifecycleState;
  operationalStatus: OperationalStatus;
  assignedEmployeeId?: string | null;
  assignedEmployeeName?: string | null;
  locationSummary?: string | null;
  warrantyEnd?: string | null;
  lastAuditDate?: string | null;
  locationSubStatus?: LocationSubStatus | null;
  auditOutcome?: AuditOutcome | null;
  department?: string | null;
};

export type AssignmentDto = {
  assignmentId: string;
  assetId: string;
  employeeId: string;
  employeeName?: string | null;
  locationId: string;
  assignmentDate: string;
  custodyAgreementDocumentId?: string | null;
  notes?: string | null;
  returnedAt?: string | null;
  managerName?: string | null;
};

export type AssetDetailDto = {
  assetId: string;
  assetNo: string;
  assetTag?: string | null;
  serialNumber?: string | null;
  assetType: AssetType;
  category?: string | null;
  make?: string | null;
  model?: string | null;
  companyEntity?: string | null;
  costCentre?: string | null;
  department?: string | null;
  location?: LocationDto | null;
  assignment?: AssignmentDto | null;
  status: { lifecycleState: LifecycleState; operationalStatus: OperationalStatus };
  financial: { purchaseCost?: number | null; purchaseOrder?: string | null; invoiceReference?: string | null };
  lifecycle: { acquisitionDate?: string | null; warrantyStart?: string | null; warrantyEnd?: string | null; warrantyVendor?: string | null };
  auditData: { lastAuditDate?: string | null; auditOutcome?: AuditOutcome | null };
  laptopControls?: { encryptionStatus: string; custodyAgreementSigned: boolean; healthIndicator: "Green" | "Amber" | "Red" } | null;
  notes?: string | null;
  createdAt: string;
  updatedAt: string;
  version: number;
  condition?: ConditionStatus | null;
  holdExpiresAt?: string | null;
};

export type HistoryDto = {
  historyId: string;
  assetId: string;
  actionType: string;
  oldValue?: unknown;
  newValue?: unknown;
  userId: string;
  changedAt: string;
  summary?: string | null;
};

export type AssetListParams = {
  page?: number;
  pageSize?: number;
  sort?: string;
  search?: string;
  lifecycleState?: LifecycleState;
  operationalStatus?: OperationalStatus;
  assetType?: AssetType;
  departmentId?: string;
  locationId?: string;
  assignedEmployeeId?: string;
  subStatus?: LocationSubStatus;
  flagged?: boolean;
};

export type CreateAssetRequest = {
  assetNo?: string;
  assetTag?: string;
  serialNumber?: string;
  assetType: AssetType;
  category?: string;
  make?: string;
  model?: string;
  companyEntity?: string;
  costCentre?: string;
  departmentId?: string;
  locationId?: string;
  lifecycleState: LifecycleState;
  purchaseCost?: number;
  purchaseOrder?: string;
  invoiceReference?: string;
  acquisitionDate?: string;
  warrantyStart?: string;
  warrantyEnd?: string;
  notes?: string;
  storeroomId?: string;
  desk?: string;
  warrantyVendor?: string;
  encryptionStatus?: string;
  condition?: ConditionStatus;
};

export type BulkCreateAssetsRequest = {
  common: CreateAssetRequest;
  units: { assetTag: string; serialNumber: string; assetNo?: string }[];
};

export type UpdateAssetRequest = {
  assetTag?: string;
  departmentId?: string;
  locationId?: string;
  warrantyEnd?: string;
  notes?: string;
  desk?: string;
  storeroomId?: string;
  warrantyVendor?: string;
  warrantyStart?: string;
  encryptionStatus?: string;
  category?: string;
  companyEntity?: string;
  costCentre?: string;
};

export type ChangeLifecycleRequest = { lifecycleState: LifecycleState; reason: string };

export type CreateAssignmentRequest = {
  employeeId: string;
  locationId: string;
  assignmentDate: string;
  custodyAgreementDocumentId?: string;
  notes?: string;
  desk?: string;
  condition: ConditionStatus;
  managerAcknowledged?: boolean;
};

export type ReturnAssetRequest = { storeroomId: string; condition: ConditionStatus; notes?: string };

export type HoldForReassignmentRequest = { expiresAt?: string; reason?: string };

export type CreateTransferRequest = {
  transferType: TransferType;
  targetEmployeeId?: string;
  targetDepartmentId?: string;
  targetLocationId?: string;
  targetDesk?: string;
  targetStoreroomId?: string;
  requestedDate: string;
  reason: string;
  notes?: string;
  custodyAgreementDocumentId?: string;
};

export type TransferDto = {
  transferId: string;
  assetId: string;
  transferType: TransferType;
  status: CaseStatus;
  requestedByUserId: string;
  requestedAt: string;
  assetNo?: string | null;
  fromValue?: string | null;
  toValue?: string | null;
  reason?: string | null;
  decidedByUserId?: string | null;
  decidedAt?: string | null;
  decisionReason?: string | null;
  atomSyncStatus?: string | null;
};

export type MaintenanceLogDto = {
  logId: string;
  assetId: string;
  lastServiceDate: string;
  nextDueDate?: string | null;
  serviceProvider: string;
  notes?: string | null;
  recordedAt: string;
};

export type AssetListResponse = PaginatedResponse<AssetListItemDto>;
export type AssetDetailResponse = ApiResponse<AssetDetailDto>;
export type AssetHistoryResponse = ApiResponse<HistoryDto[]>;
export type AssignmentHistoryResponse = ApiResponse<AssignmentDto[]>;
export type TransferListResponse = PaginatedResponse<TransferDto>;
export type TransferResponseEnvelope = ApiResponse<TransferDto>;
