import { apiClient } from "@/shared/api/api-client";
import { ApiResponse } from "@/shared/api/api-responses.types";
import {
  AssetDetailResponse,
  AssetHistoryResponse,
  AssetListItemDto,
  AssetListParams,
  AssetListResponse,
  AssignmentDto,
  AssignmentHistoryResponse,
  BulkCreateAssetsRequest,
  ChangeLifecycleRequest,
  CreateAssetRequest,
  CreateAssignmentRequest,
  CreateTransferRequest,
  HoldForReassignmentRequest,
  MaintenanceLogDto,
  ReturnAssetRequest,
  TransferListResponse,
  TransferResponseEnvelope,
  UpdateAssetRequest,
} from "./assets.types";
import { CaseStatus } from "@/shared/api/api-common.types";

export const getAssets = async (params: AssetListParams = {}): Promise<AssetListResponse> =>
  (await apiClient.get<AssetListResponse>("/assets", { params })).data;

export const createAsset = async (payload: CreateAssetRequest): Promise<AssetDetailResponse> =>
  (await apiClient.post<AssetDetailResponse>("/assets", payload)).data;

export const bulkCreateAssets = async (payload: BulkCreateAssetsRequest): Promise<ApiResponse<AssetListItemDto[]>> =>
  (await apiClient.post<ApiResponse<AssetListItemDto[]>>("/assets/bulk", payload)).data;

export const getAsset = async (assetId: string): Promise<AssetDetailResponse> =>
  (await apiClient.get<AssetDetailResponse>(`/assets/${assetId}`)).data;

export const updateAsset = async (assetId: string, payload: UpdateAssetRequest): Promise<AssetDetailResponse> =>
  (await apiClient.patch<AssetDetailResponse>(`/assets/${assetId}`, payload)).data;

export const changeLifecycle = async (assetId: string, payload: ChangeLifecycleRequest): Promise<AssetDetailResponse> =>
  (await apiClient.post<AssetDetailResponse>(`/assets/${assetId}/lifecycle`, payload)).data;

export const getAssetHistory = async (assetId: string): Promise<AssetHistoryResponse> =>
  (await apiClient.get<AssetHistoryResponse>(`/assets/${assetId}/history`)).data;

export const getAssetAssignments = async (assetId: string): Promise<AssignmentHistoryResponse> =>
  (await apiClient.get<AssignmentHistoryResponse>(`/assets/${assetId}/assignments`)).data;

export const createAssetAssignment = async (assetId: string, payload: CreateAssignmentRequest): Promise<ApiResponse<AssignmentDto>> =>
  (await apiClient.post<ApiResponse<AssignmentDto>>(`/assets/${assetId}/assignments`, payload)).data;

export const returnAsset = async (assetId: string, payload: ReturnAssetRequest): Promise<AssetDetailResponse> =>
  (await apiClient.post<AssetDetailResponse>(`/assets/${assetId}/return`, payload)).data;

export const holdAssetForReassignment = async (assetId: string, payload: HoldForReassignmentRequest): Promise<AssetDetailResponse> =>
  (await apiClient.post<AssetDetailResponse>(`/assets/${assetId}/hold-for-reassignment`, payload)).data;

export const getMaintenanceLog = async (assetId: string): Promise<ApiResponse<MaintenanceLogDto[]>> =>
  (await apiClient.get<ApiResponse<MaintenanceLogDto[]>>(`/assets/${assetId}/maintenance-log`)).data;

// Transfers
export const createAssetTransfer = async (assetId: string, payload: CreateTransferRequest): Promise<TransferResponseEnvelope> =>
  (await apiClient.post<TransferResponseEnvelope>(`/assets/${assetId}/transfers`, payload)).data;

export const getTransfers = async (status?: CaseStatus): Promise<TransferListResponse> =>
  (await apiClient.get<TransferListResponse>("/transfers", { params: { status, pageSize: 100 } })).data;

export const approveTransfer = async (transferId: string, reason?: string): Promise<TransferResponseEnvelope> =>
  (await apiClient.post<TransferResponseEnvelope>(`/transfers/${transferId}/approve`, { reason })).data;

export const declineTransfer = async (transferId: string, reason: string): Promise<TransferResponseEnvelope> =>
  (await apiClient.post<TransferResponseEnvelope>(`/transfers/${transferId}/decline`, { reason })).data;
