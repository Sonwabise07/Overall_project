import { useState } from "react";
import { useQuery } from "@tanstack/react-query";

import { useApiMutation } from "@/shared/api/api-mutation";
import { CaseStatus } from "@/shared/api/api-common.types";
import {
  approveTransfer,
  bulkCreateAssets,
  changeLifecycle,
  createAsset,
  createAssetAssignment,
  createAssetTransfer,
  declineTransfer,
  getAsset,
  getAssetAssignments,
  getAssetHistory,
  getAssets,
  getMaintenanceLog,
  getTransfers,
  holdAssetForReassignment,
  returnAsset,
  updateAsset,
} from "./assets.api";
import {
  AssetListItemDto,
  AssetListParams,
  BulkCreateAssetsRequest,
  ChangeLifecycleRequest,
  CreateAssetRequest,
  CreateAssignmentRequest,
  CreateTransferRequest,
  HoldForReassignmentRequest,
  ReturnAssetRequest,
  UpdateAssetRequest,
} from "./assets.types";

export const useAssets = (params: AssetListParams = {}, enabled = true) =>
  useQuery({ queryKey: ["assets", "list", params], queryFn: () => getAssets(params), enabled });

export const useAsset = (assetId?: string) =>
  useQuery({ queryKey: ["assets", assetId], queryFn: () => getAsset(assetId!), enabled: Boolean(assetId) });

export const useAssetHistory = (assetId?: string) =>
  useQuery({ queryKey: ["assets", assetId, "history"], queryFn: () => getAssetHistory(assetId!), enabled: Boolean(assetId) });

export const useAssetAssignments = (assetId?: string) =>
  useQuery({ queryKey: ["assets", assetId, "assignments"], queryFn: () => getAssetAssignments(assetId!), enabled: Boolean(assetId) });

export const useMaintenanceLog = (assetId?: string) =>
  useQuery({ queryKey: ["assets", assetId, "maintenance-log"], queryFn: () => getMaintenanceLog(assetId!), enabled: Boolean(assetId) });

// An asset passed in the route (e.g. "Log fault" on the asset's page) starts selected; the user can still change or clear it.
export function usePreselectedAsset(assetId?: string) {
  const { data } = useAsset(assetId);
  const [picked, setPicked] = useState<AssetListItemDto | null>();
  const a = data?.data;
  const fromRoute: AssetListItemDto | undefined = a && {
    assetId: a.assetId,
    assetNo: a.assetNo,
    assetTag: a.assetTag,
    assetType: a.assetType,
    make: a.make,
    model: a.model,
    lifecycleState: a.status.lifecycleState,
    operationalStatus: a.status.operationalStatus,
    assignedEmployeeId: a.assignment?.employeeId,
    assignedEmployeeName: a.assignment?.employeeName,
  };
  const asset = picked === undefined ? fromRoute : (picked ?? undefined);
  return [asset, (value?: AssetListItemDto) => setPicked(value ?? null)] as const;
}

export const useTransfers = (status?: CaseStatus) =>
  useQuery({ queryKey: ["transfers", status], queryFn: () => getTransfers(status) });

const useAssetMutation = <TVariables, TResult>(mutationFn: (variables: TVariables) => Promise<TResult>) =>
  useApiMutation(mutationFn, "transfers");

export const useCreateAsset = () => useAssetMutation((payload: CreateAssetRequest) => createAsset(payload));
export const useBulkCreateAssets = () => useAssetMutation((payload: BulkCreateAssetsRequest) => bulkCreateAssets(payload));
export const useUpdateAsset = () =>
  useAssetMutation(({ assetId, payload }: { assetId: string; payload: UpdateAssetRequest }) => updateAsset(assetId, payload));
export const useChangeLifecycle = () =>
  useAssetMutation(({ assetId, payload }: { assetId: string; payload: ChangeLifecycleRequest }) => changeLifecycle(assetId, payload));
export const useCreateAssetAssignment = () =>
  useAssetMutation(({ assetId, payload }: { assetId: string; payload: CreateAssignmentRequest }) => createAssetAssignment(assetId, payload));
export const useReturnAsset = () =>
  useAssetMutation(({ assetId, payload }: { assetId: string; payload: ReturnAssetRequest }) => returnAsset(assetId, payload));
export const useHoldAssetForReassignment = () =>
  useAssetMutation(({ assetId, payload }: { assetId: string; payload: HoldForReassignmentRequest }) => holdAssetForReassignment(assetId, payload));
export const useCreateAssetTransfer = () =>
  useAssetMutation(({ assetId, payload }: { assetId: string; payload: CreateTransferRequest }) => createAssetTransfer(assetId, payload));
export const useApproveTransfer = () =>
  useAssetMutation(({ transferId, reason }: { transferId: string; reason?: string }) => approveTransfer(transferId, reason));
export const useDeclineTransfer = () =>
  useAssetMutation(({ transferId, reason }: { transferId: string; reason: string }) => declineTransfer(transferId, reason));
