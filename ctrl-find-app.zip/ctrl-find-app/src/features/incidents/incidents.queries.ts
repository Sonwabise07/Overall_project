import { useQuery } from "@tanstack/react-query";

import { useApiMutation } from "@/shared/api/api-mutation";
import { createIncident, decideNegligence, getAodRecords, getIncidents, recordAodPayment } from "./incidents.api";
import { CreateIncidentRequest, NegligenceDecisionRequest } from "./incidents.types";

export const useIncidents = () => useQuery({ queryKey: ["incidents"], queryFn: getIncidents });
export const useAodRecords = (enabled = true) => useQuery({ queryKey: ["incidents", "aod"], queryFn: getAodRecords, enabled });

export const useCreateIncident = () => useApiMutation((payload: CreateIncidentRequest) => createIncident(payload), "incidents");
export const useDecideNegligence = () =>
  useApiMutation(({ incidentId, payload }: { incidentId: string; payload: NegligenceDecisionRequest }) => decideNegligence(incidentId, payload), "incidents");
export const useRecordAodPayment = () =>
  useApiMutation(({ aodId, amount, paidOn, reference }: { aodId: string; amount: number; paidOn: string; reference?: string }) =>
    recordAodPayment(aodId, amount, paidOn, reference), "incidents");
