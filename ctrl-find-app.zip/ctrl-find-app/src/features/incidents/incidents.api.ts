import { apiClient } from "@/shared/api/api-client";
import { ApiResponse } from "@/shared/api/api-responses.types";
import { AodDto, CreateIncidentRequest, IncidentDto, NegligenceDecisionRequest } from "./incidents.types";

export const getIncidents = async () => (await apiClient.get<ApiResponse<IncidentDto[]>>("/incidents")).data;

export const createIncident = async (payload: CreateIncidentRequest) =>
  (await apiClient.post<ApiResponse<IncidentDto>>("/incidents", payload)).data;

export const decideNegligence = async (incidentId: string, payload: NegligenceDecisionRequest) =>
  (await apiClient.post<ApiResponse<IncidentDto>>(`/incidents/${incidentId}/negligence-decision`, payload)).data;

export const getAodRecords = async () => (await apiClient.get<ApiResponse<AodDto[]>>("/aod-records")).data;

export const recordAodPayment = async (aodId: string, amount: number, paidOn: string, reference?: string) =>
  (await apiClient.post<ApiResponse<AodDto>>(`/aod-records/${aodId}/payments`, { amount, paidOn, reference })).data;
