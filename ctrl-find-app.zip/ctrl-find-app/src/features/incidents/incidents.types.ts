import { CaseStatus } from "@/shared/api/api-common.types";

export type IncidentType = "Loss" | "Theft";
export type NegligenceStatus = "UnderInvestigation" | "Negligent" | "NotNegligent";

export type CreateIncidentRequest = {
  assetId: string;
  incidentType: IncidentType;
  reportedByEmployeeId: string;
  incidentDate: string;
  locationDescription: string;
  description: string;
  policeCaseNumber?: string;
};

export type IncidentDto = {
  incidentId: string;
  assetId: string;
  incidentType: IncidentType;
  status: CaseStatus;
  negligenceStatus: NegligenceStatus;
  policeCaseNumber?: string | null;
  aodId?: string | null;
  createdAt: string;
  request: CreateIncidentRequest;
  assetNo?: string | null;
  assetDescription?: string | null;
  employeeName?: string | null;
  recordedPurchaseCost?: number | null;
  escalatedToHr: boolean;
  employeeIncidentCount: number;
};

export type NegligenceDecisionRequest = {
  negligenceStatus: NegligenceStatus;
  decisionReason: string;
  aodAmount?: number;
  recoveryTerms?: string;
};

export type AodDto = {
  aodId: string;
  incidentId: string;
  amount: number;
  recoveryTerms: string;
  recoveredAmount: number;
  status: "Open" | "InRecovery" | "Recovered" | "Cancelled";
  employeeId?: string | null;
  assetId?: string | null;
};
