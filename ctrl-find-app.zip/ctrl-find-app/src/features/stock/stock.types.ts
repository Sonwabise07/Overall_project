import { AssetType, ConditionStatus } from "@/shared/api/api-common.types";

export type StockState = "Available" | "Reserved" | "Damaged";
export type StockAlertLevel = "Healthy" | "LowStock" | "NoStock";

export type StockItemDto = {
  assetId: string;
  assetNo: string;
  assetType: AssetType;
  stockState: StockState;
  conditionStatus?: ConditionStatus | null;
  locationId?: string | null;
  storeroomId?: string | null;
  reservedForId?: string | null;
  make?: string | null;
  model?: string | null;
};

export type StockTypeSummaryDto = {
  assetType: AssetType;
  available: number;
  reserved: number;
  damaged: number;
  minimumThreshold?: number | null;
  alert: StockAlertLevel;
};

export type StoreroomStockDto = {
  storeroomId: string;
  name: string;
  locationId?: string | null;
  region?: string | null;
  building?: string | null;
  available: number;
  reserved: number;
  damaged: number;
  alert: StockAlertLevel;
};

export type StockSummaryDto = {
  byType: StockTypeSummaryDto[];
  byStoreroom: StoreroomStockDto[];
  unfulfilledDemand: { caseId: string; employeeName: string; assetType: AssetType; quantity: number; neededBy: string }[];
};

export type StockCountRequest = {
  storeroomId: string;
  countType: "Opening" | "Closing";
  countDate: string;
  items: { assetId: string; conditionStatus: ConditionStatus }[];
  notes?: string;
};

export type StockReconciliationDto = {
  storeroomId: string;
  weekStart: string;
  openingCount?: number | null;
  unitsOut: number;
  unitsIn: number;
  expectedClosing?: number | null;
  closingCount?: number | null;
  discrepancy?: number | null;
};
