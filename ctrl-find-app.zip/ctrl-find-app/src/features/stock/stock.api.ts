import { apiClient } from "@/shared/api/api-client";
import { AssetType } from "@/shared/api/api-common.types";
import { ApiResponse, PaginatedResponse } from "@/shared/api/api-responses.types";
import { StockCountRequest, StockItemDto, StockReconciliationDto, StockState, StockSummaryDto, StockTypeSummaryDto } from "./stock.types";

export type StockItemParams = { state?: StockState; assetType?: AssetType; storeroomId?: string; pageSize?: number };

export const getStockItems = async (params: StockItemParams = {}) =>
  (await apiClient.get<PaginatedResponse<StockItemDto>>("/stock/items", { params: { pageSize: 100, ...params } })).data;

export const getStockSummary = async () => (await apiClient.get<ApiResponse<StockSummaryDto>>("/stock/summary")).data;

export const setStockThreshold = async (assetType: AssetType, minimumAvailable: number) =>
  (await apiClient.put<ApiResponse<StockTypeSummaryDto[]>>(`/stock/thresholds/${assetType}`, { minimumAvailable })).data;

export const recordStockCount = async (payload: StockCountRequest) => (await apiClient.post("/stock/counts", payload)).data;

export const getStockReconciliation = async (storeroomId: string, weekStart?: string) =>
  (await apiClient.get<ApiResponse<StockReconciliationDto>>("/stock/reconciliation", { params: { storeroomId, weekStart } })).data;
