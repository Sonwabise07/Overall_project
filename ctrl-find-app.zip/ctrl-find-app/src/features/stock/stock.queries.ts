import { useQuery } from "@tanstack/react-query";

import { AssetType } from "@/shared/api/api-common.types";
import { useApiMutation } from "@/shared/api/api-mutation";
import { getStockItems, getStockReconciliation, getStockSummary, recordStockCount, setStockThreshold, StockItemParams } from "./stock.api";
import { StockCountRequest } from "./stock.types";

export const useStockItems = (params: StockItemParams = {}) =>
  useQuery({ queryKey: ["stock", "items", params], queryFn: () => getStockItems(params) });
export const useStockSummary = () => useQuery({ queryKey: ["stock", "summary"], queryFn: getStockSummary });
export const useStockReconciliation = (storeroomId?: string) =>
  useQuery({ queryKey: ["stock", "reconciliation", storeroomId], queryFn: () => getStockReconciliation(storeroomId!), enabled: Boolean(storeroomId) });

export const useSetStockThreshold = () =>
  useApiMutation(({ assetType, minimum }: { assetType: AssetType; minimum: number }) => setStockThreshold(assetType, minimum));
export const useRecordStockCount = () => useApiMutation((payload: StockCountRequest) => recordStockCount(payload));
