import { AssetType } from "@/shared/api/api-common.types";

export type DepartmentDto = { departmentId: string; name: string };

export type EmployeeDto = {
  employeeId: string;
  fullName: string;
  email?: string | null;
  departmentId?: string | null;
  jobRole?: string | null;
  managerEmployeeId?: string | null;
  locationId?: string | null;
  isActive: boolean;
  negligentIncidents: number;
};

export type StoreroomDto = { storeroomId: string; name: string; locationId?: string | null };

export type LocationSummaryDto = {
  locationId: string;
  name: string;
  region?: string | null;
  building?: string | null;
  floor?: string | null;
  assetCount: number;
  storeroomCount: number;
};

export type RoleKitDto = {
  jobRole: string;
  items: { assetType: AssetType; quantity: number }[];
  custodyAgreementRequired: boolean;
};
