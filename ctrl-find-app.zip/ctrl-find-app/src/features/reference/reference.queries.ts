import { useQuery } from "@tanstack/react-query";

import { useApiMutation } from "@/shared/api/api-mutation";
import { getDepartments, getEmployee, getEmployees, getLocations, getRoleKits, getStorerooms, saveRoleKit } from "./reference.api";
import { RoleKitDto } from "./reference.types";

// Reference data changes rarely, so it is kept for ten minutes.
const STALE = 1000 * 60 * 10;

export const useDepartments = () => useQuery({ queryKey: ["reference", "departments"], queryFn: getDepartments, staleTime: STALE });
export const useEmployees = (search?: string) =>
  useQuery({ queryKey: ["reference", "employees", search ?? ""], queryFn: () => getEmployees(search), staleTime: STALE });
export const useEmployee = (employeeId?: string) =>
  useQuery({ queryKey: ["reference", "employee", employeeId], queryFn: () => getEmployee(employeeId!), enabled: Boolean(employeeId) });
export const useLocations = () => useQuery({ queryKey: ["reference", "locations"], queryFn: getLocations, staleTime: STALE });
export const useStorerooms = () => useQuery({ queryKey: ["reference", "storerooms"], queryFn: getStorerooms, staleTime: STALE });
export const useRoleKits = () => useQuery({ queryKey: ["reference", "role-kits"], queryFn: getRoleKits, staleTime: STALE });
export const useSaveRoleKit = () =>
  useApiMutation(({ jobRole, items }: { jobRole: string; items: RoleKitDto["items"] }) => saveRoleKit(jobRole, items), "reference");
