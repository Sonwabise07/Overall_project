import { apiClient } from "@/shared/api/api-client";
import { ApiResponse } from "@/shared/api/api-responses.types";
import { DepartmentDto, EmployeeDto, LocationSummaryDto, RoleKitDto, StoreroomDto } from "./reference.types";

export const getDepartments = async () => (await apiClient.get<ApiResponse<DepartmentDto[]>>("/departments")).data;

export const getEmployees = async (search?: string) =>
  (await apiClient.get<ApiResponse<EmployeeDto[]>>("/employees", { params: { search } })).data;

export const getEmployee = async (employeeId: string) => (await apiClient.get<ApiResponse<EmployeeDto>>(`/employees/${employeeId}`)).data;

export const getLocations = async () => (await apiClient.get<ApiResponse<LocationSummaryDto[]>>("/locations")).data;

export const getStorerooms = async () => (await apiClient.get<ApiResponse<StoreroomDto[]>>("/storerooms")).data;

export const getRoleKits = async () => (await apiClient.get<ApiResponse<RoleKitDto[]>>("/role-kits")).data;

export const saveRoleKit = async (jobRole: string, items: RoleKitDto["items"]) =>
  (await apiClient.put<ApiResponse<RoleKitDto>>(`/role-kits/${encodeURIComponent(jobRole)}`, { items })).data;
