import { useQuery } from "@tanstack/react-query";

import { useApiMutation } from "@/shared/api/api-mutation";
import {
  addMaintenanceLog,
  closeRepair,
  closeWarrantyClaim,
  createMaintenanceCase,
  createWarrantyClaim,
  diagnoseMaintenanceCase,
  getExpiringWarranties,
  getMaintenanceCases,
  getWarrantyClaims,
  recordFaultOutcome,
} from "./maintenance.api";
import {
  CreateMaintenanceCaseRequest,
  CreateMaintenanceLogRequest,
  CreateWarrantyClaimRequest,
  DiagnoseMaintenanceCaseRequest,
  FaultOutcome,
} from "./maintenance.types";

export const useMaintenanceCases = (openOnly = false) =>
  useQuery({ queryKey: ["maintenance", "cases", openOnly], queryFn: () => getMaintenanceCases(openOnly) });
export const useWarrantyClaims = (openOnly = false) =>
  useQuery({ queryKey: ["maintenance", "claims", openOnly], queryFn: () => getWarrantyClaims(openOnly) });
export const useExpiringWarranties = (days = 90) =>
  useQuery({ queryKey: ["maintenance", "expiring", days], queryFn: () => getExpiringWarranties(days) });

export const useCreateMaintenanceCase = () =>
  useApiMutation((payload: CreateMaintenanceCaseRequest) => createMaintenanceCase(payload), "maintenance");
export const useDiagnoseMaintenanceCase = () =>
  useApiMutation(({ caseId, payload }: { caseId: string; payload: DiagnoseMaintenanceCaseRequest }) => diagnoseMaintenanceCase(caseId, payload), "maintenance");
export const useRecordFaultOutcome = () =>
  useApiMutation(({ caseId, outcome, replacementAssetId, notes }: { caseId: string; outcome: FaultOutcome; replacementAssetId?: string; notes?: string }) =>
    recordFaultOutcome(caseId, outcome, replacementAssetId, notes), "maintenance");
export const useCloseRepair = () => useApiMutation((caseId: string) => closeRepair(caseId), "maintenance");
export const useCreateWarrantyClaim = () =>
  useApiMutation((payload: CreateWarrantyClaimRequest) => createWarrantyClaim(payload), "maintenance");
export const useCloseWarrantyClaim = () =>
  useApiMutation(({ claimId, actualReturnDate, outcome }: { claimId: string; actualReturnDate: string; outcome: string }) =>
    closeWarrantyClaim(claimId, actualReturnDate, outcome), "maintenance");
export const useAddMaintenanceLog = () =>
  useApiMutation(({ assetId, payload }: { assetId: string; payload: CreateMaintenanceLogRequest }) => addMaintenanceLog(assetId, payload), "maintenance");
