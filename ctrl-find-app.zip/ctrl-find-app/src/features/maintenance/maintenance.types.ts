import { CaseStatus } from "@/shared/api/api-common.types";

export type FaultClassification = "HardwareFailure" | "AccidentalDamage" | "WearAndTear" | "Unknown";
export type FaultOutcome = "Repair" | "Replace" | "WarrantyClaim" | "Retire";
export type RepairabilityDecision = "Repairable" | "NonRepairable" | "WarrantyClaimRequired" | "PendingVendorAssessment";

export type CreateMaintenanceCaseRequest = {
  assetId: string;
  classification: FaultClassification;
  reportedByEmployeeId: string;
  zendeskTicketId: string;
  description: string;
  reportedAt: string;
};

export type DiagnoseMaintenanceCaseRequest = {
  diagnosis: string;
  repairabilityDecision: RepairabilityDecision;
  estimatedRepairCost?: number;
  notes?: string;
};

export type MaintenanceCaseDto = {
  caseId: string;
  status: CaseStatus;
  assetId: string;
  assetNo?: string | null;
  classification: FaultClassification;
  reportedByEmployeeId: string;
  zendeskTicketId: string;
  description: string;
  reportedAt: string;
  costRecoveryReview: boolean;
  diagnosis?: string | null;
  repairabilityDecision?: RepairabilityDecision | null;
  estimatedRepairCost?: number | null;
  outcome?: FaultOutcome | null;
  replacementAssetId?: string | null;
  closedAt?: string | null;
  assetDescription?: string | null;
};

export type CreateWarrantyClaimRequest = {
  assetId: string;
  maintenanceCaseId: string;
  vendorName: string;
  vendorReference?: string;
  dispatchDate: string;
  expectedReturnDate?: string;
};

export type WarrantyClaimDto = {
  claimId: string;
  assetId: string;
  assetNo?: string | null;
  maintenanceCaseId: string;
  vendorName: string;
  vendorReference?: string | null;
  dispatchDate: string;
  expectedReturnDate?: string | null;
  actualReturnDate?: string | null;
  outcome?: string | null;
  status: CaseStatus;
};

export type WarrantyExpiryDto = {
  assetId: string;
  assetNo: string;
  make?: string | null;
  model?: string | null;
  vendor?: string | null;
  warrantyEnd: string;
  daysLeft: number;
  alertStage: string;
};

export type CreateMaintenanceLogRequest = { lastServiceDate: string; nextDueDate?: string; serviceProvider: string; notes?: string };
