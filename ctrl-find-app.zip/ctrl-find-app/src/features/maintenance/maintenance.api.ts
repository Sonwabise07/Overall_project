import { apiClient } from "@/shared/api/api-client";
import { ApiResponse } from "@/shared/api/api-responses.types";
import {
  CreateMaintenanceCaseRequest,
  CreateMaintenanceLogRequest,
  CreateWarrantyClaimRequest,
  DiagnoseMaintenanceCaseRequest,
  FaultOutcome,
  MaintenanceCaseDto,
  WarrantyClaimDto,
  WarrantyExpiryDto,
} from "./maintenance.types";

type CaseEnvelope = ApiResponse<MaintenanceCaseDto>;

export const getMaintenanceCases = async (openOnly = false) =>
  (await apiClient.get<ApiResponse<MaintenanceCaseDto[]>>("/maintenance-cases", { params: { openOnly } })).data;

export const createMaintenanceCase = async (payload: CreateMaintenanceCaseRequest) =>
  (await apiClient.post<CaseEnvelope>("/maintenance-cases", payload)).data;

export const diagnoseMaintenanceCase = async (caseId: string, payload: DiagnoseMaintenanceCaseRequest) =>
  (await apiClient.post<CaseEnvelope>(`/maintenance-cases/${caseId}/diagnose`, payload)).data;

export const recordFaultOutcome = async (caseId: string, outcome: FaultOutcome, replacementAssetId?: string, notes?: string) =>
  (await apiClient.post<CaseEnvelope>(`/maintenance-cases/${caseId}/outcome`, { outcome, replacementAssetId, notes })).data;

export const closeRepair = async (caseId: string) => (await apiClient.post<CaseEnvelope>(`/maintenance-cases/${caseId}/close`)).data;

export const getWarrantyClaims = async (openOnly = false) =>
  (await apiClient.get<ApiResponse<WarrantyClaimDto[]>>("/warranty-claims", { params: { openOnly } })).data;

export const createWarrantyClaim = async (payload: CreateWarrantyClaimRequest) =>
  (await apiClient.post<ApiResponse<WarrantyClaimDto>>("/warranty-claims", payload)).data;

export const closeWarrantyClaim = async (claimId: string, actualReturnDate: string, outcome: string) =>
  (await apiClient.post<ApiResponse<WarrantyClaimDto>>(`/warranty-claims/${claimId}/close`, { actualReturnDate, outcome })).data;

export const getExpiringWarranties = async (days = 90) =>
  (await apiClient.get<ApiResponse<WarrantyExpiryDto[]>>("/warranty/expiring", { params: { days } })).data;

export const addMaintenanceLog = async (assetId: string, payload: CreateMaintenanceLogRequest) =>
  (await apiClient.post(`/assets/${assetId}/maintenance-log`, payload)).data;
