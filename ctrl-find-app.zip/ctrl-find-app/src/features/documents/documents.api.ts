import { Linking, Platform } from "react-native";

import { apiClient } from "@/shared/api/api-client";
import { API_URL } from "@/shared/api/api-config";
import { ApiResponse } from "@/shared/api/api-responses.types";
import { DocumentReferenceDto, DocumentType, PickedFile } from "./documents.types";

export const getAssetDocuments = async (assetId: string) =>
  (await apiClient.get<ApiResponse<DocumentReferenceDto[]>>(`/assets/${assetId}/documents`)).data;

export const uploadAssetDocument = async (assetId: string, picked: PickedFile, documentType: DocumentType, description?: string) => {
  const form = new FormData();
  if (Platform.OS === "web" && picked.file) {
    form.append("file", picked.file, picked.name);
  } else {
    // React Native's FormData accepts { uri, name, type } for files.
    form.append("file", { uri: picked.uri, name: picked.name, type: picked.mimeType } as unknown as Blob);
  }
  form.append("documentType", documentType);
  if (description) form.append("description", description);
  form.append("capturedAt", new Date().toISOString());

  return (await apiClient.post<ApiResponse<DocumentReferenceDto>>(`/assets/${assetId}/documents`, form, {
    headers: { "Content-Type": "multipart/form-data" },
  })).data;
};

// Download URLs from the API are relative; images and links need the full address.
export const absoluteDocumentUrl = (downloadUrl: string) => `${API_URL}${downloadUrl}`;

// Downloads need the bearer token, so on web the file is fetched first and opened (or saved as fileName) from memory.
// Native builds hand the address to the system browser (see the app's docs/DECISIONS.md).
export async function openDocument(downloadUrl: string, fileName?: string) {
  if (Platform.OS !== "web") return Linking.openURL(absoluteDocumentUrl(downloadUrl));
  const response = await apiClient.get(downloadUrl.replace("/api/v1", ""), { responseType: "blob" });
  const objectUrl = URL.createObjectURL(response.data as Blob);
  if (fileName) {
    const link = document.createElement("a");
    link.href = objectUrl;
    link.download = fileName;
    link.click();
  } else {
    window.open(objectUrl, "_blank");
  }
  setTimeout(() => URL.revokeObjectURL(objectUrl), 60_000);
}
