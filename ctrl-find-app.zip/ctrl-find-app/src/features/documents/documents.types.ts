export type DocumentType = "CustodyAgreement" | "Invoice" | "Warranty" | "ReturnForm" | "PoliceReport" | "Photo" | "DataWipeCertificate" | "Other";

export type DocumentReferenceDto = {
  documentId: string;
  documentType: DocumentType;
  fileName: string;
  contentType: string;
  fileSizeBytes: number;
  uploadedAt: string;
  uploadedByUserId: string;
  downloadUrl: string;
  description?: string | null;
  capturedAt?: string | null;
};

// A file chosen with the image picker (native) or the browser (web).
export type PickedFile = { uri: string; name: string; mimeType: string; file?: File };
