import { useQuery } from "@tanstack/react-query";

import { useApiMutation } from "@/shared/api/api-mutation";
import { getAssetDocuments, uploadAssetDocument } from "./documents.api";
import { DocumentType, PickedFile } from "./documents.types";

export const useAssetDocuments = (assetId?: string) =>
  useQuery({ queryKey: ["assets", assetId, "documents"], queryFn: () => getAssetDocuments(assetId!), enabled: Boolean(assetId) });

export const useUploadAssetDocument = () =>
  useApiMutation(({ assetId, file, documentType, description }: { assetId: string; file: PickedFile; documentType: DocumentType; description?: string }) =>
    uploadAssetDocument(assetId, file, documentType, description));
