import { apiClient } from "@/shared/api/api-client";
import { ApiResponse } from "@/shared/api/api-responses.types";
import { CreateEmergencySwapRequest, EmergencySwapDto } from "./emergency-swaps.types";

export const getEmergencySwaps = async () => (await apiClient.get<ApiResponse<EmergencySwapDto[]>>("/emergency-swaps")).data;

export const createEmergencySwap = async (payload: CreateEmergencySwapRequest) =>
  (await apiClient.post<ApiResponse<EmergencySwapDto>>("/emergency-swaps", payload)).data;

export const resolveEmergencySwap = async (swapId: string, resolution: string) =>
  (await apiClient.post<ApiResponse<EmergencySwapDto>>(`/emergency-swaps/${swapId}/resolve`, { resolution })).data;
