import { useQuery } from "@tanstack/react-query";

import { useApiMutation } from "@/shared/api/api-mutation";
import { createEmergencySwap, getEmergencySwaps, resolveEmergencySwap } from "./emergency-swaps.api";
import { CreateEmergencySwapRequest } from "./emergency-swaps.types";

export const useEmergencySwaps = () => useQuery({ queryKey: ["emergency-swaps"], queryFn: getEmergencySwaps });

export const useCreateEmergencySwap = () =>
  useApiMutation((payload: CreateEmergencySwapRequest) => createEmergencySwap(payload), "emergency-swaps");
export const useResolveEmergencySwap = () =>
  useApiMutation(({ swapId, resolution }: { swapId: string; resolution: string }) => resolveEmergencySwap(swapId, resolution), "emergency-swaps");
