import { CaseStatus } from "@/shared/api/api-common.types";

export type EmergencySwapDto = {
  swapId: string;
  employeeId: string;
  employeeName?: string | null;
  originalAssetId?: string | null;
  temporaryAssetId: string;
  temporaryAssetNo?: string | null;
  issueDescription: string;
  reportedAt: string;
  resolveBy: string;
  status: CaseStatus;
  isEscalated: boolean;
  resolution?: string | null;
  resolvedAt?: string | null;
  fixedAssetsNotified: boolean;
};

export type CreateEmergencySwapRequest = {
  employeeId: string;
  originalAssetId?: string;
  temporaryAssetId: string;
  issueDescription: string;
  reportedAt: string;
  custodyAgreementDocumentId?: string;
};
