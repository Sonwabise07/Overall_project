import { useQuery } from "@tanstack/react-query";

import { getManagementDashboard, getOperationalDashboard, getPowerBiDatasets } from "./reporting.api";

export const useOperationalDashboard = (enabled = true) =>
  useQuery({ queryKey: ["reports", "operational"], queryFn: getOperationalDashboard, enabled });
export const useManagementDashboard = (enabled = true) =>
  useQuery({ queryKey: ["reports", "management"], queryFn: getManagementDashboard, enabled });
export const usePowerBiDatasets = (enabled = true) =>
  useQuery({ queryKey: ["reports", "powerbi"], queryFn: getPowerBiDatasets, enabled });
