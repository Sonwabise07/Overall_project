import { apiClient } from "@/shared/api/api-client";
import { ApiResponse } from "@/shared/api/api-responses.types";
import { ManagementDashboardDto, OperationalDashboardDto, PowerBiDataset } from "./reporting.types";

export const getOperationalDashboard = async () =>
  (await apiClient.get<ApiResponse<OperationalDashboardDto>>("/reports/operational-dashboard")).data;

export const getManagementDashboard = async () =>
  (await apiClient.get<ApiResponse<ManagementDashboardDto>>("/reports/management-dashboard")).data;

export const getPowerBiDatasets = async () =>
  (await apiClient.post<ApiResponse<{ datasets: PowerBiDataset[] }>>("/exports/powerbi")).data;
