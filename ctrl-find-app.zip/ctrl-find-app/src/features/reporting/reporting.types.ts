import { StockTypeSummaryDto } from "@/features/stock/stock.types";

export type CountByLabel = { label: string; count: number };
export type RiskDistribution = { high: number; medium: number; low: number; total: number };
export type TrendPoint = { period: string; value: number };

export type OperationalDashboardDto = {
  totalAssets: number;
  addedThisMonth: number;
  flaggedForAudit: number;
  assetsAtHome: number;
  overdueWarrantyOrMaintenance: number;
  byOperationalStatus: CountByLabel[];
  byAssetType: CountByLabel[];
  stockLevels: StockTypeSummaryDto[];
  onboarding: { openCases: number; kitsFullyReserved: number; shortNotice: number; withShortfall: number };
  offboarding: { openCases: number; completedThisMonth: number; laptopRecoveriesOutstanding: number };
  openIncidents: number;
  lossExposure: number;
  warrantyAlerts: number;
  activeWarrantyClaims: number;
  openRepairs: number;
  openAuditDiscrepancies: number;
  resolvedAuditDiscrepancies: number;
  utilisationPercent: number;
  auditRisk: RiskDistribution;
  recentActivity: { assetId: string; assetNo: string; assetDescription?: string | null; event: string; summary?: string | null; employee?: string | null; at: string }[];
};

export type ManagementDashboardDto = {
  risk: RiskDistribution;
  incidentTrend: TrendPoint[];
  confirmationComplianceTrend: TrendPoint[];
  incidentsByEmployee: CountByLabel[];
  incidentsByLocation: CountByLabel[];
  incidentsByAssetType: CountByLabel[];
  totalAssetValue: number;
  lostOrStolenValue: number;
  openAodValue: number;
  recoveredAodValue: number;
  employeesWithRepeatIncidents: number;
  laptopsOffSite: number;
  flaggedItems: { assetId: string; assetNo: string; assetDescription?: string | null; reason: string; photoUrl?: string | null }[];
};

export type PowerBiDataset = { name: string; url: string };
