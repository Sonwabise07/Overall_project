import { useQuery } from "@tanstack/react-query";

import { useApiMutation } from "@/shared/api/api-mutation";
import { getTakeHomes, issueTakeHome, resolveDamageReview, returnTakeHome } from "./take-home.api";
import { TakeHomeIssueRequest, TakeHomeReturnRequest } from "./take-home.types";

export const useTakeHomes = () => useQuery({ queryKey: ["take-home"], queryFn: getTakeHomes });

export const useIssueTakeHome = () => useApiMutation((payload: TakeHomeIssueRequest) => issueTakeHome(payload), "take-home");
export const useReturnTakeHome = () =>
  useApiMutation(({ takeHomeId, payload }: { takeHomeId: string; payload: TakeHomeReturnRequest }) => returnTakeHome(takeHomeId, payload), "take-home");
export const useResolveDamageReview = () =>
  useApiMutation(({ takeHomeId, outcome }: { takeHomeId: string; outcome: string }) => resolveDamageReview(takeHomeId, outcome), "take-home");
