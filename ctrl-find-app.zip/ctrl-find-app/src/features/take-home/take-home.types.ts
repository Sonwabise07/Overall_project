import { ConditionStatus } from "@/shared/api/api-common.types";

export type TakeHomeDto = {
  takeHomeId: string;
  assetId: string;
  assetNo?: string | null;
  assetDescription?: string | null;
  employeeId: string;
  employeeName?: string | null;
  issuedAt: string;
  issueCondition: ConditionStatus;
  issuePhotoDocumentId: string;
  acknowledgedAt: string;
  returnedAt?: string | null;
  returnCondition?: ConditionStatus | null;
  returnPhotoDocumentId?: string | null;
  damageReviewRequired: boolean;
  damageReviewOutcome?: string | null;
  status: "AtHome" | "DamageReview" | "Returned";
};

export type TakeHomeIssueRequest = {
  assetId: string;
  employeeId: string;
  issuePhotoDocumentId: string;
  issueCondition: ConditionStatus;
  employeeAcknowledged: boolean;
  notes?: string;
};

export type TakeHomeReturnRequest = { returnPhotoDocumentId: string; returnCondition: ConditionStatus; notes?: string };
