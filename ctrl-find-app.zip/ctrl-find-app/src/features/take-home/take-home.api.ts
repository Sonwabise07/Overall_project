import { apiClient } from "@/shared/api/api-client";
import { ApiResponse } from "@/shared/api/api-responses.types";
import { TakeHomeDto, TakeHomeIssueRequest, TakeHomeReturnRequest } from "./take-home.types";

type Envelope = ApiResponse<TakeHomeDto>;

export const getTakeHomes = async () => (await apiClient.get<ApiResponse<TakeHomeDto[]>>("/take-home")).data;

export const issueTakeHome = async (payload: TakeHomeIssueRequest) => (await apiClient.post<Envelope>("/take-home/issue", payload)).data;

export const returnTakeHome = async (takeHomeId: string, payload: TakeHomeReturnRequest) =>
  (await apiClient.post<Envelope>(`/take-home/${takeHomeId}/return`, payload)).data;

export const resolveDamageReview = async (takeHomeId: string, outcome: string) =>
  (await apiClient.post<Envelope>(`/take-home/${takeHomeId}/damage-review`, { outcome })).data;
