import { apiClient } from "@/shared/api/api-client";
import { ConditionStatus } from "@/shared/api/api-common.types";
import { ApiResponse } from "@/shared/api/api-responses.types";
import { AuditDto, AuditItemDto, AuditScanRequest, CreateAuditRequest } from "./audits.types";

type AuditEnvelope = ApiResponse<AuditDto>;
type ItemEnvelope = ApiResponse<AuditItemDto>;

export const getAudits = async () => (await apiClient.get<ApiResponse<AuditDto[]>>("/audits")).data;

export const createAudit = async (payload: CreateAuditRequest) => (await apiClient.post<AuditEnvelope>("/audits", payload)).data;

export const scanAuditAsset = async (auditId: string, payload: AuditScanRequest) =>
  (await apiClient.post<ItemEnvelope>(`/audits/${auditId}/scan`, payload)).data;

export const sendAuditSelfConfirmations = async (auditId: string) =>
  (await apiClient.post<AuditEnvelope>(`/audits/${auditId}/self-confirmations`)).data;

export const resolveAuditItem = async (auditId: string, itemId: string, resolution: string) =>
  (await apiClient.post<ItemEnvelope>(`/audits/${auditId}/items/${itemId}/resolve`, { resolution })).data;

export const closeAudit = async (auditId: string) => (await apiClient.post<AuditEnvelope>(`/audits/${auditId}/close`)).data;

export const getMySelfConfirmations = async () => (await apiClient.get<ApiResponse<AuditItemDto[]>>("/self-confirmations")).data;

export const confirmAuditItem = async (auditId: string, itemId: string, serialNumber: string, conditionStatus: ConditionStatus) =>
  (await apiClient.post<ItemEnvelope>(`/audits/${auditId}/items/${itemId}/confirm`, { serialNumber, conditionStatus })).data;
