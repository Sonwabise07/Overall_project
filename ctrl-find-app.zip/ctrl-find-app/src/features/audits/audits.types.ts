import { AssetType, AuditOutcome, ConditionStatus } from "@/shared/api/api-common.types";

export type AuditStatus = "Draft" | "Scheduled" | "InProgress" | "UnderReview" | "Closed" | "Cancelled";

export type CreateAuditRequest = {
  auditName: string;
  locationIds?: string[];
  departmentIds?: string[];
  assetTypes?: AssetType[];
  scheduledStartDate: string;
  scheduledEndDate: string;
  notes?: string;
  fullScope?: boolean;
};

export type AuditScanRequest = {
  assetTag: string;
  serialNumber: string;
  scannedLocationId: string;
  conditionStatus: ConditionStatus;
  scannedAt: string;
  notes?: string;
};

export type AuditItemDto = {
  auditItemId: string;
  assetId?: string | null;
  outcome?: AuditOutcome | null;
  serialMismatch: boolean;
  locationMismatch: boolean;
  requiresInvestigation: boolean;
  message: string;
  assetNo?: string | null;
  method: "PhysicalScan" | "SelfConfirmation";
  reasonFlagged?: string | null;
  resolved: boolean;
  resolution?: string | null;
  auditId?: string | null;
};

export type AuditDto = {
  auditId: string;
  status: AuditStatus;
  request: CreateAuditRequest;
  items: AuditItemDto[];
  selfConfirmationsSent: boolean;
  openInvestigations: number;
  openDiscrepancies: number;
};
