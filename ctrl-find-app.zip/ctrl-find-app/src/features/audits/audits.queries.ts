import { useQuery } from "@tanstack/react-query";

import { ConditionStatus } from "@/shared/api/api-common.types";
import { useApiMutation } from "@/shared/api/api-mutation";
import {
  closeAudit,
  confirmAuditItem,
  createAudit,
  getAudits,
  getMySelfConfirmations,
  resolveAuditItem,
  scanAuditAsset,
  sendAuditSelfConfirmations,
} from "./audits.api";
import { AuditScanRequest, CreateAuditRequest } from "./audits.types";

export const useAudits = (enabled = true) => useQuery({ queryKey: ["audits"], queryFn: getAudits, enabled });
export const useMySelfConfirmations = () => useQuery({ queryKey: ["audits", "mine"], queryFn: getMySelfConfirmations });

export const useCreateAudit = () => useApiMutation((payload: CreateAuditRequest) => createAudit(payload), "audits");
export const useScanAuditAsset = () =>
  useApiMutation(({ auditId, payload }: { auditId: string; payload: AuditScanRequest }) => scanAuditAsset(auditId, payload), "audits");
export const useSendAuditSelfConfirmations = () => useApiMutation((auditId: string) => sendAuditSelfConfirmations(auditId), "audits");
export const useResolveAuditItem = () =>
  useApiMutation(({ auditId, itemId, resolution }: { auditId: string; itemId: string; resolution: string }) => resolveAuditItem(auditId, itemId, resolution), "audits");
export const useCloseAudit = () => useApiMutation((auditId: string) => closeAudit(auditId), "audits");
export const useConfirmAuditItem = () =>
  useApiMutation(({ auditId, itemId, serialNumber, conditionStatus }: { auditId: string; itemId: string; serialNumber: string; conditionStatus: ConditionStatus }) =>
    confirmAuditItem(auditId, itemId, serialNumber, conditionStatus), "audits");
