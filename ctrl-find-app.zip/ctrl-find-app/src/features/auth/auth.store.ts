import { useSyncExternalStore } from "react";
import { Platform } from "react-native";
import { create } from "zustand";
import { createJSONStorage, persist, StateStorage } from "zustand/middleware";

import { UserProfileDto } from "./auth.types";

type AuthState = {
  accessToken?: string;
  refreshToken?: string;
  user?: UserProfileDto;
  signIn: (accessToken: string, refreshToken: string, user: UserProfileDto) => void;
  setTokens: (accessToken: string, refreshToken: string) => void;
  signOut: () => void;
};

// The web build keeps the session in localStorage; native keeps it in memory until secure storage is added.
const memory = new Map<string, string>();
const memoryStorage: StateStorage = {
  getItem: (key) => memory.get(key) ?? null,
  setItem: (key, value) => void memory.set(key, value),
  removeItem: (key) => void memory.delete(key),
};

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      signIn: (accessToken, refreshToken, user) => set({ accessToken, refreshToken, user }),
      setTokens: (accessToken, refreshToken) => set({ accessToken, refreshToken }),
      signOut: () => set({ accessToken: undefined, refreshToken: undefined, user: undefined }),
    }),
    {
      name: "asset-hub-session",
      storage: createJSONStorage(() => (Platform.OS === "web" && typeof window !== "undefined" ? window.localStorage : memoryStorage)),
      partialize: ({ accessToken, refreshToken, user }) => ({ accessToken, refreshToken, user }),
    },
  ),
);

// True once the stored session has been read. Web pages are pre-rendered without it (server snapshot false),
// so the guarded routes wait for this; otherwise a deep link would be redirected before the session loads.
export const useAuthHydrated = () =>
  useSyncExternalStore(useAuthStore.persist.onFinishHydration, useAuthStore.persist.hasHydrated, () => false);
