import { useAuthStore } from "./auth.store";

// Role names from BRD Section 5; they match the API's role claims.
export const Roles = {
  Employee: "Employee",
  Manager: "Manager",
  OfficeManager: "Office/Building Manager",
  FixedAssets: "Fixed Assets",
  HelpDesk: "IT Help Desk",
  Hr: "HR",
  Finance: "Finance / CFO",
  Administrator: "Administrator",
} as const;

export type Role = (typeof Roles)[keyof typeof Roles];

export const AssetOperators: Role[] = [Roles.FixedAssets, Roles.OfficeManager, Roles.Administrator];
export const Management: Role[] = [Roles.Manager, Roles.OfficeManager, Roles.FixedAssets, Roles.Hr, Roles.Finance, Roles.Administrator];

export function useHasRole(...roles: Role[]): boolean {
  const userRoles = useAuthStore((state) => state.user?.roles);
  return roles.length === 0 || roles.some((role) => userRoles?.includes(role));
}

// The most senior role, shown under the user's name.
export function primaryRole(roles: string[] | undefined): string {
  const order: Role[] = [Roles.Administrator, Roles.FixedAssets, Roles.Finance, Roles.Hr, Roles.OfficeManager, Roles.Manager, Roles.HelpDesk, Roles.Employee];
  return order.find((role) => roles?.includes(role)) ?? "Employee";
}
