import { ApiResponse } from "@/shared/api/api-responses.types";

export type LoginRequest = {
  username: string;
  password: string;
  rememberMe?: boolean;
};

export type UserProfileDto = {
  userId: string;
  employeeId: string;
  displayName: string;
  email: string;
  roles: string[];
  departmentIds: string[];
  locationIds: string[];
};

export type TokenDto = {
  accessToken: string;
  tokenType: string;
  expiresIn: number;
  refreshToken: string;
  refreshTokenExpiresAt: string;
  user?: UserProfileDto | null;
};

export type LoginResponse = ApiResponse<TokenDto>;
