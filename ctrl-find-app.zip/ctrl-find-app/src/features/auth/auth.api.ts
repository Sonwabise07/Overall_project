import { apiClient } from "@/shared/api/api-client";
import { LoginRequest, LoginResponse } from "./auth.types";

export const login = async (payload: LoginRequest): Promise<LoginResponse> =>
  (await apiClient.post<LoginResponse>("/auth/login", payload)).data;

export const logout = async (refreshToken?: string): Promise<void> => {
  await apiClient.post<void>("/auth/logout", { refreshToken });
};

