import { useMutation, useQueryClient } from "@tanstack/react-query";
import { AxiosError } from "axios";

import { login, logout } from "./auth.api";
import { useAuthStore } from "./auth.store";
import { LoginRequest, LoginResponse } from "./auth.types";

export const useLogin = () =>
  useMutation<LoginResponse, AxiosError, LoginRequest>({
    mutationFn: login,
    onSuccess: ({ data }) => {
      if (data.user) useAuthStore.getState().signIn(data.accessToken, data.refreshToken, data.user);
    },
  });

export const useLogout = () => {
  const queryClient = useQueryClient();
  return useMutation<void, AxiosError, void>({
    mutationFn: () => logout(useAuthStore.getState().refreshToken),
    onSettled: () => {
      useAuthStore.getState().signOut();
      queryClient.clear();
    },
  });
};

