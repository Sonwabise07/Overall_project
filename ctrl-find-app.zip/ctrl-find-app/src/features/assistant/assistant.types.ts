import { AssetType } from "@/shared/api/api-common.types";

export type AssistantTable = { columns: string[]; rows: (string | null)[][]; totalRows: number };
export type AssistantChart = { type: "bar" | "line"; title: string; valueLabel: string; points: { label: string; value: number }[] };

export type AssistantAnswerDto = {
  answer: string;
  sources: { sourceType: string; sourceId: string; label: string }[];
  unsupported: boolean;
  intent?: string | null;
  table?: AssistantTable | null;
  chart?: AssistantChart | null;
  suggestions?: string[] | null;
  conversationId?: string | null;
  evidence?: string | null;
  messageId?: string | null;
};

export type AssistantQueryRequest = {
  question: string;
  conversationId?: string;
  saveHistory?: boolean;
  context?: { departmentIds?: string[]; locationIds?: string[]; assetTypes?: AssetType[] };
};

export type AssistantQuestionType = { name: string; description: string; examples: string[] };
export type AssistantConversationSummary = { conversationId: string; title: string; updatedAt: string };
export type AssistantConversation = {
  conversationId: string;
  title: string;
  messages: { role: "user" | "assistant"; content: string; response?: AssistantAnswerDto | null; createdAt: string }[];
};
