import { apiClient } from "@/shared/api/api-client";
import { ApiResponse } from "@/shared/api/api-responses.types";
import {
  AssistantAnswerDto,
  AssistantConversation,
  AssistantConversationSummary,
  AssistantQueryRequest,
  AssistantQuestionType,
} from "./assistant.types";

// Answers can take a little longer than a normal read, so the timeout is extended.
export const askAssistant = async (payload: AssistantQueryRequest) =>
  (await apiClient.post<ApiResponse<AssistantAnswerDto>>("/assistant/query", payload, { timeout: 30_000 })).data;

export const getAssistantCatalog = async () => (await apiClient.get<ApiResponse<AssistantQuestionType[]>>("/assistant/catalog")).data;

export const getAssistantConversations = async () =>
  (await apiClient.get<ApiResponse<AssistantConversationSummary[]>>("/assistant/conversations")).data;

export const getAssistantConversation = async (conversationId: string) =>
  (await apiClient.get<ApiResponse<AssistantConversation>>(`/assistant/conversations/${conversationId}`)).data;

export const deleteAssistantConversation = async (conversationId: string) =>
  (await apiClient.delete(`/assistant/conversations/${conversationId}`)).data;

export const sendAssistantFeedback = async (messageId: string, helpful: boolean) =>
  (await apiClient.post("/assistant/feedback", { messageId, helpful })).data;
