import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AxiosError } from "axios";

import {
  askAssistant,
  deleteAssistantConversation,
  getAssistantCatalog,
  getAssistantConversation,
  getAssistantConversations,
  sendAssistantFeedback,
} from "./assistant.api";
import { AssistantQueryRequest } from "./assistant.types";

export const useAssistantCatalog = () =>
  useQuery({ queryKey: ["assistant", "catalog"], queryFn: getAssistantCatalog, staleTime: Infinity });

export const useAssistantConversations = () => useQuery({ queryKey: ["assistant", "conversations"], queryFn: getAssistantConversations });

export const useAskAssistant = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload: AssistantQueryRequest) => askAssistant(payload),
    onSuccess: (_data, payload) => {
      if (payload.saveHistory) queryClient.invalidateQueries({ queryKey: ["assistant", "conversations"] });
    },
  });
};

// Loaded on demand when a saved conversation is reopened.
export const useOpenAssistantConversation = () =>
  useMutation<Awaited<ReturnType<typeof getAssistantConversation>>, AxiosError, string>({ mutationFn: getAssistantConversation });

export const useDeleteAssistantConversation = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (conversationId: string) => deleteAssistantConversation(conversationId),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["assistant", "conversations"] }),
  });
};

export const useAssistantFeedback = () =>
  useMutation({ mutationFn: ({ messageId, helpful }: { messageId: string; helpful: boolean }) => sendAssistantFeedback(messageId, helpful) });
