export const prettyFieldNames: Record<string, string> = {
  id: "ID",

  // User
  user_id: "User ID",
  userId: "User ID",
  name: "Name",
  surname: "Surname",
  displayName: "Display Name",
  email: "Email Address",
  role: "Role",
  roles: "Roles",

  // Auth
  accessToken: "Access Token",
  tokenType: "Token Type",
  expiresIn: "Expires In",
  refreshToken: "Refresh Token",
  refreshTokenExpiresAt: "Refresh Token Expiry",

  // Employee
  employeeId: "Employee ID",
  employmentStatus: "Employment Status",
  managerEmployeeId: "Manager Employee ID",

  // Department
  departmentId: "Department ID",
  departmentIds: "Department IDs",
  department: "Department",

  // Location
  locationId: "Location ID",
  locationIds: "Location IDs",
  region: "Region",
  building: "Building",
  floor: "Floor",
  desk: "Desk",
  locationSummary: "Location Summary",
  subStatus: "Sub Status",

  // Storeroom
  storeroomId: "Storeroom ID",

  // Asset
  assetId: "Asset ID",
  assetNo: "Asset Number",
  assetTag: "Asset Tag",
  assetType: "Asset Type",
  assetTypes: "Asset Types",
  serialNumber: "Serial Number",
  category: "Category",
  make: "Manufacturer",
  model: "Model",
  companyEntity: "Company Entity",
  costCentre: "Cost Centre",

  // Assignment
  assignmentId: "Assignment ID",
  assignmentDate: "Assignment Date",
  assignedAt: "Assigned At",
  unassignedAt: "Unassigned At",
  assignedEmployeeId: "Assigned Employee ID",
  assignedEmployeeName: "Assigned Employee Name",
  employeeName: "Employee Name",

  // Status
  lifecycleState: "Lifecycle State",
  operationalStatus: "Operational Status",
  status: "Status",

  // Audit
  auditId: "Audit ID",
  auditItemId: "Audit Item ID",
  auditName: "Audit Name",
  auditOutcome: "Audit Outcome",
  lastAuditDate: "Last Audit Date",
  scannedAt: "Scanned At",
  scannedByUserId: "Scanned By User ID",
  scannedLocationId: "Scanned Location ID",
  scannedCount: "Scanned Count",
  totalAssetsInScope: "Total Assets in Scope",
  discrepancyCount: "Discrepancy Count",
  openInvestigationCount: "Open Investigation Count",
  serialMismatch: "Serial Mismatch",
  locationMismatch: "Location Mismatch",
  requiresInvestigation: "Requires Investigation",
  conditionStatus: "Condition Status",
  outcome: "Outcome",
  message: "Message",

  // Financial
  purchaseCost: "Purchase Cost",
  purchaseOrder: "Purchase Order",
  invoiceReference: "Invoice Reference",
  totalPurchaseCost: "Total Purchase Cost",
  currency: "Currency",

  // Lifecycle / Warranty
  acquisitionDate: "Acquisition Date",
  warrantyStart: "Warranty Start",
  warrantyEnd: "Warranty End",

  // Documents
  documentId: "Document ID",
  documentIds: "Document IDs",
  documentType: "Document Type",
  custodyAgreementId: "Custody Agreement ID",
  custodyAgreementDocumentId: "Custody Agreement Document ID",
  fileName: "File Name",
  contentType: "Content Type",
  fileSizeBytes: "File Size (Bytes)",
  downloadUrl: "Download URL",
  uploadedAt: "Uploaded At",
  uploadedByUserId: "Uploaded By User ID",

  // History
  historyId: "History ID",
  timestamp: "Timestamp",
  action: "Action",
  performedByUserId: "Performed By User ID",
  changes: "Changes",

  // Transfers
  transferId: "Transfer ID",
  transferType: "Transfer Type",
  fromEmployeeId: "From Employee ID",
  toEmployeeId: "To Employee ID",
  fromLocationId: "From Location ID",
  toLocationId: "To Location ID",
  requestedByUserId: "Requested By User ID",
  requestedAt: "Requested At",

  // Holds
  holdId: "Hold ID",
  holdDurationDays: "Hold Duration (Days)",
  heldAt: "Held At",
  expiresAt: "Expires At",
  reason: "Reason",

  // Onboarding
  caseId: "Case ID",
  roleKitId: "Role Kit ID",
  startDate: "Start Date",
  readinessState: "Readiness State",
  requiredAssetTypes: "Required Asset Types",
  reservedAssets: "Reserved Assets",
  reservationId: "Reservation ID",
  blockingItems: "Blocking Items",

  // Offboarding
  exitDate: "Exit Date",
  source: "Source",
  items: "Items",
  resolution: "Resolution",
  resolvedAt: "Resolved At",
  canComplete: "Can Complete",
  blockingReasons: "Blocking Reasons",

  // Stock
  stockState: "Stock State",
  reservedForId: "Reserved For ID",
  reservedForType: "Reserved For Type",
  quantity: "Quantity",
  requiredByDate: "Required By Date",
  createdAt: "Created At",
  currentAvailableCount: "Available Count",
  minimumThreshold: "Minimum Threshold",
  countedByUserId: "Counted By User ID",
  countedAt: "Counted At",
  countedQuantity: "Counted Quantity",
  expectedQuantity: "Expected Quantity",
  variance: "Variance",
  scannedAssetTags: "Scanned Asset Tags",
  notes: "Notes",

  // Maintenance
  maintenanceCaseId: "Maintenance Case ID",
  maintenanceType: "Maintenance Type",
  reportedByEmployeeId: "Reported By Employee ID",
  reportedAt: "Reported At",
  zendeskTicketId: "Zendesk Ticket ID",
  description: "Description",
  diagnosis: "Diagnosis",
  repairabilityDecision: "Repairability Decision",
  estimatedRepairCost: "Estimated Repair Cost",
  requiresReplacement: "Requires Replacement",

  // Warranty Claims
  warrantyClaimId: "Warranty Claim ID",
  vendorName: "Vendor Name",
  vendorReference: "Vendor Reference",
  claimDate: "Claim Date",
  supportingDocumentIds: "Supporting Documents",

  // Incidents
  incidentId: "Incident ID",
  incidentType: "Incident Type",
  negligenceStatus: "Negligence Status",
  incidentDate: "Incident Date",
  locationDescription: "Location Description",
  policeCaseNumber: "Police Case Number",
  aodId: "AOD ID",

  // AOD
  amount: "Amount",
  recoveryTerms: "Recovery Terms",

  // Dashboard
  available: "Available",
  reserved: "Reserved",
  damaged: "Damaged",
  healthy: "Healthy",
  pendingTransfers: "Pending Transfers",
  openOnboardingCases: "Open Onboarding Cases",
  openOffboardingCases: "Open Offboarding Cases",
  openMaintenanceCases: "Open Maintenance Cases",
  assetsInRepair: "Assets In Repair",
  next30Days: "Next 30 Days",
  next90Days: "Next 90 Days",
  expired: "Expired",

  // Management Dashboard
  totalAssets: "Total Assets",
  count: "Count",
  aging: "Asset Ageing",
  bucket: "Age Bucket",
  month: "Month",
  loss: "Losses",
  theft: "Theft",
  damage: "Damage",
  auditedLast90DaysPercent: "Audited Last 90 Days (%)",
  openDiscrepancies: "Open Discrepancies",
  openInvestigations: "Open Investigations",

  // Power BI
  exportId: "Export ID",
  feedUrl: "Feed URL",
  datasets: "Datasets",
  generatedAt: "Generated At",

  // Assistant
  answer: "Answer",
  sources: "Sources",
  sourceType: "Source Type",
  sourceId: "Source ID",
  label: "Label",
  unsupported: "Unsupported",

  // Error Responses
  httpStatus: "HTTP Status",
  error: "Error",
  code: "Error Code",
  details: "Details",
  field: "Field",
  issue: "Issue",
  traceId: "Trace ID",

  // Meta
  correlationId: "Correlation ID",
  meta: "Metadata",
  data: "Data",
} as const;

export const prettify = (value: string) =>
  value
    .replace(/([A-Z])/g, " $1")
    .replace(/_/g, " ")
    .replace(/\b\w/g, (char) => char.toUpperCase())
    .trim();

export const getPrettyLabel = (key: string) =>
  prettyFieldNames[key] ?? prettify(key);
