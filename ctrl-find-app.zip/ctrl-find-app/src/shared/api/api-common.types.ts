// Date and date-time values are ISO 8601 strings. Enumerations match the API (docs/DECISIONS.md in the API repo).

export type AssetType =
  | "Laptop"
  | "Desktop"
  | "Monitor"
  | "MobileDevice"
  | "Peripheral"
  | "NetworkEquipment"
  | "Printer"
  | "Other"
  | "DockingStation"
  | "Tablet"
  | "Keyboard"
  | "Headset";

export type LifecycleState =
  | "Ordered"
  | "Received"
  | "Registered"
  | "InStorage"
  | "Reserved"
  | "Assigned"
  | "AtHome"
  | "OffSite"
  | "HeldForReassignment"
  | "UnderAudit"
  | "InRepair"
  | "WarrantyClaim"
  | "Lost"
  | "Stolen"
  | "UnderInvestigation"
  | "Retired"
  | "Disposed"
  | "InterEntityTransfer";

export type OperationalStatus = "InUse" | "InStorage" | "InRepair" | "Retired";

export type LocationSubStatus = "InOffice" | "AtHome";

export type CaseStatus =
  | "Draft"
  | "Open"
  | "PendingApproval"
  | "InProgress"
  | "Blocked"
  | "Completed"
  | "Cancelled"
  | "Declined";

export type ConditionStatus = "New" | "Excellent" | "Good" | "Fair" | "Damaged";

export type AuditOutcome =
  | "Confirmed"
  | "NotFound"
  | "SerialMismatch"
  | "LocationMismatch"
  | "ConditionMismatch"
  | "AwaitingConfirmation"
  | "Unconfirmed";

export type ErrorEnvelope = {
  error: {
    code: string;
    message: string;
    details?: { field?: string | null; issue?: string }[];
    traceId?: string;
  };
};

export type LocationDto = {
  locationId: string;
  region: string;
  building: string;
  floor?: string | null;
  departmentId?: string | null;
  desk?: string | null;
  storeroomId?: string | null;
  subStatus?: LocationSubStatus | null;
};

export type AlertDto = {
  type: string;
  severity: "High" | "Medium" | "Low";
  title: string;
  detail: string;
  assetId?: string | null;
  dueDate?: string | null;
};

export type NotificationDto = {
  notificationId: string;
  type: string;
  title: string;
  message: string;
  assetId?: string | null;
  createdAt: string;
  isRead: boolean;
};

export const CONDITIONS: ConditionStatus[] = ["New", "Excellent", "Good", "Fair", "Damaged"];

export const ASSET_TYPES: AssetType[] = [
  "Laptop",
  "Monitor",
  "DockingStation",
  "Headset",
  "Desktop",
  "MobileDevice",
  "Tablet",
  "Printer",
  "Keyboard",
  "Peripheral",
  "NetworkEquipment",
  "Other",
];
