import { useMutation, useQueryClient } from "@tanstack/react-query";
import { AxiosError } from "axios";

// A change to one record can move figures on lists, dashboards and alerts,
// so the shared lists are refreshed together with the feature's own key.
const SHARED_KEYS = ["assets", "reports", "alerts", "notifications", "stock"];

export function useApiMutation<TVariables, TResult>(mutationFn: (variables: TVariables) => Promise<TResult>, ...featureKeys: string[]) {
  const queryClient = useQueryClient();
  return useMutation<TResult, AxiosError, TVariables>({
    mutationFn,
    onSuccess: () =>
      Promise.all([...SHARED_KEYS, ...featureKeys].map((key) => queryClient.invalidateQueries({ queryKey: [key] }))).then(() => undefined),
  });
}
