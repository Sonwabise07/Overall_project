import { Platform } from "react-native";

// EXPO_PUBLIC_API_URL points at the CtrlFind API (see .env.example). The Android emulator reaches the host on 10.0.2.2.
export const API_URL = (
  process.env.EXPO_PUBLIC_API_URL ??
  (Platform.OS === "android" ? "http://10.0.2.2:5102" : "http://localhost:5102")
).replace(/\/$/, "");

export const API_BASE_URL = `${API_URL}/api/v1`;
