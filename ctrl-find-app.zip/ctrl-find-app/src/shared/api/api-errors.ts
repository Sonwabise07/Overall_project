import { AxiosError } from "axios";

import { ErrorEnvelope } from "./api-common.types";

// Turns an API error envelope into one readable sentence for the screen.
export function getErrorMessage(error: unknown, fallback = "Something went wrong. Please try again."): string {
  const axiosError = error as AxiosError<ErrorEnvelope>;
  if (axiosError?.code === "ERR_NETWORK") return "The Asset Hub API cannot be reached. Check that it is running.";

  const body = axiosError?.response?.data?.error;
  if (!body) return fallback;

  const details = (body.details ?? [])
    .map((d) => (d.field ? `${d.field}: ${d.issue}` : d.issue))
    .filter(Boolean);
  return details.length > 0 ? `${body.message} (${details.join("; ")})` : body.message;
}

export function getErrorCode(error: unknown): string | undefined {
  return (error as AxiosError<ErrorEnvelope>)?.response?.data?.error?.code;
}
