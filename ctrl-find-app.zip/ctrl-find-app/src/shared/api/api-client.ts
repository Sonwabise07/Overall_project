import axios, { AxiosError, InternalAxiosRequestConfig } from "axios";

import { useAuthStore } from "@/features/auth/auth.store";
import { API_BASE_URL } from "./api-config";
import { ApiResponse } from "./api-responses.types";

// eslint-disable-next-line import/no-named-as-default-member -- axios.create is the documented API
export const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 15_000,
  headers: { "Content-Type": "application/json" },
});

apiClient.interceptors.request.use((config) => {
  const token = useAuthStore.getState().accessToken;
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

type RetriableRequest = InternalAxiosRequestConfig & { _retried?: boolean };
type RefreshedTokens = { accessToken: string; refreshToken: string };

let refreshInFlight: Promise<string | null> | null = null;

// Exchanges the refresh token once for every request that failed with 401 at the same time.
async function refreshAccessToken(): Promise<string | null> {
  const { refreshToken, setTokens } = useAuthStore.getState();
  if (!refreshToken) return null;
  try {
    const response = await axios.post<ApiResponse<RefreshedTokens>>(`${API_BASE_URL}/auth/refresh`, { refreshToken });
    setTokens(response.data.data.accessToken, response.data.data.refreshToken);
    return response.data.data.accessToken;
  } catch {
    return null;
  }
}

apiClient.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const request = error.config as RetriableRequest | undefined;
    const isAuthCall = request?.url?.startsWith("/auth/");
    if (error.response?.status !== 401 || !request || request._retried || isAuthCall) {
      return Promise.reject(error);
    }

    request._retried = true;
    refreshInFlight ??= refreshAccessToken().finally(() => {
      refreshInFlight = null;
    });
    const token = await refreshInFlight;
    if (!token) {
      useAuthStore.getState().signOut();
      return Promise.reject(error);
    }

    request.headers.Authorization = `Bearer ${token}`;
    return apiClient(request);
  },
);

export async function checkApiHealth() {
  const response = await axios.get<{ status: string; database: string }>(`${API_BASE_URL}/health`, { timeout: 5_000 });
  return response.data;
}

// Downloads need the bearer token, so images and files are fetched with these headers.
export function authHeaders(): Record<string, string> {
  const token = useAuthStore.getState().accessToken;
  return token ? { Authorization: `Bearer ${token}` } : {};
}
