export type ResponseMeta = {
  correlationId: string;
  timestamp: string;
};

export type PaginatedMeta = {
  page: number;
  pageSize: number;
  totalCount: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
  correlationId: string;
  timestamp: string;
};

export type ApiResponse<T> = {
  data: T;
  meta: ResponseMeta;
};

export type PaginatedResponse<T> = {
  data: T[];
  meta: PaginatedMeta;
};
