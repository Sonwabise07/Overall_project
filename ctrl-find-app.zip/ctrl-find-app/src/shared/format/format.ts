// Display helpers. Dates arrive as ISO strings; money is South African rand.

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export function formatDate(value?: string | null): string {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return `${String(date.getDate()).padStart(2, "0")} ${MONTHS[date.getMonth()]} ${date.getFullYear()}`;
}

export function formatDateTime(value?: string | null): string {
  if (!value) return "—";
  const date = new Date(value);
  return `${formatDate(value)}, ${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
}

export function formatMoney(value?: number | null): string {
  if (value === null || value === undefined) return "Not recorded";
  return `R ${value.toLocaleString("en-ZA", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).replace(/ /g, " ")}`;
}

export function formatNumber(value?: number | null): string {
  return value === null || value === undefined ? "—" : value.toLocaleString("en-ZA").replace(/ /g, " ");
}

// "HeldForReassignment" -> "Held for reassignment"
export function humanise(value?: string | null): string {
  if (!value) return "—";
  const words = value.replace(/([a-z])([A-Z])/g, "$1 $2").toLowerCase();
  return words.charAt(0).toUpperCase() + words.slice(1);
}

export function daysFromToday(value?: string | null): number | null {
  if (!value) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Math.round((new Date(value).getTime() - today.getTime()) / 86_400_000);
}

export function relativeDay(value?: string | null): string {
  const days = daysFromToday(value);
  if (days === null) return "—";
  if (days === 0) return "Today";
  if (days === -1) return "Yesterday";
  if (days === 1) return "Tomorrow";
  return formatDate(value);
}

// Today as yyyy-MM-dd for date fields.
export function todayIso(offsetDays = 0): string {
  const date = new Date();
  date.setDate(date.getDate() + offsetDays);
  return date.toISOString().slice(0, 10);
}

export function assetLabel(asset: { assetNo?: string | null; make?: string | null; model?: string | null }): string {
  const name = [asset.make, asset.model].filter(Boolean).join(" ");
  return name ? `${asset.assetNo} · ${name}` : (asset.assetNo ?? "—");
}

export function initials(name?: string | null): string {
  return (name ?? "?").split(" ").filter(Boolean).slice(0, 2).map((part) => part[0]!.toUpperCase()).join("");
}

// "2026-10" -> "Oct 2026"; other period labels (e.g. "Q3") are returned unchanged.
export function formatPeriod(period: string): string {
  const match = /^(\d{4})-(\d{2})$/.exec(period);
  return match ? `${MONTHS[Number(match[2]) - 1]} ${match[1]}` : period;
}
