// Lets TypeScript accept the global stylesheet import used by NativeWind.
declare module "*.css";
