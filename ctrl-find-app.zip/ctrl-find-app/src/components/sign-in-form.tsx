import * as React from "react";
import { type TextInput, View } from "react-native";
import { Monitor } from "lucide-react-native";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Icon } from "@/components/ui/icon";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Text } from "@/components/ui/text";
import { useLogin } from "@/features/auth/auth.queries";
import { getErrorMessage } from "@/shared/api/api-errors";

export function SignInForm() {
  const passwordInputRef = React.useRef<TextInput>(null);
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const login = useLogin();

  function onSubmit() {
    if (!email.trim() || !password) return;
    login.mutate({ username: email.trim(), password });
  }

  return (
    <Card className="gap-6 border-0">
      <CardHeader className="items-center gap-3">
        <View className="h-11 w-11 items-center justify-center rounded-xl bg-sky-500">
          <Icon as={Monitor} size={22} className="text-white" />
        </View>
        <CardTitle className="text-center text-xl">Sign in to Asset Hub</CardTitle>
        <CardDescription className="text-center">Use your company email and password.</CardDescription>
      </CardHeader>
      <CardContent className="gap-5">
        <View className="gap-1.5">
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            value={email}
            onChangeText={setEmail}
            placeholder="name@company.co.za"
            keyboardType="email-address"
            autoComplete="email"
            autoCapitalize="none"
            onSubmitEditing={() => passwordInputRef.current?.focus()}
            returnKeyType="next"
            submitBehavior="submit"
          />
        </View>
        <View className="gap-1.5">
          <Label htmlFor="password">Password</Label>
          <Input ref={passwordInputRef} id="password" value={password} onChangeText={setPassword} secureTextEntry returnKeyType="send" onSubmitEditing={onSubmit} />
        </View>
        {login.error ? <Text className="text-sm text-rose-700">{getErrorMessage(login.error)}</Text> : null}
        <Button className="w-full" onPress={onSubmit} disabled={login.isPending}>
          <Text>{login.isPending ? "Signing in…" : "Sign in"}</Text>
        </Button>
      </CardContent>
    </Card>
  );
}
