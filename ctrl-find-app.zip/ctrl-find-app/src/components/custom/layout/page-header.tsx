import { ReactNode, useState } from "react";
import { Pressable, View } from "react-native";
import { router } from "expo-router";
import { Bell, Search } from "lucide-react-native";

import { Card } from "@/components/ui/card";
import { Icon } from "@/components/ui/icon";
import { Input } from "@/components/ui/input";
import { Text } from "@/components/ui/text";
import { useMarkAllNotificationsRead, useMarkNotificationRead, useNotifications } from "@/features/alerts/alerts.queries";
import { relativeDay } from "@/shared/format/format";

type PageHeaderProps = { title: string; subtitle?: string; actions?: ReactNode };

export function PageHeader({ title, subtitle, actions }: PageHeaderProps) {
  const [search, setSearch] = useState("");

  return (
    <View className="z-10 flex-row flex-wrap items-start justify-between gap-3">
      <View className="min-w-[220px] flex-1 gap-0.5">
        <Text className="text-2xl font-bold">{title}</Text>
        {subtitle ? <Text className="text-muted-foreground text-sm">{subtitle}</Text> : null}
      </View>
      <View className="flex-row flex-wrap items-center gap-2">
        {actions}
        <View className="hidden w-60 flex-row items-center md:flex">
          <View className="absolute left-3 z-10">
            <Icon as={Search} size={14} className="text-muted-foreground" />
          </View>
          <Input
            value={search}
            onChangeText={setSearch}
            placeholder="Search assets, employees…"
            className="bg-card pl-9"
            returnKeyType="search"
            onSubmitEditing={() => router.push({ pathname: "/asset-register", params: { search } })}
          />
        </View>
        <NotificationBell />
      </View>
    </View>
  );
}

function NotificationBell() {
  const [open, setOpen] = useState(false);
  const { data } = useNotifications();
  const markRead = useMarkNotificationRead();
  const markAll = useMarkAllNotificationsRead();
  const notifications = data?.data ?? [];
  const unread = notifications.filter((n) => !n.isRead).length;

  return (
    <View>
      <Pressable
        accessibilityLabel={`Notifications, ${unread} unread`}
        onPress={() => setOpen((value) => !value)}
        className="bg-card border-border h-9 w-9 items-center justify-center rounded-md border"
      >
        <Icon as={Bell} size={16} className="text-muted-foreground" />
        {unread > 0 ? (
          <View className="absolute -right-1 -top-1 h-4 min-w-4 items-center justify-center rounded-full bg-rose-500 px-1">
            <Text className="text-[10px] font-bold text-white">{unread > 9 ? "9+" : unread}</Text>
          </View>
        ) : null}
      </Pressable>
      {open ? (
        <Card className="absolute right-0 top-11 z-20 w-80 gap-0 px-0 py-2">
          <View className="flex-row items-center justify-between px-4 pb-2">
            <Text className="text-sm font-semibold">Notifications</Text>
            {unread > 0 ? (
              <Pressable onPress={() => markAll.mutate()}>
                <Text className="text-primary text-xs">Mark all read</Text>
              </Pressable>
            ) : null}
          </View>
          {notifications.length === 0 ? (
            <Text className="text-muted-foreground px-4 py-3 text-sm">You’re all caught up.</Text>
          ) : (
            notifications.slice(0, 8).map((n) => (
              <Pressable
                key={n.notificationId}
                onPress={() => {
                  if (!n.isRead) markRead.mutate(n.notificationId);
                  if (n.assetId) router.push({ pathname: "/asset-details", params: { assetId: n.assetId } });
                  setOpen(false);
                }}
                className="border-border border-t px-4 py-2.5 web:hover:bg-muted"
              >
                <View className="flex-row items-center gap-2">
                  {!n.isRead ? <View className="bg-primary h-1.5 w-1.5 rounded-full" /> : null}
                  <Text className="flex-1 text-sm font-medium">{n.title}</Text>
                  <Text className="text-muted-foreground text-[11px]">{relativeDay(n.createdAt)}</Text>
                </View>
                <Text className="text-muted-foreground text-xs" numberOfLines={2}>{n.message}</Text>
              </Pressable>
            ))
          )}
        </Card>
      ) : null}
    </View>
  );
}
