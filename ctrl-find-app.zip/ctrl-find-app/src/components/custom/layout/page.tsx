import { ReactNode } from "react";
import { ScrollView, View } from "react-native";

import { Card } from "@/components/ui/card";
import { Text } from "@/components/ui/text";
import { cn } from "@/lib/utils";
import { PageHeader } from "./page-header";

type PageProps = { title: string; subtitle?: string; actions?: ReactNode; children: ReactNode };

export function Page({ title, subtitle, actions, children }: PageProps) {
  return (
    <View className="bg-background flex-1">
      <ScrollView contentContainerClassName="gap-5 p-4 pb-28 md:p-6" keyboardShouldPersistTaps="handled">
        <PageHeader title={title} subtitle={subtitle} actions={actions} />
        {children}
      </ScrollView>
    </View>
  );
}

// A wrapping row of summary tiles.
export function StatGrid({ children }: { children: ReactNode }) {
  return <View className="flex-row flex-wrap gap-4">{children}</View>;
}

// Main content with a side panel; stacks on narrow screens.
export function Columns({ main, side, className }: { main: ReactNode; side?: ReactNode; className?: string }) {
  return (
    <View className={cn("flex-col gap-5 xl:flex-row xl:items-start", className)}>
      <View className="gap-5 xl:flex-[2]">{main}</View>
      {side ? <View className="gap-5 xl:flex-1">{side}</View> : null}
    </View>
  );
}

type SectionProps = { title: string; description?: string; action?: ReactNode; children?: ReactNode; className?: string };

export function Section({ title, description, action, children, className }: SectionProps) {
  return (
    <Card className={cn("gap-4 px-5 py-5", className)}>
      <View className="flex-row flex-wrap items-start justify-between gap-3">
        <View className="min-w-[180px] flex-1 gap-1">
          <Text className="text-base font-semibold">{title}</Text>
          {description ? <Text className="text-muted-foreground text-xs">{description}</Text> : null}
        </View>
        {action}
      </View>
      {children}
    </Card>
  );
}
