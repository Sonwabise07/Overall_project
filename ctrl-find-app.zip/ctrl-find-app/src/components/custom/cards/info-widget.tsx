import { Pressable, View } from "react-native";
import { LucideIcon } from "lucide-react-native";

import { Card } from "@/components/ui/card";
import { Icon } from "@/components/ui/icon";
import { Text } from "@/components/ui/text";
import { cn } from "@/lib/utils";

type InfoWidgetProps = {
  icon: LucideIcon;
  heading: string;
  subheading: string;
  detail: string;
  primaryColor?: string;
  secondaryColor?: string;
  topBorderColor?: string;
  onPress?: () => void;
};

// Summary tile used at the top of every screen: icon, tag, figure and label.
export function InfoWidget({ icon, heading, subheading, detail, primaryColor, secondaryColor, topBorderColor, onPress }: InfoWidgetProps) {
  const body = (
    <Card className={cn("min-w-[200px] flex-1 gap-3 border px-5 py-4", topBorderColor && cn("border-t-4", topBorderColor))}>
      <View className="flex-row items-start justify-between">
        <View className={cn("h-9 w-9 items-center justify-center rounded-lg", primaryColor ?? "bg-slate-400")}>
          <Icon as={icon} size={18} className="text-white" />
        </View>
        <Text className={cn("text-xs font-semibold", secondaryColor ?? "text-muted-foreground")}>{detail}</Text>
      </View>
      <View className="gap-0.5">
        <Text className="text-3xl font-bold">{heading}</Text>
        <Text className="text-muted-foreground text-sm">{subheading}</Text>
      </View>
    </Card>
  );
  return onPress ? <Pressable className="min-w-[200px] flex-1" onPress={onPress}>{body}</Pressable> : body;
}

export const WidgetTones = {
  blue: { primaryColor: "bg-sky-500", secondaryColor: "text-sky-600" },
  purple: { primaryColor: "bg-violet-600", secondaryColor: "text-violet-600" },
  amber: { primaryColor: "bg-amber-500", secondaryColor: "text-amber-600" },
  red: { primaryColor: "bg-rose-500", secondaryColor: "text-rose-600" },
  green: { primaryColor: "bg-emerald-500", secondaryColor: "text-emerald-600" },
} as const;
