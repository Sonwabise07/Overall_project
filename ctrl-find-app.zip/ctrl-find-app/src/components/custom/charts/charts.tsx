import { View } from "react-native";

import { Text } from "@/components/ui/text";
import { cn } from "@/lib/utils";
import { ProgressBar } from "@/components/custom/progress/bar";

const PALETTE = ["bg-sky-500", "bg-violet-600", "bg-emerald-500", "bg-amber-500", "bg-rose-500", "bg-slate-500"];

export type ChartPoint = { label: string; value: number; colour?: string };

type BarListProps = { points: ChartPoint[]; format?: (value: number) => string; max?: number };

// Horizontal bars scaled to the largest value (or to max, e.g. 100 for percentages), as in the design's distribution panels.
export function BarList({ points, format = (v) => v.toLocaleString("en-ZA"), max: scale }: BarListProps) {
  const max = scale ?? Math.max(1, ...points.map((p) => p.value));
  return (
    <View className="gap-3">
      {points.map((point, index) => (
        <ProgressBar
          key={point.label}
          label={point.label}
          percentage={(point.value / max) * 100}
          valueLabel={format(point.value)}
          indicatorClassName={point.colour ?? PALETTE[index % PALETTE.length]}
        />
      ))}
    </View>
  );
}

// Vertical columns for trends over time. No chart library: plain views in the Asset Hub style.
export function ColumnChart({ points, format = (v) => v.toLocaleString("en-ZA"), height = 140 }: { points: ChartPoint[]; format?: (value: number) => string; height?: number }) {
  const max = Math.max(1, ...points.map((p) => p.value));
  return (
    <View className="gap-2">
      <View className="flex-row items-end gap-1.5" style={{ height }}>
        {points.map((point) => (
          <View key={point.label} className="flex-1 items-center justify-end gap-1">
            <Text className="text-muted-foreground text-[10px]">{point.value > 0 ? format(point.value) : ""}</Text>
            <View
              className={cn("w-full max-w-[36px] rounded-t-md", point.colour ?? "bg-sky-500")}
              style={{ height: Math.max(2, (point.value / max) * (height - 18)) }}
            />
          </View>
        ))}
      </View>
      <View className="flex-row gap-1.5">
        {points.map((point) => (
          <Text key={point.label} className="text-muted-foreground flex-1 text-center text-[10px]" numberOfLines={1}>
            {point.label}
          </Text>
        ))}
      </View>
    </View>
  );
}
