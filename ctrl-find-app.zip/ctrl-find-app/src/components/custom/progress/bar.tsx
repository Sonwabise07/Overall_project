import { View } from "react-native";

import { Progress } from "@/components/ui/progress";
import { Text } from "@/components/ui/text";
import { cn } from "@/lib/utils";

type ProgressBarProps = {
  label: string;
  percentage: number;
  className?: string;
  indicatorClassName?: string;
  valueLabel?: string;
};

export function ProgressBar({ label, percentage, className, indicatorClassName, valueLabel }: ProgressBarProps) {
  const value = Math.max(0, Math.min(100, percentage));
  return (
    <View className="flex-row items-center gap-3">
      <Text className="text-muted-foreground w-28 text-sm" numberOfLines={2}>{label}</Text>
      <Progress value={value} className={cn("h-2 flex-1 bg-slate-100", className)} indicatorClassName={indicatorClassName} />
      <Text className="w-14 text-right text-sm font-semibold">{valueLabel ?? `${Math.round(value)}%`}</Text>
    </View>
  );
}
