import { ReactNode } from "react";
import { ActivityIndicator, View } from "react-native";

import { Button } from "@/components/ui/button";
import { Text } from "@/components/ui/text";
import { cn } from "@/lib/utils";
import { getErrorMessage } from "@/shared/api/api-errors";

export function LoadingState({ label = "Loading…" }: { label?: string }) {
  return (
    <View className="flex-row items-center justify-center gap-3 py-8">
      <ActivityIndicator />
      <Text className="text-muted-foreground text-sm">{label}</Text>
    </View>
  );
}

export function EmptyState({ text }: { text: string }) {
  return (
    <View className="items-center py-8">
      <Text className="text-muted-foreground text-sm">{text}</Text>
    </View>
  );
}

export function ErrorState({ error, onRetry }: { error: unknown; onRetry?: () => void }) {
  return (
    <View className="items-center gap-3 py-8">
      <Text className="text-center text-sm text-rose-700">{getErrorMessage(error)}</Text>
      {onRetry ? (
        <Button variant="outline" size="sm" onPress={onRetry}>
          <Text>Try again</Text>
        </Button>
      ) : null}
    </View>
  );
}

type QueryBoundaryProps = { isLoading: boolean; error: unknown; onRetry?: () => void; children: ReactNode };

// Shows loading and error states for a query, then the content.
export function QueryBoundary({ isLoading, error, onRetry, children }: QueryBoundaryProps) {
  if (isLoading) return <LoadingState />;
  if (error) return <ErrorState error={error} onRetry={onRetry} />;
  return <>{children}</>;
}

type CalloutProps = { tone?: "info" | "warning" | "danger" | "success"; title?: string; children: ReactNode; className?: string };

const CALLOUT_TONES = {
  info: { box: "bg-sky-50 border-sky-100", text: "text-sky-800" },
  warning: { box: "bg-amber-50 border-amber-100", text: "text-amber-800" },
  danger: { box: "bg-rose-50 border-rose-100", text: "text-rose-800" },
  success: { box: "bg-emerald-50 border-emerald-100", text: "text-emerald-800" },
};

export function Callout({ tone = "info", title, children, className }: CalloutProps) {
  const colours = CALLOUT_TONES[tone];
  return (
    <View className={cn("rounded-lg border px-4 py-3", colours.box, className)}>
      <Text className={cn("text-sm leading-5", colours.text)}>
        {title ? <Text className={cn("text-sm font-semibold", colours.text)}>{title} — </Text> : null}
        {children}
      </Text>
    </View>
  );
}
