import { Pressable, ScrollView, View } from "react-native";

import { Separator } from "@/components/ui/separator";
import { Text } from "@/components/ui/text";
import { cn } from "@/lib/utils";
import { Column } from "./table.types";

type TableProps<T> = {
  columns: Column<T>[];
  rows: T[];
  rowKey: (row: T) => string;
  onRowPress?: (row: T) => void;
  selectedKey?: string;
  emptyText?: string;
  minWidth?: number;
  footer?: string;
};

// Column-based table. Scrolls sideways on narrow screens so columns never squash.
export function Table<T>({ columns, rows, rowKey, onRowPress, selectedKey, emptyText = "Nothing to show", minWidth = 640, footer }: TableProps<T>) {
  return (
    <View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerClassName="min-w-full">
        <View style={{ minWidth }} className="w-full">
          <View className="border-border flex-row gap-3 border-b px-2 pb-2">
            {columns.map((column) => (
              <Text key={column.key} style={{ flex: column.flex ?? 1 }} className="text-muted-foreground text-[11px] font-semibold uppercase tracking-wide">
                {column.label}
              </Text>
            ))}
          </View>
          {rows.length === 0 ? (
            <Text className="text-muted-foreground py-8 text-center text-sm">{emptyText}</Text>
          ) : (
            rows.map((row, index) => {
              const key = rowKey(row);
              return (
                <View key={key}>
                  {index > 0 ? <Separator /> : null}
                  <Pressable
                    disabled={!onRowPress}
                    onPress={() => onRowPress?.(row)}
                    className={cn(
                      "min-h-12 flex-row items-center gap-3 rounded-md px-2 py-2",
                      onRowPress && "web:hover:bg-muted",
                      selectedKey === key && "bg-accent",
                    )}
                  >
                    {columns.map((column) => (
                      <View key={column.key} style={{ flex: column.flex ?? 1 }}>
                        {column.render ? column.render(row) : <Text className="text-sm">{column.value?.(row) ?? "—"}</Text>}
                      </View>
                    ))}
                  </Pressable>
                </View>
              );
            })
          )}
        </View>
      </ScrollView>
      {footer ? <Text className="text-muted-foreground px-2 pt-3 text-xs">{footer}</Text> : null}
    </View>
  );
}

// Bold primary line with a muted second line, used in most first columns.
export function TwoLine({ title, subtitle }: { title: string; subtitle?: string | null }) {
  return (
    <View>
      <Text className="text-sm font-semibold">{title}</Text>
      {subtitle ? <Text className="text-muted-foreground text-xs">{subtitle}</Text> : null}
    </View>
  );
}
