import { ReactNode } from "react";

export type Column<T> = {
  key: string;
  label: string;
  flex?: number;
  // Plain text value; used when no custom render is given.
  value?: (row: T) => string | number | null | undefined;
  render?: (row: T) => ReactNode;
};
