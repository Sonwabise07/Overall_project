import { ReactNode } from "react";
import { View } from "react-native";

import { Separator } from "@/components/ui/separator";
import { Text } from "@/components/ui/text";

export type DetailItem = { label: string; value: ReactNode };

// Label on the left, value on the right, as in the design side panels.
export function DetailList({ items }: { items: DetailItem[] }) {
  return (
    <View>
      {items.map((item, index) => (
        <View key={item.label}>
          {index > 0 ? <Separator /> : null}
          <View className="flex-row items-center justify-between gap-4 py-2.5">
            <Text className="text-muted-foreground text-sm">{item.label}</Text>
            {typeof item.value === "string" || typeof item.value === "number" ? (
              <Text className="flex-shrink text-right text-sm font-semibold">{item.value}</Text>
            ) : (
              item.value
            )}
          </View>
        </View>
      ))}
    </View>
  );
}
