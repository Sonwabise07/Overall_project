import { useEffect, useState } from "react";
import { Platform, View } from "react-native";
import { Image } from "expo-image";

import { Text } from "@/components/ui/text";
import { absoluteDocumentUrl } from "@/features/documents/documents.api";
import { apiClient, authHeaders } from "@/shared/api/api-client";
import { cn } from "@/lib/utils";

type AuthImageProps = { downloadUrl?: string | null; label: string; className?: string };

// Photos are protected by the API, so they are requested with the user's token.
// Browsers cannot add headers to <img>, so on web the image is fetched first.
export function AuthImage({ downloadUrl, label, className }: AuthImageProps) {
  const [webUri, setWebUri] = useState<string>();
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    if (Platform.OS !== "web" || !downloadUrl) return;
    let objectUrl: string | undefined;
    apiClient
      .get(downloadUrl.replace("/api/v1", ""), { responseType: "blob" })
      .then((response) => {
        objectUrl = URL.createObjectURL(response.data as Blob);
        setWebUri(objectUrl);
      })
      .catch(() => setFailed(true));
    return () => {
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [downloadUrl]);

  if (!downloadUrl || failed) {
    return (
      <View className={cn("bg-muted items-center justify-center rounded-lg border border-dashed border-slate-300", className)}>
        <Text className="text-muted-foreground px-2 text-center text-xs">{failed ? `${label} unavailable` : `No ${label.toLowerCase()}`}</Text>
      </View>
    );
  }

  const source = Platform.OS === "web" ? { uri: webUri } : { uri: absoluteDocumentUrl(downloadUrl), headers: authHeaders() };
  return <Image source={source} accessibilityLabel={label} contentFit="cover" className={cn("rounded-lg", className)} onError={() => setFailed(true)} />;
}
