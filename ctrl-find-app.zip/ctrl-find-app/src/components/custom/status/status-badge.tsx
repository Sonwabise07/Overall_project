import { View } from "react-native";

import { Text } from "@/components/ui/text";
import { cn } from "@/lib/utils";
import { humanise } from "@/shared/format/format";

export type Tone = "success" | "info" | "warning" | "danger" | "purple" | "neutral";

const TONES: Record<Tone, { box: string; dot: string; text: string }> = {
  success: { box: "bg-emerald-50 border-emerald-200", dot: "bg-emerald-500", text: "text-emerald-700" },
  info: { box: "bg-sky-50 border-sky-200", dot: "bg-sky-500", text: "text-sky-700" },
  warning: { box: "bg-amber-50 border-amber-200", dot: "bg-amber-500", text: "text-amber-700" },
  danger: { box: "bg-rose-50 border-rose-200", dot: "bg-rose-500", text: "text-rose-700" },
  purple: { box: "bg-violet-50 border-violet-200", dot: "bg-violet-500", text: "text-violet-700" },
  neutral: { box: "bg-slate-100 border-slate-200", dot: "bg-slate-400", text: "text-slate-600" },
};

// One colour language for every status in the app.
const STATUS_TONES: Record<string, Tone> = {
  InUse: "info", Assigned: "info", InOffice: "info", Open: "info", InProgress: "info", Scheduled: "info", PendingApproval: "warning",
  AtHome: "purple", OffSite: "purple", HeldForReassignment: "purple", Reserved: "purple", AwaitingConfirmation: "warning", WarrantyClaim: "warning",
  InStorage: "neutral", Registered: "neutral", Ordered: "neutral", Received: "neutral", Retired: "neutral", Disposed: "neutral", Cancelled: "neutral", Draft: "neutral",
  InRepair: "warning", UnderAudit: "warning", UnderReview: "warning", UnderInvestigation: "warning", Blocked: "danger", Declined: "danger", Escalated: "danger",
  Lost: "danger", Stolen: "danger", Negligent: "danger", SerialMismatch: "danger", NotFound: "danger", Unconfirmed: "danger", NoStock: "danger", DamageReview: "danger",
  Completed: "success", Confirmed: "success", Returned: "success", Healthy: "success", NotNegligent: "success", Recovered: "success", Green: "success",
  LowStock: "warning", Amber: "warning", Red: "danger", LocationMismatch: "warning", ConditionMismatch: "warning", InRecovery: "warning",
  New: "success", Excellent: "success", Good: "info", Fair: "warning", Damaged: "danger", High: "danger", Medium: "warning", Low: "info",
};

export function toneFor(status?: string | null): Tone {
  return (status && STATUS_TONES[status]) || "neutral";
}

type StatusBadgeProps = { status?: string | null; label?: string; tone?: Tone; className?: string };

export function StatusBadge({ status, label, tone, className }: StatusBadgeProps) {
  const colours = TONES[tone ?? toneFor(status)];
  return (
    <View className={cn("flex-row items-center gap-1.5 self-start rounded-full border px-2.5 py-0.5", colours.box, className)}>
      <View className={cn("h-1.5 w-1.5 rounded-full", colours.dot)} />
      <Text className={cn("text-xs font-medium", colours.text)}>{label ?? humanise(status)}</Text>
    </View>
  );
}
