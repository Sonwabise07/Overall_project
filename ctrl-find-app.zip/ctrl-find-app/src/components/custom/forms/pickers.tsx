import { useState } from "react";
import { Pressable, View } from "react-native";
import { X } from "lucide-react-native";

import { Icon } from "@/components/ui/icon";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Text } from "@/components/ui/text";
import { useAssets } from "@/features/assets/assets.queries";
import { AssetListItemDto, AssetListParams } from "@/features/assets/assets.types";
import { useEmployees, useLocations, useStorerooms } from "@/features/reference/reference.queries";
import { EmployeeDto } from "@/features/reference/reference.types";
import { cn } from "@/lib/utils";
import { assetLabel, humanise } from "@/shared/format/format";
import { OptionPicker } from "./fields";

type SearchPickerProps<T> = {
  label: string;
  placeholder: string;
  selectedLabel?: string;
  results: T[];
  search: string;
  onSearch: (value: string) => void;
  onSelect: (item: T) => void;
  onClear: () => void;
  itemKey: (item: T) => string;
  itemTitle: (item: T) => string;
  itemSubtitle: (item: T) => string | undefined;
};

function SearchPicker<T>(props: SearchPickerProps<T>) {
  const { label, placeholder, selectedLabel, results, search, onSearch, onSelect, onClear, itemKey, itemTitle, itemSubtitle } = props;
  return (
    <View className="min-w-[200px] flex-1 gap-1.5">
      <Label>{label}</Label>
      {selectedLabel ? (
        <View className="border-input bg-accent flex-row items-center justify-between rounded-md border px-3 py-2">
          <Text className="flex-1 text-sm font-medium">{selectedLabel}</Text>
          <Pressable accessibilityLabel={`Clear ${label}`} onPress={onClear} hitSlop={8}>
            <Icon as={X} size={14} className="text-muted-foreground" />
          </Pressable>
        </View>
      ) : (
        <>
          <Input value={search} onChangeText={onSearch} placeholder={placeholder} />
          {search.trim().length >= 2 ? (
            <View className="border-border bg-card overflow-hidden rounded-md border">
              {results.length === 0 ? (
                <Text className="text-muted-foreground px-3 py-2 text-sm">No matches</Text>
              ) : (
                results.slice(0, 6).map((item) => (
                  <Pressable key={itemKey(item)} onPress={() => onSelect(item)} className="border-border border-b px-3 py-2 last:border-b-0 web:hover:bg-muted">
                    <Text className="text-sm font-medium">{itemTitle(item)}</Text>
                    {itemSubtitle(item) ? <Text className="text-muted-foreground text-xs">{itemSubtitle(item)}</Text> : null}
                  </Pressable>
                ))
              )}
            </View>
          ) : null}
        </>
      )}
    </View>
  );
}

type EmployeePickerProps = { label?: string; value?: EmployeeDto; onChange: (employee?: EmployeeDto) => void };

export function EmployeePicker({ label = "Employee", value, onChange }: EmployeePickerProps) {
  const [search, setSearch] = useState("");
  const { data } = useEmployees(search.trim().length >= 2 ? search.trim() : undefined);
  return (
    <SearchPicker
      label={label}
      placeholder="Search by name or employee number"
      selectedLabel={value ? `${value.fullName} · ${value.employeeId}` : undefined}
      results={search.trim().length >= 2 ? (data?.data ?? []) : []}
      search={search}
      onSearch={setSearch}
      onSelect={(employee) => {
        onChange(employee);
        setSearch("");
      }}
      onClear={() => onChange(undefined)}
      itemKey={(e) => e.employeeId}
      itemTitle={(e) => e.fullName}
      itemSubtitle={(e) => [e.employeeId, e.jobRole, e.departmentId].filter(Boolean).join(" · ")}
    />
  );
}

type AssetPickerProps = { label?: string; value?: AssetListItemDto; onChange: (asset?: AssetListItemDto) => void; filters?: AssetListParams };

export function AssetPicker({ label = "Asset", value, onChange, filters }: AssetPickerProps) {
  const [search, setSearch] = useState("");
  const enabled = search.trim().length >= 2;
  const { data } = useAssets({ ...filters, search: search.trim(), pageSize: 6 }, enabled);
  return (
    <SearchPicker
      label={label}
      placeholder="Search by tag, asset number or serial"
      selectedLabel={value ? assetLabel(value) : undefined}
      results={enabled ? (data?.data ?? []) : []}
      search={search}
      onSearch={setSearch}
      onSelect={(asset) => {
        onChange(asset);
        setSearch("");
      }}
      onClear={() => onChange(undefined)}
      itemKey={(a) => a.assetId}
      itemTitle={(a) => assetLabel(a)}
      itemSubtitle={(a) => [a.assetTag, humanise(a.lifecycleState), a.assignedEmployeeName].filter(Boolean).join(" · ")}
    />
  );
}

export function StoreroomPicker({ value, onChange, label = "Storeroom" }: { value?: string; onChange: (id: string) => void; label?: string }) {
  const { data } = useStorerooms();
  return <OptionPicker label={label} value={value} onChange={onChange} options={(data?.data ?? []).map((s) => ({ value: s.storeroomId, label: s.name }))} />;
}

export function LocationPicker({ value, onChange, label = "Location" }: { value?: string; onChange: (id: string) => void; label?: string }) {
  const { data } = useLocations();
  return <OptionPicker label={label} value={value} onChange={onChange} options={(data?.data ?? []).map((l) => ({ value: l.locationId, label: l.name }))} />;
}

export function Chip({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} className={cn("rounded-md px-3 py-1.5", active ? "bg-primary" : "bg-muted web:hover:bg-accent")}>
      <Text className={cn("text-sm", active ? "font-semibold text-white" : "text-foreground")}>{label}</Text>
    </Pressable>
  );
}
