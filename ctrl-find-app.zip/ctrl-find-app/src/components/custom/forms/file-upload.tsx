import { useState } from "react";
import { Platform, View } from "react-native";
import * as DocumentPicker from "expo-document-picker";
import * as ImagePicker from "expo-image-picker";
import { Camera, FileUp } from "lucide-react-native";

import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { Text } from "@/components/ui/text";
import { useUploadAssetDocument } from "@/features/documents/documents.queries";
import { DocumentReferenceDto, DocumentType, PickedFile } from "@/features/documents/documents.types";
import { FormMessage } from "./fields";

type FileUploadProps = {
  assetId?: string;
  documentType: DocumentType;
  label: string;
  onUploaded: (document: DocumentReferenceDto) => void;
  uploaded?: DocumentReferenceDto;
};

// Uploads a photo or document against an asset and hands back the stored document reference.
export function FileUpload({ assetId, documentType, label, onUploaded, uploaded }: FileUploadProps) {
  const upload = useUploadAssetDocument();
  const [pickError, setPickError] = useState<string>();
  const isPhoto = documentType === "Photo";

  async function pick(fromCamera: boolean) {
    if (!assetId) return;
    setPickError(undefined);
    let file: PickedFile | undefined;

    if (isPhoto) {
      if (fromCamera) {
        const permission = await ImagePicker.requestCameraPermissionsAsync();
        if (!permission.granted) return setPickError("Camera access is needed to take the photo.");
      }
      const result = fromCamera
        ? await ImagePicker.launchCameraAsync({ quality: 0.7, mediaTypes: ["images"] })
        : await ImagePicker.launchImageLibraryAsync({ quality: 0.7, mediaTypes: ["images"] });
      const asset = result.canceled ? undefined : result.assets[0];
      if (asset) file = { uri: asset.uri, name: asset.fileName ?? "photo.jpg", mimeType: asset.mimeType ?? "image/jpeg", file: asset.file };
    } else {
      const result = await DocumentPicker.getDocumentAsync({ type: ["application/pdf", "image/*"], copyToCacheDirectory: true });
      const asset = result.canceled ? undefined : result.assets[0];
      if (asset) file = { uri: asset.uri, name: asset.name, mimeType: asset.mimeType ?? "application/pdf", file: asset.file };
    }

    if (file) upload.mutate({ assetId, file, documentType }, { onSuccess: (response) => onUploaded(response.data) });
  }

  return (
    <View className="gap-2">
      <Text className="text-sm font-medium">{label}</Text>
      {uploaded ? (
        <Text className="text-sm text-emerald-700">Uploaded: {uploaded.fileName}</Text>
      ) : (
        <View className="flex-row flex-wrap gap-2">
          {isPhoto && Platform.OS !== "web" ? (
            <Button variant="outline" size="sm" disabled={!assetId || upload.isPending} onPress={() => pick(true)}>
              <Icon as={Camera} size={14} />
              <Text>Take photo</Text>
            </Button>
          ) : null}
          <Button variant="outline" size="sm" disabled={!assetId || upload.isPending} onPress={() => pick(false)}>
            <Icon as={FileUp} size={14} />
            <Text>{upload.isPending ? "Uploading…" : isPhoto ? "Choose photo" : "Choose file"}</Text>
          </Button>
        </View>
      )}
      {!assetId ? <Text className="text-muted-foreground text-xs">Choose the asset first.</Text> : null}
      {pickError ? <Text className="text-sm text-rose-700">{pickError}</Text> : null}
      <FormMessage error={upload.error} />
    </View>
  );
}
