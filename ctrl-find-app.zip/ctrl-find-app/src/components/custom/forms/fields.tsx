import { ReactNode } from "react";
import { Pressable, View } from "react-native";
import { Check } from "lucide-react-native";

import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Text } from "@/components/ui/text";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { getErrorMessage } from "@/shared/api/api-errors";

type FieldProps = {
  label: string;
  value: string;
  onChangeText: (value: string) => void;
  placeholder?: string;
  multiline?: boolean;
  keyboardType?: "default" | "numeric" | "email-address";
  secureTextEntry?: boolean;
  hint?: string;
  className?: string;
};

export function Field({ label, value, onChangeText, placeholder, multiline, keyboardType, secureTextEntry, hint, className }: FieldProps) {
  return (
    <View className={cn("min-w-[160px] flex-1 gap-1.5", className)}>
      <Label nativeID={label}>{label}</Label>
      {multiline ? (
        <Textarea aria-labelledby={label} value={value} onChangeText={onChangeText} placeholder={placeholder} />
      ) : (
        <Input
          aria-labelledby={label}
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          keyboardType={keyboardType}
          secureTextEntry={secureTextEntry}
          autoCapitalize={keyboardType === "email-address" ? "none" : undefined}
        />
      )}
      {hint ? <Text className="text-muted-foreground text-xs">{hint}</Text> : null}
    </View>
  );
}

export function DateField(props: Omit<FieldProps, "placeholder" | "keyboardType">) {
  return <Field {...props} placeholder="yyyy-mm-dd" hint={props.hint} />;
}

export type Option<T extends string> = { value: T; label: string };

type OptionPickerProps<T extends string> = { label?: string; options: Option<T>[]; value?: T; onChange: (value: T) => void; className?: string };

// Segmented choice used for condition ratings, transfer types and other short lists.
export function OptionPicker<T extends string>({ label, options, value, onChange, className }: OptionPickerProps<T>) {
  return (
    <View className={cn("gap-1.5", className)}>
      {label ? <Label>{label}</Label> : null}
      <View className="flex-row flex-wrap gap-2">
        {options.map((option) => {
          const selected = option.value === value;
          return (
            <Pressable
              key={option.value}
              accessibilityRole="radio"
              accessibilityState={{ selected }}
              onPress={() => onChange(option.value)}
              className={cn("rounded-md border px-3 py-1.5", selected ? "bg-primary border-primary" : "bg-card border-border web:hover:bg-muted")}
            >
              <Text className={cn("text-sm", selected ? "font-semibold text-white" : "text-foreground")}>{option.label}</Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

export function Checkbox({ label, checked, onChange }: { label: string; checked: boolean; onChange: (checked: boolean) => void }) {
  return (
    <Pressable accessibilityRole="checkbox" accessibilityState={{ checked }} onPress={() => onChange(!checked)} className="flex-row items-center gap-2.5">
      <View className={cn("h-5 w-5 items-center justify-center rounded border", checked ? "bg-primary border-primary" : "border-input bg-card")}>
        {checked ? <Icon as={Check} size={14} className="text-white" /> : null}
      </View>
      <Text className="flex-1 text-sm">{label}</Text>
    </Pressable>
  );
}

export function FormRow({ children }: { children: ReactNode }) {
  return <View className="flex-row flex-wrap gap-3">{children}</View>;
}

type SubmitProps = { label: string; onPress: () => void; pending?: boolean; disabled?: boolean; variant?: "default" | "outline" | "destructive" | "secondary" };

export function SubmitButton({ label, onPress, pending, disabled, variant = "default" }: SubmitProps) {
  return (
    <Button variant={variant} onPress={onPress} disabled={pending || disabled} className={cn("self-start", (pending || disabled) && "opacity-60")}>
      <Text>{pending ? "Saving…" : label}</Text>
    </Button>
  );
}

// Shows the API's own message for a failed action, or a confirmation once it succeeds.
export function FormMessage({ error, success }: { error?: unknown; success?: string | false | null }) {
  if (error) return <Text className="text-sm text-rose-700">{getErrorMessage(error)}</Text>;
  if (success) return <Text className="text-sm text-emerald-700">{success}</Text>;
  return null;
}
