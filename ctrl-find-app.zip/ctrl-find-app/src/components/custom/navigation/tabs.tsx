import { Pressable, ScrollView, View } from "react-native";

import { Text } from "@/components/ui/text";
import { cn } from "@/lib/utils";

type TabsProps<T extends string> = { tabs: { value: T; label: string }[]; value: T; onChange: (value: T) => void };

// Underlined tab strip, as on the asset profile and reports designs. Scrolls sideways on phones.
export function Tabs<T extends string>({ tabs, value, onChange }: TabsProps<T>) {
  return (
    <View className="border-border border-b">
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerClassName="gap-6">
        {tabs.map((tab) => {
          const active = tab.value === value;
          return (
            <Pressable
              key={tab.value}
              accessibilityRole="tab"
              accessibilityState={{ selected: active }}
              onPress={() => onChange(tab.value)}
              className={cn("-mb-px border-b-2 px-1 pb-2.5 pt-1", active ? "border-primary" : "border-transparent")}
            >
              <Text className={cn("text-sm", active ? "text-foreground font-semibold" : "text-muted-foreground")}>{tab.label}</Text>
            </Pressable>
          );
        })}
      </ScrollView>
    </View>
  );
}
