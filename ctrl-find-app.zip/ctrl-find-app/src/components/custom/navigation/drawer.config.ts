// components/navigation/drawer-config.ts
import {
  ArrowLeftRight,
  BarChart3,
  Boxes,
  ClipboardCheck,
  Home,
  LayoutDashboard,
  LogOut,
  MapPin,
  MessageCircle,
  Monitor,
  ShieldCheck,
  Trash2,
  TriangleAlert,
  UserPlus,
  Wrench,
  Zap,
  LucideIcon,
} from "lucide-react-native";

import { AssetOperators, Management, Role, Roles } from "@/features/auth/auth.roles";

export type DrawerRoute = { name: string; icon: LucideIcon; roles?: Role[] };

// Sections follow the screen designs. Routes without roles are open to everyone;
// the API still scopes the data each person can see.
export const drawerSections: { title: string; routes: DrawerRoute[] }[] = [
  { title: "OVERVIEW", routes: [{ name: "index", icon: LayoutDashboard }] },
  {
    title: "ASSET REGISTER",
    routes: [
      { name: "asset-register", icon: Monitor },
      { name: "asset-locations", icon: MapPin },
    ],
  },
  {
    title: "LIFECYCLE",
    routes: [
      { name: "onboarding", icon: UserPlus, roles: [...AssetOperators, Roles.Hr] },
      { name: "take-home-requests", icon: Home },
      { name: "transfers", icon: ArrowLeftRight },
      { name: "emergency-swap", icon: Zap, roles: [...AssetOperators, Roles.HelpDesk] },
    ],
  },
  {
    title: "OPERATIONS",
    routes: [
      { name: "stock-storeroom", icon: Boxes, roles: AssetOperators },
      { name: "faults-repairs", icon: Wrench, roles: [Roles.HelpDesk, Roles.FixedAssets, Roles.Administrator] },
      { name: "warranty", icon: ShieldCheck },
    ],
  },
  {
    title: "RISK & EXIT",
    routes: [
      { name: "loss-theft-aod", icon: TriangleAlert },
      { name: "audit-risk", icon: ClipboardCheck, roles: [Roles.Manager, ...AssetOperators] },
      { name: "offboarding", icon: LogOut, roles: [...AssetOperators, Roles.Hr] },
      { name: "disposal", icon: Trash2, roles: [Roles.FixedAssets, Roles.Finance, Roles.Administrator] },
    ],
  },
  {
    title: "INSIGHTS",
    routes: [
      { name: "reports", icon: BarChart3, roles: Management },
      { name: "data-assistant", icon: MessageCircle },
    ],
  },
];

export function canSee(route: DrawerRoute, userRoles: string[] | undefined): boolean {
  return !route.roles || route.roles.some((role) => userRoles?.includes(role));
}
