// components/navigation/custom-drawer-content.tsx
import { Pressable, View } from "react-native";
import { DrawerContentComponentProps, DrawerContentScrollView } from "expo-router/drawer";
import { LogOut, Monitor } from "lucide-react-native";

import { canSee, drawerSections } from "@/components/custom/navigation/drawer.config";
import { Icon } from "@/components/ui/icon";
import { Text } from "@/components/ui/text";
import { primaryRole } from "@/features/auth/auth.roles";
import { useLogout } from "@/features/auth/auth.queries";
import { useAuthStore } from "@/features/auth/auth.store";
import { cn } from "@/lib/utils";
import { initials } from "@/shared/format/format";

export function CustomDrawerContent(props: DrawerContentComponentProps) {
  const { state, descriptors, navigation } = props;
  const user = useAuthStore((s) => s.user);
  const logout = useLogout();
  const activeRoute = state.routes[state.index]?.name;

  return (
    <View className="bg-sidebar flex-1">
      <DrawerContentScrollView {...props} contentContainerStyle={{ paddingTop: 16 }}>
        <View className="mb-4 flex-row items-center gap-3 px-4">
          <View className="h-9 w-9 items-center justify-center rounded-lg bg-sky-500">
            <Icon as={Monitor} size={18} className="text-white" />
          </View>
          <View>
            <Text className="text-base font-bold text-white">Asset Hub</Text>
            <Text className="text-sidebar-foreground text-xs">Fixed Assets</Text>
          </View>
        </View>

        {drawerSections.map((section) => {
          const routes = section.routes.filter((route) => canSee(route, user?.roles));
          if (routes.length === 0) return null;
          return (
            <View key={section.title} className="mb-2">
              <Text className="text-sidebar-foreground/70 px-4 pb-1 pt-2 text-[10px] font-semibold tracking-widest">{section.title}</Text>
              {routes.map((route) => {
                const options = descriptors[state.routes.find((r) => r.name === route.name)?.key ?? ""]?.options;
                const focused = activeRoute === route.name;
                return (
                  <Pressable
                    key={route.name}
                    onPress={() => navigation.navigate(route.name)}
                    className={cn("mx-2 flex-row items-center gap-3 rounded-lg px-3 py-2", focused ? "bg-sidebar-active border-l-2 border-sky-400" : "web:hover:bg-sidebar-active/60")}
                  >
                    <Icon as={route.icon} size={16} className={focused ? "text-white" : "text-sidebar-foreground"} />
                    <Text className={cn("text-sm", focused ? "font-semibold text-white" : "text-sidebar-foreground")}>
                      {options?.title ?? route.name}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          );
        })}
      </DrawerContentScrollView>

      <View className="border-t border-white/10 px-4 py-3">
        <View className="flex-row items-center gap-3">
          <View className="h-9 w-9 items-center justify-center rounded-full bg-violet-600">
            <Text className="text-xs font-bold text-white">{initials(user?.displayName)}</Text>
          </View>
          <View className="flex-1">
            <Text className="text-sm font-semibold text-white" numberOfLines={1}>{user?.displayName}</Text>
            <Text className="text-sidebar-foreground text-xs" numberOfLines={1}>{primaryRole(user?.roles)}</Text>
          </View>
          <Pressable accessibilityLabel="Sign out" onPress={() => logout.mutate()} hitSlop={8}>
            <Icon as={LogOut} size={16} className="text-sidebar-foreground" />
          </Pressable>
        </View>
      </View>
    </View>
  );
}
