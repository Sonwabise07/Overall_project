import { ScrollView, View } from "react-native";

import { SignInForm } from "@/components/sign-in-form";

export default function Login() {
  return (
    <ScrollView className="bg-sidebar" contentContainerClassName="flex-1 items-center justify-center p-4">
      <View className="w-full max-w-sm">
        <SignInForm />
      </View>
    </ScrollView>
  );
}
