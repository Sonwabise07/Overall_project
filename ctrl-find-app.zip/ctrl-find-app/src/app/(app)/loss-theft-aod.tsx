import { useState } from "react";
import { View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { AlertTriangle, DollarSign, Plus, Shield, Users } from "lucide-react-native";

import { InfoWidget, WidgetTones } from "@/components/custom/cards/info-widget";
import { DetailList } from "@/components/custom/detail/detail-list";
import { Callout, EmptyState, QueryBoundary } from "@/components/custom/feedback/state";
import { DateField, Field, FormMessage, FormRow, OptionPicker, SubmitButton } from "@/components/custom/forms/fields";
import { FileUpload } from "@/components/custom/forms/file-upload";
import { AssetPicker, EmployeePicker } from "@/components/custom/forms/pickers";
import { Columns, Page, Section, StatGrid } from "@/components/custom/layout/page";
import { StatusBadge } from "@/components/custom/status/status-badge";
import { Table } from "@/components/custom/table/table";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { Text } from "@/components/ui/text";
import { usePreselectedAsset } from "@/features/assets/assets.queries";
import { Roles, useHasRole } from "@/features/auth/auth.roles";
import { useAuthStore } from "@/features/auth/auth.store";
import { DocumentReferenceDto } from "@/features/documents/documents.types";
import { useAodRecords, useCreateIncident, useDecideNegligence, useIncidents, useRecordAodPayment } from "@/features/incidents/incidents.queries";
import { AodDto, IncidentDto, IncidentType, NegligenceStatus } from "@/features/incidents/incidents.types";
import { EmployeeDto } from "@/features/reference/reference.types";
import { formatDate, formatMoney, todayIso } from "@/shared/format/format";

const AOD_LABEL: Record<AodDto["status"], string> = { Open: "AOD active", InRecovery: "AOD active", Recovered: "Recovered", Cancelled: "Cancelled" };

export default function LossTheftAod() {
  const { assetId } = useLocalSearchParams<{ assetId?: string }>();
  const canSeeAod = useHasRole(Roles.Hr, Roles.Finance, Roles.FixedAssets, Roles.Administrator);
  const incidents = useIncidents();
  const aods = useAodRecords(canSeeAod);
  const [selectedId, setSelectedId] = useState<string>();
  const [reporting, setReporting] = useState(Boolean(assetId));
  const rows = incidents.data?.data ?? [];
  const aodRows = aods.data?.data ?? [];
  const selected = rows.find((i) => i.incidentId === selectedId) ?? rows.find((i) => i.status !== "Completed") ?? rows[0];
  const aodFor = (incident: IncidentDto) => aodRows.find((a) => a.incidentId === incident.incidentId);
  const quarterStart = new Date(new Date().getFullYear(), Math.floor(new Date().getMonth() / 3) * 3, 1);

  return (
    <Page
      title="Loss, theft & AOD"
      subtitle="Incident reporting, negligence status and Acknowledgement of Debt recovery"
      actions={
        <Button onPress={() => setReporting(!reporting)}>
          <Icon as={Plus} size={14} className="text-white" />
          <Text>Report loss or theft</Text>
        </Button>
      }
    >
      <StatGrid>
        <InfoWidget icon={AlertTriangle} heading={String(rows.filter((i) => new Date(i.request.incidentDate) >= quarterStart).length)} subheading="Loss / theft incidents" detail="this quarter" {...WidgetTones.red} />
        <InfoWidget icon={Shield} heading={String(rows.filter((i) => i.negligenceStatus === "UnderInvestigation").length)} subheading="Under investigation" detail="under review" {...WidgetTones.amber} />
        <InfoWidget icon={DollarSign} heading={canSeeAod ? String(aodRows.filter((a) => a.status === "Open" || a.status === "InRecovery").length) : "—"} subheading="Recovery in progress" detail="AOD active" {...WidgetTones.purple} />
        <InfoWidget icon={Users} heading={String(new Set(rows.filter((i) => i.escalatedToHr).map((i) => i.request.reportedByEmployeeId)).size)} subheading="Repeat-incident escalations" detail="escalated" {...WidgetTones.blue} />
      </StatGrid>

      {reporting ? <ReportForm assetId={assetId} onDone={(id) => { setReporting(false); setSelectedId(id); }} /> : null}

      <Columns
        main={
          <Section title="Incident register" description="Loss, theft and negligence cases">
            <QueryBoundary isLoading={incidents.isLoading} error={incidents.error} onRetry={incidents.refetch}>
              <Table
                rows={rows}
                rowKey={(row) => row.incidentId}
                selectedKey={selected?.incidentId}
                onRowPress={(row) => setSelectedId(row.incidentId)}
                minWidth={760}
                emptyText="No incidents reported."
                columns={[
                  { key: "employee", label: "Employee", flex: 1.1, render: (row) => <Text className="text-sm font-semibold">{row.employeeName ?? row.request.reportedByEmployeeId}</Text> },
                  { key: "asset", label: "Asset", flex: 1.6, value: (row) => [row.assetNo, row.assetDescription].filter(Boolean).join(" · ") },
                  { key: "incident", label: "Incident", flex: 1.2, value: (row) => `${row.incidentType} · ${formatDate(row.request.incidentDate)}` },
                  { key: "negligence", label: "Negligence status", flex: 1.3, render: (row) => <StatusBadge status={row.negligenceStatus} /> },
                  { key: "aod", label: "AOD", render: (row) => { const aod = aodFor(row); return aod ? <StatusBadge status={aod.status === "Recovered" ? "Recovered" : "InRecovery"} label={AOD_LABEL[aod.status]} /> : <Text className="text-sm">—</Text>; } },
                ]}
              />
            </QueryBoundary>
          </Section>
        }
        side={selected ? <IncidentPanel incident={selected} aod={aodFor(selected)} /> : <Section title="Incident"><EmptyState text="Choose an incident." /></Section>}
      />
    </Page>
  );
}

function IncidentPanel({ incident, aod }: { incident: IncidentDto; aod?: AodDto }) {
  const canDecide = useHasRole(Roles.Hr, Roles.FixedAssets, Roles.Administrator);
  const canRecordPayment = useHasRole(Roles.Hr, Roles.Finance, Roles.Administrator);
  const ordinal = ["First", "Second", "Third"][incident.employeeIncidentCount - 1] ?? `${incident.employeeIncidentCount}th`;

  return (
    <Section
      title={`${incident.employeeName ?? incident.request.reportedByEmployeeId} · ${incident.assetNo ?? ""}`}
      description={`${ordinal} recorded incident${incident.escalatedToHr ? " · escalation threshold reached" : ""}`}
    >
      <DetailList
        items={[
          { label: "Incident date", value: formatDate(incident.request.incidentDate) },
          { label: "Incident type", value: incident.incidentType },
          { label: "Location", value: incident.request.locationDescription },
          { label: "Police case number", value: incident.policeCaseNumber ?? "Not supplied (optional)" },
          { label: "Purchase cost (from Pastel)", value: formatMoney(incident.recordedPurchaseCost) },
          { label: "Negligence status", value: <StatusBadge status={incident.negligenceStatus} /> },
        ]}
      />
      <Text className="text-muted-foreground text-xs">{incident.request.description}</Text>
      {aod ? (
        <>
          <Callout tone="danger" title="AOD generated">
            Acknowledgement of Debt of {formatMoney(aod.amount)} linked to {incident.employeeName ?? "the employee"} and {incident.assetNo}. Terms: {aod.recoveryTerms}
          </Callout>
          <DetailList items={[{ label: "Recovered", value: `${formatMoney(aod.recoveredAmount)} of ${formatMoney(aod.amount)}` }, { label: "Recovery status", value: <StatusBadge status={aod.status} /> }]} />
          {canRecordPayment && (aod.status === "Open" || aod.status === "InRecovery") ? <PaymentForm aod={aod} /> : null}
        </>
      ) : null}
      {incident.escalatedToHr ? <Callout tone="warning">Repeated incidents for this employee reached the configured threshold and were escalated to HR and management.</Callout> : null}
      {canDecide && incident.negligenceStatus === "UnderInvestigation" ? <DecisionForm incident={incident} /> : null}
    </Section>
  );
}

function DecisionForm({ incident }: { incident: IncidentDto }) {
  const [status, setStatus] = useState<NegligenceStatus>();
  const [reason, setReason] = useState("");
  const [amount, setAmount] = useState(incident.recordedPurchaseCost ? String(incident.recordedPurchaseCost) : "");
  const [terms, setTerms] = useState("");
  const decide = useDecideNegligence();
  const negligent = status === "Negligent";
  return (
    <View className="border-border gap-3 rounded-lg border p-4">
      <Text className="text-sm font-semibold">Negligence decision</Text>
      <OptionPicker label="Decision" value={status} onChange={setStatus} options={[{ value: "Negligent", label: "Negligent" }, { value: "NotNegligent", label: "Not negligent" }]} />
      <Field label="Reason" value={reason} onChangeText={setReason} multiline />
      {negligent ? (
        <>
          <Field label="AOD amount (R)" value={amount} onChangeText={setAmount} keyboardType="numeric" hint="Defaults to the purchase cost recorded in Pastel." />
          <Field label="Recovery terms" value={terms} onChangeText={setTerms} placeholder="e.g. 6 monthly salary deductions" />
        </>
      ) : null}
      <FormMessage error={decide.error} />
      <SubmitButton
        label={negligent ? "Record decision and generate AOD" : "Record decision"}
        pending={decide.isPending}
        disabled={!status || !reason.trim() || (negligent && !terms.trim())}
        onPress={() =>
          decide.mutate({
            incidentId: incident.incidentId,
            payload: { negligenceStatus: status!, decisionReason: reason.trim(), aodAmount: negligent && amount ? Number(amount) : undefined, recoveryTerms: negligent ? terms.trim() : undefined },
          })
        }
      />
    </View>
  );
}

function PaymentForm({ aod }: { aod: AodDto }) {
  const [amount, setAmount] = useState("");
  const [paidOn, setPaidOn] = useState(todayIso());
  const [reference, setReference] = useState("");
  const pay = useRecordAodPayment();
  return (
    <View className="border-border gap-3 rounded-lg border p-4">
      <Text className="text-sm font-semibold">Record a recovery payment</Text>
      <FormRow>
        <Field label="Amount (R)" value={amount} onChangeText={setAmount} keyboardType="numeric" />
        <DateField label="Paid on" value={paidOn} onChangeText={setPaidOn} />
      </FormRow>
      <Field label="Reference (optional)" value={reference} onChangeText={setReference} />
      <FormMessage error={pay.error} success={pay.isSuccess && "Payment recorded."} />
      <SubmitButton label="Record payment" pending={pay.isPending} disabled={!(Number(amount) > 0)} onPress={() => pay.mutate({ aodId: aod.aodId, amount: Number(amount), paidOn, reference: reference.trim() || undefined })} />
    </View>
  );
}

function ReportForm({ assetId, onDone }: { assetId?: string; onDone: (incidentId: string) => void }) {
  const me = useAuthStore((s) => s.user);
  const isEmployeeOnly = !useHasRole(Roles.FixedAssets, Roles.OfficeManager, Roles.Hr, Roles.Administrator, Roles.Manager);
  const [asset, setAsset] = usePreselectedAsset(assetId);
  const [reporter, setReporter] = useState<EmployeeDto>();
  const [type, setType] = useState<IncidentType>("Loss");
  const [date, setDate] = useState(todayIso());
  const [where, setWhere] = useState("");
  const [description, setDescription] = useState("");
  const [police, setPolice] = useState("");
  const [report, setReport] = useState<DocumentReferenceDto>();
  const create = useCreateIncident();
  const reporterId = isEmployeeOnly ? me?.employeeId : reporter?.employeeId;


  return (
    <Section title="Report a loss or theft" description="The asset moves to Lost or Stolen and the case goes to HR and Fixed Assets for a negligence decision (BR-8.10).">
      <AssetPicker value={asset} onChange={setAsset} filters={isEmployeeOnly && me ? { assignedEmployeeId: me.employeeId } : undefined} />
      {!isEmployeeOnly ? <EmployeePicker label="Employee responsible" value={reporter} onChange={setReporter} /> : null}
      <OptionPicker label="Incident type" value={type} onChange={setType} options={[{ value: "Loss", label: "Loss" }, { value: "Theft", label: "Theft" }]} />
      <FormRow>
        <DateField label="Incident date" value={date} onChangeText={setDate} />
        <Field label="Where it happened" value={where} onChangeText={setWhere} />
      </FormRow>
      <Field label="What happened?" value={description} onChangeText={setDescription} multiline />
      <Field label="Police case number (optional)" value={police} onChangeText={setPolice} placeholder="e.g. CAS 214/09/2026" />
      {police.trim() ? <FileUpload assetId={asset?.assetId} documentType="PoliceReport" label="Police report (optional)" uploaded={report} onUploaded={setReport} /> : null}
      <FormMessage error={create.error} />
      <SubmitButton
        label="Report incident"
        pending={create.isPending}
        disabled={!asset || !reporterId || !where.trim() || !description.trim()}
        onPress={() =>
          asset &&
          reporterId &&
          create.mutate(
            { assetId: asset.assetId, incidentType: type, reportedByEmployeeId: reporterId, incidentDate: date, locationDescription: where.trim(), description: description.trim(), policeCaseNumber: police.trim() || undefined },
            { onSuccess: (response) => onDone(response.data.incidentId) },
          )
        }
      />
    </Section>
  );
}
