import { useState } from "react";
import { View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { AlertTriangle, ArrowRight, Clock, Home, Shuffle } from "lucide-react-native";

import { InfoWidget, WidgetTones } from "@/components/custom/cards/info-widget";
import { Callout, QueryBoundary } from "@/components/custom/feedback/state";
import { DateField, Field, FormMessage, OptionPicker, SubmitButton } from "@/components/custom/forms/fields";
import { FileUpload } from "@/components/custom/forms/file-upload";
import { AssetPicker, EmployeePicker, LocationPicker, StoreroomPicker } from "@/components/custom/forms/pickers";
import { Columns, Page, Section, StatGrid } from "@/components/custom/layout/page";
import { StatusBadge } from "@/components/custom/status/status-badge";
import { Table, TwoLine } from "@/components/custom/table/table";
import { Button } from "@/components/ui/button";
import { Text } from "@/components/ui/text";
import { useAlerts } from "@/features/alerts/alerts.queries";
import { useApproveTransfer, useAssets, useCreateAssetTransfer, useDeclineTransfer, usePreselectedAsset, useTransfers } from "@/features/assets/assets.queries";
import { CreateTransferRequest, TransferDto, TransferType } from "@/features/assets/assets.types";
import { Roles, useHasRole } from "@/features/auth/auth.roles";
import { DocumentReferenceDto } from "@/features/documents/documents.types";
import { useDepartments } from "@/features/reference/reference.queries";
import { EmployeeDto } from "@/features/reference/reference.types";
import { formatDate, humanise, todayIso } from "@/shared/format/format";

const TYPES: { value: TransferType; label: string; table: string }[] = [
  { value: "Employee", label: "Person", table: "Person to person" },
  { value: "Location", label: "Office", table: "Office to office" },
  { value: "Department", label: "Department", table: "Department" },
  { value: "Desk", label: "Desk", table: "Desk" },
  { value: "Storeroom", label: "Storeroom", table: "To storeroom" },
];
// Mirrors AssetRules:TransferTypesRequiringApproval in the API's appsettings.json.
const NEEDS_APPROVAL: TransferType[] = ["Employee", "Department"];

export default function Transfers() {
  const transfers = useTransfers();
  const held = useAssets({ lifecycleState: "HeldForReassignment", pageSize: 1 });
  const alerts = useAlerts();
  const canDecide = useHasRole(Roles.Manager, Roles.FixedAssets, Roles.Administrator);
  const rows = transfers.data?.data ?? [];

  return (
    <Page title="Transfers" subtitle="Employee, location, department and desk assignment changes">
      <StatGrid>
        <InfoWidget icon={Shuffle} heading={String(transfers.data?.meta.totalCount ?? rows.length)} subheading="Transfers logged" detail="all time" {...WidgetTones.blue} />
        <InfoWidget icon={Clock} heading={String(rows.filter((t) => t.status === "PendingApproval").length)} subheading="Pending approval" detail="awaiting manager" {...WidgetTones.amber} />
        <InfoWidget icon={Home} heading={String(held.data?.meta.totalCount ?? "—")} subheading="Held for reassignment" detail="held at desk" {...WidgetTones.purple} />
        <InfoWidget icon={AlertTriangle} heading={String((alerts.data?.data ?? []).filter((a) => a.type === "HoldExpired").length)} subheading="Reassignment period expired" detail="overdue" {...WidgetTones.red} />
      </StatGrid>

      <Columns
        main={
          <Section title="Transfer requests" description="Person-to-person, office-to-office, department and desk transfers">
            <QueryBoundary isLoading={transfers.isLoading} error={transfers.error} onRetry={transfers.refetch}>
              <Table
                rows={rows}
                rowKey={(row) => row.transferId}
                minWidth={760}
                emptyText="No transfers yet."
                columns={[
                  { key: "asset", label: "Asset", flex: 1.3, render: (row) => <TwoLine title={row.assetNo ?? row.assetId} subtitle={formatDate(row.requestedAt)} /> },
                  { key: "type", label: "Type", value: (row) => TYPES.find((t) => t.value === row.transferType)?.table ?? row.transferType },
                  { key: "fromTo", label: "From → to", flex: 1.8, value: (row) => `${row.fromValue ?? "—"} → ${row.toValue ?? "—"}` },
                  { key: "approval", label: "Approval", flex: 1.3, render: (row) => <StatusBadge status={row.status} label={row.status === "PendingApproval" ? "Awaiting manager" : row.status === "Completed" ? "Approved" : undefined} /> },
                  { key: "atom", label: "Atom sync", value: (row) => (row.atomSyncStatus ? humanise(row.atomSyncStatus) : "—") },
                ]}
              />
            </QueryBoundary>
            {canDecide ? <Approvals pending={rows.filter((t) => t.status === "PendingApproval")} /> : null}
          </Section>
        }
        side={<TransferForm />}
      />
    </Page>
  );
}

function Approvals({ pending }: { pending: TransferDto[] }) {
  if (pending.length === 0) return null;
  return (
    <View className="gap-3">
      <Text className="text-sm font-semibold">Waiting for your decision</Text>
      {pending.map((transfer) => (
        <Decision key={transfer.transferId} transfer={transfer} />
      ))}
    </View>
  );
}

function Decision({ transfer }: { transfer: TransferDto }) {
  const [reason, setReason] = useState("");
  const approve = useApproveTransfer();
  const decline = useDeclineTransfer();
  return (
    <View className="border-border gap-2 rounded-lg border p-3">
      <Text className="text-sm font-semibold">
        {transfer.assetNo} · {humanise(transfer.transferType)}: {transfer.fromValue ?? "—"} → {transfer.toValue ?? "—"}
      </Text>
      {transfer.reason ? <Text className="text-muted-foreground text-xs">{transfer.reason}</Text> : null}
      <Field label="Reason (needed to decline)" value={reason} onChangeText={setReason} />
      <FormMessage error={approve.error ?? decline.error} />
      <View className="flex-row gap-2">
        <Button size="sm" disabled={approve.isPending} onPress={() => approve.mutate({ transferId: transfer.transferId, reason: reason.trim() || undefined })}>
          <Text>Approve</Text>
        </Button>
        <Button size="sm" variant="outline" disabled={!reason.trim() || decline.isPending} onPress={() => decline.mutate({ transferId: transfer.transferId, reason: reason.trim() })}>
          <Text>Decline</Text>
        </Button>
      </View>
    </View>
  );
}

function TransferForm() {
  const { assetId } = useLocalSearchParams<{ assetId?: string }>();
  const departments = useDepartments();
  const create = useCreateAssetTransfer();
  const [type, setType] = useState<TransferType>("Employee");
  const [asset, setAsset] = usePreselectedAsset(assetId);
  const [employee, setEmployee] = useState<EmployeeDto>();
  const [target, setTarget] = useState<string>();
  const [desk, setDesk] = useState("");
  const [date, setDate] = useState(todayIso());
  const [reason, setReason] = useState("");
  const [custody, setCustody] = useState<DocumentReferenceDto>();


  const needsCustody = type === "Employee" && asset?.assetType === "Laptop";
  const targetValue = type === "Employee" ? employee?.employeeId : type === "Desk" ? desk.trim() : target;

  function changeType(value: TransferType) {
    setType(value);
    setTarget(undefined);
    setEmployee(undefined);
  }

  function submit() {
    if (!asset) return;
    const payload: CreateTransferRequest = {
      transferType: type,
      requestedDate: date,
      reason: reason.trim(),
      custodyAgreementDocumentId: custody?.documentId,
      targetEmployeeId: type === "Employee" ? targetValue : undefined,
      targetDepartmentId: type === "Department" ? targetValue : undefined,
      targetLocationId: type === "Location" ? targetValue : undefined,
      targetDesk: type === "Desk" ? targetValue : undefined,
      targetStoreroomId: type === "Storeroom" ? targetValue : undefined,
    };
    create.mutate({ assetId: asset.assetId, payload }, { onSuccess: () => { setReason(""); setCustody(undefined); } });
  }

  return (
    <Section title="Log a transfer">
      <OptionPicker label="Transfer type" value={type} onChange={changeType} options={TYPES.map((t) => ({ value: t.value, label: t.label }))} />
      <AssetPicker value={asset} onChange={(a) => { setAsset(a); setCustody(undefined); }} />
      {asset?.assignedEmployeeName ? <Text className="text-muted-foreground text-xs">Currently with {asset.assignedEmployeeName}</Text> : null}
      {type === "Employee" ? <EmployeePicker label="To employee" value={employee} onChange={setEmployee} /> : null}
      {type === "Location" ? <LocationPicker label="To office" value={target} onChange={setTarget} /> : null}
      {type === "Department" ? (
        <OptionPicker label="To department" value={target} onChange={setTarget} options={(departments.data?.data ?? []).map((d) => ({ value: d.departmentId, label: d.name }))} />
      ) : null}
      {type === "Desk" ? <Field label="To desk" value={desk} onChangeText={setDesk} placeholder="e.g. 3-22" /> : null}
      {type === "Storeroom" ? <StoreroomPicker label="To storeroom" value={target} onChange={setTarget} /> : null}
      {needsCustody ? <FileUpload assetId={asset?.assetId} documentType="CustodyAgreement" label="New custody agreement signed by the receiving employee" uploaded={custody} onUploaded={setCustody} /> : null}
      <DateField label="Transfer date" value={date} onChangeText={setDate} />
      <Field label="Reason" value={reason} onChangeText={setReason} />
      <Callout>
        {NEEDS_APPROVAL.includes(type) ? "Manager approval is required. " : "This transfer is applied immediately. "}
        Previous and new assignment details are stored in history. Atom sync is recorded but not sent until the Atom integration is confirmed as outbound.
      </Callout>
      <FormMessage error={create.error} success={create.isSuccess && (NEEDS_APPROVAL.includes(type) ? "Submitted for approval." : "Transfer applied.")} />
      <SubmitButton
        label={NEEDS_APPROVAL.includes(type) ? "Submit for approval" : "Apply transfer"}
        pending={create.isPending}
        disabled={!asset || !targetValue || !reason.trim() || (needsCustody && !custody)}
        onPress={submit}
      />
      <View className="flex-row items-center gap-1">
        <ArrowRight size={12} color="#64748b" />
        <Text className="text-muted-foreground text-xs">To hold an asset at a desk, use Hold for reassignment on the asset’s page.</Text>
      </View>
    </Section>
  );
}
