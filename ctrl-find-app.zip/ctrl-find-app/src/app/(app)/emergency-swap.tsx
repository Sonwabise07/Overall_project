import { useState } from "react";
import { View } from "react-native";
import { AlertTriangle, CheckCircle2, Clock, Plus, Zap } from "lucide-react-native";

import { InfoWidget, WidgetTones } from "@/components/custom/cards/info-widget";
import { Callout, EmptyState, QueryBoundary } from "@/components/custom/feedback/state";
import { Field, FormMessage, SubmitButton } from "@/components/custom/forms/fields";
import { FileUpload } from "@/components/custom/forms/file-upload";
import { AssetPicker, EmployeePicker } from "@/components/custom/forms/pickers";
import { Columns, Page, Section, StatGrid } from "@/components/custom/layout/page";
import { StatusBadge } from "@/components/custom/status/status-badge";
import { Table, TwoLine } from "@/components/custom/table/table";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { Text } from "@/components/ui/text";
import { AssetListItemDto } from "@/features/assets/assets.types";
import { DocumentReferenceDto } from "@/features/documents/documents.types";
import { useCreateEmergencySwap, useEmergencySwaps, useResolveEmergencySwap } from "@/features/emergency-swaps/emergency-swaps.queries";
import { EmergencySwapDto } from "@/features/emergency-swaps/emergency-swaps.types";
import { EmployeeDto } from "@/features/reference/reference.types";
import { cn } from "@/lib/utils";
import { daysFromToday, formatDateTime } from "@/shared/format/format";

const isOpen = (s: EmergencySwapDto) => s.status !== "Completed" && s.status !== "Cancelled";
const thisMonth = (value?: string | null) => Boolean(value) && value!.slice(0, 7) === new Date().toISOString().slice(0, 7);

function windowText(swap: EmergencySwapDto) {
  if (!isOpen(swap)) return "Resolved";
  const total = Math.max(1, Math.round((new Date(swap.resolveBy).getTime() - new Date(swap.reportedAt).getTime()) / 86_400_000));
  const left = daysFromToday(swap.resolveBy) ?? 0;
  return left < 0 ? "Window expired" : `${Math.min(total, total - left)} of ${total} days used`;
}

export default function EmergencySwap() {
  const swaps = useEmergencySwaps();
  const [selectedId, setSelectedId] = useState<string>();
  const [logging, setLogging] = useState(false);
  const rows = swaps.data?.data ?? [];
  const open = rows.filter(isOpen);
  const selected = rows.find((s) => s.swapId === selectedId) ?? open[0];

  return (
    <Page
      title="Emergency swap"
      subtitle="Temporary same-day / weekend replacement, logged without prior approval"
      actions={
        <Button onPress={() => setLogging(!logging)}>
          <Icon as={Plus} size={14} className="text-white" />
          <Text>Log a swap</Text>
        </Button>
      }
    >
      <StatGrid>
        <InfoWidget icon={Zap} heading={String(rows.filter((s) => thisMonth(s.reportedAt)).length)} subheading="Swaps logged" detail="this month" {...WidgetTones.blue} />
        <InfoWidget icon={Clock} heading={String(open.length)} subheading="Awaiting formal resolution" detail="open cases" {...WidgetTones.amber} />
        <InfoWidget icon={AlertTriangle} heading={String(open.filter((s) => s.isEscalated).length)} subheading="Past resolution window" detail="escalated" {...WidgetTones.red} />
        <InfoWidget icon={CheckCircle2} heading={String(rows.filter((s) => thisMonth(s.resolvedAt)).length)} subheading="Resolved this month" detail="resolved" {...WidgetTones.green} />
      </StatGrid>

      {logging ? <LogSwapForm onDone={() => setLogging(false)} /> : null}

      <Columns
        main={
          <Section title="Active emergency swaps" description="Logged without prior approval for same-day or weekend needs">
            <QueryBoundary isLoading={swaps.isLoading} error={swaps.error} onRetry={swaps.refetch}>
              <Table
                rows={rows}
                rowKey={(row) => row.swapId}
                selectedKey={selected?.swapId}
                onRowPress={(row) => setSelectedId(row.swapId)}
                minWidth={720}
                emptyText="No emergency swaps logged."
                columns={[
                  { key: "employee", label: "Employee", flex: 1.2, render: (row) => <Text className="text-sm font-semibold">{row.employeeName ?? row.employeeId}</Text> },
                  { key: "reported", label: "Issue reported", flex: 1.2, value: (row) => formatDateTime(row.reportedAt) },
                  { key: "temp", label: "Temp asset issued", flex: 1.4, render: (row) => <TwoLine title={row.temporaryAssetNo ?? row.temporaryAssetId} subtitle={row.issueDescription} /> },
                  { key: "window", label: "Resolution window", flex: 1.2, value: windowText },
                  { key: "status", label: "Status", render: (row) => <StatusBadge status={row.isEscalated && isOpen(row) ? "Escalated" : isOpen(row) ? "Healthy" : "Completed"} label={row.isEscalated && isOpen(row) ? "Escalated" : isOpen(row) ? "On track" : "Resolved"} /> },
                ]}
              />
            </QueryBoundary>
          </Section>
        }
        side={selected ? <SwapPanel swap={selected} /> : <Section title="Emergency swap"><EmptyState text="No open swaps." /></Section>}
      />
    </Page>
  );
}

// The six steps of BR-8.6, ticked from the case's own data.
function SwapPanel({ swap }: { swap: EmergencySwapDto }) {
  const [resolution, setResolution] = useState("");
  const resolve = useResolveEmergencySwap();
  const open = isOpen(swap);
  const left = daysFromToday(swap.resolveBy) ?? 0;
  const steps = [
    { label: "Employee reports the issue", done: true },
    { label: "Temporary asset issued immediately", done: true },
    { label: "Logged as Emergency Swap", done: true },
    { label: "Fixed Assets notified", done: swap.fixedAssetsNotified },
    { label: "Formal resolution (configurable period)", done: !open },
    { label: "Escalate if unresolved", done: swap.isEscalated },
  ];

  return (
    <Section title={`Emergency swap · ${swap.employeeName ?? swap.employeeId}`}>
      <View>
        {steps.map((step, index) => (
          <View key={step.label} className="border-border flex-row items-center gap-3 border-b py-3">
            <View className={cn("h-5 w-5 items-center justify-center rounded border", step.done ? "border-emerald-500 bg-emerald-500" : "border-input")}>
              {step.done ? <Icon as={CheckCircle2} size={12} className="text-white" /> : null}
            </View>
            <Text className="text-sm font-semibold">{index + 1}. {step.label}</Text>
          </View>
        ))}
      </View>
      {open ? (
        <>
          <Callout tone={left < 0 ? "danger" : "warning"}>
            {left < 0
              ? "The resolution window has passed. The case is escalated to Fixed Assets."
              : `Resolution due in ${left} day${left === 1 ? "" : "s"}. The case escalates to Fixed Assets automatically if it is not resolved by then.`}
          </Callout>
          <Field label="Resolution" value={resolution} onChangeText={setResolution} placeholder="e.g. Original laptop repaired and returned; temporary laptop back in stock" />
          <Text className="text-muted-foreground text-xs">The temporary asset keeps all laptop controls until it is returned (DEC-025).</Text>
          <FormMessage error={resolve.error} />
          <SubmitButton label="Record resolution" pending={resolve.isPending} disabled={!resolution.trim()} onPress={() => resolve.mutate({ swapId: swap.swapId, resolution: resolution.trim() })} />
        </>
      ) : (
        <Callout tone="success">Resolved: {swap.resolution ?? "—"}</Callout>
      )}
    </Section>
  );
}

function LogSwapForm({ onDone }: { onDone: () => void }) {
  const [employee, setEmployee] = useState<EmployeeDto>();
  const [original, setOriginal] = useState<AssetListItemDto>();
  const [temporary, setTemporary] = useState<AssetListItemDto>();
  const [issue, setIssue] = useState("");
  const [custody, setCustody] = useState<DocumentReferenceDto>();
  const create = useCreateEmergencySwap();
  const needsCustody = temporary?.assetType === "Laptop";

  return (
    <Section title="Log an emergency swap" description="Issue the temporary asset first; the case is logged and Fixed Assets is notified automatically.">
      <EmployeePicker value={employee} onChange={setEmployee} />
      <AssetPicker label="Faulty asset (optional)" value={original} onChange={setOriginal} filters={employee ? { assignedEmployeeId: employee.employeeId } : undefined} />
      <AssetPicker label="Temporary asset from stock" value={temporary} onChange={(a) => { setTemporary(a); setCustody(undefined); }} filters={{ operationalStatus: "InStorage" }} />
      {needsCustody ? <FileUpload assetId={temporary?.assetId} documentType="CustodyAgreement" label="Custody agreement for the temporary laptop" uploaded={custody} onUploaded={setCustody} /> : null}
      <Field label="Issue reported" value={issue} onChangeText={setIssue} multiline />
      <FormMessage error={create.error} />
      <SubmitButton
        label="Log swap"
        pending={create.isPending}
        disabled={!employee || !temporary || !issue.trim() || (needsCustody && !custody)}
        onPress={() =>
          employee &&
          temporary &&
          create.mutate(
            {
              employeeId: employee.employeeId,
              originalAssetId: original?.assetId,
              temporaryAssetId: temporary.assetId,
              issueDescription: issue.trim(),
              reportedAt: new Date().toISOString(),
              custodyAgreementDocumentId: custody?.documentId,
            },
            { onSuccess: onDone },
          )
        }
      />
    </Section>
  );
}
