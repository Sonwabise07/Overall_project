import { useState } from "react";
import { View } from "react-native";
import { CheckCircle2, Home, Plus, ShieldAlert, ShieldCheck } from "lucide-react-native";

import { InfoWidget, WidgetTones } from "@/components/custom/cards/info-widget";
import { BarList } from "@/components/custom/charts/charts";
import { DetailList } from "@/components/custom/detail/detail-list";
import { Callout, EmptyState, QueryBoundary } from "@/components/custom/feedback/state";
import { Checkbox, DateField, Field, FormMessage, FormRow, OptionPicker, SubmitButton } from "@/components/custom/forms/fields";
import { Chip, LocationPicker } from "@/components/custom/forms/pickers";
import { Columns, Page, Section, StatGrid } from "@/components/custom/layout/page";
import { StatusBadge } from "@/components/custom/status/status-badge";
import { Table, TwoLine } from "@/components/custom/table/table";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { Text } from "@/components/ui/text";
import {
  useAudits,
  useCloseAudit,
  useCreateAudit,
  useResolveAuditItem,
  useScanAuditAsset,
  useSendAuditSelfConfirmations,
} from "@/features/audits/audits.queries";
import { AuditDto, AuditItemDto } from "@/features/audits/audits.types";
import { Roles, useHasRole } from "@/features/auth/auth.roles";
import { useLocations } from "@/features/reference/reference.queries";
import { useOperationalDashboard } from "@/features/reporting/reporting.queries";
import { CONDITIONS, ConditionStatus } from "@/shared/api/api-common.types";
import { humanise, todayIso } from "@/shared/format/format";

const itemStatus = (item: AuditItemDto) =>
  item.resolved ? { status: "Completed", label: "Resolved" }
  : item.outcome === "SerialMismatch" ? { status: "Blocked", label: "Tamper alert" }
  : item.outcome === "AwaitingConfirmation" ? { status: "AwaitingConfirmation", label: "Awaiting reply" }
  : item.requiresInvestigation || item.outcome === "NotFound" ? { status: "UnderInvestigation", label: "Under investigation" }
  : { status: item.outcome ?? "Open", label: item.outcome ? humanise(item.outcome) : "Not yet checked" };

export default function AuditRisk() {
  const audits = useAudits();
  const dashboard = useOperationalDashboard();
  const [auditId, setAuditId] = useState<string>();
  const [itemId, setItemId] = useState<string>();
  const [creating, setCreating] = useState(false);
  const list = audits.data?.data ?? [];
  const audit = list.find((a) => a.auditId === auditId) ?? list.find((a) => a.status !== "Closed") ?? list[0];
  const items = audit?.items ?? [];
  const item = items.find((i) => i.auditItemId === itemId) ?? items.find((i) => i.outcome === "SerialMismatch" && !i.resolved);
  const risk = dashboard.data?.data.auditRisk;
  const percent = (value = 0) => (risk && risk.total > 0 ? Math.round((value / risk.total) * 100) : 0);

  return (
    <Page
      title="Audit & risk"
      subtitle="Exception-based sampling · tamper detection · remote self-confirmation"
      actions={
        <Button onPress={() => setCreating(!creating)}>
          <Icon as={Plus} size={14} className="text-white" />
          <Text>New audit</Text>
        </Button>
      }
    >
      <StatGrid>
        <InfoWidget icon={ShieldCheck} heading={String(items.length)} subheading="Flagged for this audit" detail="risk-weighted" {...WidgetTones.blue} />
        <InfoWidget icon={Home} heading={String(items.filter((i) => i.outcome === "AwaitingConfirmation").length)} subheading="Remote assets to confirm" detail="self-confirm" {...WidgetTones.purple} />
        <InfoWidget icon={ShieldAlert} heading={String(audit?.openInvestigations ?? 0)} subheading="Tamper alerts open" detail="mismatch" {...WidgetTones.red} />
        <InfoWidget icon={CheckCircle2} heading={String(items.filter((i) => i.resolved).length)} subheading="Discrepancies resolved this cycle" detail="resolved" {...WidgetTones.green} />
      </StatGrid>

      {creating ? <NewAuditForm onDone={(id) => { setCreating(false); setAuditId(id); }} /> : null}

      <QueryBoundary isLoading={audits.isLoading} error={audits.error} onRetry={audits.refetch}>
        {list.length > 0 ? (
          <View className="flex-row flex-wrap gap-2">
            {list.map((a) => (
              <Chip key={a.auditId} label={`${a.request.auditName} · ${humanise(a.status)}`} active={audit?.auditId === a.auditId} onPress={() => { setAuditId(a.auditId); setItemId(undefined); }} />
            ))}
          </View>
        ) : (
          <Callout>No audits yet. Start one with New audit; it samples flagged and unconfirmed assets, not the full register (BR-8.12-01).</Callout>
        )}
      </QueryBoundary>

      <Columns
        main={
          <>
            <Section title="Exception-based audit queue" description="Routine audits review only flagged or unconfirmed assets, not the full register">
              <Table
                rows={items}
                rowKey={(row) => row.auditItemId}
                selectedKey={item?.auditItemId}
                onRowPress={(row) => setItemId(row.auditItemId)}
                minWidth={720}
                emptyText={audit ? "Nothing flagged in this audit." : "Choose an audit."}
                columns={[
                  { key: "asset", label: "Asset", flex: 1.3, render: (row) => <TwoLine title={row.assetNo ?? "Unregistered tag"} subtitle={row.message} /> },
                  { key: "reason", label: "Reason flagged", flex: 1.4, value: (row) => row.reasonFlagged ?? "—" },
                  { key: "method", label: "Method", value: (row) => (row.method === "SelfConfirmation" ? "Self-confirmation" : "Physical scan") },
                  { key: "status", label: "Status", flex: 1.2, render: (row) => <StatusBadge {...itemStatus(row)} /> },
                ]}
              />
            </Section>
            {audit && audit.status !== "Closed" ? <AuditActions audit={audit} /> : null}
          </>
        }
        side={
          <Section title="Audit risk distribution">
            <BarList
              max={100}
              format={(v) => `${v}%`}
              points={[
                { label: "High risk", value: percent(risk?.high), colour: "bg-rose-500" },
                { label: "Medium risk", value: percent(risk?.medium), colour: "bg-amber-500" },
                { label: "Low risk", value: percent(risk?.low), colour: "bg-sky-500" },
              ]}
            />
            <Text className="text-muted-foreground text-xs">Score factors: asset age, value, incident history, location type</Text>
            {item && audit ? <ItemPanel audit={audit} item={item} /> : <EmptyState text="Choose an item in the queue." />}
          </Section>
        }
      />
    </Page>
  );
}

function ItemPanel({ audit, item }: { audit: AuditDto; item: AuditItemDto }) {
  const canResolve = useHasRole(Roles.FixedAssets, Roles.Administrator);
  const [resolution, setResolution] = useState("");
  const resolve = useResolveAuditItem();
  const hasDiscrepancy = Boolean(item.outcome && item.outcome !== "Confirmed" && item.outcome !== "AwaitingConfirmation");
  return (
    <View className="border-border gap-3 border-t pt-4">
      <Text className="text-sm font-semibold">
        {item.assetNo ?? "Unregistered tag"} · {itemStatus(item).label.toLowerCase()}
      </Text>
      <DetailList items={[{ label: "Method", value: humanise(item.method) }, { label: "Outcome", value: humanise(item.outcome) }, ...(item.resolution ? [{ label: "Resolution", value: item.resolution }] : [])]} />
      {item.requiresInvestigation && !item.resolved ? (
        <Callout tone="danger" title="Mismatch detected">
          Investigation case opened. This audit cannot be closed as a simple discrepancy until the investigation is resolved.
        </Callout>
      ) : null}
      {canResolve && hasDiscrepancy && !item.resolved ? (
        <>
          <Field label="Resolution" value={resolution} onChangeText={setResolution} placeholder="What was found and done" />
          <FormMessage error={resolve.error} />
          <SubmitButton label="Resolve" pending={resolve.isPending} disabled={!resolution.trim()} onPress={() => resolve.mutate({ auditId: audit.auditId, itemId: item.auditItemId, resolution: resolution.trim() })} />
        </>
      ) : null}
    </View>
  );
}

function AuditActions({ audit }: { audit: AuditDto }) {
  const [tag, setTag] = useState("");
  const [serial, setSerial] = useState("");
  const [locationId, setLocationId] = useState<string>();
  const [condition, setCondition] = useState<ConditionStatus>("Good");
  const scan = useScanAuditAsset();
  const send = useSendAuditSelfConfirmations();
  const close = useCloseAudit();

  return (
    <Section title={`Work this audit · ${audit.request.auditName}`} description={`${audit.openDiscrepancies} open discrepancies · ${audit.openInvestigations} open investigations`}>
      <Text className="text-sm font-semibold">Scan an asset</Text>
      <FormRow>
        <Field label="Asset tag" value={tag} onChangeText={setTag} />
        <Field label="Serial number (as printed)" value={serial} onChangeText={setSerial} />
      </FormRow>
      <LocationPicker label="Scanned at" value={locationId} onChange={setLocationId} />
      <OptionPicker label="Condition" value={condition} onChange={setCondition} options={CONDITIONS.map((c) => ({ value: c, label: c }))} />
      <FormMessage error={scan.error} success={scan.data?.data.message} />
      <SubmitButton
        label="Record scan"
        pending={scan.isPending}
        disabled={!tag.trim() || !serial.trim() || !locationId}
        onPress={() =>
          scan.mutate(
            { auditId: audit.auditId, payload: { assetTag: tag.trim(), serialNumber: serial.trim(), scannedLocationId: locationId!, conditionStatus: condition, scannedAt: new Date().toISOString() } },
            { onSuccess: () => { setTag(""); setSerial(""); } },
          )
        }
      />
      <View className="border-border flex-row flex-wrap gap-2 border-t pt-4">
        {!audit.selfConfirmationsSent ? (
          <SubmitButton label="Send self-confirmation requests" variant="outline" pending={send.isPending} onPress={() => send.mutate(audit.auditId)} />
        ) : (
          <Text className="text-muted-foreground self-center text-xs">Self-confirmation requests sent to remote holders.</Text>
        )}
        <SubmitButton label="Close audit" variant="outline" pending={close.isPending} onPress={() => close.mutate(audit.auditId)} />
      </View>
      <FormMessage error={send.error ?? close.error} />
    </Section>
  );
}

function NewAuditForm({ onDone }: { onDone: (auditId: string) => void }) {
  const locations = useLocations();
  const [name, setName] = useState("");
  const [locationIds, setLocationIds] = useState<string[]>([]);
  const [fullScope, setFullScope] = useState(false);
  const [start, setStart] = useState(todayIso());
  const [end, setEnd] = useState(todayIso(14));
  const create = useCreateAudit();
  const toggle = (id: string) => setLocationIds(locationIds.includes(id) ? locationIds.filter((l) => l !== id) : [...locationIds, id]);

  return (
    <Section title="New audit" description="Initiated by location. Assets are sampled by risk score and confirmation status (BR-8.12-01, BR-8.12-02).">
      <Field label="Audit name" value={name} onChangeText={setName} placeholder="e.g. Q4 HQ Sandton audit" />
      <View className="gap-1.5">
        <Text className="text-sm font-medium">Locations</Text>
        <View className="flex-row flex-wrap gap-2">
          {(locations.data?.data ?? []).map((l) => (
            <Chip key={l.locationId} label={l.name} active={locationIds.includes(l.locationId)} onPress={() => toggle(l.locationId)} />
          ))}
        </View>
      </View>
      <FormRow>
        <DateField label="Start" value={start} onChangeText={setStart} />
        <DateField label="End" value={end} onChangeText={setEnd} />
      </FormRow>
      <Checkbox label="Full-scope audit (every asset at these locations, not just the sample)" checked={fullScope} onChange={setFullScope} />
      <FormMessage error={create.error} />
      <SubmitButton
        label="Create audit"
        pending={create.isPending}
        disabled={!name.trim() || locationIds.length === 0}
        onPress={() => create.mutate({ auditName: name.trim(), locationIds, scheduledStartDate: start, scheduledEndDate: end, fullScope }, { onSuccess: (response) => onDone(response.data.auditId) })}
      />
    </Section>
  );
}
