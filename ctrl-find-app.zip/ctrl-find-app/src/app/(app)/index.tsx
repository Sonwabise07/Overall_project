import { useState } from "react";
import { View } from "react-native";
import { router } from "expo-router";
import { CalendarClock, Home, Monitor, ShieldAlert } from "lucide-react-native";

import { InfoWidget, WidgetTones } from "@/components/custom/cards/info-widget";
import { BarList } from "@/components/custom/charts/charts";
import { EmptyState, QueryBoundary } from "@/components/custom/feedback/state";
import { FormMessage, OptionPicker, Field, SubmitButton } from "@/components/custom/forms/fields";
import { Columns, Page, Section, StatGrid } from "@/components/custom/layout/page";
import { StatusBadge } from "@/components/custom/status/status-badge";
import { Table, TwoLine } from "@/components/custom/table/table";
import { Text } from "@/components/ui/text";
import { useAlerts } from "@/features/alerts/alerts.queries";
import { useAssets } from "@/features/assets/assets.queries";
import { useConfirmAuditItem, useMySelfConfirmations } from "@/features/audits/audits.queries";
import { AuditItemDto } from "@/features/audits/audits.types";
import { Management, useHasRole } from "@/features/auth/auth.roles";
import { useAuthStore } from "@/features/auth/auth.store";
import { useOperationalDashboard } from "@/features/reporting/reporting.queries";
import { CONDITIONS, ConditionStatus } from "@/shared/api/api-common.types";
import { formatDate, humanise, relativeDay } from "@/shared/format/format";

export default function Dashboard() {
  const isManagement = useHasRole(...Management);
  return (
    <Page title="Dashboard" subtitle={isManagement ? "Fixed Assets · overview" : "Your assets and what needs your attention"}>
      {isManagement ? <ManagementOverview /> : <MyAssets />}
      <MyConfirmations />
    </Page>
  );
}

function ManagementOverview() {
  const dashboard = useOperationalDashboard();
  const alerts = useAlerts();
  const d = dashboard.data?.data;
  const risk = d?.auditRisk;
  const percent = (value: number) => (risk && risk.total > 0 ? Math.round((value / risk.total) * 100) : 0);

  return (
    <QueryBoundary isLoading={dashboard.isLoading} error={dashboard.error} onRetry={dashboard.refetch}>
      {d ? (
        <>
          <StatGrid>
            <InfoWidget icon={Monitor} heading={d.totalAssets.toLocaleString("en-ZA")} subheading="Total registered assets" detail={`+${d.addedThisMonth} this mo.`} {...WidgetTones.blue} onPress={() => router.push("/asset-register")} />
            <InfoWidget icon={ShieldAlert} heading={String(d.flaggedForAudit)} subheading="Flagged for audit" detail="risk-weighted" {...WidgetTones.amber} onPress={() => router.push("/audit-risk")} />
            <InfoWidget icon={Home} heading={String(d.assetsAtHome)} subheading="Assets at home" detail="home use" {...WidgetTones.purple} onPress={() => router.push("/take-home-requests")} />
            <InfoWidget icon={CalendarClock} heading={String(d.overdueWarrantyOrMaintenance)} subheading="Overdue warranty / maint." detail="action needed" {...WidgetTones.red} onPress={() => router.push("/warranty")} />
          </StatGrid>

          <Columns
            main={
              <Section title="Audit risk distribution" description="Score factors: asset age, value, incident history, location type" action={<Text className="text-primary text-xs font-semibold">Risk-weighted sampling active</Text>}>
                <BarList
                  max={100}
                  format={(v) => `${v}%`}
                  points={[
                    { label: "High risk", value: percent(risk?.high ?? 0), colour: "bg-rose-500" },
                    { label: "Medium risk", value: percent(risk?.medium ?? 0), colour: "bg-amber-500" },
                    { label: "Low risk", value: percent(risk?.low ?? 0), colour: "bg-sky-500" },
                  ]}
                />
              </Section>
            }
            side={
              <Section title="Upcoming alerts">
                <QueryBoundary isLoading={alerts.isLoading} error={alerts.error}>
                  {(alerts.data?.data ?? []).length === 0 ? (
                    <EmptyState text="Nothing needs attention right now." />
                  ) : (
                    <View className="gap-3">
                      {(alerts.data?.data ?? []).slice(0, 5).map((alert, index) => (
                        <View key={`${alert.type}-${index}`} className="flex-row gap-3">
                          <View className={`mt-1.5 h-2 w-2 rounded-full ${alert.severity === "High" ? "bg-rose-500" : alert.severity === "Medium" ? "bg-amber-500" : "bg-sky-500"}`} />
                          <View className="flex-1">
                            <Text className="text-sm font-semibold">{alert.title}</Text>
                            <Text className="text-muted-foreground text-xs">{alert.detail}</Text>
                          </View>
                        </View>
                      ))}
                    </View>
                  )}
                </QueryBoundary>
              </Section>
            }
          />

          <Section title="Recent activity">
            <Table
              rows={d.recentActivity}
              rowKey={(row) => `${row.assetId}-${row.at}-${row.event}`}
              onRowPress={(row) => router.push({ pathname: "/asset-details", params: { assetId: row.assetId } })}
              columns={[
                { key: "asset", label: "Asset", flex: 2, render: (row) => <TwoLine title={row.assetNo} subtitle={row.assetDescription} /> },
                { key: "event", label: "Event", flex: 2, render: (row) => <TwoLine title={humanise(row.event)} subtitle={row.summary} /> },
                { key: "employee", label: "Employee", value: (row) => row.employee ?? "—" },
                { key: "date", label: "Date", value: (row) => relativeDay(row.at) },
              ]}
            />
          </Section>
        </>
      ) : null}
    </QueryBoundary>
  );
}

function MyAssets() {
  const employeeId = useAuthStore((s) => s.user?.employeeId);
  const assets = useAssets({ assignedEmployeeId: employeeId, pageSize: 50 }, Boolean(employeeId));
  const rows = assets.data?.data ?? [];

  return (
    <Section title="My assets" description="Assets assigned to you. Report a loss or a fault from the asset's page.">
      <QueryBoundary isLoading={assets.isLoading} error={assets.error} onRetry={assets.refetch}>
        <Table
          rows={rows}
          rowKey={(row) => row.assetId}
          emptyText="No assets are assigned to you."
          onRowPress={(row) => router.push({ pathname: "/asset-details", params: { assetId: row.assetId } })}
          columns={[
            { key: "asset", label: "Asset", flex: 2, render: (row) => <TwoLine title={row.assetNo} subtitle={humanise(row.assetType)} /> },
            { key: "model", label: "Make / model", flex: 2, value: (row) => [row.make, row.model].filter(Boolean).join(" ") },
            { key: "location", label: "Location", flex: 2, value: (row) => row.locationSummary },
            { key: "status", label: "Status", render: (row) => <StatusBadge status={row.lifecycleState} /> },
            { key: "warranty", label: "Warranty end", value: (row) => formatDate(row.warrantyEnd) },
          ]}
        />
      </QueryBoundary>
    </Section>
  );
}

// Remote audit: employees confirm assets at home by entering the serial number (BR-8.12-04).
function MyConfirmations() {
  const confirmations = useMySelfConfirmations();
  const items = confirmations.data?.data ?? [];
  if (items.length === 0) return null;

  return (
    <Section title="Please confirm your assets" description="An audit asked you to confirm these assets. Enter the serial number printed on each one.">
      <View className="gap-4">
        {items.map((item) => (
          <ConfirmItem key={item.auditItemId} item={item} />
        ))}
      </View>
    </Section>
  );
}

function ConfirmItem({ item }: { item: AuditItemDto }) {
  const [serial, setSerial] = useState("");
  const [condition, setCondition] = useState<ConditionStatus>("Good");
  const confirm = useConfirmAuditItem();

  return (
    <View className="border-border gap-3 rounded-lg border p-4">
      <Text className="text-sm font-semibold">{item.assetNo}</Text>
      <Field label="Serial number" value={serial} onChangeText={setSerial} placeholder="As printed on the asset" />
      <OptionPicker label="Condition" value={condition} onChange={setCondition} options={CONDITIONS.map((c) => ({ value: c, label: c }))} />
      <FormMessage error={confirm.error} success={confirm.isSuccess && "Thank you, your asset is confirmed."} />
      <SubmitButton
        label="Confirm asset"
        pending={confirm.isPending}
        disabled={!serial.trim()}
        onPress={() => confirm.mutate({ auditId: item.auditId!, itemId: item.auditItemId, serialNumber: serial.trim(), conditionStatus: condition })}
      />
    </View>
  );
}
