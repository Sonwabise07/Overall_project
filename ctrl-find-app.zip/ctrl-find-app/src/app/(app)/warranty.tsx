import { useState } from "react";
import { View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { CheckCircle2, Clock, ShieldCheck, Wrench } from "lucide-react-native";

import { InfoWidget, WidgetTones } from "@/components/custom/cards/info-widget";
import { DetailList } from "@/components/custom/detail/detail-list";
import { EmptyState, QueryBoundary } from "@/components/custom/feedback/state";
import { DateField, Field, FormMessage, FormRow, OptionPicker, SubmitButton } from "@/components/custom/forms/fields";
import { AssetPicker, Chip } from "@/components/custom/forms/pickers";
import { Columns, Page, Section, StatGrid } from "@/components/custom/layout/page";
import { StatusBadge, Tone } from "@/components/custom/status/status-badge";
import { Table, TwoLine } from "@/components/custom/table/table";
import { Text } from "@/components/ui/text";
import { useMaintenanceLog } from "@/features/assets/assets.queries";
import { AssetListItemDto } from "@/features/assets/assets.types";
import {
  useAddMaintenanceLog,
  useCloseWarrantyClaim,
  useCreateWarrantyClaim,
  useExpiringWarranties,
  useMaintenanceCases,
  useWarrantyClaims,
} from "@/features/maintenance/maintenance.queries";
import { WarrantyClaimDto } from "@/features/maintenance/maintenance.types";
import { formatDate, todayIso } from "@/shared/format/format";

const WINDOWS = [90, 180, 365];
const stageLabel = (stage: string) => (stage === "NotYetDue" ? "Not yet due" : stage.replace("DayAlert", "-day alert"));
const stageTone = (stage: string): Tone => (stage.startsWith("30") ? "danger" : stage.startsWith("60") ? "warning" : stage.startsWith("90") ? "info" : "neutral");
const thisMonth = (value?: string | null) => Boolean(value) && value!.slice(0, 7) === new Date().toISOString().slice(0, 7);

export default function Warranty() {
  const [days, setDays] = useState(90);
  const expiring = useExpiringWarranties(days);
  const claims = useWarrantyClaims();
  const [selectedId, setSelectedId] = useState<string>();
  const rows = expiring.data?.data ?? [];
  const claimRows = claims.data?.data ?? [];
  const active = claimRows.filter((c) => c.status !== "Completed");
  const selected = claimRows.find((c) => c.claimId === selectedId) ?? active[0];

  return (
    <Page title="Warranty" subtitle="Vendor, expiry alerts, claims and scheduled maintenance">
      <StatGrid>
        <InfoWidget icon={ShieldCheck} heading={String(rows.filter((r) => r.alertStage !== "NotYetDue").length)} subheading="Warranty alerts open" detail="expiring soon" {...WidgetTones.blue} />
        <InfoWidget icon={Clock} heading={String(rows.filter((r) => r.daysLeft <= 30).length)} subheading="Expiring within 30 days" detail="30 days" {...WidgetTones.amber} />
        <InfoWidget icon={Wrench} heading={String(active.length)} subheading="Warranty claims in progress" detail="active claims" {...WidgetTones.purple} />
        <InfoWidget icon={CheckCircle2} heading={String(claimRows.filter((c) => thisMonth(c.actualReturnDate)).length)} subheading="Claims returned this month" detail="returned" {...WidgetTones.green} />
      </StatGrid>

      <Columns
        main={
          <>
            <Section
              title="Warranty expiry tracker"
              description="Alerts generated at 90, 60 and 30 days ahead of expiry"
              action={
                <View className="flex-row gap-2">
                  {WINDOWS.map((w) => (
                    <Chip key={w} label={`${w} days`} active={days === w} onPress={() => setDays(w)} />
                  ))}
                </View>
              }
            >
              <QueryBoundary isLoading={expiring.isLoading} error={expiring.error} onRetry={expiring.refetch}>
                <Table
                  rows={rows}
                  rowKey={(row) => row.assetId}
                  onRowPress={(row) => router.push({ pathname: "/asset-details", params: { assetId: row.assetId } })}
                  emptyText={`No warranties end in the next ${days} days.`}
                  columns={[
                    { key: "asset", label: "Asset", flex: 1.8, render: (row) => <TwoLine title={row.assetNo} subtitle={[row.make, row.model].filter(Boolean).join(" ")} /> },
                    { key: "vendor", label: "Vendor", value: (row) => row.vendor ?? row.make ?? "—" },
                    { key: "end", label: "Warranty end", value: (row) => formatDate(row.warrantyEnd) },
                    { key: "days", label: "Days left", value: (row) => String(row.daysLeft) },
                    { key: "stage", label: "Alert stage", render: (row) => <StatusBadge tone={stageTone(row.alertStage)} label={stageLabel(row.alertStage)} /> },
                  ]}
                />
              </QueryBoundary>
            </Section>
            <Section title="Warranty claims">
              <QueryBoundary isLoading={claims.isLoading} error={claims.error} onRetry={claims.refetch}>
                <Table
                  rows={claimRows}
                  rowKey={(row) => row.claimId}
                  selectedKey={selected?.claimId}
                  onRowPress={(row) => setSelectedId(row.claimId)}
                  emptyText="No warranty claims."
                  columns={[
                    { key: "asset", label: "Asset", value: (row) => row.assetNo ?? row.assetId },
                    { key: "vendor", label: "Vendor", flex: 1.4, render: (row) => <TwoLine title={row.vendorName} subtitle={row.vendorReference} /> },
                    { key: "dispatch", label: "Dispatched", value: (row) => formatDate(row.dispatchDate) },
                    { key: "status", label: "Status", render: (row) => <StatusBadge status={row.status} /> },
                  ]}
                />
              </QueryBoundary>
              <NewClaimForm />
            </Section>
          </>
        }
        side={
          <>
            {selected ? <ClaimPanel claim={selected} /> : <Section title="Active warranty claim"><EmptyState text="No claims in progress." /></Section>}
            <MaintenanceLog />
          </>
        }
      />
    </Page>
  );
}

function ClaimPanel({ claim }: { claim: WarrantyClaimDto }) {
  const [returned, setReturned] = useState(todayIso());
  const [outcome, setOutcome] = useState("");
  const close = useCloseWarrantyClaim();
  const open = claim.status !== "Completed";
  return (
    <Section title={`${open ? "Active warranty claim" : "Warranty claim"} · ${claim.assetNo ?? ""}`}>
      <DetailList
        items={[
          { label: "Vendor", value: claim.vendorName },
          { label: "Dispatch date", value: formatDate(claim.dispatchDate) },
          { label: "Expected return", value: formatDate(claim.expectedReturnDate) },
          { label: "Actual return", value: formatDate(claim.actualReturnDate) },
          { label: "Asset status while active", value: <StatusBadge status={open ? "WarrantyClaim" : "Completed"} label={open ? "Warranty claim" : "Returned"} /> },
          ...(claim.outcome ? [{ label: "Outcome", value: claim.outcome }] : []),
        ]}
      />
      {open ? (
        <View className="gap-3">
          <DateField label="Actual return date" value={returned} onChangeText={setReturned} />
          <Field label="Vendor outcome" value={outcome} onChangeText={setOutcome} placeholder="e.g. Mainboard replaced under warranty" />
          <FormMessage error={close.error} />
          <SubmitButton label="Record return" pending={close.isPending} disabled={!outcome.trim()} onPress={() => close.mutate({ claimId: claim.claimId, actualReturnDate: returned, outcome: outcome.trim() })} />
        </View>
      ) : null}
    </Section>
  );
}

// A claim is raised from a fault whose outcome is Warranty claim (BR-8.9).
function NewClaimForm() {
  const { maintenanceCaseId } = useLocalSearchParams<{ maintenanceCaseId?: string }>();
  const cases = useMaintenanceCases(true);
  const claims = useWarrantyClaims(true);
  const waiting = (cases.data?.data ?? []).filter((c) => c.outcome === "WarrantyClaim" && !(claims.data?.data ?? []).some((cl) => cl.maintenanceCaseId === c.caseId));
  const [caseId, setCaseId] = useState<string | undefined>(maintenanceCaseId);
  const [vendor, setVendor] = useState("");
  const [reference, setReference] = useState("");
  const [dispatch, setDispatch] = useState(todayIso());
  const [expected, setExpected] = useState(todayIso(14));
  const create = useCreateWarrantyClaim();
  const chosen = waiting.find((c) => c.caseId === caseId);

  if (waiting.length === 0) return <Text className="text-muted-foreground text-xs">New claims start from a fault whose outcome is Warranty claim.</Text>;

  return (
    <View className="border-border gap-3 rounded-lg border p-4">
      <OptionPicker label="Raise a claim for" value={caseId} onChange={setCaseId} options={waiting.map((c) => ({ value: c.caseId, label: `${c.assetNo ?? c.assetId} · ${c.zendeskTicketId}` }))} />
      <FormRow>
        <Field label="Vendor" value={vendor} onChangeText={setVendor} />
        <Field label="Vendor reference" value={reference} onChangeText={setReference} />
      </FormRow>
      <FormRow>
        <DateField label="Dispatch date" value={dispatch} onChangeText={setDispatch} />
        <DateField label="Expected return" value={expected} onChangeText={setExpected} />
      </FormRow>
      <FormMessage error={create.error} success={create.isSuccess && "Claim raised."} />
      <SubmitButton
        label="Raise claim"
        pending={create.isPending}
        disabled={!chosen || !vendor.trim()}
        onPress={() =>
          chosen &&
          create.mutate({ assetId: chosen.assetId, maintenanceCaseId: chosen.caseId, vendorName: vendor.trim(), vendorReference: reference.trim() || undefined, dispatchDate: dispatch, expectedReturnDate: expected || undefined })
        }
      />
    </View>
  );
}

function MaintenanceLog() {
  const [asset, setAsset] = useState<AssetListItemDto>();
  const log = useMaintenanceLog(asset?.assetId);
  const [lastService, setLastService] = useState(todayIso());
  const [nextDue, setNextDue] = useState(todayIso(180));
  const [provider, setProvider] = useState("");
  const add = useAddMaintenanceLog();
  const latest = log.data?.data[0];

  return (
    <Section title="Maintenance log" description="Scheduled servicing per asset (BR-8.9-03)">
      <AssetPicker value={asset} onChange={setAsset} />
      {asset ? (
        <>
          <DetailList
            items={[
              { label: "Last service date", value: formatDate(latest?.lastServiceDate) },
              { label: "Next due date", value: formatDate(latest?.nextDueDate) },
              { label: "Service provider", value: latest?.serviceProvider ?? "—" },
            ]}
          />
          <FormRow>
            <DateField label="Serviced on" value={lastService} onChangeText={setLastService} />
            <DateField label="Next due" value={nextDue} onChangeText={setNextDue} />
          </FormRow>
          <Field label="Service provider" value={provider} onChangeText={setProvider} />
          <FormMessage error={add.error} success={add.isSuccess && "Service recorded."} />
          <SubmitButton
            label="Record service"
            pending={add.isPending}
            disabled={!provider.trim()}
            onPress={() => add.mutate({ assetId: asset.assetId, payload: { lastServiceDate: lastService, nextDueDate: nextDue || undefined, serviceProvider: provider.trim() } })}
          />
        </>
      ) : null}
    </Section>
  );
}
