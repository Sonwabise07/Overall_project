import { useState } from "react";
import { View } from "react-native";
import { AlertTriangle, CheckCircle2, Clock, LogOut, Plus, X } from "lucide-react-native";

import { InfoWidget, WidgetTones } from "@/components/custom/cards/info-widget";
import { Callout, EmptyState, QueryBoundary } from "@/components/custom/feedback/state";
import { DateField, Field, FormMessage, OptionPicker, SubmitButton } from "@/components/custom/forms/fields";
import { EmployeePicker, StoreroomPicker } from "@/components/custom/forms/pickers";
import { Columns, Page, Section, StatGrid } from "@/components/custom/layout/page";
import { StatusBadge } from "@/components/custom/status/status-badge";
import { Table } from "@/components/custom/table/table";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { Text } from "@/components/ui/text";
import { Roles, useHasRole } from "@/features/auth/auth.roles";
import { useCompleteOffboardingCase, useCreateOffboardingCase, useOffboardingCases, useResolveOffboardingItem } from "@/features/offboarding/offboarding.queries";
import { OffboardingCaseDto, OffboardingItemDto, OffboardingItemResolution } from "@/features/offboarding/offboarding.types";
import { EmployeeDto } from "@/features/reference/reference.types";
import { CONDITIONS, ConditionStatus } from "@/shared/api/api-common.types";
import { cn } from "@/lib/utils";
import { daysFromToday, formatDate, humanise, todayIso } from "@/shared/format/format";

const RESOLUTION_TEXT: Record<OffboardingItemResolution, string> = {
  Returned: "Returned to storeroom",
  HeldForReassignment: "Held at desk for reassignment",
  Escalated: "Escalated as lost or not returned",
  AuthorisedException: "Authorised exception by Fixed Assets",
};

export default function Offboarding() {
  const cases = useOffboardingCases(false);
  const [selectedId, setSelectedId] = useState<string>();
  const [creating, setCreating] = useState(false);
  const rows = (cases.data?.data ?? []).filter((c) => c.status !== "Cancelled");
  const open = rows.filter((c) => c.status !== "Completed");
  const selected = rows.find((c) => c.caseId === selectedId) ?? open[0];
  const quarterStart = new Date(new Date().getFullYear(), Math.floor(new Date().getMonth() / 3) * 3, 1);

  return (
    <Page
      title="Offboarding"
      subtitle="Recovery checklist triggered by Oracle exit notice · laptop recovery is blocking"
      actions={
        <Button onPress={() => setCreating(!creating)}>
          <Icon as={Plus} size={14} className="text-white" />
          <Text>New exit case</Text>
        </Button>
      }
    >
      <StatGrid>
        <InfoWidget icon={LogOut} heading={String(open.length)} subheading="Exit cases open" detail="open" {...WidgetTones.blue} />
        <InfoWidget icon={Clock} heading={String(open.filter((c) => (daysFromToday(c.exitDate) ?? 99) <= 7).length)} subheading="Exit approaching" detail="within 7 days" {...WidgetTones.amber} />
        <InfoWidget icon={AlertTriangle} heading={String(open.filter((c) => !c.laptopRecovered).length)} subheading="Laptop recovery outstanding" detail="blocking" {...WidgetTones.red} />
        <InfoWidget icon={CheckCircle2} heading={String(rows.filter((c) => c.status === "Completed" && new Date(c.exitDate) >= quarterStart).length)} subheading="Offboarded this quarter" detail="completed" {...WidgetTones.green} />
      </StatGrid>

      {creating ? <NewExitForm onDone={(id) => { setCreating(false); setSelectedId(id); }} /> : null}

      <Columns
        main={
          <Section title="Active exit cases" description="Triggered automatically by Oracle exit notice">
            <QueryBoundary isLoading={cases.isLoading} error={cases.error} onRetry={cases.refetch}>
              <Table
                rows={rows}
                rowKey={(row) => row.caseId}
                selectedKey={selected?.caseId}
                onRowPress={(row) => setSelectedId(row.caseId)}
                emptyText="No exit cases."
                columns={[
                  { key: "employee", label: "Employee", flex: 1.3, render: (row) => <Text className="text-sm font-semibold">{row.employeeName ?? row.employeeId}</Text> },
                  { key: "exit", label: "Exit date", value: (row) => formatDate(row.exitDate) },
                  { key: "assets", label: "Assets listed", value: (row) => String(row.items.length) },
                  { key: "laptop", label: "Laptop recovery", render: (row) => <StatusBadge status={row.laptopRecovered ? "Recovered" : "Blocked"} label={row.laptopRecovered ? "Recovered" : "Pending"} /> },
                  { key: "status", label: "Status", render: (row) => <StatusBadge status={row.status === "Completed" ? "Completed" : row.canComplete ? "InProgress" : "Blocked"} label={row.status === "Completed" ? "Complete" : row.canComplete ? "Ready to complete" : "Blocked"} /> },
                ]}
              />
            </QueryBoundary>
          </Section>
        }
        side={selected ? <Checklist item={selected} /> : <Section title="Recovery checklist"><EmptyState text="No open exit cases." /></Section>}
      />
    </Page>
  );
}

function Checklist({ item }: { item: OffboardingCaseDto }) {
  const complete = useCompleteOffboardingCase();
  const [resolvingId, setResolvingId] = useState<string>();
  const open = item.status !== "Completed";

  return (
    <Section title={`${item.employeeName ?? item.employeeId} · recovery checklist`} description={`Exit date ${formatDate(item.exitDate)} · cannot complete until every item is resolved`}>
      <View>
        {item.items.length === 0 ? <EmptyState text="No assets are assigned to this employee." /> : null}
        {item.items.map((asset) => (
          <View key={asset.assetId} className="border-border gap-3 border-b py-3">
            <View className="flex-row items-center gap-3">
              <View className={cn("h-6 w-6 items-center justify-center rounded", asset.resolution ? "bg-emerald-500" : "bg-rose-500")}>
                <Icon as={asset.resolution ? CheckCircle2 : X} size={14} className="text-white" />
              </View>
              <View className="flex-1">
                <Text className="text-sm font-semibold">{humanise(asset.assetType)} · {asset.assetNo}</Text>
                <Text className="text-muted-foreground text-xs">
                  {asset.resolution ? RESOLUTION_TEXT[asset.resolution] : `${asset.requiredForCompletion ? "Mandatory, blocking" : "Required"} · not yet recovered`}
                </Text>
              </View>
              {open && !asset.resolution ? (
                <Button size="sm" variant="outline" onPress={() => setResolvingId(resolvingId === asset.assetId ? undefined : asset.assetId)}>
                  <Text>{resolvingId === asset.assetId ? "Cancel" : "Resolve"}</Text>
                </Button>
              ) : null}
            </View>
            {resolvingId === asset.assetId ? <ResolveForm caseId={item.caseId} asset={asset} onDone={() => setResolvingId(undefined)} /> : null}
          </View>
        ))}
      </View>
      {open && !item.laptopRecovered ? (
        <Callout tone="danger">Offboarding cannot be marked complete while laptop recovery is outstanding. Fixed Assets can only proceed through an authorised exception.</Callout>
      ) : null}
      {item.blockingReasons.map((reason) => (
        <Text key={reason} className="text-sm text-rose-700">• {reason}</Text>
      ))}
      {open ? (
        <>
          <FormMessage error={complete.error} success={complete.isSuccess && "Offboarding complete."} />
          <SubmitButton label="Complete offboarding" pending={complete.isPending} disabled={!item.canComplete} onPress={() => complete.mutate(item.caseId)} />
        </>
      ) : (
        <Callout tone="success">Offboarding complete.</Callout>
      )}
    </Section>
  );
}

function ResolveForm({ caseId, asset, onDone }: { caseId: string; asset: OffboardingItemDto; onDone: () => void }) {
  const isFixedAssets = useHasRole(Roles.FixedAssets, Roles.Administrator);
  const options: OffboardingItemResolution[] = ["Returned", "HeldForReassignment", "Escalated", ...(isFixedAssets ? (["AuthorisedException"] as const) : [])];
  const [resolution, setResolution] = useState<OffboardingItemResolution>("Returned");
  const [condition, setCondition] = useState<ConditionStatus>("Good");
  const [storeroomId, setStoreroomId] = useState<string>();
  const [date, setDate] = useState(todayIso());
  const [notes, setNotes] = useState("");
  const resolve = useResolveOffboardingItem();
  const returned = resolution === "Returned";

  return (
    <View className="bg-muted/40 gap-3 rounded-lg p-3">
      <OptionPicker label="Resolution" value={resolution} onChange={setResolution} options={options.map((o) => ({ value: o, label: humanise(o) }))} />
      {returned ? (
        <>
          <OptionPicker label="Condition on return" value={condition} onChange={setCondition} options={CONDITIONS.map((c) => ({ value: c, label: c }))} />
          <StoreroomPicker value={storeroomId} onChange={setStoreroomId} />
          <DateField label="Returned on" value={date} onChangeText={setDate} />
        </>
      ) : null}
      <Field label={resolution === "AuthorisedException" ? "Reason for the exception (required)" : "Notes"} value={notes} onChangeText={setNotes} />
      <FormMessage error={resolve.error} />
      <SubmitButton
        label="Save"
        pending={resolve.isPending}
        disabled={(returned && !storeroomId) || (resolution === "AuthorisedException" && !notes.trim())}
        onPress={() =>
          resolve.mutate(
            {
              caseId,
              payload: {
                assetId: asset.assetId,
                resolution,
                conditionStatus: returned ? condition : undefined,
                storeroomId: returned ? storeroomId : undefined,
                returnedDate: returned ? date : undefined,
                notes: notes.trim() || undefined,
              },
            },
            { onSuccess: onDone },
          )
        }
      />
    </View>
  );
}

function NewExitForm({ onDone }: { onDone: (caseId: string) => void }) {
  const [employee, setEmployee] = useState<EmployeeDto>();
  const [exitDate, setExitDate] = useState(todayIso(14));
  const [reason, setReason] = useState("");
  const create = useCreateOffboardingCase();
  return (
    <Section title="New exit case" description="Oracle exit notices create these automatically. Use this form for manual or early notice.">
      <EmployeePicker value={employee} onChange={setEmployee} />
      <DateField label="Exit date" value={exitDate} onChangeText={setExitDate} />
      <Field label="Reason" value={reason} onChangeText={setReason} placeholder="e.g. Resignation" />
      <FormMessage error={create.error} />
      <SubmitButton
        label="Create exit case"
        pending={create.isPending}
        disabled={!employee || !reason.trim()}
        onPress={() => employee && create.mutate({ employeeId: employee.employeeId, exitDate, source: "Manual", reason: reason.trim() }, { onSuccess: (response) => onDone(response.data.caseId) })}
      />
    </Section>
  );
}
