import { useRef, useState } from "react";
import { Pressable, ScrollView, View } from "react-native";
import { router } from "expo-router";
import { Check, MessageSquarePlus, Send, ThumbsDown, ThumbsUp, Trash2 } from "lucide-react-native";

import { BarList, ColumnChart } from "@/components/custom/charts/charts";
import { Callout, QueryBoundary } from "@/components/custom/feedback/state";
import { Checkbox } from "@/components/custom/forms/fields";
import { Chip } from "@/components/custom/forms/pickers";
import { Columns, Page, Section } from "@/components/custom/layout/page";
import { Table } from "@/components/custom/table/table";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { Input } from "@/components/ui/input";
import { Text } from "@/components/ui/text";
import {
  useAskAssistant,
  useAssistantCatalog,
  useAssistantConversations,
  useAssistantFeedback,
  useDeleteAssistantConversation,
  useOpenAssistantConversation,
} from "@/features/assistant/assistant.queries";
import { AssistantAnswerDto, AssistantChart, AssistantConversation, AssistantTable } from "@/features/assistant/assistant.types";
import { cn } from "@/lib/utils";
import { getErrorMessage } from "@/shared/api/api-errors";
import { formatPeriod, relativeDay } from "@/shared/format/format";

type ChatMessage = { id: string; role: "user" | "assistant"; text: string; answer?: AssistantAnswerDto | null; failedQuestion?: string };

const WELCOME: ChatMessage = {
  id: "welcome",
  role: "assistant",
  text: "Hi! Ask me about your assets in plain English: counts, where things are, who has them, stock, warranty, audits, losses, costs and the workflows behind them. Every figure comes from Asset Hub's own records, within what you are allowed to see.",
  answer: {
    answer: "",
    sources: [],
    unsupported: false,
    suggestions: ["How many laptops are currently unconfirmed?", "Which office has the most audit exceptions?", "Show assets going out of warranty next month", "What needs my attention?"],
  },
};
const TABLE_ROWS = 10;
let nextId = 0;
const newId = () => `m${++nextId}`;

function fromConversation(conversation: AssistantConversation): ChatMessage[] {
  return conversation.messages.map((m) => ({ id: newId(), role: m.role, text: m.response?.answer ?? m.content, answer: m.response }));
}

export default function DataAssistant() {
  const [messages, setMessages] = useState<ChatMessage[]>([WELCOME]);
  const [question, setQuestion] = useState("");
  const [conversationId, setConversationId] = useState<string>();
  const [saveHistory, setSaveHistory] = useState(true);
  const scroll = useRef<ScrollView>(null);
  const ask = useAskAssistant();
  const open = useOpenAssistantConversation();

  function send(text = question) {
    const trimmed = text.trim();
    if (!trimmed || ask.isPending) return;
    setQuestion("");
    setMessages((current) => [...current, { id: newId(), role: "user", text: trimmed }]);
    ask.mutate(
      { question: trimmed, conversationId, saveHistory },
      {
        onSuccess: (response) => {
          setConversationId(response.data.conversationId ?? conversationId);
          setMessages((current) => [...current, { id: newId(), role: "assistant", text: response.data.answer, answer: response.data }]);
        },
        onError: (error) => setMessages((current) => [...current, { id: newId(), role: "assistant", text: getErrorMessage(error), failedQuestion: trimmed }]),
      },
    );
  }

  function startNew() {
    setMessages([WELCOME]);
    setConversationId(undefined);
  }

  function reopen(id: string) {
    open.mutate(id, {
      onSuccess: (response) => {
        setConversationId(response.data.conversationId);
        setMessages([WELCOME, ...fromConversation(response.data)]);
      },
    });
  }

  return (
    <Page
      title="Data assistant"
      subtitle="Plain-English questions, answered only from this system's own data"
      actions={
        <Button variant="outline" onPress={startNew}>
          <Icon as={MessageSquarePlus} size={14} />
          <Text>New chat</Text>
        </Button>
      }
    >
      <Columns
        main={
          <Section title="Ask about your assets" description="Answers only from this system's own data · never Atom directly · follow-ups like “what about Durban?” keep the context">
            <ScrollView
              ref={scroll}
              style={{ maxHeight: 620 }}
              contentContainerClassName="gap-4 pb-2"
              onContentSizeChange={() => scroll.current?.scrollToEnd({ animated: true })}
            >
              {messages.map((message) =>
                message.role === "user" ? (
                  <View key={message.id} className="max-w-[85%] self-end rounded-2xl rounded-br-md bg-sky-500 px-4 py-3">
                    <Text className="text-sm text-white">{message.text}</Text>
                  </View>
                ) : (
                  <AnswerBubble key={message.id} message={message} onAsk={send} />
                ),
              )}
              {ask.isPending ? (
                <View className="bg-muted self-start rounded-2xl rounded-bl-md px-4 py-3">
                  <Text className="text-muted-foreground text-sm">Checking the records…</Text>
                </View>
              ) : null}
            </ScrollView>
            <View className="border-border flex-row items-center gap-2 border-t pt-4">
              <Input
                className="flex-1"
                value={question}
                onChangeText={setQuestion}
                placeholder="Ask a question about assets, warranty, audits or losses…"
                returnKeyType="send"
                onSubmitEditing={() => send()}
                maxLength={500}
              />
              <Button size="icon" accessibilityLabel="Send" disabled={!question.trim() || ask.isPending} onPress={() => send()}>
                <Icon as={Send} size={16} className="text-white" />
              </Button>
            </View>
          </Section>
        }
        side={
          <>
            <Catalogue onAsk={send} />
            <SavedChats activeId={conversationId} saveHistory={saveHistory} onSaveHistory={setSaveHistory} onOpen={reopen} onDeleted={(id) => id === conversationId && startNew()} />
            {open.error ? <Callout tone="danger">{getErrorMessage(open.error)}</Callout> : null}
          </>
        }
      />
    </Page>
  );
}

function AnswerBubble({ message, onAsk }: { message: ChatMessage; onAsk: (question: string) => void }) {
  const answer = message.answer;
  const assetLinks = (answer?.sources ?? []).filter((s) => s.sourceType === "Asset");
  return (
    <View className={cn("bg-muted max-w-[92%] gap-3 self-start rounded-2xl rounded-bl-md px-4 py-3", (answer?.unsupported || message.failedQuestion) && "border border-amber-200 bg-amber-50")}>
      <Text className="text-sm leading-6">{message.text}</Text>
      {answer?.evidence ? <Text className="text-muted-foreground text-xs">{answer.evidence}</Text> : null}
      {answer?.chart && answer.chart.points.length > 0 ? <AnswerChart chart={answer.chart} /> : null}
      {answer?.table && answer.table.rows.length > 0 ? <AnswerTable table={answer.table} assetIds={new Map(assetLinks.map((s) => [s.label, s.sourceId]))} /> : null}
      {assetLinks.length > 0 && !answer?.table ? (
        <View className="flex-row flex-wrap gap-2">
          {assetLinks.slice(0, 8).map((s) => (
            <Chip key={s.sourceId} label={s.label} active={false} onPress={() => router.push({ pathname: "/asset-details", params: { assetId: s.sourceId } })} />
          ))}
        </View>
      ) : null}
      {message.failedQuestion ? (
        <Button variant="outline" size="sm" className="self-start" onPress={() => onAsk(message.failedQuestion!)}>
          <Text>Try again</Text>
        </Button>
      ) : null}
      {answer?.suggestions?.length ? (
        <View className="flex-row flex-wrap gap-2">
          {answer.suggestions.map((s) => (
            <Pressable key={s} onPress={() => onAsk(s)} className="border-border bg-card rounded-full border px-3 py-1.5 web:hover:bg-accent">
              <Text className="text-primary text-xs font-medium">{s}</Text>
            </Pressable>
          ))}
        </View>
      ) : null}
      {answer?.messageId ? <Feedback messageId={answer.messageId} /> : null}
    </View>
  );
}

function AnswerChart({ chart }: { chart: AssistantChart }) {
  const points = chart.points.map((p) => ({ label: formatPeriod(p.label), value: p.value }));
  return (
    <View className="border-border bg-card gap-3 rounded-xl border p-4">
      <Text className="text-xs font-semibold">{chart.title}</Text>
      {chart.type === "line" ? (
        <ColumnChart points={points.map((p) => ({ ...p, label: p.label.slice(0, 3) }))} />
      ) : (
        <BarList points={points.slice(0, 12)} format={(v) => v.toLocaleString("en-ZA")} />
      )}
      <Text className="text-muted-foreground text-[10px]">{chart.valueLabel}</Text>
    </View>
  );
}

// Rows that mention an asset number open that asset.
function AnswerTable({ table, assetIds }: { table: AssistantTable; assetIds: Map<string, string> }) {
  const [all, setAll] = useState(false);
  const rows = table.rows.map((cells, index) => ({ index, cells, assetId: cells.map((c) => (c ? assetIds.get(c) : undefined)).find(Boolean) }));
  const shown = all ? rows : rows.slice(0, TABLE_ROWS);
  return (
    <View className="border-border bg-card rounded-xl border p-3">
      <Table
        rows={shown}
        rowKey={(row) => String(row.index)}
        minWidth={Math.max(360, table.columns.length * 130)}
        onRowPress={rows.some((r) => r.assetId) ? (row) => row.assetId && router.push({ pathname: "/asset-details", params: { assetId: row.assetId } }) : undefined}
        columns={table.columns.map((label, i) => ({ key: `${i}-${label}`, label, flex: i === 0 ? 1.4 : 1, value: (row: (typeof rows)[number]) => row.cells[i] ?? "—" }))}
      />
      {table.rows.length > TABLE_ROWS || table.totalRows > table.rows.length ? (
        <View className="flex-row items-center justify-between gap-2 px-2 pt-2">
          <Text className="text-muted-foreground text-xs">
            Showing {shown.length} of {table.totalRows.toLocaleString("en-ZA")}
            {table.totalRows > table.rows.length ? ". Narrow the question to see the rest." : ""}
          </Text>
          {table.rows.length > TABLE_ROWS ? (
            <Pressable onPress={() => setAll(!all)}>
              <Text className="text-primary text-xs font-semibold">{all ? "Show fewer" : "Show all"}</Text>
            </Pressable>
          ) : null}
        </View>
      ) : null}
    </View>
  );
}

function Feedback({ messageId }: { messageId: string }) {
  const feedback = useAssistantFeedback();
  const [given, setGiven] = useState<boolean>();
  if (given !== undefined) {
    return (
      <View className="flex-row items-center gap-1">
        <Icon as={Check} size={12} className="text-emerald-600" />
        <Text className="text-muted-foreground text-xs">{given ? "Thanks for the feedback." : "Thanks. Unhelpful answers are reviewed to improve the assistant."}</Text>
      </View>
    );
  }
  const rate = (helpful: boolean) => feedback.mutate({ messageId, helpful }, { onSuccess: () => setGiven(helpful) });
  return (
    <View className="flex-row items-center gap-3">
      <Text className="text-muted-foreground text-xs">Was this helpful?</Text>
      <Pressable accessibilityLabel="Helpful" onPress={() => rate(true)} hitSlop={6}>
        <Icon as={ThumbsUp} size={14} className="text-muted-foreground" />
      </Pressable>
      <Pressable accessibilityLabel="Not helpful" onPress={() => rate(false)} hitSlop={6}>
        <Icon as={ThumbsDown} size={14} className="text-muted-foreground" />
      </Pressable>
    </View>
  );
}

function Catalogue({ onAsk }: { onAsk: (question: string) => void }) {
  const catalogue = useAssistantCatalog();
  return (
    <Section title="Supported question types" description="Tap an example to ask it">
      <QueryBoundary isLoading={catalogue.isLoading} error={catalogue.error}>
        <View>
          {(catalogue.data?.data ?? []).map((type) => (
            <View key={type.name} className="border-border gap-1.5 border-b py-3">
              <View className="flex-row items-center gap-2">
                <View className="h-5 w-5 items-center justify-center rounded bg-emerald-500">
                  <Icon as={Check} size={12} className="text-white" />
                </View>
                <Text className="text-sm font-semibold">{type.name}</Text>
              </View>
              <Text className="text-muted-foreground text-xs">{type.description}</Text>
              <View className="flex-row flex-wrap gap-x-3 gap-y-1">
                {type.examples.map((example) => (
                  <Pressable key={example} onPress={() => onAsk(example)}>
                    <Text className="text-primary text-xs">“{example}”</Text>
                  </Pressable>
                ))}
              </View>
            </View>
          ))}
        </View>
      </QueryBoundary>
      <Callout>Only ever reports figures actually present in the data. States plainly when a question is out of scope, rather than estimating an answer.</Callout>
    </Section>
  );
}

type SavedChatsProps = { activeId?: string; saveHistory: boolean; onSaveHistory: (value: boolean) => void; onOpen: (id: string) => void; onDeleted: (id: string) => void };

function SavedChats({ activeId, saveHistory, onSaveHistory, onOpen, onDeleted }: SavedChatsProps) {
  const conversations = useAssistantConversations();
  const remove = useDeleteAssistantConversation();
  const rows = conversations.data?.data ?? [];
  return (
    <Section title="Saved conversations">
      <Checkbox label="Save this conversation to my history" checked={saveHistory} onChange={onSaveHistory} />
      {rows.length === 0 ? <Text className="text-muted-foreground text-xs">No saved conversations yet.</Text> : null}
      {rows.slice(0, 10).map((c) => (
        <View key={c.conversationId} className={cn("flex-row items-center gap-2 rounded-md px-2 py-1.5", c.conversationId === activeId && "bg-accent")}>
          <Pressable className="flex-1" onPress={() => onOpen(c.conversationId)}>
            <Text className="text-sm font-medium" numberOfLines={1}>{c.title}</Text>
            <Text className="text-muted-foreground text-xs">{relativeDay(c.updatedAt)}</Text>
          </Pressable>
          <Pressable accessibilityLabel={`Delete ${c.title}`} hitSlop={6} onPress={() => remove.mutate(c.conversationId, { onSuccess: () => onDeleted(c.conversationId) })}>
            <Icon as={Trash2} size={14} className="text-muted-foreground" />
          </Pressable>
        </View>
      ))}
    </Section>
  );
}
