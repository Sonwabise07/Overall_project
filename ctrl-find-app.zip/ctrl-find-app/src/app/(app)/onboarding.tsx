import { useState } from "react";
import { Pressable, View } from "react-native";
import { AlertTriangle, CheckCircle2, Package, Plus, Users } from "lucide-react-native";

import { InfoWidget, WidgetTones } from "@/components/custom/cards/info-widget";
import { DetailList } from "@/components/custom/detail/detail-list";
import { Callout, EmptyState, QueryBoundary } from "@/components/custom/feedback/state";
import { Checkbox, DateField, Field, FormMessage, FormRow, OptionPicker, SubmitButton } from "@/components/custom/forms/fields";
import { EmployeePicker, LocationPicker } from "@/components/custom/forms/pickers";
import { Columns, Page, Section, StatGrid } from "@/components/custom/layout/page";
import { StatusBadge } from "@/components/custom/status/status-badge";
import { Table } from "@/components/custom/table/table";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { Text } from "@/components/ui/text";
import { Roles, useHasRole } from "@/features/auth/auth.roles";
import {
  useCreateOnboardingCase,
  useIssueOnboardingAssets,
  useOnboardingCases,
  useReserveOnboardingStock,
} from "@/features/onboarding/onboarding.queries";
import { CreateOnboardingCaseRequest, OnboardingCaseDto } from "@/features/onboarding/onboarding.types";
import { useDepartments, useRoleKits, useSaveRoleKit } from "@/features/reference/reference.queries";
import { EmployeeDto } from "@/features/reference/reference.types";
import { ASSET_TYPES, AssetType } from "@/shared/api/api-common.types";
import { cn } from "@/lib/utils";
import { formatDate, humanise, todayIso } from "@/shared/format/format";

// Pipeline columns follow the case's readiness (BR-8.4-01 to BR-8.4-05).
const STAGES: { title: string; states: OnboardingCaseDto["readinessState"][] }[] = [
  { title: "Notified (provisional)", states: ["Provisional"] },
  { title: "Confirmed · Oracle", states: ["NoKitDefined", "AwaitingStock"] },
  { title: "Stock reserved", states: ["ReadyToIssue"] },
  { title: "Issued · assigned", states: ["Issued"] },
];

export default function Onboarding() {
  const cases = useOnboardingCases(false);
  const [selectedId, setSelectedId] = useState<string>();
  const [creating, setCreating] = useState(false);
  const all = (cases.data?.data ?? []).filter((c) => c.status !== "Cancelled");
  const open = all.filter((c) => c.readinessState !== "Issued");
  const selected = all.find((c) => c.caseId === selectedId) ?? open.find((c) => c.isShortNotice) ?? open[0];

  return (
    <Page
      title="Onboarding"
      subtitle="New hire provisioning · recruitment + Oracle confirmation"
      actions={
        <Button onPress={() => setCreating(!creating)}>
          <Icon as={Plus} size={14} className="text-white" />
          <Text>New hire case</Text>
        </Button>
      }
    >
      <StatGrid>
        <InfoWidget icon={Users} heading={String(open.length)} subheading="New hire cases open" detail="open" {...WidgetTones.blue} />
        <InfoWidget icon={AlertTriangle} heading={String(open.filter((c) => c.isShortNotice).length)} subheading="Short-notice exceptions" detail="< 28 days notice" {...WidgetTones.red} />
        <InfoWidget icon={Package} heading={String(open.filter((c) => c.shortfalls.length > 0).length)} subheading="Stock shortfalls to fulfil" detail="action needed" {...WidgetTones.amber} />
        <InfoWidget icon={CheckCircle2} heading={String(open.filter((c) => c.readinessState === "ReadyToIssue").length)} subheading="Kits fully reserved" detail="on track" {...WidgetTones.green} />
      </StatGrid>

      {creating ? <NewHireForm onDone={() => setCreating(false)} /> : null}

      <Section title="Provisioning pipeline" description="Fed by recruitment placement data, confirmed by Oracle on start-date notice">
        <QueryBoundary isLoading={cases.isLoading} error={cases.error} onRetry={cases.refetch}>
          <View className="flex-row flex-wrap gap-4">
            {STAGES.map((stage) => {
              const items = all.filter((c) => stage.states.includes(c.readinessState));
              const shown = stage.states.includes("Issued") ? items.slice(0, 6) : items;
              return (
                <View key={stage.title} className="min-w-[220px] flex-1 gap-3">
                  <View className="flex-row items-center justify-between">
                    <Text className="text-muted-foreground text-sm font-semibold">{stage.title}</Text>
                    <View className="bg-muted rounded-full px-2 py-0.5">
                      <Text className="text-xs font-semibold">{items.length}</Text>
                    </View>
                  </View>
                  {shown.length === 0 ? <Text className="text-muted-foreground text-xs">None</Text> : null}
                  {shown.map((c) => (
                    <Pressable
                      key={c.caseId}
                      onPress={() => setSelectedId(c.caseId)}
                      className={cn("bg-card gap-1 rounded-lg border p-3 web:hover:bg-muted", selected?.caseId === c.caseId ? "border-primary" : "border-border")}
                    >
                      <Text className="text-sm font-semibold">{c.employeeName}</Text>
                      <Text className="text-muted-foreground text-xs">
                        {c.jobRole} · starts {formatDate(c.startDate)}
                      </Text>
                      {c.isShortNotice ? <StatusBadge status="Blocked" label="Short notice" /> : null}
                      {c.shortfalls.length > 0 ? <StatusBadge status="LowStock" label="Stock shortfall" /> : null}
                    </Pressable>
                  ))}
                </View>
              );
            })}
          </View>
        </QueryBoundary>
      </Section>

      <Columns main={<RoleKits />} side={selected ? <CasePanel item={selected} /> : <Section title="Case"><EmptyState text="Choose a case in the pipeline." /></Section>} />
    </Page>
  );
}

function CasePanel({ item }: { item: OnboardingCaseDto }) {
  const confirm = useCreateOnboardingCase();
  const reserve = useReserveOnboardingStock();
  const issue = useIssueOnboardingAssets();
  const [acknowledged, setAcknowledged] = useState(false);
  const stockCheck = item.shortfalls.length > 0 ? item.shortfalls.map((s) => `${s.quantity} × ${humanise(s.assetType)}`).join(", ") + " short" : item.reservedAssets.length > 0 ? "Kit reserved" : "Not reserved";
  const error = confirm.error ?? reserve.error ?? issue.error;

  // Oracle confirmation is the same case posted again with Source = Oracle (BR-8.4-02).
  const confirmPayload: CreateOnboardingCaseRequest = {
    employeeId: item.employeeId,
    employeeName: item.employeeName,
    departmentId: item.departmentId,
    jobRole: item.jobRole,
    locationId: item.locationId,
    startDate: item.startDate.slice(0, 10),
    source: "Oracle",
  };

  return (
    <Section title={`${item.employeeName}${item.isShortNotice ? " · short notice" : ""}`}>
      {item.isShortNotice ? (
        <Callout tone="danger" title="Flagged exception">
          Confirmed notice arrived less than 28 calendar days before the start date. The case is in the exception queue.
        </Callout>
      ) : null}
      <DetailList
        items={[
          { label: "Role profile", value: item.jobRole },
          { label: "Start date", value: formatDate(item.startDate) },
          { label: "Confirmed by Oracle", value: item.isConfirmed ? "Yes" : "Not yet" },
          { label: "Readiness", value: <StatusBadge tone={item.readinessState === "Issued" || item.readinessState === "ReadyToIssue" ? "success" : "warning"} label={humanise(item.readinessState)} /> },
          { label: "Stock check", value: <Text className={cn("text-sm font-semibold", item.shortfalls.length > 0 && "text-rose-700")}>{stockCheck}</Text> },
        ]}
      />
      {item.reservedAssets.length > 0 ? (
        <Text className="text-muted-foreground text-xs">Reserved: {item.reservedAssets.map((r) => r.assetNo ?? humanise(r.assetType)).join(", ")}</Text>
      ) : null}
      {item.shortfalls.length > 0 ? (
        <Callout tone="warning">
          Office/Building Manager notified automatically: {item.shortfalls.map((s) => `${s.quantity} × ${humanise(s.assetType).toLowerCase()}`).join(", ")} needed by {formatDate(item.shortfalls[0]!.neededBy)}.
        </Callout>
      ) : null}
      {item.blockingItems.map((reason) => (
        <Text key={reason} className="text-sm text-rose-700">• {reason}</Text>
      ))}

      {item.readinessState !== "Issued" ? (
        <View className="gap-3">
          <FormMessage error={error} success={issue.isSuccess && "Assets issued and assigned."} />
          <View className="flex-row flex-wrap gap-2">
            {!item.isConfirmed ? <SubmitButton label="Record Oracle confirmation" pending={confirm.isPending} onPress={() => confirm.mutate(confirmPayload)} /> : null}
            {item.shortfalls.length > 0 || item.reservedAssets.length === 0 ? (
              <SubmitButton label="Reserve stock" variant="outline" pending={reserve.isPending} onPress={() => reserve.mutate(item.caseId)} />
            ) : null}
          </View>
          {item.isConfirmed && item.reservedAssets.some((r) => !r.issued) ? (
            <View className="gap-2">
              <Checkbox label="Manager acknowledged (needed only if the new hire has a prior negligent loss)" checked={acknowledged} onChange={setAcknowledged} />
              <SubmitButton label="Issue reserved assets" pending={issue.isPending} onPress={() => issue.mutate({ caseId: item.caseId, managerAcknowledged: acknowledged })} />
              <Text className="text-muted-foreground text-xs">Laptops need a signed custody agreement uploaded on the laptop’s page first.</Text>
            </View>
          ) : null}
        </View>
      ) : null}
    </Section>
  );
}

function RoleKits() {
  const kits = useRoleKits();
  const canEdit = useHasRole(Roles.FixedAssets, Roles.Administrator);
  const [editing, setEditing] = useState(false);
  return (
    <Section
      title="Standard kit by role profile"
      action={canEdit ? <Button variant="outline" size="sm" onPress={() => setEditing(!editing)}><Text>{editing ? "Close" : "Define kit"}</Text></Button> : null}
    >
      <QueryBoundary isLoading={kits.isLoading} error={kits.error}>
        <Table
          rows={kits.data?.data ?? []}
          rowKey={(row) => row.jobRole}
          emptyText="No role kits defined. Onboarding waits until a kit exists for the job role."
          columns={[
            { key: "role", label: "Role", render: (row) => <Text className="text-sm font-semibold">{row.jobRole}</Text> },
            { key: "kit", label: "Kit", flex: 2.5, value: (row) => row.items.map((i) => `${i.quantity > 1 ? `${i.quantity} × ` : ""}${humanise(i.assetType).toLowerCase()}`).join(", ") },
            { key: "custody", label: "Custody agreement", render: (row) => (row.custodyAgreementRequired ? <StatusBadge status="Open" label="Required" /> : <Text className="text-sm">—</Text>) },
          ]}
        />
      </QueryBoundary>
      {editing ? <KitForm onDone={() => setEditing(false)} /> : null}
    </Section>
  );
}

function KitForm({ onDone }: { onDone: () => void }) {
  const [jobRole, setJobRole] = useState("");
  const [quantities, setQuantities] = useState<Partial<Record<AssetType, number>>>({});
  const save = useSaveRoleKit();
  const items = Object.entries(quantities).filter(([, q]) => (q ?? 0) > 0).map(([assetType, quantity]) => ({ assetType: assetType as AssetType, quantity: quantity! }));

  return (
    <View className="border-border gap-3 rounded-lg border p-4">
      <Field label="Job role" value={jobRole} onChangeText={setJobRole} placeholder="Exactly as it comes from recruitment, e.g. Team Leader" hint="Saving an existing role replaces its kit." />
      <View className="flex-row flex-wrap gap-x-6 gap-y-2">
        {ASSET_TYPES.map((type) => (
          <View key={type} className="w-[200px] flex-row items-center gap-2">
            <Checkbox label={humanise(type)} checked={(quantities[type] ?? 0) > 0} onChange={(checked) => setQuantities({ ...quantities, [type]: checked ? 1 : 0 })} />
            {(quantities[type] ?? 0) > 0 ? (
              <Button variant="outline" size="sm" onPress={() => setQuantities({ ...quantities, [type]: ((quantities[type] ?? 1) % 3) + 1 })}>
                <Text>× {quantities[type]}</Text>
              </Button>
            ) : null}
          </View>
        ))}
      </View>
      <FormMessage error={save.error} />
      <SubmitButton label="Save kit" pending={save.isPending} disabled={!jobRole.trim() || items.length === 0} onPress={() => save.mutate({ jobRole: jobRole.trim(), items }, { onSuccess: onDone })} />
    </View>
  );
}

function NewHireForm({ onDone }: { onDone: () => void }) {
  const departments = useDepartments();
  const create = useCreateOnboardingCase();
  const [existing, setExisting] = useState<EmployeeDto>();
  const [employeeId, setEmployeeId] = useState("");
  const [name, setName] = useState("");
  const [jobRole, setJobRole] = useState("");
  const [departmentId, setDepartmentId] = useState<string>();
  const [locationId, setLocationId] = useState<string>();
  const [startDate, setStartDate] = useState(todayIso(30));
  const [source, setSource] = useState<"Recruitment" | "Oracle">("Recruitment");
  const [manager, setManager] = useState<EmployeeDto>();

  function pickExisting(employee?: EmployeeDto) {
    setExisting(employee);
    if (!employee) return;
    setEmployeeId(employee.employeeId);
    setName(employee.fullName);
    setJobRole(employee.jobRole ?? "");
    setDepartmentId(employee.departmentId ?? undefined);
    setLocationId(employee.locationId ?? undefined);
  }

  return (
    <Section title="New hire case" description="Recruitment creates a provisional case. Oracle confirms it; notice is measured from confirmation.">
      <EmployeePicker label="Existing employee record (optional)" value={existing} onChange={pickExisting} />
      <FormRow>
        <Field label="Employee number" value={employeeId} onChangeText={setEmployeeId} />
        <Field label="Full name" value={name} onChangeText={setName} />
        <Field label="Job role" value={jobRole} onChangeText={setJobRole} />
      </FormRow>
      <OptionPicker label="Department" value={departmentId} onChange={setDepartmentId} options={(departments.data?.data ?? []).map((d) => ({ value: d.departmentId, label: d.name }))} />
      <LocationPicker value={locationId} onChange={setLocationId} />
      <EmployeePicker label="Manager (optional)" value={manager} onChange={setManager} />
      <FormRow>
        <DateField label="Start date" value={startDate} onChangeText={setStartDate} />
      </FormRow>
      <OptionPicker label="Source" value={source} onChange={setSource} options={[{ value: "Recruitment", label: "Recruitment (provisional)" }, { value: "Oracle", label: "Oracle (confirmed)" }]} />
      <FormMessage error={create.error} />
      <SubmitButton
        label="Create case"
        pending={create.isPending}
        disabled={!employeeId.trim() || !name.trim() || !jobRole.trim() || !departmentId || !locationId}
        onPress={() =>
          create.mutate(
            { employeeId: employeeId.trim(), employeeName: name.trim(), jobRole: jobRole.trim(), departmentId: departmentId!, locationId: locationId!, startDate, source, managerEmployeeId: manager?.employeeId },
            { onSuccess: onDone },
          )
        }
      />
    </Section>
  );
}
