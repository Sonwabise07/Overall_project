import { Pressable, useWindowDimensions, View } from "react-native";
import { router, usePathname } from "expo-router";
import { Drawer, DrawerToggleButton } from "expo-router/drawer";
import { MessageCircle } from "lucide-react-native";

import { CustomDrawerContent } from "@/components/custom/navigation/custom-drawer";
import { Icon } from "@/components/ui/icon";

const SCREENS: { name: string; title: string; hidden?: boolean }[] = [
  { name: "index", title: "Dashboard" },
  { name: "asset-register", title: "Asset register" },
  { name: "asset-details", title: "Asset details", hidden: true },
  { name: "register-asset", title: "Register asset", hidden: true },
  { name: "asset-locations", title: "Asset locations" },
  { name: "onboarding", title: "Onboarding" },
  { name: "take-home-requests", title: "Take-home requests" },
  { name: "transfers", title: "Transfers" },
  { name: "emergency-swap", title: "Emergency swap" },
  { name: "stock-storeroom", title: "Stock & storeroom" },
  { name: "faults-repairs", title: "Faults & repairs" },
  { name: "warranty", title: "Warranty" },
  { name: "loss-theft-aod", title: "Loss, theft & AOD" },
  { name: "audit-risk", title: "Audit & risk" },
  { name: "offboarding", title: "Offboarding" },
  { name: "disposal", title: "Disposal" },
  { name: "reports", title: "Reports" },
  { name: "data-assistant", title: "Data assistant" },
];

export default function AppLayout() {
  const { width } = useWindowDimensions();
  const pathname = usePathname();
  const wide = width >= 1024;

  return (
    <View className="flex-1">
      <Drawer
        screenOptions={{
          drawerType: wide ? "permanent" : "front",
          headerShown: !wide,
          headerLeft: () => <DrawerToggleButton />,
          drawerStyle: { width: 248, borderRightWidth: 0 },
        }}
        drawerContent={(props) => <CustomDrawerContent {...props} />}
      >
        {SCREENS.map((screen) => (
          <Drawer.Screen key={screen.name} name={screen.name} options={{ title: screen.title, drawerItemStyle: screen.hidden ? { display: "none" } : undefined }} />
        ))}
      </Drawer>

      {/* The Data Assistant is one tap away from every screen. */}
      {pathname !== "/data-assistant" ? (
        <Pressable
          accessibilityLabel="Open the Data Assistant"
          onPress={() => router.push("/data-assistant")}
          className="absolute bottom-6 right-6 h-14 w-14 items-center justify-center rounded-full bg-sky-500 shadow-lg shadow-black/20"
        >
          <Icon as={MessageCircle} size={24} className="text-white" />
        </Pressable>
      ) : null}
    </View>
  );
}
