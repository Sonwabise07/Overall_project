import { useState } from "react";
import { View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { AlertTriangle, CheckCircle2, Clock, Plus, Wrench } from "lucide-react-native";

import { InfoWidget, WidgetTones } from "@/components/custom/cards/info-widget";
import { DetailList } from "@/components/custom/detail/detail-list";
import { Callout, EmptyState, QueryBoundary } from "@/components/custom/feedback/state";
import { Field, FormMessage, OptionPicker, SubmitButton } from "@/components/custom/forms/fields";
import { AssetPicker, EmployeePicker } from "@/components/custom/forms/pickers";
import { Columns, Page, Section, StatGrid } from "@/components/custom/layout/page";
import { StatusBadge, Tone } from "@/components/custom/status/status-badge";
import { Table, TwoLine } from "@/components/custom/table/table";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { Text } from "@/components/ui/text";
import { usePreselectedAsset } from "@/features/assets/assets.queries";
import { AssetListItemDto } from "@/features/assets/assets.types";
import { Roles, useHasRole } from "@/features/auth/auth.roles";
import {
  useCloseRepair,
  useCreateMaintenanceCase,
  useDiagnoseMaintenanceCase,
  useMaintenanceCases,
  useRecordFaultOutcome,
} from "@/features/maintenance/maintenance.queries";
import { FaultClassification, FaultOutcome, MaintenanceCaseDto, RepairabilityDecision } from "@/features/maintenance/maintenance.types";
import { EmployeeDto } from "@/features/reference/reference.types";
import { formatDate, formatMoney, humanise } from "@/shared/format/format";

const CLASSIFICATIONS: FaultClassification[] = ["HardwareFailure", "AccidentalDamage", "WearAndTear", "Unknown"];
const CLASS_TONE: Record<FaultClassification, Tone> = { HardwareFailure: "info", AccidentalDamage: "danger", WearAndTear: "neutral", Unknown: "neutral" };
const DECISIONS: RepairabilityDecision[] = ["Repairable", "NonRepairable", "WarrantyClaimRequired", "PendingVendorAssessment"];
const OUTCOMES: FaultOutcome[] = ["Repair", "Replace", "WarrantyClaim", "Retire"];
const thisMonth = (value?: string | null) => Boolean(value) && value!.slice(0, 7) === new Date().toISOString().slice(0, 7);

export default function FaultsRepairs() {
  const { assetId } = useLocalSearchParams<{ assetId?: string }>();
  const cases = useMaintenanceCases();
  const [selectedId, setSelectedId] = useState<string>();
  const [logging, setLogging] = useState(Boolean(assetId));
  const rows = cases.data?.data ?? [];
  const selected = rows.find((c) => c.caseId === selectedId) ?? rows.find((c) => c.status !== "Completed") ?? rows[0];

  return (
    <Page
      title="Faults & repairs"
      subtitle="Hardware failure, accidental damage, wear and tear, or unknown · Zendesk-linked"
      actions={
        <Button onPress={() => setLogging(!logging)}>
          <Icon as={Plus} size={14} className="text-white" />
          <Text>Log fault</Text>
        </Button>
      }
    >
      <StatGrid>
        <InfoWidget icon={Wrench} heading={String(rows.filter((c) => thisMonth(c.reportedAt)).length)} subheading="Faults logged" detail="this month" {...WidgetTones.blue} />
        <InfoWidget icon={AlertTriangle} heading={String(rows.filter((c) => c.costRecoveryReview && c.status !== "Completed").length)} subheading="Accidental damage flags" detail="review needed" {...WidgetTones.red} />
        <InfoWidget icon={Clock} heading={String(rows.filter((c) => !c.diagnosis && c.status !== "Completed").length)} subheading="Diagnosis pending" detail="awaiting IT" {...WidgetTones.amber} />
        <InfoWidget icon={CheckCircle2} heading={String(rows.filter((c) => thisMonth(c.closedAt)).length)} subheading="Resolved this month" detail="closed" {...WidgetTones.green} />
      </StatGrid>

      {logging ? <LogFaultForm assetId={assetId} onDone={(caseId) => { setLogging(false); setSelectedId(caseId); }} /> : null}

      <Columns
        main={
          <Section title="Fault tickets" description="Every fault is linked to a Zendesk ticket for helpdesk review">
            <QueryBoundary isLoading={cases.isLoading} error={cases.error} onRetry={cases.refetch}>
              <Table
                rows={rows}
                rowKey={(row) => row.caseId}
                selectedKey={selected?.caseId}
                onRowPress={(row) => setSelectedId(row.caseId)}
                minWidth={760}
                emptyText="No faults logged."
                columns={[
                  { key: "asset", label: "Asset", flex: 1.6, render: (row) => <TwoLine title={row.assetNo ?? row.assetId} subtitle={row.assetDescription} /> },
                  { key: "ticket", label: "Ticket", value: (row) => row.zendeskTicketId },
                  { key: "class", label: "Classification", flex: 1.4, render: (row) => <StatusBadge tone={CLASS_TONE[row.classification]} label={humanise(row.classification)} /> },
                  { key: "diagnosis", label: "IT diagnosis", flex: 1.2, value: (row) => (row.repairabilityDecision ? humanise(row.repairabilityDecision) : "Diagnosing") },
                  { key: "outcome", label: "Outcome", render: (row) => (row.outcome ? <StatusBadge status={row.status === "Completed" ? "Completed" : "InProgress"} label={humanise(row.outcome)} /> : <Text className="text-muted-foreground text-sm">Pending</Text>) },
                ]}
              />
            </QueryBoundary>
          </Section>
        }
        side={selected ? <CasePanel item={selected} /> : <Section title="Fault"><EmptyState text="Choose a fault ticket." /></Section>}
      />
    </Page>
  );
}

function CasePanel({ item }: { item: MaintenanceCaseDto }) {
  const isHelpDesk = useHasRole(Roles.HelpDesk, Roles.Administrator);
  const isFixedAssets = useHasRole(Roles.FixedAssets, Roles.Administrator);
  const close = useCloseRepair();
  const open = item.status !== "Completed";

  return (
    <Section title={`${item.zendeskTicketId} · ${item.assetNo ?? ""}`} description={`${item.assetDescription ?? ""} · reported ${formatDate(item.reportedAt)}`}>
      <StatusBadge tone={CLASS_TONE[item.classification]} label={humanise(item.classification)} />
      <Text className="text-sm">{item.description}</Text>
      {item.costRecoveryReview ? <Callout tone="danger">Accidental damage: Fixed Assets reviews this case for cost recovery (BR-8.8-03).</Callout> : null}
      <DetailList
        items={[
          { label: "IT Help Desk diagnosis", value: item.diagnosis ? humanise(item.repairabilityDecision) : "Pending" },
          { label: "Estimated repair cost", value: item.estimatedRepairCost ? formatMoney(item.estimatedRepairCost) : "—" },
          { label: "Outcome", value: item.outcome ? humanise(item.outcome) : "Pending" },
          { label: "Replacement asset", value: item.replacementAssetId ?? "—" },
          { label: "Status", value: <StatusBadge status={item.status} /> },
        ]}
      />
      {item.diagnosis ? <Text className="text-muted-foreground text-xs">Diagnosis: {item.diagnosis}</Text> : null}
      {item.replacementAssetId ? (
        <Button variant="outline" size="sm" className="self-start" onPress={() => router.push({ pathname: "/asset-details", params: { assetId: item.replacementAssetId! } })}>
          <Text>Open replacement asset</Text>
        </Button>
      ) : null}

      {open && !item.diagnosis && isHelpDesk ? <DiagnoseForm item={item} /> : null}
      {open && !item.diagnosis && !isHelpDesk ? <Callout>Waiting for IT Help Desk to diagnose the fault.</Callout> : null}
      {open && item.diagnosis && !item.outcome && isFixedAssets ? <OutcomeForm item={item} /> : null}
      {open && item.outcome === "Repair" ? (
        <View className="gap-2">
          <FormMessage error={close.error} />
          <SubmitButton label="Close repair · asset back in service" pending={close.isPending} onPress={() => close.mutate(item.caseId)} />
        </View>
      ) : null}
      {open && item.outcome === "WarrantyClaim" ? (
        <Button variant="outline" size="sm" className="self-start" onPress={() => router.push({ pathname: "/warranty", params: { maintenanceCaseId: item.caseId } })}>
          <Text>Open warranty claim</Text>
        </Button>
      ) : null}
      <Callout>A replacement can only be issued once IT confirms non-repairable status on the Zendesk ticket. The replacement is linked to the original asset, the employee and the ticket.</Callout>
    </Section>
  );
}

function DiagnoseForm({ item }: { item: MaintenanceCaseDto }) {
  const [diagnosis, setDiagnosis] = useState("");
  const [decision, setDecision] = useState<RepairabilityDecision>();
  const [cost, setCost] = useState("");
  const diagnose = useDiagnoseMaintenanceCase();
  return (
    <View className="border-border gap-3 rounded-lg border p-4">
      <Text className="text-sm font-semibold">IT diagnosis</Text>
      <Field label="Diagnosis" value={diagnosis} onChangeText={setDiagnosis} multiline />
      <OptionPicker label="Repairability" value={decision} onChange={setDecision} options={DECISIONS.map((d) => ({ value: d, label: humanise(d) }))} />
      <Field label="Estimated repair cost (R, optional)" value={cost} onChangeText={setCost} keyboardType="numeric" />
      <FormMessage error={diagnose.error} />
      <SubmitButton
        label="Save diagnosis"
        pending={diagnose.isPending}
        disabled={!diagnosis.trim() || !decision}
        onPress={() => diagnose.mutate({ caseId: item.caseId, payload: { diagnosis: diagnosis.trim(), repairabilityDecision: decision!, estimatedRepairCost: cost.trim() ? Number(cost) : undefined } })}
      />
    </View>
  );
}

function OutcomeForm({ item }: { item: MaintenanceCaseDto }) {
  const nonRepairable = item.repairabilityDecision === "NonRepairable";
  const [outcome, setOutcome] = useState<FaultOutcome>();
  const [replacement, setReplacement] = useState<AssetListItemDto>();
  const [notes, setNotes] = useState("");
  const record = useRecordFaultOutcome();
  // Replace and Retire need a confirmed non-repairable diagnosis (BR-8.8-05).
  const allowed = OUTCOMES.filter((o) => nonRepairable || (o !== "Replace" && o !== "Retire"));

  return (
    <View className="border-border gap-3 rounded-lg border p-4">
      <Text className="text-sm font-semibold">Fixed Assets outcome</Text>
      <OptionPicker label="Outcome" value={outcome} onChange={setOutcome} options={allowed.map((o) => ({ value: o, label: humanise(o) }))} />
      {outcome === "Replace" ? <AssetPicker label="Replacement from stock (optional, otherwise the best match is chosen)" value={replacement} onChange={setReplacement} filters={{ lifecycleState: "InStorage" }} /> : null}
      <Field label="Notes" value={notes} onChangeText={setNotes} />
      <FormMessage error={record.error} />
      <SubmitButton
        label="Record outcome"
        pending={record.isPending}
        disabled={!outcome}
        onPress={() => record.mutate({ caseId: item.caseId, outcome: outcome!, replacementAssetId: replacement?.assetId, notes: notes.trim() || undefined })}
      />
    </View>
  );
}

function LogFaultForm({ assetId, onDone }: { assetId?: string; onDone: (caseId: string) => void }) {
  const [asset, setAsset] = usePreselectedAsset(assetId);
  const [reporter, setReporter] = useState<EmployeeDto>();
  const [classification, setClassification] = useState<FaultClassification>("HardwareFailure");
  const [ticket, setTicket] = useState("");
  const [description, setDescription] = useState("");
  const create = useCreateMaintenanceCase();


  return (
    <Section title="Log a fault" description="Create the Zendesk ticket first and enter its number here (BR-8.8-02).">
      <AssetPicker value={asset} onChange={setAsset} />
      <EmployeePicker label="Reported by" value={reporter} onChange={setReporter} />
      <OptionPicker label="Fault classification" value={classification} onChange={setClassification} options={CLASSIFICATIONS.map((c) => ({ value: c, label: humanise(c) }))} />
      <Field label="Zendesk ticket" value={ticket} onChangeText={setTicket} placeholder="e.g. ZD-88213" />
      <Field label="What is wrong?" value={description} onChangeText={setDescription} multiline />
      <FormMessage error={create.error} />
      <SubmitButton
        label="Log fault"
        pending={create.isPending}
        disabled={!asset || !reporter || !ticket.trim() || !description.trim()}
        onPress={() =>
          asset &&
          reporter &&
          create.mutate(
            { assetId: asset.assetId, reportedByEmployeeId: reporter.employeeId, classification, zendeskTicketId: ticket.trim(), description: description.trim(), reportedAt: new Date().toISOString() },
            { onSuccess: (response) => onDone(response.data.caseId) },
          )
        }
      />
    </Section>
  );
}
