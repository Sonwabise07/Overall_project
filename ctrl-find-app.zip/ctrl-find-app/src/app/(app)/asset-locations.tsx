import { View, Pressable } from "react-native";
import { router } from "expo-router";
import { Boxes, Building2, Home, MapPin } from "lucide-react-native";

import { InfoWidget, WidgetTones } from "@/components/custom/cards/info-widget";
import { QueryBoundary } from "@/components/custom/feedback/state";
import { Page, Section, StatGrid } from "@/components/custom/layout/page";
import { StatusBadge } from "@/components/custom/status/status-badge";
import { Table, TwoLine } from "@/components/custom/table/table";
import { Separator } from "@/components/ui/separator";
import { Text } from "@/components/ui/text";
import { useLocations } from "@/features/reference/reference.queries";
import { LocationSummaryDto } from "@/features/reference/reference.types";
import { useStockSummary } from "@/features/stock/stock.queries";
import { useTakeHomes } from "@/features/take-home/take-home.queries";
import { formatNumber } from "@/shared/format/format";

export default function AssetLocations() {
  const locations = useLocations();
  const stock = useStockSummary();
  const takeHomes = useTakeHomes();
  const rows = locations.data?.data ?? [];
  const regions = groupByRegion(rows);
  const buildings = new Set(rows.map((l) => `${l.region}|${l.building ?? l.name}`)).size;
  const storerooms = stock.data?.data.byStoreroom ?? [];
  const atHome = (takeHomes.data?.data ?? []).filter((t) => t.status === "AtHome").length;

  return (
    <Page title="Asset locations" subtitle="Region · building · floor · department · desk hierarchy">
      <StatGrid>
        <InfoWidget icon={MapPin} heading={String(regions.length)} subheading="Regions" detail={`${regions.length} regions`} {...WidgetTones.blue} />
        <InfoWidget icon={Building2} heading={String(buildings)} subheading="Buildings" detail={`${rows.length} sites`} {...WidgetTones.purple} />
        <InfoWidget icon={Boxes} heading={String(storerooms.length)} subheading="Storerooms" detail={`${storerooms.length} rooms`} {...WidgetTones.amber} onPress={() => router.push("/stock-storeroom")} />
        <InfoWidget icon={Home} heading={String(atHome)} subheading="Screens currently off-site" detail="At home" {...WidgetTones.green} onPress={() => router.push("/take-home-requests")} />
      </StatGrid>

      <QueryBoundary isLoading={locations.isLoading} error={locations.error} onRetry={locations.refetch}>
        <View className="flex-row flex-wrap gap-5">
          {regions.map(([region, sites]) => (
            <Section key={region} title={region} className="min-w-[300px] flex-1">
              {sites.map((site, index) => (
                <View key={site.locationId}>
                  {index > 0 ? <Separator /> : null}
                  <Pressable
                    onPress={() => router.push({ pathname: "/asset-register", params: { locationId: site.locationId } })}
                    className="flex-row items-center justify-between gap-3 rounded-md py-3 web:hover:bg-muted"
                  >
                    <TwoLine
                      title={site.name}
                      subtitle={[site.floor && `Floor ${site.floor}`, `${site.storeroomCount} storeroom${site.storeroomCount === 1 ? "" : "s"}`].filter(Boolean).join(" · ")}
                    />
                    <Text className="text-sm font-semibold">{formatNumber(site.assetCount)} assets</Text>
                  </Pressable>
                </View>
              ))}
            </Section>
          ))}
        </View>
      </QueryBoundary>

      <Section
        title="Storeroom stock by location"
        action={
          <Pressable onPress={() => router.push("/stock-storeroom")}>
            <Text className="text-primary text-sm font-semibold">Manage thresholds</Text>
          </Pressable>
        }
      >
        <QueryBoundary isLoading={stock.isLoading} error={stock.error} onRetry={stock.refetch}>
          <Table
            rows={storerooms}
            rowKey={(row) => row.storeroomId}
            emptyText="No storerooms set up."
            columns={[
              { key: "name", label: "Storeroom", flex: 1.4, render: (row) => <Text className="text-sm font-semibold">{row.name}</Text> },
              { key: "where", label: "Region / building", flex: 2, value: (row) => [row.region, row.building].filter(Boolean).join(" · ") || "—" },
              { key: "available", label: "Available", value: (row) => String(row.available) },
              { key: "reserved", label: "Reserved", value: (row) => String(row.reserved) },
              { key: "damaged", label: "Damaged", value: (row) => String(row.damaged) },
              { key: "status", label: "Status", render: (row) => <StatusBadge status={row.alert} /> },
            ]}
          />
        </QueryBoundary>
      </Section>
    </Page>
  );
}

function groupByRegion(locations: LocationSummaryDto[]): [string, LocationSummaryDto[]][] {
  const groups = new Map<string, LocationSummaryDto[]>();
  for (const location of locations) {
    const region = location.region ?? "Other";
    groups.set(region, [...(groups.get(region) ?? []), location]);
  }
  return [...groups.entries()];
}
