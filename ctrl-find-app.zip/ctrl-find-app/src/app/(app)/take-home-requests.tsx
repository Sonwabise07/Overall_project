import { useState } from "react";
import { View } from "react-native";
import { AlertTriangle, Home, Image as ImageIcon, Monitor, Plus } from "lucide-react-native";

import { InfoWidget, WidgetTones } from "@/components/custom/cards/info-widget";
import { AuthImage } from "@/components/custom/detail/auth-image";
import { DetailList } from "@/components/custom/detail/detail-list";
import { Callout, EmptyState, QueryBoundary } from "@/components/custom/feedback/state";
import { Checkbox, Field, FormMessage, OptionPicker, SubmitButton } from "@/components/custom/forms/fields";
import { FileUpload } from "@/components/custom/forms/file-upload";
import { AssetPicker, EmployeePicker } from "@/components/custom/forms/pickers";
import { Columns, Page, Section, StatGrid } from "@/components/custom/layout/page";
import { StatusBadge } from "@/components/custom/status/status-badge";
import { Table, TwoLine } from "@/components/custom/table/table";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { Text } from "@/components/ui/text";
import { AssetListItemDto } from "@/features/assets/assets.types";
import { AssetOperators, useHasRole } from "@/features/auth/auth.roles";
import { DocumentReferenceDto } from "@/features/documents/documents.types";
import { EmployeeDto } from "@/features/reference/reference.types";
import { useIssueTakeHome, useResolveDamageReview, useReturnTakeHome, useTakeHomes } from "@/features/take-home/take-home.queries";
import { TakeHomeDto } from "@/features/take-home/take-home.types";
import { CONDITIONS, ConditionStatus } from "@/shared/api/api-common.types";
import { formatDate } from "@/shared/format/format";

const photoUrl = (documentId?: string | null) => (documentId ? `/api/v1/documents/${documentId}/download` : undefined);
const thisMonth = (value?: string | null) => Boolean(value) && value!.slice(0, 7) === new Date().toISOString().slice(0, 7);

export default function TakeHomeRequests() {
  const takeHomes = useTakeHomes();
  const isOperator = useHasRole(...AssetOperators);
  const [selectedId, setSelectedId] = useState<string>();
  const [issuing, setIssuing] = useState(false);
  const rows = takeHomes.data?.data ?? [];
  const selected = rows.find((r) => r.takeHomeId === selectedId) ?? rows[0];
  const reviews = rows.filter((r) => r.status === "DamageReview");

  return (
    <Page
      title="Take-home requests"
      subtitle="Screens issued for home use · condition tracked at hand-over and return"
      actions={
        isOperator ? (
          <Button onPress={() => setIssuing(!issuing)}>
            <Icon as={Plus} size={14} className="text-white" />
            <Text>Issue a screen</Text>
          </Button>
        ) : null
      }
    >
      <StatGrid>
        <InfoWidget icon={Home} heading={String(rows.filter((r) => r.status === "AtHome").length)} subheading="Screens currently at home" detail="at home" {...WidgetTones.purple} />
        <InfoWidget icon={Monitor} heading={String(rows.filter((r) => thisMonth(r.issuedAt)).length)} subheading="Issued for home use this month" detail="this mo." {...WidgetTones.blue} />
        <InfoWidget icon={ImageIcon} heading={String(rows.filter((r) => thisMonth(r.returnedAt)).length)} subheading="Returned this month" detail="returned" {...WidgetTones.amber} />
        <InfoWidget icon={AlertTriangle} heading={String(reviews.length)} subheading="Damage-review cases open" detail="action needed" {...WidgetTones.red} />
      </StatGrid>

      {issuing ? <IssueForm onDone={() => setIssuing(false)} /> : null}

      <Columns
        main={
          <Section title="Home-use screens" description="Condition tracked at hand-over and again at return" action={<StatusBadge tone="neutral" label={`${rows.length} records`} />}>
            <QueryBoundary isLoading={takeHomes.isLoading} error={takeHomes.error} onRetry={takeHomes.refetch}>
              <Table
                rows={rows}
                rowKey={(row) => row.takeHomeId}
                selectedKey={selected?.takeHomeId}
                onRowPress={(row) => setSelectedId(row.takeHomeId)}
                minWidth={760}
                emptyText="No screens have been issued for home use."
                columns={[
                  { key: "asset", label: "Asset", flex: 1.6, render: (row) => <TwoLine title={row.assetDescription ?? row.assetNo ?? "—"} subtitle={row.assetNo} /> },
                  { key: "employee", label: "Employee", flex: 1.2, value: (row) => row.employeeName ?? row.employeeId },
                  { key: "issued", label: "Issued", value: (row) => formatDate(row.issuedAt) },
                  { key: "issueCondition", label: "Issue condition", render: (row) => <StatusBadge status={row.issueCondition} /> },
                  { key: "returned", label: "Returned", value: (row) => formatDate(row.returnedAt) },
                  { key: "returnCondition", label: "Return condition", render: (row) => (row.returnCondition ? <StatusBadge status={row.returnCondition} /> : <Text className="text-sm">—</Text>) },
                  { key: "status", label: "Status", render: (row) => <StatusBadge status={row.status} /> },
                ]}
              />
            </QueryBoundary>
          </Section>
        }
        side={
          <>
            {selected ? <RecordPanel item={selected} canAct={isOperator} /> : <Section title="Record"><EmptyState text="Choose a record." /></Section>}
            {reviews.map((review) => (
              <DamageReview key={review.takeHomeId} item={review} canAct={isOperator} />
            ))}
          </>
        }
      />
    </Page>
  );
}

function RecordPanel({ item, canAct }: { item: TakeHomeDto; canAct: boolean }) {
  return (
    <Section title={`${item.assetNo ?? ""}${item.assetDescription ? ` · ${item.assetDescription}` : ""}`} description={`Issued to ${item.employeeName ?? item.employeeId} for home use`}>
      <View className="flex-row gap-3">
        <AuthImage downloadUrl={photoUrl(item.issuePhotoDocumentId)} label="Hand-over photo" className="h-32 flex-1" />
        <AuthImage downloadUrl={photoUrl(item.returnPhotoDocumentId)} label="Return photo" className="h-32 flex-1" />
      </View>
      <DetailList
        items={[
          { label: "Condition at hand-over", value: <StatusBadge status={item.issueCondition} /> },
          { label: "Employee acknowledgement", value: `Confirmed · ${formatDate(item.acknowledgedAt)}` },
          { label: "Location sub-status", value: item.status === "AtHome" ? "At home" : "In office" },
        ]}
      />
      {item.status === "AtHome" ? (
        <>
          <Callout>On return, a new photo and condition rating are captured on the same scale. If the condition is worse than at hand-over, a damage-review case is created automatically.</Callout>
          {canAct ? <ReturnForm item={item} /> : null}
        </>
      ) : null}
    </Section>
  );
}

function ReturnForm({ item }: { item: TakeHomeDto }) {
  const [photo, setPhoto] = useState<DocumentReferenceDto>();
  const [condition, setCondition] = useState<ConditionStatus>(item.issueCondition);
  const [notes, setNotes] = useState("");
  const returnScreen = useReturnTakeHome();
  return (
    <View className="border-border gap-3 rounded-lg border p-4">
      <Text className="text-sm font-semibold">Record return</Text>
      <FileUpload assetId={item.assetId} documentType="Photo" label="Return photo" uploaded={photo} onUploaded={setPhoto} />
      <OptionPicker label="Condition at return" value={condition} onChange={setCondition} options={CONDITIONS.map((c) => ({ value: c, label: c }))} />
      <Field label="Notes" value={notes} onChangeText={setNotes} />
      <FormMessage error={returnScreen.error} success={returnScreen.isSuccess && "Return recorded."} />
      <SubmitButton
        label="Record return"
        pending={returnScreen.isPending}
        disabled={!photo}
        onPress={() => photo && returnScreen.mutate({ takeHomeId: item.takeHomeId, payload: { returnPhotoDocumentId: photo.documentId, returnCondition: condition, notes: notes.trim() || undefined } })}
      />
    </View>
  );
}

function DamageReview({ item, canAct }: { item: TakeHomeDto; canAct: boolean }) {
  const [outcome, setOutcome] = useState("");
  const resolve = useResolveDamageReview();
  return (
    <Section title={`${item.assetNo ?? "Screen"} · Damage review required`} className="border-rose-200">
      <DetailList
        items={[
          { label: "Issued", value: item.issueCondition },
          { label: "Returned", value: item.returnCondition ?? "—" },
        ]}
      />
      <Callout tone="danger" title="Variance detected">
        Condition dropped from {item.issueCondition} to {item.returnCondition} between hand-over and return. Flagged for Fixed Assets review.
      </Callout>
      {canAct ? (
        <>
          <Field label="Review outcome" value={outcome} onChangeText={setOutcome} placeholder="e.g. Fair wear, no further action" />
          <FormMessage error={resolve.error} />
          <SubmitButton label="Close review" pending={resolve.isPending} disabled={!outcome.trim()} onPress={() => resolve.mutate({ takeHomeId: item.takeHomeId, outcome: outcome.trim() })} />
        </>
      ) : null}
    </Section>
  );
}

function IssueForm({ onDone }: { onDone: () => void }) {
  const [asset, setAsset] = useState<AssetListItemDto>();
  const [employee, setEmployee] = useState<EmployeeDto>();
  const [photo, setPhoto] = useState<DocumentReferenceDto>();
  const [condition, setCondition] = useState<ConditionStatus>("Good");
  const [acknowledged, setAcknowledged] = useState(false);
  const issue = useIssueTakeHome();
  return (
    <Section title="Issue a screen for home use" description="Monitors only (BR-8.2). A hand-over photo, condition rating and the employee's acknowledgement are required.">
      <AssetPicker label="Screen" value={asset} onChange={(a) => { setAsset(a); setPhoto(undefined); }} filters={{ assetType: "Monitor" }} />
      <EmployeePicker value={employee} onChange={setEmployee} />
      <FileUpload assetId={asset?.assetId} documentType="Photo" label="Hand-over photo" uploaded={photo} onUploaded={setPhoto} />
      <OptionPicker label="Condition at hand-over" value={condition} onChange={setCondition} options={CONDITIONS.map((c) => ({ value: c, label: c }))} />
      <Checkbox label="The employee has seen the photo and condition and acknowledges the hand-over" checked={acknowledged} onChange={setAcknowledged} />
      <FormMessage error={issue.error} />
      <SubmitButton
        label="Issue screen"
        pending={issue.isPending}
        disabled={!asset || !employee || !photo || !acknowledged}
        onPress={() =>
          asset &&
          employee &&
          photo &&
          issue.mutate(
            { assetId: asset.assetId, employeeId: employee.employeeId, issuePhotoDocumentId: photo.documentId, issueCondition: condition, employeeAcknowledged: acknowledged },
            { onSuccess: onDone },
          )
        }
      />
    </Section>
  );
}
