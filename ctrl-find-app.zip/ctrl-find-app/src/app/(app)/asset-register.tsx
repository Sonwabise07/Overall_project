import { useState } from "react";
import { View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Boxes, Laptop, Monitor, MonitorSmartphone, Plus, Rows3 } from "lucide-react-native";

import { InfoWidget, WidgetTones } from "@/components/custom/cards/info-widget";
import { QueryBoundary } from "@/components/custom/feedback/state";
import { Chip } from "@/components/custom/forms/pickers";
import { Page, Section, StatGrid } from "@/components/custom/layout/page";
import { StatusBadge } from "@/components/custom/status/status-badge";
import { Table, TwoLine } from "@/components/custom/table/table";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { Input } from "@/components/ui/input";
import { Text } from "@/components/ui/text";
import { useAssets } from "@/features/assets/assets.queries";
import { AssetListParams } from "@/features/assets/assets.types";
import { Roles, useHasRole } from "@/features/auth/auth.roles";
import { useStockSummary } from "@/features/stock/stock.queries";
import { formatDate, humanise, relativeDay } from "@/shared/format/format";

const FILTERS: { label: string; params: AssetListParams }[] = [
  { label: "All assets", params: {} },
  { label: "In use", params: { operationalStatus: "InUse" } },
  { label: "In storage", params: { operationalStatus: "InStorage" } },
  { label: "In repair", params: { operationalStatus: "InRepair" } },
  { label: "Retired", params: { operationalStatus: "Retired" } },
  { label: "At home", params: { subStatus: "AtHome" } },
  { label: "Flagged", params: { flagged: true } },
];
const PAGE_SIZE = 25;

export default function AssetRegister() {
  const params = useLocalSearchParams<{ search?: string; locationId?: string }>();
  const [filter, setFilter] = useState(0);
  const [search, setSearch] = useState(params.search ?? "");
  const [page, setPage] = useState(1);
  const canRegister = useHasRole(Roles.FixedAssets, Roles.Administrator);

  // A new search from the page header replaces whatever was typed here.
  const [headerSearch, setHeaderSearch] = useState(params.search);
  if (params.search !== headerSearch) {
    setHeaderSearch(params.search);
    setSearch(params.search ?? "");
    setPage(1);
  }

  const query = { ...FILTERS[filter]!.params, locationId: params.locationId, search: search.trim() || undefined, page, pageSize: PAGE_SIZE };
  const assets = useAssets(query);
  const all = useAssets({ pageSize: 1 });
  const laptops = useAssets({ assetType: "Laptop", pageSize: 1 });
  const monitors = useAssets({ assetType: "Monitor", pageSize: 1 });
  const stock = useStockSummary();
  const spare = stock.data?.data.byType.reduce((sum, s) => sum + s.available, 0);
  const meta = assets.data?.meta;

  return (
    <Page
      title="Asset register"
      subtitle="Core register · search, filter and spare-stock lookup"
      actions={
        canRegister ? (
          <>
            <Button variant="outline" onPress={() => router.push({ pathname: "/register-asset", params: { mode: "bulk" } })}>
              <Icon as={Rows3} size={14} />
              <Text>Bulk register</Text>
            </Button>
            <Button onPress={() => router.push("/register-asset")}>
              <Icon as={Plus} size={14} className="text-white" />
              <Text>Register asset</Text>
            </Button>
          </>
        ) : null
      }
    >
      <StatGrid>
        <InfoWidget icon={MonitorSmartphone} heading={String(all.data?.meta.totalCount ?? "—")} subheading="Total registered assets" detail="in your view" {...WidgetTones.blue} />
        <InfoWidget icon={Laptop} heading={String(laptops.data?.meta.totalCount ?? "—")} subheading="Laptops in fleet" detail="laptops" {...WidgetTones.purple} />
        <InfoWidget icon={Monitor} heading={String(monitors.data?.meta.totalCount ?? "—")} subheading="Monitors in fleet" detail="monitors" {...WidgetTones.amber} />
        <InfoWidget icon={Boxes} heading={spare === undefined ? "—" : String(spare)} subheading="Spare stock available" detail="spare" {...WidgetTones.green} onPress={() => router.push("/stock-storeroom")} />
      </StatGrid>

      <Section title="Core asset register" description="Identification, ownership, location, assignment, status, financial and lifecycle data">
        <View className="flex-row flex-wrap items-center gap-2">
          {FILTERS.map((f, index) => (
            <Chip key={f.label} label={f.label} active={filter === index} onPress={() => { setFilter(index); setPage(1); }} />
          ))}
          {params.locationId ? <Chip label="One location · clear" active onPress={() => router.setParams({ locationId: undefined })} /> : null}
          <View className="min-w-[220px] flex-1">
            <Input value={search} onChangeText={(value) => { setSearch(value); setPage(1); }} placeholder="Search tag, serial, make, model or person" />
          </View>
        </View>

        <QueryBoundary isLoading={assets.isLoading} error={assets.error} onRetry={assets.refetch}>
          <Table
            rows={assets.data?.data ?? []}
            rowKey={(row) => row.assetId}
            minWidth={820}
            emptyText="No assets match this search."
            onRowPress={(row) => router.push({ pathname: "/asset-details", params: { assetId: row.assetId } })}
            columns={[
              { key: "asset", label: "Asset tag · type", flex: 1.4, render: (row) => <TwoLine title={row.assetNo} subtitle={`${row.assetTag ?? "Untagged"} · ${humanise(row.assetType)}`} /> },
              { key: "model", label: "Make / model", flex: 1.6, value: (row) => [row.make, row.model].filter(Boolean).join(" ") || "—" },
              { key: "holder", label: "Assigned to", flex: 1.3, value: (row) => row.assignedEmployeeName ?? "—" },
              { key: "location", label: "Location", flex: 2, value: (row) => row.locationSummary ?? "—" },
              { key: "status", label: "Status", flex: 1.2, render: (row) => <StatusBadge status={row.lifecycleState} /> },
              { key: "audit", label: "Last audit", flex: 1, value: (row) => (row.lastAuditDate ? relativeDay(row.lastAuditDate) : "Never") },
            ]}
            footer={meta ? `Showing ${(meta.page - 1) * meta.pageSize + (assets.data?.data.length ? 1 : 0)}–${(meta.page - 1) * meta.pageSize + (assets.data?.data.length ?? 0)} of ${meta.totalCount}. Warranty dates and full details are on each asset's page.` : undefined}
          />
          {meta && meta.totalPages > 1 ? (
            <View className="flex-row items-center justify-end gap-2">
              <Button variant="outline" size="sm" disabled={!meta.hasPreviousPage} onPress={() => setPage(page - 1)}>
                <Text>Previous</Text>
              </Button>
              <Text className="text-muted-foreground text-sm">Page {meta.page} of {meta.totalPages}</Text>
              <Button variant="outline" size="sm" disabled={!meta.hasNextPage} onPress={() => setPage(page + 1)}>
                <Text>Next</Text>
              </Button>
            </View>
          ) : null}
        </QueryBoundary>
      </Section>
      <Text className="text-muted-foreground text-xs">Last refreshed {formatDate(new Date().toISOString())}.</Text>
    </Page>
  );
}
