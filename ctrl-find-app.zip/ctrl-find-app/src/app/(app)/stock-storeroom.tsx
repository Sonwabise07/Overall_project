import { useState } from "react";
import { View } from "react-native";
import { AlertTriangle, Clock, Package, Wrench } from "lucide-react-native";

import { InfoWidget, WidgetTones } from "@/components/custom/cards/info-widget";
import { DetailList } from "@/components/custom/detail/detail-list";
import { Callout, QueryBoundary } from "@/components/custom/feedback/state";
import { Checkbox, DateField, Field, FormMessage, OptionPicker, SubmitButton } from "@/components/custom/forms/fields";
import { StoreroomPicker } from "@/components/custom/forms/pickers";
import { Columns, Page, Section, StatGrid } from "@/components/custom/layout/page";
import { StatusBadge } from "@/components/custom/status/status-badge";
import { Table } from "@/components/custom/table/table";
import { Button } from "@/components/ui/button";
import { Text } from "@/components/ui/text";
import { Roles, useHasRole } from "@/features/auth/auth.roles";
import { useRecordStockCount, useSetStockThreshold, useStockItems, useStockReconciliation, useStockSummary } from "@/features/stock/stock.queries";
import { StockTypeSummaryDto } from "@/features/stock/stock.types";
import { formatDate, humanise, todayIso } from "@/shared/format/format";

const signed = (value: number, sign: "+" | "-") => (value === 0 ? "0" : `${sign}${value}`);

export default function StockStoreroom() {
  const summary = useStockSummary();
  const canManage = useHasRole(Roles.FixedAssets, Roles.Administrator);
  const [storeroomId, setStoreroomId] = useState<string>();
  const s = summary.data?.data;
  const byType = s?.byType ?? [];
  const sum = (pick: (t: StockTypeSummaryDto) => number) => byType.reduce((total, t) => total + pick(t), 0);

  // Show the first storeroom's reconciliation until the user picks another.
  const activeStoreroom = storeroomId ?? s?.byStoreroom[0]?.storeroomId;

  return (
    <Page title="Stock & storeroom" subtitle="Available, reserved and damaged stock · thresholds and weekly counts">
      <StatGrid>
        <InfoWidget icon={Package} heading={String(sum((t) => t.available))} subheading="Available spare units" detail={`across ${s?.byStoreroom.length ?? 0} rooms`} {...WidgetTones.blue} />
        <InfoWidget icon={Clock} heading={String(sum((t) => t.reserved))} subheading="Reserved for onboarding" detail="reserved" {...WidgetTones.amber} />
        <InfoWidget icon={AlertTriangle} heading={String(byType.filter((t) => t.alert !== "Healthy").length)} subheading="Low / no stock alerts" detail="below threshold" {...WidgetTones.red} />
        <InfoWidget icon={Wrench} heading={String(sum((t) => t.damaged))} subheading="Damaged stock units" detail="damaged" {...WidgetTones.purple} />
      </StatGrid>

      <Columns
        main={
          <Section title="Stock by asset type" description="Minimum threshold configured per type">
            <QueryBoundary isLoading={summary.isLoading} error={summary.error} onRetry={summary.refetch}>
              <Table
                rows={byType}
                rowKey={(row) => row.assetType}
                emptyText="No stock recorded."
                columns={[
                  { key: "type", label: "Asset type", flex: 1.5, render: (row) => <Text className="text-sm font-semibold">{humanise(row.assetType)}</Text> },
                  { key: "available", label: "Available", value: (row) => String(row.available) },
                  { key: "reserved", label: "Reserved", value: (row) => String(row.reserved) },
                  { key: "damaged", label: "Damaged", value: (row) => String(row.damaged) },
                  { key: "threshold", label: "Threshold", value: (row) => (row.minimumThreshold === null || row.minimumThreshold === undefined ? "Not set" : String(row.minimumThreshold)) },
                  { key: "alert", label: "Alert", render: (row) => <StatusBadge status={row.alert} /> },
                ]}
              />
            </QueryBoundary>
            {canManage ? <ThresholdForm types={byType} /> : null}
          </Section>
        }
        side={<Reconciliation storeroomId={activeStoreroom} onStoreroom={setStoreroomId} />}
      />

      <Section title="Unfulfilled onboarding demand">
        <Table
          rows={s?.unfulfilledDemand ?? []}
          rowKey={(row) => `${row.caseId}-${row.assetType}`}
          emptyText="Every onboarding kit is covered by stock."
          columns={[
            { key: "type", label: "Asset type", render: (row) => <Text className="text-sm font-semibold">{humanise(row.assetType)}</Text> },
            { key: "for", label: "For", value: (row) => row.employeeName },
            { key: "quantity", label: "Quantity needed", value: (row) => String(row.quantity) },
            { key: "by", label: "Needed by", value: (row) => formatDate(row.neededBy) },
            { key: "notified", label: "Notified", flex: 1.5, value: () => "Office/Building Manager · auto-notified" },
          ]}
        />
      </Section>

      <CountForm />
    </Page>
  );
}

function ThresholdForm({ types }: { types: StockTypeSummaryDto[] }) {
  const [assetType, setAssetType] = useState<StockTypeSummaryDto["assetType"]>();
  const [minimum, setMinimum] = useState("");
  const save = useSetStockThreshold();
  return (
    <View className="border-border gap-3 rounded-lg border p-4">
      <OptionPicker label="Set a minimum threshold" value={assetType} onChange={setAssetType} options={types.map((t) => ({ value: t.assetType, label: humanise(t.assetType) }))} />
      <View className="flex-row items-end gap-3">
        <Field label="Minimum available" value={minimum} onChangeText={setMinimum} keyboardType="numeric" className="max-w-[200px]" />
        <SubmitButton label="Save threshold" pending={save.isPending} disabled={!assetType || !/^\d+$/.test(minimum)} onPress={() => save.mutate({ assetType: assetType!, minimum: Number(minimum) })} />
      </View>
      <FormMessage error={save.error} success={save.isSuccess && "Threshold saved."} />
    </View>
  );
}

// BR-8.7-03: Monday opening count, units out and in, Friday closing count and the expected figure.
function Reconciliation({ storeroomId, onStoreroom }: { storeroomId?: string; onStoreroom: (id: string) => void }) {
  const reconciliation = useStockReconciliation(storeroomId);
  const r = reconciliation.data?.data;
  const units = (value?: number | null) => (value === null || value === undefined ? "Not counted" : `${value} units`);
  return (
    <Section title="Weekly reconciliation">
      <StoreroomPicker value={storeroomId} onChange={onStoreroom} />
      <QueryBoundary isLoading={reconciliation.isLoading} error={reconciliation.error}>
        {r ? (
          <>
            <Text className="text-muted-foreground text-xs">Week starting {formatDate(r.weekStart)}</Text>
            <DetailList
              items={[
                { label: "Monday opening count", value: units(r.openingCount) },
                { label: "Issues this week", value: signed(r.unitsOut, "-") },
                { label: "Returns this week", value: signed(r.unitsIn, "+") },
                { label: "Friday closing count", value: units(r.closingCount) },
                { label: "Expected (reconciled)", value: units(r.expectedClosing) },
              ]}
            />
            {r.discrepancy ? (
              <Callout tone="warning" title={`Discrepancy of ${Math.abs(r.discrepancy)} unit${Math.abs(r.discrepancy) === 1 ? "" : "s"}`}>
                Visible in the stock-movement record, pending Fixed Assets review.
              </Callout>
            ) : r.closingCount !== null && r.closingCount !== undefined ? (
              <Callout tone="success">Closing count matches the expected figure.</Callout>
            ) : null}
          </>
        ) : null}
      </QueryBoundary>
    </Section>
  );
}

function CountForm() {
  const [open, setOpen] = useState(false);
  const [storeroomId, setStoreroomId] = useState<string>();
  const [countType, setCountType] = useState<"Opening" | "Closing">(new Date().getDay() >= 4 ? "Closing" : "Opening");
  const [date, setDate] = useState(todayIso());
  const [missing, setMissing] = useState<string[]>([]);
  const items = useStockItems({ storeroomId, pageSize: 200 });
  const record = useRecordStockCount();
  const stock = (items.data?.data ?? []).filter(() => Boolean(storeroomId));
  const counted = stock.filter((item) => !missing.includes(item.assetId));

  return (
    <Section
      title="Record a stock count"
      description="Untick anything that is not on the shelf. Conditions are saved with the count."
      action={<Button variant="outline" size="sm" onPress={() => setOpen(!open)}><Text>{open ? "Close" : "Start count"}</Text></Button>}
    >
      {open ? (
        <View className="gap-4">
          <StoreroomPicker value={storeroomId} onChange={(id) => { setStoreroomId(id); setMissing([]); }} />
          <OptionPicker label="Count" value={countType} onChange={setCountType} options={[{ value: "Opening", label: "Monday opening" }, { value: "Closing", label: "Friday closing" }]} />
          <DateField label="Count date" value={date} onChangeText={setDate} />
          <QueryBoundary isLoading={items.isLoading && Boolean(storeroomId)} error={items.error}>
            <View className="gap-2">
              {stock.map((item) => (
                <Checkbox
                  key={item.assetId}
                  label={`${item.assetNo} · ${[item.make, item.model].filter(Boolean).join(" ") || humanise(item.assetType)} · ${humanise(item.stockState)}${item.conditionStatus ? ` · ${item.conditionStatus}` : ""}`}
                  checked={!missing.includes(item.assetId)}
                  onChange={(checked) => setMissing(checked ? missing.filter((id) => id !== item.assetId) : [...missing, item.assetId])}
                />
              ))}
              {storeroomId && stock.length === 0 && !items.isLoading ? <Text className="text-muted-foreground text-sm">This storeroom has no stock on record.</Text> : null}
            </View>
          </QueryBoundary>
          <FormMessage error={record.error} success={record.isSuccess && "Count saved."} />
          <SubmitButton
            label={`Save count (${counted.length} units)`}
            pending={record.isPending}
            disabled={!storeroomId}
            onPress={() =>
              record.mutate({ storeroomId: storeroomId!, countType, countDate: date, items: counted.map((item) => ({ assetId: item.assetId, conditionStatus: item.conditionStatus ?? "Good" })) })
            }
          />
        </View>
      ) : null}
    </Section>
  );
}
