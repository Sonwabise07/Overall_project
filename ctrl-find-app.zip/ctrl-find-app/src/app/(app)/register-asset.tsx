import { useState } from "react";
import { View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";

import { Callout } from "@/components/custom/feedback/state";
import { DateField, Field, FormMessage, FormRow, OptionPicker, SubmitButton } from "@/components/custom/forms/fields";
import { StoreroomPicker } from "@/components/custom/forms/pickers";
import { Page, Section } from "@/components/custom/layout/page";
import { Text } from "@/components/ui/text";
import { useBulkCreateAssets, useCreateAsset } from "@/features/assets/assets.queries";
import { CreateAssetRequest } from "@/features/assets/assets.types";
import { useDepartments } from "@/features/reference/reference.queries";
import { ASSET_TYPES, AssetType, CONDITIONS, ConditionStatus, LifecycleState } from "@/shared/api/api-common.types";
import { humanise, todayIso } from "@/shared/format/format";

// New assets start in one of these states (API RegistrationStates). Ordered and Received may be untagged.
const START_STATES: LifecycleState[] = ["Ordered", "Received", "Registered", "InStorage"];

const EMPTY = {
  assetTag: "", serialNumber: "", make: "", model: "", category: "", companyEntity: "", costCentre: "",
  purchaseOrder: "", invoiceReference: "", purchaseCost: "", acquisitionDate: todayIso(), warrantyStart: todayIso(),
  warrantyEnd: "", warrantyVendor: "", encryptionStatus: "", desk: "", notes: "",
};

// Bulk units are pasted one per line as "tag, serial".
function parseUnits(text: string) {
  return text
    .split(/\r?\n/)
    .map((line) => line.split(/[,\t;]/).map((part) => part.trim()))
    .filter(([tag]) => Boolean(tag))
    .map(([assetTag, serialNumber]) => ({ assetTag: assetTag!, serialNumber: serialNumber ?? "" }));
}

export default function RegisterAsset() {
  const bulk = useLocalSearchParams<{ mode?: string }>().mode === "bulk";
  const [form, setForm] = useState(EMPTY);
  const [assetType, setAssetType] = useState<AssetType>("Laptop");
  const [state, setState] = useState<LifecycleState>("InStorage");
  const [condition, setCondition] = useState<ConditionStatus>("New");
  const [departmentId, setDepartmentId] = useState<string>();
  const [storeroomId, setStoreroomId] = useState<string>();
  const [unitsText, setUnitsText] = useState("");
  const departments = useDepartments();
  const create = useCreateAsset();
  const createBulk = useBulkCreateAssets();
  const mutation = bulk ? createBulk : create;

  const set = (key: keyof typeof EMPTY) => (value: string) => setForm((current) => ({ ...current, [key]: value }));
  const optional = (value: string) => value.trim() || undefined;
  const units = parseUnits(unitsText);
  const tagged = state !== "Ordered" && state !== "Received";

  function payload(): CreateAssetRequest {
    return {
      assetType,
      lifecycleState: state,
      condition,
      departmentId,
      storeroomId,
      assetTag: bulk ? undefined : optional(form.assetTag),
      serialNumber: bulk ? undefined : optional(form.serialNumber),
      make: optional(form.make),
      model: optional(form.model),
      category: optional(form.category),
      companyEntity: optional(form.companyEntity),
      costCentre: optional(form.costCentre),
      purchaseOrder: optional(form.purchaseOrder),
      invoiceReference: optional(form.invoiceReference),
      purchaseCost: form.purchaseCost.trim() ? Number(form.purchaseCost.replace(/[^\d.]/g, "")) : undefined,
      acquisitionDate: optional(form.acquisitionDate),
      warrantyStart: optional(form.warrantyStart),
      warrantyEnd: optional(form.warrantyEnd),
      warrantyVendor: optional(form.warrantyVendor),
      encryptionStatus: assetType === "Laptop" ? optional(form.encryptionStatus) : undefined,
      desk: optional(form.desk),
      notes: optional(form.notes),
    };
  }

  function submit() {
    if (bulk) {
      createBulk.mutate({ common: payload(), units }, { onSuccess: () => router.replace("/asset-register") });
    } else {
      create.mutate(payload(), { onSuccess: (response) => router.replace({ pathname: "/asset-details", params: { assetId: response.data.assetId } }) });
    }
  }

  return (
    <Page title={bulk ? "Bulk register assets" : "Register asset"} subtitle="Fixed Assets · new asset onto the register">
      <Callout title="Mandatory details">
        Registered and In storage assets need a tag, serial number and full financial and warranty details (BR-7-01, BR-8.1-01). Use Ordered or Received while stock is still on its way.
      </Callout>

      <Section title="Asset">
        <OptionPicker label="Asset type" value={assetType} onChange={setAssetType} options={ASSET_TYPES.map((t) => ({ value: t, label: humanise(t) }))} />
        <OptionPicker label="Starting state" value={state} onChange={setState} options={START_STATES.map((s) => ({ value: s, label: humanise(s) }))} />
        {!bulk ? (
          <FormRow>
            <Field label="Asset tag" value={form.assetTag} onChangeText={set("assetTag")} placeholder="e.g. TAG-01234" />
            <Field label="Serial number" value={form.serialNumber} onChangeText={set("serialNumber")} />
          </FormRow>
        ) : (
          <View className="gap-2">
            <Field
              label="Units (one per line: tag, serial)"
              value={unitsText}
              onChangeText={setUnitsText}
              multiline
              placeholder={"TAG-01001, SN-ABC123\nTAG-01002, SN-ABC124"}
              hint={`${units.length} unit${units.length === 1 ? "" : "s"} ready. All units share the details below.`}
            />
          </View>
        )}
        <FormRow>
          <Field label="Make" value={form.make} onChangeText={set("make")} placeholder="e.g. Dell" />
          <Field label="Model" value={form.model} onChangeText={set("model")} placeholder="e.g. Latitude 5450" />
          <Field label="Category" value={form.category} onChangeText={set("category")} placeholder="e.g. Computer equipment" />
        </FormRow>
        <OptionPicker label="Condition" value={condition} onChange={setCondition} options={CONDITIONS.map((c) => ({ value: c, label: c }))} />
        {assetType === "Laptop" ? (
          <Field label="Encryption status" value={form.encryptionStatus} onChangeText={set("encryptionStatus")} placeholder="e.g. BitLocker enabled" hint="Required for laptops (BR-8.3-01)." />
        ) : null}
      </Section>

      <Section title="Ownership and location">
        <FormRow>
          <Field label="Company entity" value={form.companyEntity} onChangeText={set("companyEntity")} />
          <Field label="Cost centre" value={form.costCentre} onChangeText={set("costCentre")} />
        </FormRow>
        <OptionPicker label="Department (optional)" value={departmentId} onChange={setDepartmentId} options={(departments.data?.data ?? []).map((d) => ({ value: d.departmentId, label: d.name }))} />
        <StoreroomPicker value={storeroomId} onChange={setStoreroomId} label={tagged ? "Storeroom (required)" : "Storeroom"} />
        <Field label="Desk (optional)" value={form.desk} onChangeText={set("desk")} />
      </Section>

      <Section title="Financial and warranty">
        <FormRow>
          <Field label="Purchase order" value={form.purchaseOrder} onChangeText={set("purchaseOrder")} />
          <Field label="Invoice reference" value={form.invoiceReference} onChangeText={set("invoiceReference")} />
          <Field label="Purchase cost (R)" value={form.purchaseCost} onChangeText={set("purchaseCost")} keyboardType="numeric" />
        </FormRow>
        <FormRow>
          <DateField label="Acquisition date" value={form.acquisitionDate} onChangeText={set("acquisitionDate")} />
          <DateField label="Warranty start" value={form.warrantyStart} onChangeText={set("warrantyStart")} />
          <DateField label="Warranty end" value={form.warrantyEnd} onChangeText={set("warrantyEnd")} />
        </FormRow>
        <Field label="Warranty vendor" value={form.warrantyVendor} onChangeText={set("warrantyVendor")} />
        <Field label="Notes" value={form.notes} onChangeText={set("notes")} multiline />
      </Section>

      <View className="gap-3">
        <FormMessage error={mutation.error} />
        <View className="flex-row gap-3">
          <SubmitButton label={bulk ? `Register ${units.length} assets` : "Register asset"} pending={mutation.isPending} disabled={bulk && units.length === 0} onPress={submit} />
          <SubmitButton label="Cancel" variant="outline" onPress={() => router.back()} />
        </View>
        <Text className="text-muted-foreground text-xs">The asset number is assigned automatically.</Text>
      </View>
    </Page>
  );
}
