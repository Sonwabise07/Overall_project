import { useState } from "react";
import { View } from "react-native";
import { AlertTriangle, Clock, ShieldCheck, Trash2 } from "lucide-react-native";

import { InfoWidget, WidgetTones } from "@/components/custom/cards/info-widget";
import { QueryBoundary } from "@/components/custom/feedback/state";
import { Checkbox, DateField, Field, FormMessage, FormRow, OptionPicker, SubmitButton } from "@/components/custom/forms/fields";
import { FileUpload } from "@/components/custom/forms/file-upload";
import { Page, Section, StatGrid } from "@/components/custom/layout/page";
import { StatusBadge } from "@/components/custom/status/status-badge";
import { Table, TwoLine } from "@/components/custom/table/table";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { Text } from "@/components/ui/text";
import { Roles, useHasRole } from "@/features/auth/auth.roles";
import { useCreateDisposal, useDisposals, usePendingDispositions } from "@/features/disposals/disposals.queries";
import { PendingDispositionDto } from "@/features/disposals/disposals.types";
import { DocumentReferenceDto } from "@/features/documents/documents.types";
import { daysFromToday, formatDate, relativeDay, todayIso } from "@/shared/format/format";

const METHODS = ["Recycler · certified", "Donation", "Sale", "Scrapped", "Returned to vendor"];
// The API decides whether a wipe is required (devices that store data); this is only a hint.
const STORES_DATA = /laptop|desktop|macbook|tablet|phone|mobile|ipad|surface/i;
type Row = { key: string; assetId: string; assetNo?: string | null; description?: string | null; reason: string; method?: string; wiped?: boolean; disposed: boolean; date: string };

export default function Disposal() {
  const disposals = useDisposals();
  const pending = usePendingDispositions();
  const canRecord = useHasRole(Roles.FixedAssets, Roles.Administrator);
  const [recording, setRecording] = useState(false);
  const done = disposals.data?.data ?? [];
  const waiting = pending.data?.data ?? [];
  const quarterStart = new Date(new Date().getFullYear(), Math.floor(new Date().getMonth() / 3) * 3, 1);

  const rows: Row[] = [
    ...waiting.map((p) => ({ key: `p-${p.assetId}`, assetId: p.assetId, assetNo: p.assetNo, description: p.assetDescription, reason: p.reason, disposed: false, date: p.since })),
    ...done.map((d) => ({ key: d.disposalId, assetId: d.assetId, assetNo: d.assetNo, description: d.assetDescription, reason: d.reason, method: d.method, wiped: d.dataWipeConfirmed, disposed: true, date: d.disposedOn })),
  ];

  return (
    <Page title="Disposal" subtitle="Formal disposal and scrapping, with a consistently recorded final disposition">
      <StatGrid>
        <InfoWidget icon={Trash2} heading={String(done.filter((d) => new Date(d.disposedOn) >= quarterStart).length)} subheading="Assets disposed" detail="this quarter" {...WidgetTones.blue} />
        <InfoWidget icon={Clock} heading={String(waiting.length)} subheading="Awaiting final disposition" detail="pending" {...WidgetTones.amber} />
        <InfoWidget icon={ShieldCheck} heading={String(done.filter((d) => d.dataWipeConfirmed).length)} subheading="Data-wipe confirmed" detail="data-wipe" {...WidgetTones.purple} />
        <InfoWidget icon={AlertTriangle} heading={String(waiting.filter((p) => (daysFromToday(p.since) ?? 0) < -90).length)} subheading="Waiting over 90 days" detail="unresolved" {...WidgetTones.red} />
      </StatGrid>

      {recording ? <DisposalForm pending={waiting} onDone={() => setRecording(false)} /> : null}

      <Section
        title="Disposal register"
        description="Final disposition recorded so assets don't end up in storage indefinitely"
        action={
          canRecord ? (
            <Button onPress={() => setRecording(!recording)}>
              <Icon as={Trash2} size={14} className="text-white" />
              <Text>Record disposal</Text>
            </Button>
          ) : null
        }
      >
        <QueryBoundary isLoading={disposals.isLoading || pending.isLoading} error={disposals.error ?? pending.error} onRetry={() => { disposals.refetch(); pending.refetch(); }}>
          <Table
            rows={rows}
            rowKey={(row) => row.key}
            minWidth={820}
            emptyText="Nothing is retired or disposed."
            columns={[
              { key: "asset", label: "Asset", flex: 1.5, render: (row) => <TwoLine title={row.assetNo ?? row.assetId} subtitle={row.description} /> },
              { key: "reason", label: "Reason", flex: 1.5, value: (row) => row.reason },
              { key: "method", label: "Method", flex: 1.2, value: (row) => row.method ?? "—" },
              { key: "wipe", label: "Data-wipe", render: (row) => (row.wiped ? <StatusBadge status="Confirmed" /> : <Text className="text-muted-foreground text-sm">{row.disposed ? "Not applicable" : "—"}</Text>) },
              { key: "status", label: "Status", flex: 1.2, render: (row) => <StatusBadge status={row.disposed ? "Disposed" : "PendingApproval"} label={row.disposed ? "Disposed" : "Pending disposition"} /> },
              { key: "date", label: "Date", flex: 1.2, value: (row) => (row.disposed ? relativeDay(row.date) : `Retired since ${formatDate(row.date)}`) },
            ]}
          />
        </QueryBoundary>
      </Section>
    </Page>
  );
}

function DisposalForm({ pending, onDone }: { pending: PendingDispositionDto[]; onDone: () => void }) {
  const [assetId, setAssetId] = useState<string>();
  const [method, setMethod] = useState(METHODS[0]!);
  const [reason, setReason] = useState("");
  const [wiped, setWiped] = useState(false);
  const [certificate, setCertificate] = useState<DocumentReferenceDto>();
  const [date, setDate] = useState(todayIso());
  const create = useCreateDisposal();
  const chosen = pending.find((p) => p.assetId === assetId);
  const storesData = STORES_DATA.test(chosen?.assetDescription ?? "");

  function choose(id: string) {
    setAssetId(id);
    setReason(pending.find((p) => p.assetId === id)?.reason ?? "");
    setCertificate(undefined);
  }

  if (pending.length === 0) {
    return (
      <Section title="Record disposal">
        <Text className="text-muted-foreground text-sm">Only retired assets can be disposed. Retire an asset from its page first.</Text>
      </Section>
    );
  }

  return (
    <Section title="Record disposal" description="Only retired assets can be disposed. Devices that store data need a confirmed data wipe (BR-8.13).">
      <OptionPicker label="Asset" value={assetId} onChange={choose} options={pending.map((p) => ({ value: p.assetId, label: `${p.assetNo}${p.assetDescription ? ` · ${p.assetDescription}` : ""}` }))} />
      <OptionPicker label="Method" value={method} onChange={setMethod} options={METHODS.map((m) => ({ value: m, label: m }))} />
      <FormRow>
        <Field label="Reason" value={reason} onChangeText={setReason} />
        <DateField label="Disposed on" value={date} onChangeText={setDate} />
      </FormRow>
      <Checkbox label={`Data wipe confirmed${storesData ? " (required for this device)" : ""}`} checked={wiped} onChange={setWiped} />
      <View>
        <FileUpload key={assetId} assetId={assetId} documentType="DataWipeCertificate" label="Data-wipe or recycler certificate (optional)" uploaded={certificate} onUploaded={setCertificate} />
      </View>
      <FormMessage error={create.error} />
      <SubmitButton
        label="Record disposal"
        pending={create.isPending}
        disabled={!assetId || !reason.trim()}
        onPress={() => create.mutate({ assetId: assetId!, method, reason: reason.trim(), dataWipeConfirmed: wiped, certificateDocumentId: certificate?.documentId, disposedOn: date }, { onSuccess: onDone })}
      />
    </Section>
  );
}
