import { useState } from "react";
import { View } from "react-native";
import { Download } from "lucide-react-native";

import { BarList, ColumnChart } from "@/components/custom/charts/charts";
import { AuthImage } from "@/components/custom/detail/auth-image";
import { DetailList } from "@/components/custom/detail/detail-list";
import { Callout, QueryBoundary } from "@/components/custom/feedback/state";
import { Columns, Page, Section } from "@/components/custom/layout/page";
import { Tabs } from "@/components/custom/navigation/tabs";
import { StatusBadge } from "@/components/custom/status/status-badge";
import { Table, TwoLine } from "@/components/custom/table/table";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { Text } from "@/components/ui/text";
import { Roles, useHasRole } from "@/features/auth/auth.roles";
import { openDocument } from "@/features/documents/documents.api";
import { useManagementDashboard, useOperationalDashboard, usePowerBiDatasets } from "@/features/reporting/reporting.queries";
import { CountByLabel, OperationalDashboardDto } from "@/features/reporting/reporting.types";
import { formatMoney, formatNumber, formatPeriod, humanise } from "@/shared/format/format";

type Tab = "operational" | "management";
const pct = (part: number, whole: number) => (whole > 0 ? Math.round((part / whole) * 100) : 0);
const toPoints = (rows: CountByLabel[]) => rows.map((r) => ({ label: humanise(r.label), value: r.count }));

export default function Reports() {
  const [tab, setTab] = useState<Tab>("operational");
  return (
    <Page title="Reports" subtitle="Operational and management dashboards · Power BI-ready output">
      <Section title="Dashboards">
        <Tabs tabs={[{ value: "operational", label: "Operational" }, { value: "management", label: "Management" }]} value={tab} onChange={setTab} />
        {tab === "operational" ? <Operational /> : <Management />}
      </Section>
    </Page>
  );
}

function Operational() {
  const dashboard = useOperationalDashboard();
  const d = dashboard.data?.data;
  return (
    <QueryBoundary isLoading={dashboard.isLoading} error={dashboard.error} onRetry={dashboard.refetch}>
      {d ? (
        <View className="gap-5">
          <Columns
            main={
              <View className="border-border gap-4 rounded-lg border p-4">
                <Text className="text-sm font-semibold">Stock levels by type · available units against threshold</Text>
                <BarList
                  points={d.stockLevels.map((s) => ({
                    label: humanise(s.assetType),
                    value: s.available,
                    colour: s.alert === "NoStock" ? "bg-rose-500" : s.alert === "LowStock" ? "bg-amber-500" : "bg-sky-500",
                  }))}
                  format={(v) => `${v} units`}
                />
              </View>
            }
            side={
              <View className="border-border gap-4 rounded-lg border p-4">
                <Text className="text-sm font-semibold">Onboarding readiness</Text>
                <BarList
                  max={100}
                  format={(v) => `${v}%`}
                  points={[
                    { label: "Kits fully reserved", value: pct(d.onboarding.kitsFullyReserved, d.onboarding.openCases), colour: "bg-emerald-500" },
                    { label: "Short notice", value: pct(d.onboarding.shortNotice, d.onboarding.openCases), colour: "bg-rose-500" },
                    { label: "Stock shortfall", value: pct(d.onboarding.withShortfall, d.onboarding.openCases), colour: "bg-amber-500" },
                  ]}
                />
                <Text className="text-muted-foreground text-xs">{d.onboarding.openCases} open onboarding cases</Text>
              </View>
            }
          />
          <TopicTable d={d} />
          <View className="flex-row flex-wrap gap-5">
            <View className="border-border min-w-[280px] flex-1 gap-3 rounded-lg border p-4">
              <Text className="text-sm font-semibold">Assets by status</Text>
              <BarList points={toPoints(d.byOperationalStatus)} />
            </View>
            <View className="border-border min-w-[280px] flex-1 gap-3 rounded-lg border p-4">
              <Text className="text-sm font-semibold">Assets by type</Text>
              <BarList points={toPoints(d.byAssetType)} />
            </View>
          </View>
        </View>
      ) : null}
    </QueryBoundary>
  );
}

function TopicTable({ d }: { d: OperationalDashboardDto }) {
  const offboardingTotal = d.offboarding.openCases + d.offboarding.completedThisMonth;
  const rows = [
    { topic: "Offboarding recoveries", value: `${d.offboarding.completedThisMonth} of ${offboardingTotal} complete`, note: d.offboarding.laptopRecoveriesOutstanding ? `${d.offboarding.laptopRecoveriesOutstanding} laptop recoveries outstanding` : "on track" },
    { topic: "Losses (financial exposure)", value: formatMoney(d.lossExposure), note: `${d.openIncidents} open incidents` },
    { topic: "Warranty cases", value: `${d.warrantyAlerts} alerts, ${d.activeWarrantyClaims} claims`, note: `${d.openRepairs} repairs open` },
    { topic: "Audit discrepancies", value: `${d.openAuditDiscrepancies} open, ${d.resolvedAuditDiscrepancies} resolved`, note: d.openAuditDiscrepancies ? "needs review" : "clear" },
    { topic: "Asset utilisation", value: `${d.utilisationPercent}% assigned`, note: `${formatNumber(d.totalAssets)} assets` },
  ];
  return (
    <Table
      rows={rows}
      rowKey={(row) => row.topic}
      columns={[
        { key: "topic", label: "Topic", flex: 1.5, render: (row) => <Text className="text-sm font-semibold">{row.topic}</Text> },
        { key: "value", label: "This month", flex: 1.3, value: (row) => row.value },
        { key: "note", label: "Note", flex: 1.3, value: (row) => row.note },
      ]}
    />
  );
}

function Management() {
  const dashboard = useManagementDashboard();
  const canExport = useHasRole(Roles.Finance, Roles.FixedAssets, Roles.Administrator);
  const m = dashboard.data?.data;
  return (
    <QueryBoundary isLoading={dashboard.isLoading} error={dashboard.error} onRetry={dashboard.refetch}>
      {m ? (
        <View className="gap-5">
          <Columns
            main={
              <View className="gap-5">
                <View className="border-border gap-3 rounded-lg border p-4">
                  <Text className="text-sm font-semibold">Loss and theft incidents · last 12 months</Text>
                  <ColumnChart points={m.incidentTrend.map((p) => ({ label: formatPeriod(p.period).slice(0, 3), value: p.value, colour: "bg-rose-500" }))} />
                </View>
                <View className="border-border gap-3 rounded-lg border p-4">
                  <Text className="text-sm font-semibold">Audit confirmation compliance · last 12 months</Text>
                  <ColumnChart points={m.confirmationComplianceTrend.map((p) => ({ label: formatPeriod(p.period).slice(0, 3), value: p.value, colour: "bg-emerald-500" }))} format={(v) => `${v}%`} />
                </View>
                <View className="flex-row flex-wrap gap-5">
                  <Breakdown title="Incidents by employee" rows={m.incidentsByEmployee} />
                  <Breakdown title="Incidents by location" rows={m.incidentsByLocation} />
                  <Breakdown title="Incidents by asset type" rows={m.incidentsByAssetType} />
                </View>
              </View>
            }
            side={
              <View className="border-border gap-4 rounded-lg border p-4">
                <Text className="text-sm font-semibold">Financial exposure & repeated negligence</Text>
                <DetailList
                  items={[
                    { label: "Total asset value", value: formatMoney(m.totalAssetValue) },
                    { label: "Lost or stolen value", value: formatMoney(m.lostOrStolenValue) },
                    { label: "Open AOD value", value: formatMoney(m.openAodValue) },
                    { label: "Recovered through AOD", value: formatMoney(m.recoveredAodValue) },
                    { label: "Employees with repeat incidents", value: `${m.employeesWithRepeatIncidents} escalated` },
                    { label: "Laptops off-site", value: `${m.laptopsOffSite} units` },
                  ]}
                />
                <Text className="text-sm font-semibold">Audit risk</Text>
                <BarList
                  max={100}
                  format={(v) => `${v}%`}
                  points={[
                    { label: "High", value: pct(m.risk.high, m.risk.total), colour: "bg-rose-500" },
                    { label: "Medium", value: pct(m.risk.medium, m.risk.total), colour: "bg-amber-500" },
                    { label: "Low", value: pct(m.risk.low, m.risk.total), colour: "bg-sky-500" },
                  ]}
                />
                <Callout>Key financial amounts are shown here, not only inside exportable reports. All exports are Power BI-ready.</Callout>
                {canExport ? <PowerBiExports /> : null}
              </View>
            }
          />
          <View className="gap-3">
            <Text className="text-sm font-semibold">Flagged items with photo evidence</Text>
            <Table
              rows={m.flaggedItems}
              rowKey={(row) => `${row.assetId}-${row.reason}`}
              emptyText="Nothing flagged."
              columns={[
                { key: "asset", label: "Asset", flex: 1.5, render: (row) => <TwoLine title={row.assetNo} subtitle={row.assetDescription} /> },
                { key: "reason", label: "Reason", flex: 2, value: (row) => row.reason },
                { key: "photo", label: "Photo evidence", render: (row) => (row.photoUrl ? <AuthImage downloadUrl={row.photoUrl} label="Photo" className="h-12 w-16" /> : <StatusBadge tone="neutral" label="No photo" />) },
              ]}
            />
          </View>
        </View>
      ) : null}
    </QueryBoundary>
  );
}

function Breakdown({ title, rows }: { title: string; rows: CountByLabel[] }) {
  return (
    <View className="border-border min-w-[220px] flex-1 gap-3 rounded-lg border p-4">
      <Text className="text-sm font-semibold">{title}</Text>
      {rows.length === 0 ? <Text className="text-muted-foreground text-xs">No incidents.</Text> : <BarList points={toPoints(rows.slice(0, 6))} />}
    </View>
  );
}

// Power BI reads these CSV datasets (scheduled refresh or manual import). Embedding waits for workspace details.
function PowerBiExports() {
  const [open, setOpen] = useState(false);
  const datasets = usePowerBiDatasets(open);
  return (
    <View className="gap-2">
      <Button className="self-start" onPress={() => setOpen(true)}>
        <Icon as={Download} size={14} className="text-white" />
        <Text>Export to Power BI</Text>
      </Button>
      {open ? (
        <QueryBoundary isLoading={datasets.isLoading} error={datasets.error}>
          <View className="flex-row flex-wrap gap-2">
            {(datasets.data?.data.datasets ?? []).map((dataset) => (
              <Button key={dataset.name} variant="outline" size="sm" onPress={() => void openDocument(dataset.url, `${dataset.name}.csv`)}>
                <Text>{humanise(dataset.name)}.csv</Text>
              </Button>
            ))}
          </View>
        </QueryBoundary>
      ) : null}
    </View>
  );
}
