import { useState } from "react";
import { View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { AlertTriangle, ArrowLeftRight, Wrench } from "lucide-react-native";

import { DetailList } from "@/components/custom/detail/detail-list";
import { Callout, QueryBoundary } from "@/components/custom/feedback/state";
import { Checkbox, DateField, Field, FormMessage, FormRow, OptionPicker, SubmitButton } from "@/components/custom/forms/fields";
import { FileUpload } from "@/components/custom/forms/file-upload";
import { Chip, EmployeePicker, LocationPicker, StoreroomPicker } from "@/components/custom/forms/pickers";
import { Columns, Page, Section } from "@/components/custom/layout/page";
import { Tabs } from "@/components/custom/navigation/tabs";
import { StatusBadge } from "@/components/custom/status/status-badge";
import { Table, TwoLine } from "@/components/custom/table/table";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { Text } from "@/components/ui/text";
import {
  useAsset,
  useAssetAssignments,
  useAssetHistory,
  useChangeLifecycle,
  useCreateAssetAssignment,
  useHoldAssetForReassignment,
  useMaintenanceLog,
  useReturnAsset,
} from "@/features/assets/assets.queries";
import { AssetDetailDto } from "@/features/assets/assets.types";
import { AssetOperators, Roles, useHasRole } from "@/features/auth/auth.roles";
import { openDocument } from "@/features/documents/documents.api";
import { useAssetDocuments } from "@/features/documents/documents.queries";
import { DocumentReferenceDto, DocumentType } from "@/features/documents/documents.types";
import { EmployeeDto } from "@/features/reference/reference.types";
import { CONDITIONS, ConditionStatus, LifecycleState } from "@/shared/api/api-common.types";
import { formatDate, formatDateTime, formatMoney, humanise, todayIso } from "@/shared/format/format";

type Tab = "overview" | "location" | "financial" | "documents" | "history";
const TABS: { value: Tab; label: string }[] = [
  { value: "overview", label: "Overview" },
  { value: "location", label: "Location & assignment" },
  { value: "financial", label: "Financial & warranty" },
  { value: "documents", label: "Documents" },
  { value: "history", label: "History" },
];

export default function AssetDetails() {
  const { assetId } = useLocalSearchParams<{ assetId: string }>();
  const asset = useAsset(assetId);
  const [tab, setTab] = useState<Tab>("overview");
  const a = asset.data?.data;

  return (
    <Page
      title={a?.assetNo ?? "Asset"}
      subtitle="Asset profile · back to Asset register"
      actions={
        a ? (
          <>
            <Button variant="outline" onPress={() => router.push({ pathname: "/faults-repairs", params: { assetId: a.assetId } })}>
              <Icon as={Wrench} size={14} />
              <Text>Log fault</Text>
            </Button>
            <Button variant="outline" onPress={() => router.push({ pathname: "/loss-theft-aod", params: { assetId: a.assetId } })}>
              <Icon as={AlertTriangle} size={14} />
              <Text>Report loss</Text>
            </Button>
            <Button variant="outline" onPress={() => router.push({ pathname: "/transfers", params: { assetId: a.assetId } })}>
              <Icon as={ArrowLeftRight} size={14} />
              <Text>Transfer</Text>
            </Button>
          </>
        ) : null
      }
    >
      <QueryBoundary isLoading={asset.isLoading} error={asset.error} onRetry={asset.refetch}>
        {a ? (
          <>
            <Section
              title={[a.assetNo, a.make, a.model].filter(Boolean).join(" · ")}
              description={[humanise(a.assetType), a.serialNumber && `Serial ${a.serialNumber}`, a.assignment?.employeeName && `Assigned to ${a.assignment.employeeName}`, a.department]
                .filter(Boolean)
                .join(" · ")}
              action={
                <View className="flex-row flex-wrap gap-2">
                  <StatusBadge status={a.status.operationalStatus} />
                  <StatusBadge status={a.status.lifecycleState} />
                  {a.laptopControls ? <StatusBadge status={a.laptopControls.healthIndicator} label={HEALTH_LABEL[a.laptopControls.healthIndicator]} /> : null}
                </View>
              }
            >
              <Tabs tabs={TABS} value={tab} onChange={setTab} />
              {tab === "overview" ? <Overview asset={a} /> : null}
              {tab === "location" ? <LocationTab asset={a} /> : null}
              {tab === "financial" ? <FinancialTab asset={a} /> : null}
              {tab === "documents" ? <DocumentsTab asset={a} /> : null}
              {tab === "history" ? <HistoryTab assetId={a.assetId} /> : null}
            </Section>
            <AssetActions asset={a} />
          </>
        ) : null}
      </QueryBoundary>
    </Page>
  );
}

const HEALTH_LABEL = { Green: "Healthy · in warranty", Amber: "Ageing or warranty ending", Red: "Out of warranty" } as const;

function AssignmentPanel({ asset }: { asset: AssetDetailDto }) {
  return (
    <DetailList
      items={[
        { label: "Employee", value: asset.assignment?.employeeName ?? "Unassigned" },
        { label: "Manager", value: asset.assignment?.managerName ?? "—" },
        { label: "Assignment date", value: formatDate(asset.assignment?.assignmentDate) },
        { label: "Location sub-status", value: humanise(asset.location?.subStatus) },
        { label: "Condition", value: asset.condition ?? "—" },
      ]}
    />
  );
}

function Overview({ asset }: { asset: AssetDetailDto }) {
  const laptop = asset.laptopControls;
  return (
    <Columns
      main={
        <View className="gap-4">
          <DetailList
            items={[
              { label: "Asset type / category", value: [humanise(asset.assetType), asset.category].filter(Boolean).join(" · ") },
              { label: "Make / model", value: [asset.make, asset.model].filter(Boolean).join(" / ") || "—" },
              { label: "Serial number", value: asset.serialNumber ?? "—" },
              { label: "Asset tag", value: asset.assetTag ?? "Not tagged yet" },
              { label: "Company entity", value: asset.companyEntity ?? "—" },
              { label: "Cost centre", value: asset.costCentre ?? "—" },
              { label: "Department", value: asset.department ?? "—" },
            ]}
          />
          {laptop ? (
            <View className="gap-3">
              <Text className="text-sm font-semibold">High-value asset protection (laptop)</Text>
              <DetailList
                items={[
                  { label: "Warranty expiry", value: formatDate(asset.lifecycle.warrantyEnd) },
                  { label: "Encryption status", value: laptop.encryptionStatus || "Not recorded" },
                  { label: "Health indicator", value: <StatusBadge status={laptop.healthIndicator} label={HEALTH_LABEL[laptop.healthIndicator]} /> },
                ]}
              />
              <Callout tone={laptop.custodyAgreementSigned ? "info" : "warning"} title="Digital custody agreement">
                {laptop.custodyAgreementSigned
                  ? `Signed by ${asset.assignment?.employeeName ?? "the holder"} for serial ${asset.serialNumber ?? "—"}. Required before this laptop could be released.`
                  : "No signed agreement on the current assignment. A new agreement is required before this laptop is released to anyone."}
              </Callout>
            </View>
          ) : null}
          {asset.holdExpiresAt ? <Callout tone="warning">Held at the desk for reassignment until {formatDate(asset.holdExpiresAt)}.</Callout> : null}
          {asset.notes ? <Text className="text-muted-foreground text-sm">{asset.notes}</Text> : null}
        </View>
      }
      side={
        <View className="bg-muted/40 border-border gap-4 rounded-lg border p-4">
          <Text className="text-sm font-semibold">Assignment</Text>
          <AssignmentPanel asset={asset} />
          <Text className="text-sm font-semibold">Financial (read from Pastel)</Text>
          <DetailList
            items={[
              { label: "Purchase cost", value: formatMoney(asset.financial.purchaseCost) },
              { label: "Purchase order", value: asset.financial.purchaseOrder ?? "—" },
              { label: "Invoice reference", value: asset.financial.invoiceReference ?? "—" },
            ]}
          />
        </View>
      }
    />
  );
}

function LocationTab({ asset }: { asset: AssetDetailDto }) {
  const assignments = useAssetAssignments(asset.assetId);
  const l = asset.location;
  return (
    <View className="gap-5">
      <Columns
        main={
          <DetailList
            items={[
              { label: "Region", value: l?.region ?? "—" },
              { label: "Building", value: l?.building ?? "—" },
              { label: "Floor", value: l?.floor ?? "—" },
              { label: "Desk", value: l?.desk ?? "—" },
              { label: "Storeroom", value: l?.storeroomId ?? "—" },
              { label: "Sub-status", value: humanise(l?.subStatus) },
            ]}
          />
        }
        side={<AssignmentPanel asset={asset} />}
      />
      <Text className="text-sm font-semibold">Assignment history</Text>
      <QueryBoundary isLoading={assignments.isLoading} error={assignments.error}>
        <Table
          rows={assignments.data?.data ?? []}
          rowKey={(row) => row.assignmentId}
          emptyText="This asset has never been assigned."
          columns={[
            { key: "employee", label: "Employee", flex: 2, value: (row) => row.employeeName ?? row.employeeId },
            { key: "from", label: "Assigned", value: (row) => formatDate(row.assignmentDate) },
            { key: "to", label: "Returned", value: (row) => (row.returnedAt ? formatDate(row.returnedAt) : "Current") },
            { key: "custody", label: "Custody agreement", value: (row) => (row.custodyAgreementDocumentId ? "On file" : "—") },
          ]}
        />
      </QueryBoundary>
    </View>
  );
}

function FinancialTab({ asset }: { asset: AssetDetailDto }) {
  const log = useMaintenanceLog(asset.assetId);
  return (
    <View className="gap-5">
      <Columns
        main={
          <DetailList
            items={[
              { label: "Purchase cost", value: formatMoney(asset.financial.purchaseCost) },
              { label: "Purchase order", value: asset.financial.purchaseOrder ?? "—" },
              { label: "Invoice reference", value: asset.financial.invoiceReference ?? "—" },
              { label: "Acquisition date", value: formatDate(asset.lifecycle.acquisitionDate) },
            ]}
          />
        }
        side={
          <DetailList
            items={[
              { label: "Warranty start", value: formatDate(asset.lifecycle.warrantyStart) },
              { label: "Warranty end", value: formatDate(asset.lifecycle.warrantyEnd) },
              { label: "Warranty vendor", value: asset.lifecycle.warrantyVendor ?? "—" },
              { label: "Last audit", value: formatDate(asset.auditData.lastAuditDate) },
              { label: "Audit outcome", value: asset.auditData.auditOutcome ? <StatusBadge status={asset.auditData.auditOutcome} /> : "—" },
            ]}
          />
        }
      />
      <Text className="text-sm font-semibold">Maintenance log</Text>
      <QueryBoundary isLoading={log.isLoading} error={log.error}>
        <Table
          rows={log.data?.data ?? []}
          rowKey={(row) => row.logId}
          emptyText="No services recorded."
          columns={[
            { key: "date", label: "Last service", value: (row) => formatDate(row.lastServiceDate) },
            { key: "next", label: "Next due", value: (row) => formatDate(row.nextDueDate) },
            { key: "provider", label: "Provider", flex: 1.5, value: (row) => row.serviceProvider },
            { key: "notes", label: "Notes", flex: 2, value: (row) => row.notes ?? "—" },
          ]}
        />
      </QueryBoundary>
    </View>
  );
}

const UPLOAD_TYPES: DocumentType[] = ["CustodyAgreement", "Invoice", "Warranty", "Photo", "ReturnForm", "PoliceReport", "DataWipeCertificate", "Other"];

function DocumentsTab({ asset }: { asset: AssetDetailDto }) {
  const documents = useAssetDocuments(asset.assetId);
  const [type, setType] = useState<DocumentType>("Invoice");
  const [uploaded, setUploaded] = useState<DocumentReferenceDto>();
  return (
    <View className="gap-4">
      <QueryBoundary isLoading={documents.isLoading} error={documents.error}>
        <Table
          rows={documents.data?.data ?? []}
          rowKey={(row) => row.documentId}
          emptyText="No documents uploaded."
          onRowPress={(row) => void openDocument(row.downloadUrl)}
          columns={[
            { key: "name", label: "File", flex: 2, render: (row) => <TwoLine title={row.fileName} subtitle={row.description} /> },
            { key: "type", label: "Type", value: (row) => humanise(row.documentType) },
            { key: "date", label: "Uploaded", value: (row) => formatDateTime(row.uploadedAt) },
          ]}
        />
      </QueryBoundary>
      <View className="border-border gap-3 rounded-lg border p-4">
        <OptionPicker label="Upload a document" value={type} onChange={(value) => { setType(value); setUploaded(undefined); }} options={UPLOAD_TYPES.map((t) => ({ value: t, label: humanise(t) }))} />
        <FileUpload key={type} assetId={asset.assetId} documentType={type} label={humanise(type)} uploaded={uploaded} onUploaded={setUploaded} />
      </View>
    </View>
  );
}

function HistoryTab({ assetId }: { assetId: string }) {
  const history = useAssetHistory(assetId);
  return (
    <QueryBoundary isLoading={history.isLoading} error={history.error}>
      <Table
        rows={history.data?.data ?? []}
        rowKey={(row) => row.historyId}
        emptyText="No history yet."
        footer="History is permanent and cannot be edited or deleted (BR-7-04)."
        columns={[
          { key: "when", label: "When", value: (row) => formatDateTime(row.changedAt) },
          { key: "action", label: "Action", flex: 3, render: (row) => <TwoLine title={humanise(row.actionType)} subtitle={row.summary} /> },
          { key: "by", label: "By", value: (row) => row.userId },
        ]}
      />
    </QueryBoundary>
  );
}

type Action = "assign" | "return" | "hold" | "state";

// Day-to-day register actions. The API enforces every rule; the form only shows what applies.
function AssetActions({ asset }: { asset: AssetDetailDto }) {
  const isOperator = useHasRole(...AssetOperators);
  const isFixedAssets = useHasRole(Roles.FixedAssets, Roles.Administrator);
  const assigned = Boolean(asset.assignment && !asset.assignment.returnedAt);
  const actions: { value: Action; label: string }[] = [
    ...(!assigned && ["Registered", "InStorage", "HeldForReassignment"].includes(asset.status.lifecycleState) ? [{ value: "assign" as const, label: "Assign to employee" }] : []),
    ...(assigned ? [{ value: "return" as const, label: "Return to storeroom" }, { value: "hold" as const, label: "Hold for reassignment" }] : []),
    ...(isFixedAssets ? [{ value: "state" as const, label: "Change state" }] : []),
  ];
  const [action, setAction] = useState<Action | undefined>(undefined);
  if (!isOperator || actions.length === 0) return null;
  const current = actions.find((a) => a.value === action)?.value;

  return (
    <Section title="Actions" description="Every change is written to the asset's permanent history.">
      <View className="flex-row flex-wrap gap-2">
        {actions.map((a) => (
          <Chip key={a.value} label={a.label} active={current === a.value} onPress={() => setAction(current === a.value ? undefined : a.value)} />
        ))}
      </View>
      {current === "assign" ? <AssignForm asset={asset} /> : null}
      {current === "return" ? <ReturnForm asset={asset} /> : null}
      {current === "hold" ? <HoldForm asset={asset} /> : null}
      {current === "state" ? <StateForm asset={asset} /> : null}
    </Section>
  );
}

function AssignForm({ asset }: { asset: AssetDetailDto }) {
  const [employee, setEmployee] = useState<EmployeeDto>();
  const [locationId, setLocationId] = useState<string>();
  const [date, setDate] = useState(todayIso());
  const [desk, setDesk] = useState("");
  const [condition, setCondition] = useState<ConditionStatus>(asset.condition ?? "Good");
  const [custody, setCustody] = useState<DocumentReferenceDto>();
  const [acknowledged, setAcknowledged] = useState(false);
  const assign = useCreateAssetAssignment();
  const isLaptop = asset.assetType === "Laptop";

  return (
    <View className="gap-4">
      <EmployeePicker value={employee} onChange={(e) => { setEmployee(e); if (e?.locationId) setLocationId(e.locationId); }} />
      <LocationPicker value={locationId} onChange={setLocationId} />
      <FormRow>
        <DateField label="Assignment date" value={date} onChangeText={setDate} />
        <Field label="Desk (optional)" value={desk} onChangeText={setDesk} />
      </FormRow>
      <OptionPicker label="Condition at handover" value={condition} onChange={setCondition} options={CONDITIONS.map((c) => ({ value: c, label: c }))} />
      {isLaptop ? (
        <>
          <FileUpload assetId={asset.assetId} documentType="CustodyAgreement" label="Signed custody agreement (required for laptops)" uploaded={custody} onUploaded={setCustody} />
          {employee && employee.negligentIncidents > 0 ? (
            <>
              <Callout tone="warning">{employee.fullName} has a prior negligent-loss record. Their manager must acknowledge this release.</Callout>
              <Checkbox label="Manager has acknowledged" checked={acknowledged} onChange={setAcknowledged} />
            </>
          ) : null}
        </>
      ) : null}
      <FormMessage error={assign.error} success={assign.isSuccess && "Asset assigned."} />
      <SubmitButton
        label="Assign asset"
        pending={assign.isPending}
        disabled={!employee || !locationId || (isLaptop && !custody)}
        onPress={() =>
          employee &&
          locationId &&
          assign.mutate({
            assetId: asset.assetId,
            payload: {
              employeeId: employee.employeeId,
              locationId,
              assignmentDate: date,
              desk: desk.trim() || undefined,
              condition,
              custodyAgreementDocumentId: custody?.documentId,
              managerAcknowledged: acknowledged,
            },
          })
        }
      />
    </View>
  );
}

function ReturnForm({ asset }: { asset: AssetDetailDto }) {
  const [storeroomId, setStoreroomId] = useState<string>();
  const [condition, setCondition] = useState<ConditionStatus>("Good");
  const [notes, setNotes] = useState("");
  const returnAsset = useReturnAsset();
  return (
    <View className="gap-4">
      <StoreroomPicker value={storeroomId} onChange={setStoreroomId} />
      <OptionPicker label="Condition on return" value={condition} onChange={setCondition} options={CONDITIONS.map((c) => ({ value: c, label: c }))} />
      <Field label="Notes" value={notes} onChangeText={setNotes} multiline />
      <FormMessage error={returnAsset.error} success={returnAsset.isSuccess && "Asset returned to storage."} />
      <SubmitButton
        label="Return asset"
        pending={returnAsset.isPending}
        disabled={!storeroomId}
        onPress={() => returnAsset.mutate({ assetId: asset.assetId, payload: { storeroomId: storeroomId!, condition, notes: notes.trim() || undefined } })}
      />
    </View>
  );
}

function HoldForm({ asset }: { asset: AssetDetailDto }) {
  const [expiresAt, setExpiresAt] = useState(todayIso(14));
  const [reason, setReason] = useState("");
  const hold = useHoldAssetForReassignment();
  return (
    <View className="gap-4">
      <Callout>The asset stays at the desk for the next person instead of going back to the storeroom (BR-8.5-04).</Callout>
      <FormRow>
        <DateField label="Hold until" value={expiresAt} onChangeText={setExpiresAt} />
        <Field label="Reason" value={reason} onChangeText={setReason} />
      </FormRow>
      <FormMessage error={hold.error} success={hold.isSuccess && "Asset held for reassignment."} />
      <SubmitButton label="Hold asset" pending={hold.isPending} onPress={() => hold.mutate({ assetId: asset.assetId, payload: { expiresAt, reason: reason.trim() || undefined } })} />
    </View>
  );
}

// Only states without their own workflow (API DirectStates).
const DIRECT_STATES: LifecycleState[] = ["Ordered", "Received", "Registered", "InStorage", "OffSite", "UnderAudit", "InterEntityTransfer", "Retired"];

function StateForm({ asset }: { asset: AssetDetailDto }) {
  const [state, setState] = useState<LifecycleState>();
  const [reason, setReason] = useState("");
  const change = useChangeLifecycle();
  return (
    <View className="gap-4">
      <Text className="text-muted-foreground text-xs">Assignment, repairs, incidents and disposal change the state through their own screens.</Text>
      <OptionPicker label="New state" value={state} onChange={setState} options={DIRECT_STATES.filter((s) => s !== asset.status.lifecycleState).map((s) => ({ value: s, label: humanise(s) }))} />
      <Field label="Reason" value={reason} onChangeText={setReason} />
      <FormMessage error={change.error} success={change.isSuccess && "State changed."} />
      <SubmitButton label="Change state" pending={change.isPending} disabled={!state || !reason.trim()} onPress={() => change.mutate({ assetId: asset.assetId, payload: { lifecycleState: state!, reason: reason.trim() } })} />
    </View>
  );
}

