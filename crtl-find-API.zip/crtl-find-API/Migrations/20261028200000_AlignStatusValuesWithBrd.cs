using CtrlFind.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CtrlFind.Migrations
{
    /// <summary>
    /// Data-only migration (no model change, so no designer file):
    /// converts stored status values to the BRD lists (DEC-003, DEC-004) and makes asset history permanent (DEC-016).
    /// </summary>
    [DbContext(typeof(ApplicationDbContext))]
    [Migration("20261028200000_AlignStatusValuesWithBrd")]
    public partial class AlignStatusValuesWithBrd : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("""
                UPDATE dbo.Assets SET LifecycleState = 'InStorage' WHERE LifecycleState = 'InStock';
                UPDATE dbo.Assets SET LifecycleState = 'InRepair' WHERE LifecycleState = 'UnderMaintenance';
                UPDATE dbo.Assets SET LifecycleState = 'Assigned' WHERE LifecycleState = 'InTransit';

                UPDATE dbo.Assets SET OperationalStatus = CASE
                    WHEN LifecycleState IN ('Ordered', 'Received', 'Registered', 'InStorage', 'Reserved') THEN 'InStorage'
                    WHEN LifecycleState IN ('InRepair', 'WarrantyClaim') THEN 'InRepair'
                    WHEN LifecycleState IN ('Lost', 'Stolen', 'Retired', 'Disposed') THEN 'Retired'
                    ELSE 'InUse' END;

                UPDATE dbo.Assets SET AuditOutcome = 'Confirmed' WHERE AuditOutcome = 'Passed';
                UPDATE dbo.Assets SET AuditOutcome = NULL
                WHERE AuditOutcome NOT IN ('Confirmed', 'NotFound', 'SerialMismatch', 'LocationMismatch', 'ConditionMismatch', 'AwaitingConfirmation', 'Unconfirmed');
                """);

            migrationBuilder.Sql("""
                CREATE OR ALTER TRIGGER dbo.TR_AssetHistory_Permanent ON dbo.AssetHistory
                INSTEAD OF UPDATE, DELETE
                AS
                BEGIN
                    SET NOCOUNT ON;
                    THROW 51000, 'Asset history is permanent and cannot be changed or deleted (BR-8.13-01).', 1;
                END
                """);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Status conversions are not reversed: the old values are no longer valid.
            migrationBuilder.Sql("DROP TRIGGER IF EXISTS dbo.TR_AssetHistory_Permanent;");
        }
    }
}
