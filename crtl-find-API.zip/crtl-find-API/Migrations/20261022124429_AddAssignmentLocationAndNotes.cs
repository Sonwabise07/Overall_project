﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CtrlFind.Migrations
{
    /// <inheritdoc />
    public partial class AddAssignmentLocationAndNotes : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
