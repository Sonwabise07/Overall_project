﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CtrlFind.Migrations
{
    /// <inheritdoc />
    public partial class AlignAssetManagementSchema : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_AssetDocuments_AssetId",
                table: "AssetDocuments");

            migrationBuilder.AddColumn<DateTime>(
                name: "AcquisitionDate",
                table: "Assets",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "AuditOutcome",
                table: "Assets",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Category",
                table: "Assets",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "CompanyEntity",
                table: "Assets",
                type: "nvarchar(150)",
                maxLength: 150,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "CostCentre",
                table: "Assets",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "CustodyAgreementSigned",
                table: "Assets",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "EncryptionStatus",
                table: "Assets",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "HealthIndicator",
                table: "Assets",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "InvoiceReference",
                table: "Assets",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Notes",
                table: "Assets",
                type: "nvarchar(2000)",
                maxLength: 2000,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "PurchaseOrder",
                table: "Assets",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "WarrantyStart",
                table: "Assets",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "LocationId",
                table: "AssetAssignments",
                type: "nvarchar(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Notes",
                table: "AssetAssignments",
                type: "nvarchar(2000)",
                maxLength: 2000,
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_AssetDocuments_AssetId_UploadedAt",
                table: "AssetDocuments",
                columns: new[] { "AssetId", "UploadedAt" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_AssetDocuments_AssetId_UploadedAt",
                table: "AssetDocuments");

            migrationBuilder.DropColumn(
                name: "AcquisitionDate",
                table: "Assets");

            migrationBuilder.DropColumn(
                name: "AuditOutcome",
                table: "Assets");

            migrationBuilder.DropColumn(
                name: "Category",
                table: "Assets");

            migrationBuilder.DropColumn(
                name: "CompanyEntity",
                table: "Assets");

            migrationBuilder.DropColumn(
                name: "CostCentre",
                table: "Assets");

            migrationBuilder.DropColumn(
                name: "CustodyAgreementSigned",
                table: "Assets");

            migrationBuilder.DropColumn(
                name: "EncryptionStatus",
                table: "Assets");

            migrationBuilder.DropColumn(
                name: "HealthIndicator",
                table: "Assets");

            migrationBuilder.DropColumn(
                name: "InvoiceReference",
                table: "Assets");

            migrationBuilder.DropColumn(
                name: "Notes",
                table: "Assets");

            migrationBuilder.DropColumn(
                name: "PurchaseOrder",
                table: "Assets");

            migrationBuilder.DropColumn(
                name: "WarrantyStart",
                table: "Assets");

            migrationBuilder.DropColumn(
                name: "LocationId",
                table: "AssetAssignments");

            migrationBuilder.DropColumn(
                name: "Notes",
                table: "AssetAssignments");

            migrationBuilder.CreateIndex(
                name: "IX_AssetDocuments_AssetId",
                table: "AssetDocuments",
                column: "AssetId");
        }
    }
}
