# CtrlFind Asset Management API

ASP.NET Core (.NET 10) Web API for CTRL + Find Asset Hub, the internal asset management and asset tracking system. Data is stored in SQL Server through EF Core. Technical decisions are recorded in [docs/DECISIONS.md](docs/DECISIONS.md).

## First-time setup

1. Restore packages:

   ```powershell
   dotnet restore
   ```

2. Create the workflow migration if `Migrations/*_AddWorkflowPersistence.cs` does not exist yet. One developer runs this, reviews the result and commits it, so everyone shares the same migration:

   ```powershell
   dotnet tool install --global dotnet-ef   # once per machine
   dotnet ef migrations add AddWorkflowPersistence
   ```

3. Apply the migrations to your development database (connection string `AssetManagement` in `appsettings.json`):

   ```powershell
   dotnet ef database update
   ```

4. Load the development data by running `scripts/seed-dev-data.sql` in SSMS (or `sqlcmd`) against the same database. The script stops if it has already run.

5. Start the API:

   ```powershell
   dotnet run --launch-profile http
   ```

   OpenAPI is available in Development at `http://localhost:5102/openapi/v1.json`. Health check: `GET /api/v1/health`.

## Development sign-in

All seeded accounts use the password `AssetHub!2026`, except `maya.chen@example.com`, which keeps `AssetApi!2026`.

| Email | Roles |
|---|---|
| naledi.mokoena@ctrlfind.test | Fixed Assets |
| lindiwe.fourie@ctrlfind.test | Manager (Sales) |
| andile.shange@ctrlfind.test | Office/Building Manager (HQ Sandton, Midrand DC) |
| pieter.kruger@ctrlfind.test | IT Help Desk |
| fatima.essop@ctrlfind.test | HR |
| grace.naidoo@ctrlfind.test | Finance / CFO |
| tuan.nguyen@ctrlfind.test | Employee |
| admin@ctrlfind.test | Administrator |
| maya.chen@example.com | Manager, Fixed Assets, Administrator |

Every endpoint except login, refresh and health needs a bearer token. What a user can see depends on their role: employees see their own assets, managers see their department, and office/building managers see their locations (BRD Section 5).

Before any shared deployment, change `Jwt:SigningKey` and set `Cors:AllowedOrigins`.

## API areas

All routes start with `/api/v1`.

| Area | Routes |
|---|---|
| Authentication | `auth/login`, `auth/refresh`, `auth/logout`, `auth/me` |
| Asset register | `assets` (list, create, `bulk`, get, patch), `assets/{id}/lifecycle`, `assignments`, `return`, `hold-for-reassignment`, `history`, `documents`, `maintenance-log` |
| Transfers | `assets/{id}/transfers`, `transfers`, `transfers/{id}/approve`, `transfers/{id}/decline` |
| Onboarding | `onboarding-cases`, `{id}/reserve-stock`, `{id}/issue-assets`, `role-kits` |
| Offboarding | `offboarding-cases`, `{id}/resolve-item`, `{id}/complete` |
| Stock | `stock/items`, `stock/summary`, `stock/thresholds`, `stock/counts`, `stock/reconciliation`, `stock/alerts` |
| Faults and warranty | `maintenance-cases` (`diagnose`, `outcome`, `close`), `warranty-claims` (`close`), `warranty/expiring` |
| Loss, theft and AOD | `incidents`, `incidents/{id}/negligence-decision`, `aod-records`, `aod-records/{id}/payments` |
| Audits | `audits`, `{id}/scan`, `{id}/self-confirmations`, `{id}/items/{itemId}/confirm`, `{id}/items/{itemId}/resolve`, `{id}/close`, `self-confirmations` |
| Take-home screens | `take-home`, `take-home/issue`, `{id}/return`, `{id}/damage-review` |
| Emergency swaps | `emergency-swaps`, `{id}/resolve` |
| Disposal | `disposals`, `disposals/pending` |
| Reference data | `departments`, `employees`, `locations`, `storerooms` |
| Alerts and notifications | `alerts`, `notifications`, `notifications/{id}/read`, `notifications/read-all` |
| Reports | `reports/operational-dashboard`, `reports/management-dashboard`, `exports/powerbi`, `exports/powerbi/{dataset}.csv` |
| Data Assistant | `assistant/query`, `assistant/catalog`, `assistant/conversations`, `assistant/feedback`, `assistant/unanswered` |
| Integrations | `integrations/oracle/sync`, `integrations/pastel/sync`, `integrations/zendesk/events`, `integrations/atom/outbox` |

Responses use the standard envelopes: `{ data, meta }` for success and `{ error: { code, message, details, traceId } }` for errors.

## Business rules configuration

Values the BRD calls "configurable" are in the `AssetRules` section of `appsettings.json`: short-notice days, emergency swap resolution days, hold-for-reassignment days, repeat-incident threshold, audit confirmation window, laptop ageing years, warranty alert days and which transfer types need manager approval.

## Data Assistant

`POST /api/v1/assistant/query` answers plain-English questions from this system's own data, within the user's access. The question is matched to a supported question type and answered with read-only EF Core queries. No SQL is generated and nothing is estimated. Questions outside the supported types get a plain "out of scope" answer. Comparisons come with a chart, and follow-up questions such as "what about Durban?" or "show that as a chart" use the previous question's context.

The optional local Ollama model (`Assistant:UseLocalModel`) is used only to rephrase unusual wording into a supported question. It never sees data and never writes SQL. Every question is logged with whether it was answered; `GET assistant/unanswered` lists the gaps so new question types can be added.

## Smoke test

With the API built and the seed data loaded:

```powershell
pwsh -File scripts/smoke-test.ps1
```
