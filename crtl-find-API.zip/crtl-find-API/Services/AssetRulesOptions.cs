namespace CtrlFind.Services;

// Values the requirements call "configurable" (DEC-008). Defaults live in appsettings.json.
public sealed class AssetRulesOptions
{
    public const string SectionName = "AssetRules";

    public int ShortNoticeDays { get; init; } = 28;
    public int EmergencySwapResolutionDays { get; init; } = 5;
    public int HoldForReassignmentDays { get; init; } = 14;
    public int RepeatIncidentThreshold { get; init; } = 2;
    public int AuditConfirmationDays { get; init; } = 90;
    public int LaptopAgeingYears { get; init; } = 3;
    public bool PriorNegligenceRequiresManagerAcknowledgement { get; init; } = true;
    public int[] WarrantyAlertDays { get; init; } = [];
    public string[] TransferTypesRequiringApproval { get; init; } = [];
}
