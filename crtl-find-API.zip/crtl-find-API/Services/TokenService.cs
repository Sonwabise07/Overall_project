using System.Collections.Concurrent;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using CtrlFind.Contracts;
using Microsoft.IdentityModel.Tokens;

namespace CtrlFind.Services;

// Issues access tokens and rotates refresh tokens. Refresh tokens are kept in memory,
// so a restart signs users out; replace with a store when an identity provider is chosen (DEC-017).
public sealed class TokenService(IConfiguration configuration)
{
    private sealed record StoredRefreshToken(string UserId, string FamilyId, DateTimeOffset ExpiresAt, bool Revoked);
    private readonly ConcurrentDictionary<string, StoredRefreshToken> _refreshTokens = new();
    private readonly IConfigurationSection _jwt = configuration.GetSection("Jwt");

    public TokenResponse Issue(UserProfile user, bool rememberMe = false, string? familyId = null)
    {
        const int expiresIn = 3600;
        var now = DateTimeOffset.UtcNow;
        var claims = new List<Claim>
        {
            new("sub", user.UserId), new("employeeId", user.EmployeeId), new("name", user.DisplayName),
            new("email", user.Email), new("jti", Guid.NewGuid().ToString())
        };
        claims.AddRange(user.Roles.Select(role => new Claim("roles", role)));
        claims.AddRange(user.DepartmentIds.Select(id => new Claim("departmentIds", id)));
        claims.AddRange(user.LocationIds.Select(id => new Claim("locationIds", id)));

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwt["SigningKey"]!));
        var token = new JwtSecurityToken(
            _jwt["Issuer"], _jwt["Audience"], claims,
            now.UtcDateTime, now.AddSeconds(expiresIn).UtcDateTime,
            new SigningCredentials(key, SecurityAlgorithms.HmacSha256));

        var refreshToken = Convert.ToBase64String(RandomNumberGenerator.GetBytes(48));
        var refreshExpiry = now.AddDays(rememberMe ? 30 : 7);
        _refreshTokens[Hash(refreshToken)] = new(user.UserId, familyId ?? Guid.NewGuid().ToString(), refreshExpiry, false);
        return new(new JwtSecurityTokenHandler().WriteToken(token), "Bearer", expiresIn, refreshToken, refreshExpiry, user);
    }

    // Returns the owner of a valid refresh token and revokes it. Reuse of a revoked token revokes its whole family.
    public (string UserId, string FamilyId)? Consume(string refreshToken)
    {
        var hash = Hash(refreshToken);
        if (!_refreshTokens.TryGetValue(hash, out var stored) || stored.ExpiresAt <= DateTimeOffset.UtcNow) return null;
        if (stored.Revoked)
        {
            foreach (var pair in _refreshTokens.Where(x => x.Value.FamilyId == stored.FamilyId))
                _refreshTokens[pair.Key] = pair.Value with { Revoked = true };
            return null;
        }

        _refreshTokens[hash] = stored with { Revoked = true };
        return (stored.UserId, stored.FamilyId);
    }

    public void Revoke(string? refreshToken)
    {
        if (string.IsNullOrWhiteSpace(refreshToken)) return;
        var hash = Hash(refreshToken);
        if (_refreshTokens.TryGetValue(hash, out var stored)) _refreshTokens[hash] = stored with { Revoked = true };
    }

    private static string Hash(string value) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(value)));
}
