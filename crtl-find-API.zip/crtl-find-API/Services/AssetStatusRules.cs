using CtrlFind.Contracts;
using CtrlFind.Infrastructure.Persistence.Entities;

namespace CtrlFind.Services;

public static class AssetStatusRules
{
    // State-to-status mapping (DEC-004, OQ-03).
    public static OperationalStatus OperationalStatusFor(LifecycleState state) => state switch
    {
        LifecycleState.Ordered or LifecycleState.Received or LifecycleState.Registered
            or LifecycleState.InStorage or LifecycleState.Reserved => OperationalStatus.InStorage,
        LifecycleState.InRepair or LifecycleState.WarrantyClaim => OperationalStatus.InRepair,
        LifecycleState.Lost or LifecycleState.Stolen or LifecycleState.Retired
            or LifecycleState.Disposed => OperationalStatus.Retired,
        _ => OperationalStatus.InUse
    };

    public static void Apply(AssetEntity asset, LifecycleState state)
    {
        asset.LifecycleState = state.ToString();
        asset.OperationalStatus = OperationalStatusFor(state).ToString();
        asset.UpdatedAtUtc = DateTime.UtcNow;
    }

    // Registration is complete only once the asset is tagged (BR-8.1-01).
    public static bool RequiresTag(LifecycleState state) =>
        state is not (LifecycleState.Ordered or LifecycleState.Received);

    // Colour-coded laptop health (BR-8.3-04): red when out of warranty or past ageing + 1 year,
    // amber when warranty ends within 90 days or the laptop has reached the ageing threshold.
    public static HealthIndicator LaptopHealth(AssetEntity asset, DateTime today, int ageingYears)
    {
        var age = asset.AcquisitionDate is null ? 0 : (today - asset.AcquisitionDate.Value).TotalDays / 365.25;
        if (asset.WarrantyEnd is null || asset.WarrantyEnd < today || age >= ageingYears + 1) return HealthIndicator.Red;
        if (asset.WarrantyEnd < today.AddDays(90) || age >= ageingYears) return HealthIndicator.Amber;
        return HealthIndicator.Green;
    }

    // The scale runs New -> Damaged, so a higher value on return is a deterioration (BR-8.2-04).
    public static bool IsDeterioration(ConditionStatus issued, ConditionStatus returned) => returned > issued;

    // Audit risk score (dashboard "score factors: asset age, value, incident history, location type").
    public static string RiskLevel(AssetEntity asset, bool holderHasIncidents, DateTime today, int ageingYears)
    {
        var score = 0;
        var age = asset.AcquisitionDate is null ? 0 : (today - asset.AcquisitionDate.Value).TotalDays / 365.25;
        if (age >= ageingYears + 1) score += 2;
        else if (age >= ageingYears) score += 1;
        if (asset.PurchaseCost >= 25000) score += 2;
        else if (asset.PurchaseCost >= 15000) score += 1;
        if (holderHasIncidents) score += 2;
        if (asset.LocationSubStatus == nameof(LocationSubStatus.AtHome) || asset.LifecycleState == nameof(LifecycleState.OffSite)) score += 1;
        if (asset.AuditOutcome is not null && asset.AuditOutcome != nameof(AuditOutcome.Confirmed)) score += 2;
        return score >= 4 ? "High" : score >= 2 ? "Medium" : "Low";
    }

    public static bool NeedsDataWipe(AssetType type) =>
        type is AssetType.Laptop or AssetType.Desktop or AssetType.MobileDevice or AssetType.Tablet;

    public static string Describe(AssetEntity asset) =>
        string.Join(' ', new[] { asset.Make, asset.Model }.Where(x => !string.IsNullOrWhiteSpace(x))) is { Length: > 0 } name
            ? name
            : asset.AssetType;
}

public static class Enums
{
    public static T Parse<T>(string value) where T : struct, Enum =>
        Enum.TryParse<T>(value, ignoreCase: true, out var result) && Enum.IsDefined(result)
            ? result
            : throw new InvalidOperationException($"Stored value '{value}' is not a valid {typeof(T).Name}.");

    public static T? ParseOrNull<T>(string? value) where T : struct, Enum =>
        string.IsNullOrWhiteSpace(value) ? null : Parse<T>(value);
}
