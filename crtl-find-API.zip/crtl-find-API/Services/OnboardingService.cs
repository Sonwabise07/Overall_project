using CtrlFind.Contracts;
using CtrlFind.Infrastructure.Persistence;
using CtrlFind.Infrastructure.Persistence.Entities;
using Microsoft.EntityFrameworkCore;

namespace CtrlFind.Services;

// Kit reservation and shortfall rules for new hires (BR-8.4-01 to BR-8.4-05).
public sealed class OnboardingService(ApplicationDbContext db, AssetLifecycleService lifecycle)
{
    private static readonly string[] OpenStatuses = [nameof(CaseStatus.Open), nameof(CaseStatus.InProgress), nameof(CaseStatus.Blocked)];

    public static bool IsOpen(OnboardingCaseEntity c) => OpenStatuses.Contains(c.Status);

    public static IQueryable<OnboardingCaseEntity> OpenCases(IQueryable<OnboardingCaseEntity> cases) =>
        cases.Where(c => OpenStatuses.Contains(c.Status));

    // Reserves available spare stock for whatever part of the kit is still outstanding.
    // Stock in the case's own region is used first. Returns the shortfall that remains.
    public async Task<List<StockShortfallDto>> ReserveAsync(OnboardingCaseEntity onboardingCase, string userId)
    {
        var kit = await db.RoleKitItems.AsNoTracking().Where(k => k.JobRole == onboardingCase.JobRole).ToListAsync();
        var held = await db.OnboardingReservations
            .Where(r => r.CaseId == onboardingCase.CaseId && r.ReleasedAt == null)
            .GroupBy(r => r.AssetType)
            .Select(g => new { AssetType = g.Key, Count = g.Count() })
            .ToDictionaryAsync(x => x.AssetType, x => x.Count);

        var region = await db.Locations.Where(l => l.LocationId == onboardingCase.LocationId).Select(l => l.Region).FirstOrDefaultAsync();
        var inStorage = nameof(LifecycleState.InStorage);
        var damaged = nameof(ConditionStatus.Damaged);
        var shortfalls = new List<StockShortfallDto>();

        foreach (var item in kit)
        {
            var needed = item.Quantity - held.GetValueOrDefault(item.AssetType);
            if (needed <= 0) continue;

            var spares = await db.Assets
                .Where(a => a.AssetType == item.AssetType && a.LifecycleState == inStorage && a.Condition != damaged)
                .OrderBy(a => a.Region == region ? 0 : 1)
                .ThenBy(a => a.AssetNo)
                .Take(needed)
                .ToListAsync();

            foreach (var asset in spares)
            {
                lifecycle.ChangeState(asset, LifecycleState.Reserved, userId, $"Reserved for onboarding of {onboardingCase.EmployeeName}.");
                db.OnboardingReservations.Add(new OnboardingReservationEntity { CaseId = onboardingCase.CaseId, AssetId = asset.AssetId, AssetType = item.AssetType });
            }

            if (spares.Count < needed)
                shortfalls.Add(new(Enums.Parse<AssetType>(item.AssetType), needed - spares.Count, DateOnly.FromDateTime(onboardingCase.StartDate)));
        }

        return shortfalls;
    }

    // Outstanding kit items per case, after counting what is reserved or issued.
    public async Task<Dictionary<long, List<StockShortfallDto>>> ShortfallsAsync(IReadOnlyCollection<OnboardingCaseEntity> cases)
    {
        var roles = cases.Select(c => c.JobRole).Distinct().ToList();
        var ids = cases.Select(c => c.CaseId).ToList();
        var kits = await db.RoleKitItems.AsNoTracking().Where(k => roles.Contains(k.JobRole)).ToListAsync();
        var reserved = await db.OnboardingReservations.AsNoTracking()
            .Where(r => ids.Contains(r.CaseId) && r.ReleasedAt == null)
            .GroupBy(r => new { r.CaseId, r.AssetType })
            .Select(g => new { g.Key.CaseId, g.Key.AssetType, Count = g.Count() })
            .ToListAsync();

        return cases.ToDictionary(c => c.CaseId, c => kits
            .Where(k => k.JobRole == c.JobRole)
            .Select(k => new { k.AssetType, Missing = k.Quantity - reserved.Where(r => r.CaseId == c.CaseId && r.AssetType == k.AssetType).Sum(r => r.Count) })
            .Where(x => x.Missing > 0)
            .Select(x => new StockShortfallDto(Enums.Parse<AssetType>(x.AssetType), x.Missing, DateOnly.FromDateTime(c.StartDate)))
            .ToList());
    }

    public void NotifyShortfall(OnboardingCaseEntity onboardingCase, IReadOnlyList<StockShortfallDto> shortfalls)
    {
        if (!onboardingCase.IsConfirmed || shortfalls.Count == 0) return;
        var items = string.Join(", ", shortfalls.Select(s => $"{s.Quantity} x {s.AssetType}"));
        lifecycle.Notify(Roles.OfficeManager, "StockShortfall", "Stock needed for new hire",
            $"{items} needed by {onboardingCase.StartDate:dd MMM yyyy} for {onboardingCase.EmployeeName} ({onboardingCase.JobRole}).");
    }
}
