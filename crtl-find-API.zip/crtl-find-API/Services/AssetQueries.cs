using CtrlFind.Contracts;
using CtrlFind.Infrastructure.Persistence;
using CtrlFind.Infrastructure.Persistence.Entities;
using Microsoft.EntityFrameworkCore;

namespace CtrlFind.Services;

// Read-only queries shared by controllers, dashboards and the Data Assistant so they report the same figures.
public static class AssetQueries
{
    public static IQueryable<AssetEntity> StockAssets(ApplicationDbContext db) =>
        db.Assets.AsNoTracking().Where(a => a.LifecycleState == nameof(LifecycleState.InStorage) || a.LifecycleState == nameof(LifecycleState.Reserved));

    // BR-8.7-01 and BR-8.7-02.
    public static async Task<IReadOnlyList<StockTypeSummaryDto>> SummariseStockByTypeAsync(ApplicationDbContext db)
    {
        var counts = await StockAssets(db)
            .GroupBy(a => new { a.AssetType, a.LifecycleState, Damaged = a.Condition == nameof(ConditionStatus.Damaged) })
            .Select(g => new { g.Key.AssetType, g.Key.LifecycleState, g.Key.Damaged, Count = g.Count() })
            .ToListAsync();
        var thresholds = await db.StockThresholds.AsNoTracking().ToDictionaryAsync(t => t.AssetType, t => t.MinimumAvailable);

        return counts.Select(c => c.AssetType).Concat(thresholds.Keys).Distinct().OrderBy(t => t).Select(type =>
        {
            var rows = counts.Where(c => c.AssetType == type).ToList();
            var available = rows.Where(r => r.LifecycleState == nameof(LifecycleState.InStorage) && !r.Damaged).Sum(r => r.Count);
            var reserved = rows.Where(r => r.LifecycleState == nameof(LifecycleState.Reserved)).Sum(r => r.Count);
            var damaged = rows.Where(r => r.LifecycleState == nameof(LifecycleState.InStorage) && r.Damaged).Sum(r => r.Count);
            int? minimum = thresholds.TryGetValue(type, out var value) ? value : null;
            var alert = available == 0 ? "NoStock" : minimum is not null && available <= minimum ? "LowStock" : "Healthy";
            return new StockTypeSummaryDto(Enums.Parse<AssetType>(type), available, reserved, damaged, minimum, alert);
        }).ToList();
    }

    public static IReadOnlyList<AlertDto> StockAlerts(IReadOnlyList<StockTypeSummaryDto> summary) => summary
        .Where(s => s.Alert != "Healthy" && (s.MinimumThreshold is not null || s.Reserved > 0))
        .Select(s => new AlertDto(s.Alert, s.Alert == "NoStock" ? "High" : "Medium",
            s.Alert == "NoStock" ? $"No {s.AssetType} stock" : $"Low {s.AssetType} stock",
            $"{s.Available} available, minimum {s.MinimumThreshold?.ToString() ?? "not set"}.", null, null))
        .ToList();

    public static async Task<IReadOnlyList<WarrantyExpiryDto>> WarrantyExpiringAsync(IQueryable<AssetEntity> assets, int days, int[] alertDays)
    {
        var today = DateTime.UtcNow.Date;
        var cutoff = today.AddDays(days);
        string[] inactive = [nameof(LifecycleState.Retired), nameof(LifecycleState.Disposed), nameof(LifecycleState.Lost), nameof(LifecycleState.Stolen)];
        var rows = await assets
            .Where(a => a.WarrantyEnd != null && a.WarrantyEnd >= today && a.WarrantyEnd <= cutoff && !inactive.Contains(a.LifecycleState))
            .OrderBy(a => a.WarrantyEnd)
            .Select(a => new { a.AssetId, a.AssetNo, a.Make, a.Model, a.WarrantyVendor, WarrantyEnd = a.WarrantyEnd!.Value })
            .ToListAsync();

        var stages = alertDays.Length > 0 ? alertDays.OrderBy(d => d).ToArray() : [30, 60, 90];
        return rows.Select(r =>
        {
            var daysLeft = (int)(r.WarrantyEnd.Date - today).TotalDays;
            var stage = stages.FirstOrDefault(s => daysLeft <= s);
            return new WarrantyExpiryDto(r.AssetId, r.AssetNo, r.Make, r.Model, r.WarrantyVendor, DateOnly.FromDateTime(r.WarrantyEnd), daysLeft,
                stage == 0 ? "NotYetDue" : $"{stage}DayAlert");
        }).ToList();
    }
}
