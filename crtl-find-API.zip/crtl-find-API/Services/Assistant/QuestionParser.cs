using System.Globalization;
using System.Text.RegularExpressions;
using CtrlFind.Contracts;

namespace CtrlFind.Services.Assistant;

// Turns a plain-English question into a typed plan. No database access and no SQL:
// the plan only names a supported question type and validated filters (BR-8.15-02).
public static partial class QuestionParser
{
    private static readonly (string Pattern, AssetType Type)[] AssetTypes =
    [
        ("docking stations?|docks?", AssetType.DockingStation), ("laptops?|notebooks?|macbooks?", AssetType.Laptop),
        ("monitors?|screens?|displays?", AssetType.Monitor), ("desktops?|pcs?|workstations?", AssetType.Desktop),
        ("headsets?", AssetType.Headset), ("mobile devices?|mobile phones?|cell ?phones?|phones?|mobiles?", AssetType.MobileDevice),
        ("tablets?|ipads?", AssetType.Tablet), ("printers?", AssetType.Printer), ("keyboards?", AssetType.Keyboard),
        ("routers?|switches|network equipment", AssetType.NetworkEquipment), ("peripherals?|mice|mouse", AssetType.Peripheral)
    ];

    private static readonly (string Pattern, LifecycleState State)[] States =
    [
        ("held for reassignment|held at (the )?desk", LifecycleState.HeldForReassignment), ("in storage|in stock|in the storeroom", LifecycleState.InStorage),
        ("under investigation", LifecycleState.UnderInvestigation), ("under audit", LifecycleState.UnderAudit),
        ("in repair|being repaired|under repair", LifecycleState.InRepair), ("off-?site", LifecycleState.OffSite),
        ("inter-?entity", LifecycleState.InterEntityTransfer), ("reserved", LifecycleState.Reserved), ("retired", LifecycleState.Retired),
        ("disposed", LifecycleState.Disposed), ("ordered|on order", LifecycleState.Ordered), ("received", LifecycleState.Received),
        ("registered", LifecycleState.Registered)
    ];

    private static readonly string[] AssetWords = ["asset", "assets", "device", "devices", "equipment", "item", "items", "fleet", "inventory", "register"];

    private static readonly string[] OutOfScopeTopics =
    [
        "headcount|head count|how many (people|staff|employees) (work|are employed)", "salary|salaries|payroll|leave balance|leave days",
        "weather|news|share price|stock price|exchange rate", "depreciation|book value|net book|valuation",
        "password|log ?in to|reset my", "atom"
    ];

    public static AssistantPlan Parse(string question, AssistantPlan? previous, Vocabulary vocabulary, DateOnly today, string? currentEmployeeId)
    {
        var original = question.Trim();
        var t = Normalise(original);
        var none = new AssistantFilters();

        if (Is(t, @"^(hi|hello|hey|hiya|good (morning|afternoon|evening)|howzit|sawubona|molo)\b") && t.Split(' ').Length <= 4)
            return new(AssistantIntent.Greeting, none);
        if (Is(t, @"^(thanks|thank you|thx|cheers|great|perfect|ok(ay)?)\b") && t.Split(' ').Length <= 4)
            return new(AssistantIntent.Thanks, none);
        if (Is(t, @"\b(what can you (do|answer)|what (questions|can i ask)|help me|how do i use|what do you know)\b") || t is "help" or "?")
            return new(AssistantIntent.Help, none);

        var wantsChart = Is(t, @"\b(chart|graph|plot|visuali[sz]e|bar|trend line)\b");
        if (previous is not null && wantsChart && t.Split(' ').Length <= 8 && !Is(t, @"\b(how many|which|what|list|show me (the )?\w+ (by|per))\b"))
            return previous with { Intent = AssistantIntent.ShowAsChart, WantsChart = true, Topic = previous.Intent.ToString() };

        var filters = ExtractFilters(original, t, vocabulary, today, currentEmployeeId);
        var refersBack = Is(t, @"\b(it|its|this one|that one|this asset|that asset|the same asset)\b");
        if (refersBack && filters.AssetId is null && filters.UnknownIdentifier is null && previous?.Filters.AssetId is not null)
            filters = filters with { AssetId = previous.Filters.AssetId };
        var aboutOneAsset = filters.AssetId is not null || filters.UnknownIdentifier is not null;
        if (refersBack && !aboutOneAsset && Is(t, @"\b(is|was|does|has) it\b|\bits (warranty|status|location|history|condition)\b"))
            return new(AssistantIntent.Clarify, filters, Clarification: "Which asset do you mean? Give its asset number, tag or serial number.");
        var (ranking, top) = ExtractRanking(t);
        var groupBy = ExtractDimension(t) ?? (ranking != Ranking.None ? RankedDimension(t) : null);

        var isCount = Is(t, @"\b(how many|number of|count|total number|how much stock)\b");
        var hasAssetWord = AssetWords.Any(w => Is(t, $@"\b{w}\b")) || filters.AssetType is not null;
        var byCost = Is(t, @"\b(cost|costs|spend|spent|spending|value|worth|price|rand|amount)\b");

        AssistantPlan Plan(AssistantIntent intent, Dimension? dimension = null) =>
            new(intent, filters, dimension ?? groupBy, byCost, ranking, top, wantsChart || ranking != Ranking.None || filters.ComparePeriod is not null);

        if (OutOfScopeTopics.Any(p => Is(t, $@"\b({p})\b")) && !Is(t, @"\b(asset|laptop|monitor|warranty|stock)\b"))
            return new(AssistantIntent.OutOfScope, none, Topic: t);

        if (Is(t, @"\bdashboards?\b"))
        {
            var name = Match(t, @"\b(operational|operations|management|stock|warranty|incidents?|loss(es)?|audit|risk|onboarding|offboarding)\b");
            return name is null ? new(AssistantIntent.DashboardList, none) : new(AssistantIntent.DashboardOpen, none, Dashboard: name);
        }

        if (Is(t, @"\b(alerts?|needs? (my )?attention|action needed|what should i (look at|do)|anything urgent|to ?do list)\b"))
            return Plan(AssistantIntent.Alerts);

        if (Is(t, @"\b(history|audit trail|what happened (to|with)|timeline|movements? of|changes to)\b"))
        {
            if (filters.AssetId is null && filters.UnknownIdentifier is null && previous?.Filters.AssetId is not null)
                filters = filters with { AssetId = previous.Filters.AssetId };
            return filters.AssetId is null && filters.UnknownIdentifier is null
                ? new(AssistantIntent.Clarify, filters, Clarification: "Which asset should I show the history for? Give its asset number, tag or serial number.")
                : Plan(AssistantIntent.AssetHistory);
        }

        if (Is(t, @"\b(who has|who is using|who('s| is) holding|assigned to whom|who holds)\b"))
        {
            if (filters.AssetId is null && filters.UnknownIdentifier is null && previous?.Filters.AssetId is not null)
                filters = filters with { AssetId = previous.Filters.AssetId };
            if (filters.AssetId is not null || filters.UnknownIdentifier is not null) return Plan(AssistantIntent.AssetHolder);
        }

        if (Is(t, @"\b(overdue confirmations?|confirmations? (are )?overdue|late confirmations?)\b"))
            return Plan(AssistantIntent.OverdueConfirmations);
        if (Is(t, @"\b(unconfirmed|not (been )?confirmed|haven'?t confirmed|not verified|unverified)\b"))
            return Plan(AssistantIntent.UnconfirmedAssets);
        if (Is(t, @"\b(audit exceptions?|exceptions?|discrepanc(y|ies)|tamper(ing)?|mismatch(es)?|flagged)\b"))
            return Plan(AssistantIntent.AuditExceptions);

        if (Is(t, @"\b(aods?|acknowledg(e)?ments? of debt|owed|owing|outstanding debt|recover(y|ed|ies))\b"))
            return Plan(AssistantIntent.AodOutstanding);
        if (Is(t, @"\b(repeat(ed)?|more than once|multiple) (incidents?|loss(es)?|offenders?|negligen\w*)|\brepeat offenders?\b|\bnegligen(t|ce) (employees|people|staff)\b"))
            return Plan(AssistantIntent.RepeatIncidents);
        if (Is(t, @"\b(lost|loss(es)?|stolen|theft|thefts|incidents?|negligen\w*)\b") && !Is(t, @"\bwarranty\b"))
            return Plan(AssistantIntent.Incidents);

        if (Is(t, @"\bwarranty claims?\b|\bclaims?\b.*\bvendor\b|\b(returned|sent) to (the )?vendor\b"))
            return Plan(AssistantIntent.WarrantyClaims);
        if (Is(t, @"\b(faults?|faulty|broken|repairs?|repaired|zendesk|tickets?|accidental damage|wear and tear)\b"))
            return Plan(AssistantIntent.Faults);

        if (aboutOneAsset && Is(t, @"\b(warrant(y|ies)|condition|status|where is|location|worth|cost|encrypt\w*|custody|health)\b"))
            return Plan(AssistantIntent.AssetDetail);

        var goingOutOfWarranty = Is(t, @"\b(going|go|will (be|go)|about to go|due to go) out of warranty\b") || filters.Period?.From > today;
        if (!goingOutOfWarranty && Is(t, @"\b(out of warranty|warrant(y|ies) (has |have )?(expired|lapsed)|expired warrant(y|ies)|no longer under warranty)\b"))
            return Plan(AssistantIntent.OutOfWarranty);
        if (Is(t, @"\b(warrant(y|ies)|expir(e|es|ing|y|ies))\b"))
            return Plan(AssistantIntent.WarrantyExpiring) with
            {
                Filters = filters with { Period = filters.Period ?? new DateRange(today, today.AddDays(91), "the next 90 days") }
            };

        if (Is(t, @"\b(onboarding|new hires?|new joiners?|joiners?|starters?|starting soon|short notice)\b"))
            return Plan(AssistantIntent.Onboarding);
        if (Is(t, @"\b(offboarding|exits?|exiting|leavers?|leaving|resign\w*|recovery checklists?)\b"))
            return Plan(AssistantIntent.Offboarding);
        if (Is(t, @"\btransfers?\b|\b(waiting|awaiting|pending) (for )?(manager )?approval\b|\bmoves?\b"))
            return Plan(AssistantIntent.PendingTransfers);
        if (Is(t, @"\b(emergency|swaps?|temporary (laptop|asset|device)s?|loan(er)?s?)\b"))
            return Plan(AssistantIntent.EmergencySwaps);
        if (Is(t, @"\b(take-?home|home use|damage reviews?)\b") || (Is(t, @"\bat home\b") && filters.AssetType is AssetType.Monitor or null && !isCount && groupBy is null))
            return Plan(AssistantIntent.TakeHome);
        if (Is(t, @"\b(dispos(e|ed|al|als)|scrap(ped)?|awaiting disposition|written off|e-?waste)\b"))
            return Plan(AssistantIntent.PendingDisposal);

        var mentionsPurchase = Is(t, @"\b(purchas\w*|acquir\w*|acquisitions?|bought|buy|procur\w*|spend|spent|spending)\b");
        if ((byCost || mentionsPurchase) && (filters.ComparePeriod is not null || Is(t, @"\b(compare|compared|comparison|versus|vs|than last|than the previous|change from|difference)\b")))
            return Plan(AssistantIntent.CostComparison) with { Filters = WithComparison(filters, today) };
        if ((mentionsPurchase || byCost) && Is(t, @"\b(trend|by month|monthly|per month|over time|each month|month by month)\b"))
            return Plan(AssistantIntent.AcquisitionTrend, Dimension.Month);
        if (byCost && groupBy is null && !Is(t, @"\bwhich\b"))
            return Plan(AssistantIntent.CostSummary);

        if (Is(t, @"\b(stock|spares?|available|in storage|storerooms?|low stock|shortages?)\b") && filters.EmployeeId is null && filters.AssetId is null)
            return Plan(AssistantIntent.StockLevels);

        if (filters.EmployeeId is not null && !isCount && groupBy is null && Is(t, @"\b(has|have|holding|hold|assigned|using|with|kit|my)\b"))
            return Plan(AssistantIntent.EmployeeAssets);

        if (groupBy is not null && (hasAssetWord || isCount || ranking != Ranking.None || byCost || Is(t, @"\b(breakdown|split|spread|distribution)\b")))
            return Plan(AssistantIntent.AssetBreakdown);

        if (filters.AssetId is not null || filters.UnknownIdentifier is not null)
            return Plan(AssistantIntent.AssetDetail);

        if (isCount && (hasAssetWord || !filters.IsEmpty))
            return Plan(AssistantIntent.AssetCount);

        // Follow-ups reuse the previous question with the new filter: "what about Durban?", "only laptops".
        var isFollowUp = Is(t, @"^(what about|how about|and|only|just|same (for|but)|now|then|for|in|at|what if)\b")
            || (t.Split(' ').Length <= 3 && !Is(t, @"\b(show|list|how many|which|who|what|tell|find)\b"));
        if (previous is not null && !filters.IsEmpty && isFollowUp && IsResultIntent(previous.Intent))
        {
            var singleAsset = previous.Intent is AssistantIntent.AssetDetail or AssistantIntent.AssetHistory or AssistantIntent.AssetHolder;
            return singleAsset
                ? Plan(AssistantIntent.AssetList)
                : previous with { Filters = previous.Filters.Merge(filters), WantsChart = previous.WantsChart || wantsChart };
        }

        if (hasAssetWord || !filters.IsEmpty)
            return Plan(AssistantIntent.AssetList);

        return new(AssistantIntent.OutOfScope, none, Topic: t);
    }

    public static bool IsResultIntent(AssistantIntent intent) =>
        intent is not (AssistantIntent.Greeting or AssistantIntent.Help or AssistantIntent.Thanks or AssistantIntent.OutOfScope
            or AssistantIntent.Clarify or AssistantIntent.DashboardList);

    internal static AssistantFilters ExtractFilters(string original, string t, Vocabulary vocabulary, DateOnly today, string? currentEmployeeId)
    {
        AssetType? assetType = null;
        foreach (var (pattern, type) in AssetTypes)
        {
            if (!Is(t, $@"\b({pattern})\b")) continue;
            assetType = type;
            break;
        }

        LifecycleState? state = null;
        foreach (var (pattern, value) in States)
        {
            if (!Is(t, $@"\b({pattern})\b")) continue;
            state = value;
            break;
        }
        var mentionsLost = Is(t, @"\b(lost|loss|losses)\b");
        var mentionsStolen = Is(t, @"\b(stolen|theft|thefts)\b");
        if (mentionsStolen && !mentionsLost) state ??= LifecycleState.Stolen;
        else if (mentionsLost && !mentionsStolen) state ??= LifecycleState.Lost;

        OperationalStatus? status = Is(t, @"\bin use\b") ? OperationalStatus.InUse : null;
        bool? assigned = Is(t, @"\b(unassigned|not assigned|spare|unallocated|free)\b") ? false
            : Is(t, @"\b(assigned|allocated|issued)\b") ? true : null;
        bool? atHome = Is(t, @"\bat home\b|\bhome use\b") ? true : null;
        IncidentType? incidentType = mentionsStolen && !mentionsLost ? IncidentType.Theft : mentionsLost && !mentionsStolen ? IncidentType.Loss : null;

        var location = Find(original, t, vocabulary.Locations);
        var region = location is null ? Find(original, t, vocabulary.Regions) : null;
        var department = Find(original, t, vocabulary.Departments);
        var employee = Find(original, t, vocabulary.Employees);
        var make = Find(original, t, vocabulary.Makes)?.Id ?? (Is(t, @"\b(macbooks?|ipads?|apple)\b") ? "Apple" : null);
        if (employee is null && currentEmployeeId is not null && Is(t, @"\b(my|mine|i have|i hold|do i have|assigned to me)\b"))
            employee = new VocabularyEntry("me", currentEmployeeId, "you");

        var (period, compare) = ExtractPeriods(t, today);
        var identifier = ExtractIdentifier(original, employee?.Id);

        return new AssistantFilters
        {
            AssetType = assetType,
            Lifecycle = state,
            Status = status,
            LocationId = location?.Id,
            Region = region?.Id,
            DepartmentId = department?.Id,
            EmployeeId = employee?.Id,
            Make = make,
            UnknownIdentifier = identifier,
            Assigned = assigned,
            AtHome = atHome,
            IncidentType = incidentType,
            Period = period,
            ComparePeriod = compare
        };
    }

    // Short codes such as "IT" or "HR" only match when written in capitals, so "is it" is not read as IT.
    private static VocabularyEntry? Find(string original, string t, IReadOnlyList<VocabularyEntry> entries) =>
        entries.FirstOrDefault(e => e.Phrase.Length <= 3
            ? Regex.IsMatch(original, $@"\b{Regex.Escape(e.Phrase.ToUpperInvariant())}\b")
            : Regex.IsMatch(t, $@"\b{Regex.Escape(e.Phrase)}\b"));

    // Asset numbers, tags and serials contain letters and digits ("AST-0001", "EXT-009188", "DLL-7X92K11").
    private static string? ExtractIdentifier(string original, string? employeeId)
    {
        foreach (Match m in IdentifierRegex().Matches(original))
        {
            var token = m.Value.Trim('.', ',', '?', '!', ':', ';');
            if (token.Equals(employeeId, StringComparison.OrdinalIgnoreCase)) continue;
            if (Regex.IsMatch(token, @"^(Q[1-4]|20\d\d|\d+[a-z]{0,2}|EMP-\d+|\d{4}-\d{2}-\d{2})$", RegexOptions.IgnoreCase)) continue;
            return token;
        }
        return null;
    }

    private static (Ranking, int?) ExtractRanking(string t)
    {
        var topN = Regex.Match(t, @"\b(top|bottom|first)\s+(\d{1,2})\b");
        int? top = topN.Success ? int.Parse(topN.Groups[2].Value, CultureInfo.InvariantCulture) : null;
        if (topN.Success && topN.Groups[1].Value == "bottom") return (Ranking.Least, top);
        if (Is(t, @"\b(least|fewest|lowest|smallest|minimum)\b")) return (Ranking.Least, top);
        if (top is not null || Is(t, @"\b(most|highest|largest|biggest|maximum|top|leading|worst)\b")) return (Ranking.Most, top);
        return (Ranking.None, null);
    }

    private static Dimension? ExtractDimension(string t)
    {
        var m = Regex.Match(t, @"\b(by|per|each|which|what|across|split by|grouped by|for every)\s+(the\s+)?(location|locations|office|offices|site|sites|building|buildings|branch|region|regions|province|provinces|department|departments|team|teams|business unit|employee|employees|person|people|staff member|type|types|category|categories|asset type|status|statuses|lifecycle( state)?|make|makes|brand|brands|manufacturer|vendor|model|models|month|months|classification|fault type)\b");
        if (!m.Success) return null;
        return m.Groups[3].Value switch
        {
            "location" or "locations" or "office" or "offices" or "site" or "sites" or "building" or "buildings" or "branch" => Dimension.Location,
            "region" or "regions" or "province" or "provinces" => Dimension.Region,
            "department" or "departments" or "team" or "teams" or "business unit" => Dimension.Department,
            "employee" or "employees" or "person" or "people" or "staff member" => Dimension.Employee,
            "status" or "statuses" => Dimension.Status,
            "make" or "makes" or "brand" or "brands" or "manufacturer" or "vendor" => Dimension.Make,
            "model" or "models" => Dimension.Model,
            "month" or "months" => Dimension.Month,
            "classification" or "fault type" => Dimension.Classification,
            var v when v.StartsWith("lifecycle") => Dimension.Lifecycle,
            _ => Dimension.AssetType
        };
    }

    private static Dimension? RankedDimension(string t)
    {
        var m = Regex.Match(t, @"\b(locations|offices|sites|buildings|regions|provinces|departments|teams|employees|people|staff|types|categories|brands|makes|manufacturers|models)\b");
        return m.Success ? ExtractDimension($"by {m.Value.TrimEnd('s')}") ?? ExtractDimension($"by {m.Value}") : null;
    }

    private static AssistantFilters WithComparison(AssistantFilters filters, DateOnly today)
    {
        if (filters.Period is not null && filters.ComparePeriod is not null) return filters;
        var current = filters.Period ?? Quarter(today, 0);
        var length = current.To.DayNumber - current.From.DayNumber;
        var previous = length is >= 89 and <= 92 ? Quarter(current.From, -1)
            : length is >= 365 and <= 366 ? new DateRange(current.From.AddYears(-1), current.From, (current.From.Year - 1).ToString(CultureInfo.InvariantCulture))
            : length is >= 28 and <= 31 ? Month(current.From, -1)
            : new DateRange(current.From.AddDays(-length), current.From, "the previous period");
        return filters with { Period = current, ComparePeriod = previous };
    }

    // Finds every period mentioned, in order. The first is the period; a second is the comparison.
    internal static (DateRange?, DateRange?) ExtractPeriods(string t, DateOnly today)
    {
        var found = new List<(int Index, int Length, DateRange Range)>();
        void Add(Match m, DateRange? range)
        {
            if (range is not null && !found.Any(f => m.Index < f.Index + f.Length && f.Index < m.Index + m.Length))
                found.Add((m.Index, m.Length, range));
        }

        foreach (Match m in Regex.Matches(t, @"\bbetween (\d{4}-\d{2}-\d{2}) and (\d{4}-\d{2}-\d{2})\b"))
            Add(m, TryRange(m.Groups[1].Value, m.Groups[2].Value, inclusiveEnd: true));
        foreach (Match m in Regex.Matches(t, @"\b(since|from|after) (\d{4}-\d{2}-\d{2})\b"))
            Add(m, ParseDate(m.Groups[2].Value) is { } d ? new DateRange(m.Groups[1].Value == "after" ? d.AddDays(1) : d, today.AddDays(1), $"since {d:dd MMM yyyy}") : null);
        foreach (Match m in Regex.Matches(t, @"\b(before|until) (\d{4}-\d{2}-\d{2})\b"))
            Add(m, ParseDate(m.Groups[2].Value) is { } d ? new DateRange(new DateOnly(2000, 1, 1), d, $"before {d:dd MMM yyyy}") : null);
        foreach (Match m in Regex.Matches(t, @"\b(last|past|previous|next|coming|within(?: the next)?|in the next|in the last)\s+(\d{1,3})\s+(days?|weeks?|months?|years?)\b"))
        {
            var n = int.Parse(m.Groups[2].Value, CultureInfo.InvariantCulture);
            var days = m.Groups[3].Value switch { var u when u.StartsWith("week") => n * 7, var u when u.StartsWith("month") => n * 30, var u when u.StartsWith("year") => n * 365, _ => n };
            var forward = m.Groups[1].Value is "next" or "coming" or "in the next" || m.Groups[1].Value.StartsWith("within");
            Add(m, forward ? new DateRange(today, today.AddDays(days + 1), $"the next {n} {m.Groups[3].Value}") : new DateRange(today.AddDays(-days), today.AddDays(1), $"the last {n} {m.Groups[3].Value}"));
        }
        foreach (Match m in Regex.Matches(t, @"\b(this|current|last|previous|next|coming)\s+(week|month|quarter|year)\b"))
        {
            var offset = m.Groups[1].Value switch { "last" or "previous" => -1, "next" or "coming" => 1, _ => 0 };
            Add(m, m.Groups[2].Value switch
            {
                "week" => Week(today, offset),
                "month" => Month(today, offset),
                "quarter" => Quarter(today, offset),
                _ => new DateRange(new DateOnly(today.Year + offset, 1, 1), new DateOnly(today.Year + offset + 1, 1, 1), (today.Year + offset).ToString(CultureInfo.InvariantCulture))
            });
        }
        foreach (Match m in Regex.Matches(t, @"\bq([1-4])(?:\s+(20\d{2}))?\b"))
        {
            var year = m.Groups[2].Success ? int.Parse(m.Groups[2].Value, CultureInfo.InvariantCulture) : today.Year;
            var start = new DateOnly(year, (int.Parse(m.Groups[1].Value, CultureInfo.InvariantCulture) - 1) * 3 + 1, 1);
            Add(m, new DateRange(start, start.AddMonths(3), $"Q{m.Groups[1].Value} {year}"));
        }
        foreach (Match m in Regex.Matches(t, @"\b(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|sept|oct|nov|dec)(?:\s+(20\d{2}))?\b"))
        {
            if (m.Groups[1].Value == "may" && !m.Groups[2].Success) continue; // "may" is usually a verb
            var month = DateTime.ParseExact(m.Groups[1].Value[..3], "MMM", CultureInfo.InvariantCulture).Month;
            var year = m.Groups[2].Success ? int.Parse(m.Groups[2].Value, CultureInfo.InvariantCulture) : (month > today.Month ? today.Year - 1 : today.Year);
            var start = new DateOnly(year, month, 1);
            Add(m, new DateRange(start, start.AddMonths(1), start.ToString("MMMM yyyy", CultureInfo.InvariantCulture)));
        }
        foreach (Match m in Regex.Matches(t, @"\b(today|yesterday)\b"))
            Add(m, m.Value == "today" ? new DateRange(today, today.AddDays(1), "today") : new DateRange(today.AddDays(-1), today, "yesterday"));
        foreach (Match m in Regex.Matches(t, @"\b(20\d{2})\b"))
        {
            var year = int.Parse(m.Value, CultureInfo.InvariantCulture);
            Add(m, new DateRange(new DateOnly(year, 1, 1), new DateOnly(year + 1, 1, 1), m.Value));
        }

        var ordered = found.OrderBy(f => f.Index).Select(f => f.Range).ToList();
        return (ordered.ElementAtOrDefault(0), ordered.ElementAtOrDefault(1));
    }

    private static DateRange Week(DateOnly today, int offset)
    {
        var monday = today.AddDays(-(((int)today.DayOfWeek + 6) % 7) + offset * 7);
        return new DateRange(monday, monday.AddDays(7), offset switch { -1 => "last week", 1 => "next week", _ => "this week" });
    }

    private static DateRange Month(DateOnly date, int offset)
    {
        var start = new DateOnly(date.Year, date.Month, 1).AddMonths(offset);
        return new DateRange(start, start.AddMonths(1), start.ToString("MMMM yyyy", CultureInfo.InvariantCulture));
    }

    private static DateRange Quarter(DateOnly date, int offset)
    {
        var start = new DateOnly(date.Year, (date.Month - 1) / 3 * 3 + 1, 1).AddMonths(offset * 3);
        return new DateRange(start, start.AddMonths(3), $"Q{(start.Month - 1) / 3 + 1} {start.Year}");
    }

    private static DateRange? TryRange(string from, string to, bool inclusiveEnd) =>
        ParseDate(from) is { } f && ParseDate(to) is { } e && e >= f
            ? new DateRange(f, inclusiveEnd ? e.AddDays(1) : e, $"{f:dd MMM yyyy} to {e:dd MMM yyyy}")
            : null;

    private static DateOnly? ParseDate(string value) =>
        DateOnly.TryParseExact(value, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var d) ? d : null;

    private static string Normalise(string text) =>
        Regex.Replace(Regex.Replace(text.ToLowerInvariant().Replace('’', '\''), @"[^\p{L}\p{N}\s\-'/?]", " "), @"\s+", " ").Trim();

    private static bool Is(string text, string pattern) => Regex.IsMatch(text, pattern);

    private static string? Match(string text, string pattern) => Regex.Match(text, pattern) is { Success: true } m ? m.Groups[1].Value : null;

    [GeneratedRegex(@"\b[A-Za-z]{1,6}[-_]?[A-Za-z0-9]*\d[A-Za-z0-9\-_]*\b")]
    private static partial Regex IdentifierRegex();
}
