using System.Text.Json;
using System.Text.Json.Serialization;
using CtrlFind.Contracts;
using CtrlFind.Infrastructure.Persistence;
using CtrlFind.Infrastructure.Persistence.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace CtrlFind.Services.Assistant;

// Orchestrates one question: understand it, answer it from data, remember context for follow-ups,
// log it for coverage review and, when the user opts in, save the conversation.
public sealed class AssistantService(
    ApplicationDbContext db,
    AssistantVocabulary vocabulary,
    AssistantQueryRunner runner,
    LocalModelPlanner localModel,
    IMemoryCache cache,
    ILogger<AssistantService> logger)
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web) { Converters = { new JsonStringEnumConverter() } };
    private static readonly TimeSpan ContextLifetime = TimeSpan.FromMinutes(30);

    public static readonly IReadOnlyList<AssistantQuestionTypeDto> Catalogue =
    [
        new("Counts and lists", "How many assets, of which type, where and in what state.", ["How many laptops are in Durban?", "Show monitors at home", "How many assets are in storage?"]),
        new("Asset lookup", "Details, holder and permanent history of one asset by number, tag or serial.", ["Tell me about AST-0001", "Who has AST-0001?", "Show the history of AST-0001"]),
        new("Comparisons and rankings", "Breakdowns by location, department, type, status or make, with a chart.", ["Which office has the most laptops?", "Assets by department", "Top 3 locations by asset value"]),
        new("Warranty timelines", "What goes out of warranty and when, and what is already out.", ["Show assets going out of warranty next month", "How many laptops are out of warranty?"]),
        new("Confirmations and audits", "Unconfirmed assets, overdue self-confirmations and audit exceptions.", ["How many laptops are currently unconfirmed?", "Which office has the most audit exceptions?", "Overdue confirmations"]),
        new("Costs", "Recorded purchase cost (from Pastel), comparisons between periods and monthly trends.", ["Total cost of laptops", "Compare purchase cost this quarter with last quarter", "Monthly purchase trend"]),
        new("Loss, theft and AOD", "Incidents, repeat incidents and outstanding Acknowledgements of Debt.", ["Lost or stolen assets this year", "Repeat incidents", "Outstanding AOD balance"]),
        new("Workflows", "Stock, faults, warranty claims, new hires, exits, transfers, swaps, take-home screens and disposal.", ["Show stock levels", "Open fault cases", "New hires starting next month", "Transfers waiting for approval"]),
        new("Dashboards and alerts", "Open a dashboard in the chat, or see what needs attention.", ["List dashboards", "Open the operational dashboard", "What needs my attention?"])
    ];

    public async Task<AssistantQueryResponseDto> AskAsync(AssistantQueryRequest request, IQueryable<AssetEntity> assets, AssistantUser user, CancellationToken cancellationToken)
    {
        var conversationId = Guid.TryParse(request.ConversationId, out var existing) ? existing : Guid.NewGuid();
        var cacheKey = $"assistant:plan:{user.UserId}:{conversationId}";
        var previous = cache.Get<AssistantPlan>(cacheKey) ?? await SavedPlanAsync(conversationId, user.UserId);
        var vocab = await vocabulary.GetAsync();
        var today = DateOnly.FromDateTime(AssistantText.LocalNow());

        var plan = QuestionParser.Parse(request.Question, previous, vocab, today, user.EmployeeId);
        if (plan.Intent == AssistantIntent.OutOfScope && await localModel.RewriteAsync(request.Question, cancellationToken) is { } rewrite)
        {
            var retry = QuestionParser.Parse(rewrite, previous, vocab, today, user.EmployeeId);
            if (retry.Intent != AssistantIntent.OutOfScope) plan = retry;
        }

        plan = await ResolveIdentifierAsync(ApplyContext(plan, request.Context), assets);

        AssistantResult result;
        try
        {
            result = await AnswerAsync(plan, previous, assets, user, vocab);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            logger.LogError(ex, "Assistant failed to answer intent {Intent}", plan.Intent);
            result = new AssistantResult("I couldn't get that figure from the database just now, so I won't guess. Please try again in a moment.");
        }

        if (QuestionParser.IsResultIntent(plan.Intent) && plan.Intent != AssistantIntent.ShowAsChart)
            cache.Set(cacheKey, plan, new MemoryCacheEntryOptions { SlidingExpiration = ContextLifetime });

        var log = new AssistantQuestionLogEntity
        {
            UserId = user.UserId,
            ConversationId = conversationId,
            Question = request.Question.Length > 500 ? request.Question[..500] : request.Question,
            Intent = plan.Intent.ToString(),
            Answered = !result.Unsupported
        };
        db.AssistantQuestionLog.Add(log);
        await db.SaveChangesAsync(cancellationToken);

        var response = new AssistantQueryResponseDto(result.Answer, result.Sources ?? [], result.Unsupported, plan.Intent.ToString(),
            result.Table, result.Chart, result.Suggestions, conversationId.ToString(), result.Evidence, log.LogId.ToString());

        if (request.SaveHistory) await SaveTurnAsync(conversationId, user.UserId, request.Question, response, plan, cancellationToken);
        return response;
    }

    private async Task<AssistantResult> AnswerAsync(AssistantPlan plan, AssistantPlan? previous, IQueryable<AssetEntity> assets, AssistantUser user, Vocabulary vocab)
    {
        switch (plan.Intent)
        {
            case AssistantIntent.Greeting:
                return new("Hi! I answer questions from Asset Hub's own data: assets, where they are, who has them, stock, warranty, audits, losses, costs and the workflows behind them. What would you like to know?",
                    Suggestions: ["What needs my attention?", "How many laptops are currently unconfirmed?", "List dashboards"]);
            case AssistantIntent.Thanks:
                return new("You're welcome. Ask me anything else about your assets.", Suggestions: ["What needs my attention?", "Show stock levels"]);
            case AssistantIntent.Help:
                return new("These are the questions I can answer. Every figure comes straight from Asset Hub's records; if something isn't recorded, I'll say so.",
                    new AssistantTable(["Question type", "Examples"], Catalogue.Select(c => (IReadOnlyList<string?>)[c.Name, string.Join(" · ", c.Examples)]).ToList(), Catalogue.Count),
                    Suggestions: Catalogue.Select(c => c.Examples[0]).Take(4).ToList());
            case AssistantIntent.Clarify:
                return new(plan.Clarification ?? "Could you tell me which asset, place or period you mean?");
            case AssistantIntent.OutOfScope:
                return OutOfScope(plan.Topic ?? string.Empty);
            case AssistantIntent.ShowAsChart:
                return await ChartOfPreviousAsync(previous, assets, user, vocab);
            default:
                return await runner.RunAsync(plan, assets, user, vocab);
        }
    }

    private async Task<AssistantResult> ChartOfPreviousAsync(AssistantPlan? previous, IQueryable<AssetEntity> assets, AssistantUser user, Vocabulary vocab)
    {
        if (previous is null) return new("Ask a question first, then I can show the result as a chart.", Suggestions: ["Laptops by location"]);

        var charted = await runner.RunAsync(previous with { WantsChart = true }, assets, user, vocab);
        if (charted.Chart is null && previous.GroupBy is null && previous.Intent is AssistantIntent.AssetCount or AssistantIntent.AssetList)
            charted = await runner.RunAsync(previous with { Intent = AssistantIntent.AssetBreakdown, GroupBy = Dimension.Location, WantsChart = true }, assets, user, vocab);

        return charted.Chart is null
            ? new("That answer is a single figure or a plain list, so there's nothing to compare on a chart. Try asking for a breakdown, such as \"laptops by location\".",
                Suggestions: ["Laptops by location", "Assets by status"])
            : charted with { Answer = $"Here it is as a chart. {charted.Answer}" };
    }

    // BR-8.15-02: say plainly when a question is outside the supported scope.
    private static AssistantResult OutOfScope(string topic)
    {
        var redirect = topic switch
        {
            var t when t.Contains("headcount") || t.Contains("head count") || t.Contains("salary") || t.Contains("payroll") || t.Contains("leave") || t.Contains("people") || t.Contains("staff") =>
                " For headcount, pay or leave, use Oracle HR reporting.",
            var t when t.Contains("depreciation") || t.Contains("book value") || t.Contains("valuation") =>
                " Depreciation and valuation stay in Pastel and Atom; I can give recorded purchase costs.",
            var t when t.Contains("atom") => " I only read Asset Hub's own data and never query Atom directly.",
            _ => string.Empty
        };
        return new($"That question is outside what I can answer. I only answer from Asset Hub's own records about assets and their workflows.{redirect}",
            Suggestions: ["What can you do?", "How many assets do we have?", "What needs my attention?"], Unsupported: true);
    }

    // Filters chosen in the app (for example a department picker) apply when the question did not set them.
    private static AssistantPlan ApplyContext(AssistantPlan plan, AssistantContext? context)
    {
        if (context is null) return plan;
        var f = plan.Filters;
        return plan with
        {
            Filters = f with
            {
                DepartmentId = f.DepartmentId ?? (context.DepartmentIds is [var department] ? department : null),
                LocationId = f.LocationId ?? (f.Region is null && context.LocationIds is [var location] ? location : null),
                AssetType = f.AssetType ?? (context.AssetTypes is [var type] ? type : null)
            }
        };
    }

    // Asset numbers, tags and serials are matched exactly against the assets this user can see.
    private static async Task<AssistantPlan> ResolveIdentifierAsync(AssistantPlan plan, IQueryable<AssetEntity> assets)
    {
        if (plan.Filters.UnknownIdentifier is not { } token) return plan;

        var assetId = await assets.Where(a => a.AssetNo == token || a.AssetTag == token || a.SerialNumber == token).Select(a => a.AssetId).FirstOrDefaultAsync();
        if (assetId is not null) return plan with { Filters = plan.Filters with { AssetId = assetId, UnknownIdentifier = null } };

        var needsAsset = plan.Intent is AssistantIntent.AssetDetail or AssistantIntent.AssetHistory or AssistantIntent.AssetHolder;
        return needsAsset ? plan : plan with { Filters = plan.Filters with { UnknownIdentifier = null } };
    }

    private async Task<AssistantPlan?> SavedPlanAsync(Guid conversationId, string userId)
    {
        var context = await db.AssistantConversations.AsNoTracking()
            .Where(c => c.ConversationId == conversationId && c.OwnerId == userId)
            .Select(c => c.ContextJson)
            .FirstOrDefaultAsync();
        if (context is null) return null;
        try { return JsonSerializer.Deserialize<AssistantPlan>(context, Json); }
        catch (JsonException) { return null; }
    }

    private async Task SaveTurnAsync(Guid conversationId, string userId, string question, AssistantQueryResponseDto response, AssistantPlan plan, CancellationToken cancellationToken)
    {
        var conversation = await db.AssistantConversations.FirstOrDefaultAsync(c => c.ConversationId == conversationId, cancellationToken);
        if (conversation is null)
        {
            conversation = new AssistantConversationEntity { ConversationId = conversationId, OwnerId = userId, Title = question.Length > 120 ? question[..120] : question };
            db.AssistantConversations.Add(conversation);
        }
        else if (conversation.OwnerId != userId)
        {
            return;
        }

        if (QuestionParser.IsResultIntent(plan.Intent) && plan.Intent != AssistantIntent.ShowAsChart)
            conversation.ContextJson = JsonSerializer.Serialize(plan, Json);
        conversation.UpdatedAtUtc = DateTime.UtcNow;
        db.AssistantMessages.Add(new AssistantMessageEntity { ConversationId = conversationId, Role = "user", Content = question });
        db.AssistantMessages.Add(new AssistantMessageEntity { ConversationId = conversationId, Role = "assistant", Content = response.Answer, MetadataJson = JsonSerializer.Serialize(response, Json) });
        await db.SaveChangesAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<AssistantConversationSummaryDto>> ConversationsAsync(string userId) =>
        (await db.AssistantConversations.AsNoTracking().Where(c => c.OwnerId == userId).OrderByDescending(c => c.UpdatedAtUtc).Take(50).ToListAsync())
            .Select(c => new AssistantConversationSummaryDto(c.ConversationId.ToString(), c.Title, new DateTimeOffset(DateTime.SpecifyKind(c.UpdatedAtUtc, DateTimeKind.Utc)))).ToList();

    public async Task<AssistantConversationDto?> ConversationAsync(string userId, Guid conversationId)
    {
        var conversation = await db.AssistantConversations.AsNoTracking().FirstOrDefaultAsync(c => c.ConversationId == conversationId && c.OwnerId == userId);
        if (conversation is null) return null;

        var messages = await db.AssistantMessages.AsNoTracking().Where(m => m.ConversationId == conversationId).OrderBy(m => m.MessageId).ToListAsync();
        return new AssistantConversationDto(conversation.ConversationId.ToString(), conversation.Title, messages.Select(m => new AssistantMessageDto(
            m.Role, m.Content, m.MetadataJson is null ? null : JsonSerializer.Deserialize<AssistantQueryResponseDto>(m.MetadataJson, Json),
            new DateTimeOffset(DateTime.SpecifyKind(m.CreatedAtUtc, DateTimeKind.Utc)))).ToList());
    }

    public async Task<bool> DeleteConversationAsync(string userId, Guid conversationId)
    {
        var conversation = await db.AssistantConversations.FirstOrDefaultAsync(c => c.ConversationId == conversationId && c.OwnerId == userId);
        if (conversation is null) return false;
        db.AssistantConversations.Remove(conversation);
        await db.SaveChangesAsync();
        cache.Remove($"assistant:plan:{userId}:{conversationId}");
        return true;
    }

    public async Task<bool> FeedbackAsync(string userId, AssistantFeedbackRequest request)
    {
        if (!long.TryParse(request.MessageId, out var id)) return false;
        var entry = await db.AssistantQuestionLog.FirstOrDefaultAsync(l => l.LogId == id && l.UserId == userId);
        if (entry is null) return false;
        entry.Helpful = request.Helpful;
        entry.Comment = request.Comment;
        await db.SaveChangesAsync();
        return true;
    }

    // Questions the assistant could not answer, or that users marked unhelpful, to guide new question types.
    public async Task<IReadOnlyList<UnansweredQuestionDto>> UnansweredAsync() =>
        (await db.AssistantQuestionLog.AsNoTracking()
            .Where(l => !l.Answered || l.Helpful == false)
            .GroupBy(l => l.Question)
            .Select(g => new { Question = g.Key, Times = g.Count(), NotHelpful = g.Count(l => l.Helpful == false), Last = g.Max(l => l.CreatedAtUtc) })
            .OrderByDescending(x => x.Times).Take(100).ToListAsync())
        .Select(x => new UnansweredQuestionDto(x.Question, x.Times, x.NotHelpful, new DateTimeOffset(DateTime.SpecifyKind(x.Last, DateTimeKind.Utc)))).ToList();
}

public static class AssistantServiceCollectionExtensions
{
    public static IServiceCollection AddAssistant(this IServiceCollection services)
    {
        services.AddMemoryCache();
        services.AddHttpClient(nameof(LocalModelPlanner));
        services.AddScoped<AssistantVocabulary>();
        services.AddScoped<AssistantQueryRunner>();
        services.AddScoped<LocalModelPlanner>();
        services.AddScoped<AssistantService>();
        return services;
    }
}
