using System.Globalization;
using System.Text.RegularExpressions;
using CtrlFind.Contracts;
using CtrlFind.Infrastructure.Persistence.Entities;

namespace CtrlFind.Services.Assistant;

// Wording and formatting for answers: plain English, exact figures, no estimates.
internal static partial class AssistantText
{
    private static readonly CultureInfo Culture = CultureInfo.InvariantCulture;

    public static string Money(decimal value) => $"R {value.ToString("N2", Culture)}";

    public static string Date(DateTime? value) => value is null ? "Not recorded" : value.Value.ToString("dd MMM yyyy", Culture);

    public static string Date(DateOnly? value) => value is null ? "Not recorded" : value.Value.ToString("dd MMM yyyy", Culture);

    public static string Number(decimal value) => value == Math.Round(value) ? value.ToString("N0", Culture) : value.ToString("N1", Culture);

    public static string Count(int n, string singular, string? plural = null) =>
        $"{n.ToString("N0", Culture)} {(n == 1 ? singular : plural ?? singular + "s")}";

    // "InStorage" -> "In storage"
    public static string Humanise(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "Not recorded";
        var words = CamelCase().Replace(value, " $1").Trim().ToLowerInvariant();
        return char.ToUpperInvariant(words[0]) + words[1..];
    }

    public static string Noun(AssetType? type, bool plural = true) => type switch
    {
        null => plural ? "assets" : "asset",
        AssetType.DockingStation => plural ? "docking stations" : "docking station",
        AssetType.MobileDevice => plural ? "mobile devices" : "mobile device",
        AssetType.NetworkEquipment => plural ? "network equipment items" : "network equipment item",
        AssetType.Other => plural ? "other assets" : "other asset",
        AssetType t => plural ? t.ToString().ToLowerInvariant() + "s" : t.ToString().ToLowerInvariant()
    };

    public static string CountOf(int n, AssetType? type) => $"{n.ToString("N0", Culture)} {Noun(type, n != 1)}";

    // "laptops at Durban Office in Finance held by Maya Chen"
    public static string Scope(AssistantFilters f, Vocabulary vocabulary, bool includePeriod = false, string periodVerb = "acquired")
    {
        var parts = new List<string>();
        if (f.Make is not null) parts.Add($"made by {f.Make}");
        if (f.Lifecycle is not null) parts.Add(Humanise(f.Lifecycle.ToString()).ToLowerInvariant());
        if (f.Status is not null) parts.Add(Humanise(f.Status.ToString()).ToLowerInvariant());
        if (f.Assigned == true && f.EmployeeId is null) parts.Add("assigned");
        if (f.Assigned == false) parts.Add("unassigned");
        if (f.AtHome == true) parts.Add("at home");
        if (f.LocationId is not null) parts.Add($"at {vocabulary.LocationNames.GetValueOrDefault(f.LocationId, f.LocationId)}");
        if (f.Region is not null) parts.Add($"in {f.Region}");
        if (f.DepartmentId is not null) parts.Add($"in {vocabulary.DepartmentNames.GetValueOrDefault(f.DepartmentId, f.DepartmentId)}");
        if (f.EmployeeId is not null) parts.Add($"held by {EmployeeName(f.EmployeeId, vocabulary)}");
        if (includePeriod && f.Period is not null) parts.Add($"{periodVerb} {PeriodPhrase(f.Period)}");
        return parts.Count == 0 ? string.Empty : " " + string.Join(' ', parts);
    }

    public static string PeriodPhrase(DateRange period) =>
        period.Label.StartsWith("the ") || period.Label.StartsWith("since") || period.Label.StartsWith("before") || period.Label is "today" or "yesterday"
            || period.Label.StartsWith("this ") || period.Label.StartsWith("last ") || period.Label.StartsWith("next ")
            ? period.Label
            : $"in {period.Label}";

    public static string EmployeeName(string employeeId, Vocabulary vocabulary) =>
        vocabulary.Employees.FirstOrDefault(e => e.Id == employeeId)?.Label ?? employeeId;

    public static string Location(AssetEntity asset, Vocabulary vocabulary)
    {
        if (asset.LocationSubStatus == nameof(LocationSubStatus.AtHome)) return "At home";
        var name = asset.LocationId is null ? null : vocabulary.LocationNames.GetValueOrDefault(asset.LocationId, asset.LocationId);
        var parts = new[] { name ?? asset.Region, asset.Floor is null ? null : $"Fl {asset.Floor}", asset.Desk, asset.StoreroomId };
        var text = string.Join(" · ", parts.Where(p => !string.IsNullOrWhiteSpace(p)));
        return text.Length == 0 ? "Not recorded" : text;
    }

    public static string Evidence(string source, int records) =>
        $"Source: {source} ({Count(records, "record")} in your access). As of {LocalNow().ToString("dd MMM yyyy, HH:mm", Culture)}.";

    // The business runs on South African time; fall back to UTC if the zone is unavailable.
    public static DateTime LocalNow()
    {
        try { return TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, "Africa/Johannesburg"); }
        catch (TimeZoneNotFoundException) { return DateTime.UtcNow; }
    }

    public static string JoinWithAnd(IReadOnlyList<string> items) => items.Count switch
    {
        0 => string.Empty,
        1 => items[0],
        _ => string.Join(", ", items.Take(items.Count - 1)) + " and " + items[^1]
    };

    [GeneratedRegex("(?<=[a-z])([A-Z])")]
    private static partial Regex CamelCase();
}
