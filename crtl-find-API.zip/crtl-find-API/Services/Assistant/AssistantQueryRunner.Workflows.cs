using CtrlFind.Contracts;
using CtrlFind.Infrastructure.Persistence.Entities;
using Microsoft.EntityFrameworkCore;
using static CtrlFind.Services.Assistant.AssistantText;

namespace CtrlFind.Services.Assistant;

public sealed partial class AssistantQueryRunner
{
    private static readonly string[] ManagementRoles = [Roles.Manager, Roles.OfficeManager, Roles.FixedAssets, Roles.Hr, Roles.Finance, Roles.Administrator];
    private static readonly string[] OperatorRoles = [Roles.FixedAssets, Roles.OfficeManager, Roles.Hr, Roles.Administrator];
    private static readonly string[] FinanceRoles = [Roles.Hr, Roles.Finance, Roles.FixedAssets, Roles.Administrator];

    private static AssistantResult NoAccess(string what) =>
        new($"{what} is only available to the teams that manage it. You can still ask about your own assets.", Suggestions: ["What assets do I have?", "What can you do?"]);

    // ---------- Audit and confirmation ----------

    // BRD example: "How many laptops are currently unconfirmed?"
    private async Task<AssistantResult> UnconfirmedAsync(Run run)
    {
        var cutoff = run.Today.AddDays(-lifecycle.Rules.AuditConfirmationDays);
        string[] waiting = [nameof(AuditOutcome.AwaitingConfirmation), nameof(AuditOutcome.Unconfirmed)];
        var query = Filtered(run, byAcquisition: false).Where(a => a.OperationalStatus == nameof(OperationalStatus.InUse)
            && ((a.AuditOutcome != null && waiting.Contains(a.AuditOutcome)) || a.LastAuditDate == null || a.LastAuditDate < cutoff));
        var definition = $"not confirmed in the last {lifecycle.Rules.AuditConfirmationDays} days, or still waiting for a self-confirmation reply";
        if (run.Plan.GroupBy is { } dimension) return await GroupedAsync(run, query, dimension, $"unconfirmed {Noun(run.Filters.AssetType)}");

        var total = await query.CountAsync();
        var assets = await query.OrderBy(a => a.LastAuditDate).Take(MaxRows).ToListAsync();
        var scope = Scope(run.Filters, run.Vocabulary);
        if (total == 0) return new($"All {Noun(run.Filters.AssetType)} in use{scope} are confirmed ({definition.Replace("not ", "")}).", Evidence: Evidence(AssetSource, 0));

        var rows = assets.Select(a => (IReadOnlyList<string?>)[a.AssetNo, AssetStatusRules.Describe(a), a.EmployeeName ?? "Not assigned", Location(a, run.Vocabulary),
            a.LastAuditDate is null ? "Never" : Date(a.LastAuditDate),
            a.AuditOutcome is not null && waiting.Contains(a.AuditOutcome) ? Humanise(a.AuditOutcome) : "Not confirmed recently"]).ToList();
        return new($"{CountOf(total, run.Filters.AssetType)}{scope} {(total == 1 ? "is" : "are")} currently unconfirmed: {definition}.",
            new AssistantTable(["Asset", "Make and model", "Assigned to", "Location", "Last confirmed", "Reason"], rows, total),
            Sources: AssetSources(assets), Evidence: Evidence(AssetSource, total),
            Suggestions: [$"Unconfirmed {Noun(run.Filters.AssetType)} by location", "Which office has the most audit exceptions?", "Overdue confirmations"]);
    }

    private async Task<AssistantResult> OverdueConfirmationsAsync(Run run)
    {
        var rows = await db.AuditItems.AsNoTracking()
            .Where(i => i.Method == nameof(AuditMethod.SelfConfirmation)
                && (i.Outcome == nameof(AuditOutcome.Unconfirmed) || i.Outcome == nameof(AuditOutcome.AwaitingConfirmation)) && i.ResolvedAt == null)
            .Join(db.Audits, i => i.AuditId, a => a.AuditId, (i, a) => new { Item = i, a.AuditName, a.ScheduledEndDate })
            .Where(x => x.Item.Outcome == nameof(AuditOutcome.Unconfirmed) || x.ScheduledEndDate < run.Today)
            .Join(Filtered(run, byAcquisition: false), x => x.Item.AssetId, a => a.AssetId, (x, a) => new { x.AuditName, x.ScheduledEndDate, Asset = a })
            .OrderBy(x => x.ScheduledEndDate)
            .ToListAsync();

        if (rows.Count == 0) return new("No self-confirmations are overdue.", Evidence: Evidence("Audits", 0), Suggestions: ["How many laptops are currently unconfirmed?"]);

        var table = rows.Take(MaxRows).Select(x => (IReadOnlyList<string?>)[x.Asset.AssetNo, AssetStatusRules.Describe(x.Asset), x.Asset.EmployeeName ?? "Not assigned", x.AuditName, Date(x.ScheduledEndDate)]).ToList();
        var people = rows.Select(x => x.Asset.EmployeeId).Distinct().Count();
        return new($"{Count(rows.Count, "self-confirmation")} {(rows.Count == 1 ? "is" : "are")} overdue, from {Count(people, "employee")}. These assets are flagged for follow-up.",
            new AssistantTable(["Asset", "Make and model", "Employee", "Audit", "Was due"], table, rows.Count),
            Sources: AssetSources(rows.Select(x => x.Asset)), Evidence: Evidence("Audits", rows.Count), Suggestions: ["Which office has the most audit exceptions?"]);
    }

    // BRD example: "Which office has the most audit exceptions?"
    private async Task<AssistantResult> AuditExceptionsAsync(Run run)
    {
        string[] notExceptions = [nameof(AuditOutcome.Confirmed), nameof(AuditOutcome.AwaitingConfirmation)];
        var exceptions = await db.AuditItems.AsNoTracking()
            .Where(i => i.Outcome != null && !notExceptions.Contains(i.Outcome) && i.ResolvedAt == null)
            .Join(Filtered(run, byAcquisition: false), i => i.AssetId, a => a.AssetId, (i, a) => new { Item = i, Asset = a })
            .ToListAsync();

        if (exceptions.Count == 0)
            return new($"There are no open audit exceptions{Scope(run.Filters, run.Vocabulary)}.", Evidence: Evidence("Audits", 0), Suggestions: ["How many laptops are currently unconfirmed?"]);

        var dimension = run.Plan.GroupBy ?? (run.Plan.Ranking != Ranking.None ? Dimension.Location : (Dimension?)null);
        if (dimension is { } d)
        {
            var groups = exceptions
                .GroupBy(x => d switch
                {
                    Dimension.Region => x.Asset.Region,
                    Dimension.Department => x.Asset.DepartmentId,
                    Dimension.AssetType => x.Asset.AssetType,
                    Dimension.Employee => x.Asset.EmployeeName,
                    _ => x.Asset.LocationId
                })
                .Select(g => new Group(Label(d is Dimension.Region or Dimension.Department or Dimension.AssetType or Dimension.Employee ? d : Dimension.Location, g.Key, run.Vocabulary), g.Count(), 0))
                .ToList();
            return Ranked(run with { Plan = run.Plan with { ByCost = false } }, groups, "open audit exceptions", DimensionName(d), "Audits", exceptions.Count,
                ["Show the open audit exceptions", "Overdue confirmations"]);
        }

        var tamper = exceptions.Count(x => x.Item.RequiresInvestigation);
        var byOutcome = exceptions.GroupBy(x => x.Item.Outcome!).OrderByDescending(g => g.Count()).Select(g => $"{g.Count():N0} {Humanise(g.Key).ToLowerInvariant()}").ToList();
        var rows = exceptions.Take(MaxRows).Select(x => (IReadOnlyList<string?>)[x.Asset.AssetNo, AssetStatusRules.Describe(x.Asset), Humanise(x.Item.Outcome),
            Location(x.Asset, run.Vocabulary), x.Item.ReasonFlagged, x.Item.RequiresInvestigation ? "Tamper investigation" : "Needs resolution"]).ToList();
        return new($"There are {Count(exceptions.Count, "open audit exception")}: {JoinWithAnd(byOutcome)}."
            + (tamper > 0 ? $" {Count(tamper, "tamper alert")} {(tamper == 1 ? "needs" : "need")} an investigation before the audit can close." : ""),
            new AssistantTable(["Asset", "Make and model", "Finding", "Location", "Why it was checked", "Next step"], rows, exceptions.Count),
            Sources: AssetSources(exceptions.Select(x => x.Asset)), Evidence: Evidence("Audits", exceptions.Count),
            Suggestions: ["Which office has the most audit exceptions?", "Overdue confirmations"]);
    }

    // ---------- Loss, theft and AOD ----------

    private async Task<AssistantResult> IncidentsAsync(Run run)
    {
        var f = run.Filters;
        var assets = Filtered(run with { Plan = run.Plan with { Filters = f with { Lifecycle = null, EmployeeId = null, Period = null } } }, byAcquisition: false);
        var query = db.Incidents.AsNoTracking().Join(run.Assets.Where(a => assets.Any(x => x.AssetId == a.AssetId)), i => i.AssetId, a => a.AssetId, (i, a) => new { Incident = i, Asset = a });
        if (f.IncidentType is { } type) { var v = type.ToString(); query = query.Where(x => x.Incident.IncidentType == v); }
        if (f.EmployeeId is { } employee) query = query.Where(x => x.Incident.ReportedByEmployeeId == employee);
        if (f.Period is { } period) query = query.Where(x => x.Incident.IncidentDate >= period.FromUtc && x.Incident.IncidentDate < period.ToUtc);

        var rows = await query.OrderByDescending(x => x.Incident.IncidentDate).ToListAsync();
        var what = f.IncidentType switch { IncidentType.Theft => "theft", IncidentType.Loss => "loss", _ => "loss and theft" };
        var when = f.Period is null ? "" : $" {PeriodPhrase(f.Period)}";
        if (rows.Count == 0) return new($"There are no {what} incidents{when} in the records you can see.", Evidence: Evidence("Loss and theft register", 0));

        var names = run.Vocabulary.Employees.GroupBy(e => e.Id).ToDictionary(g => g.Key, g => g.First().Label);
        var dimension = run.Plan.GroupBy ?? (run.Plan.Ranking != Ranking.None ? Dimension.Employee : (Dimension?)null);
        if (dimension is { } d)
        {
            var groups = rows.GroupBy(x => d switch
                {
                    Dimension.Location => run.Vocabulary.LocationNames.GetValueOrDefault(x.Asset.LocationId ?? "", x.Asset.Region ?? "Not recorded"),
                    Dimension.Region => x.Asset.Region ?? "Not recorded",
                    Dimension.AssetType => Humanise(x.Asset.AssetType),
                    Dimension.Month => x.Incident.IncidentDate.ToString("yyyy-MM"),
                    _ => names.GetValueOrDefault(x.Incident.ReportedByEmployeeId, x.Incident.ReportedByEmployeeId)
                })
                .Select(g => new Group(g.Key, g.Count(), g.Sum(x => x.Asset.PurchaseCost ?? 0)))
                .OrderBy(g => d == Dimension.Month ? g.Label : null).ToList();
            return Ranked(run, groups, $"{what} incidents", DimensionName(d), "Loss and theft register", rows.Count, ["Repeat incidents", "Outstanding AOD balance"]);
        }

        var thefts = rows.Count(x => x.Incident.IncidentType == nameof(IncidentType.Theft));
        var open = rows.Count(x => x.Incident.NegligenceStatus == nameof(NegligenceStatus.UnderInvestigation));
        var exposure = rows.Sum(x => x.Asset.PurchaseCost ?? 0);
        var answer = $"There {(rows.Count == 1 ? "was" : "were")} {Count(rows.Count, $"{what} incident")}{when} ({Count(thefts, "theft")}, {Count(rows.Count - thefts, "loss", "losses")}). "
            + $"{open:N0} {(open == 1 ? "is" : "are")} under investigation. Recorded cost of the assets involved: {Money(exposure)}.";
        var table = rows.Take(MaxRows).Select(x => (IReadOnlyList<string?>)[Date(x.Incident.IncidentDate), Humanise(x.Incident.IncidentType), $"{x.Asset.AssetNo} · {AssetStatusRules.Describe(x.Asset)}",
            names.GetValueOrDefault(x.Incident.ReportedByEmployeeId, x.Incident.ReportedByEmployeeId), Humanise(x.Incident.NegligenceStatus), x.Incident.PoliceCaseNumber ?? "None"]).ToList();
        return new(answer, new AssistantTable(["Date", "Type", "Asset", "Employee", "Negligence", "Police case"], table, rows.Count),
            Sources: AssetSources(rows.Select(x => x.Asset)), Evidence: Evidence("Loss and theft register", rows.Count),
            Suggestions: ["Incidents by month", "Incidents by location", "Repeat incidents"]);
    }

    private async Task<AssistantResult> RepeatIncidentsAsync(Run run)
    {
        if (!run.User.HasAny(ManagementRoles)) return NoAccess("Repeat-incident information");

        var threshold = lifecycle.Rules.RepeatIncidentThreshold;
        var rows = await db.Incidents.AsNoTracking()
            .Where(i => run.Assets.Any(a => a.AssetId == i.AssetId))
            .GroupBy(i => i.ReportedByEmployeeId)
            .Select(g => new { EmployeeId = g.Key, Count = g.Count(), Negligent = g.Count(i => i.NegligenceStatus == nameof(NegligenceStatus.Negligent)), Escalated = g.Count(i => i.EscalatedToHr) > 0, Last = g.Max(i => i.IncidentDate) })
            .Where(x => x.Count >= threshold)
            .OrderByDescending(x => x.Count)
            .ToListAsync();

        if (rows.Count == 0) return new($"No employee has reached the repeat-incident threshold ({threshold} incidents).", Evidence: Evidence("Loss and theft register", 0));

        var names = run.Vocabulary.Employees.GroupBy(e => e.Id).ToDictionary(g => g.Key, g => g.First().Label);
        var table = rows.Select(x => (IReadOnlyList<string?>)[names.GetValueOrDefault(x.EmployeeId, x.EmployeeId), x.Count.ToString(), x.Negligent.ToString(), x.Escalated ? "Yes" : "No", Date(x.Last)]).ToList();
        return new($"{Count(rows.Count, "employee")} {(rows.Count == 1 ? "has" : "have")} {threshold} or more recorded incidents and {(rows.Count == 1 ? "is" : "are")} escalated to HR and management.",
            new AssistantTable(["Employee", "Incidents", "Negligent", "Escalated", "Latest"], table, rows.Count), Evidence: Evidence("Loss and theft register", rows.Sum(r => r.Count)),
            Suggestions: ["Outstanding AOD balance", "Incidents by month"]);
    }

    private async Task<AssistantResult> AodAsync(Run run)
    {
        if (!run.User.HasAny(FinanceRoles)) return NoAccess("Acknowledgement of Debt information");

        var rows = await db.AodRecords.AsNoTracking().Where(a => a.Status != "Cancelled")
            .Join(db.Assets, a => a.AssetId, x => x.AssetId, (a, x) => new { Aod = a, x.AssetNo })
            .OrderByDescending(x => x.Aod.CreatedAt).ToListAsync();
        if (rows.Count == 0) return new("There are no Acknowledgement of Debt records.", Evidence: Evidence("AOD records", 0));

        var open = rows.Where(x => x.Aod.Status != "Recovered").ToList();
        var names = run.Vocabulary.Employees.GroupBy(e => e.Id).ToDictionary(g => g.Key, g => g.First().Label);
        var table = rows.Take(MaxRows).Select(x => (IReadOnlyList<string?>)[names.GetValueOrDefault(x.Aod.EmployeeId, x.Aod.EmployeeId), x.AssetNo, Money(x.Aod.Amount), Money(x.Aod.RecoveredAmount),
            Money(x.Aod.Amount - x.Aod.RecoveredAmount), Humanise(x.Aod.Status)]).ToList();
        return new($"{Count(open.Count, "AOD")} {(open.Count == 1 ? "is" : "are")} still being recovered, with {Money(open.Sum(x => x.Aod.Amount - x.Aod.RecoveredAmount))} outstanding. "
            + $"{Money(rows.Sum(x => x.Aod.RecoveredAmount))} has been recovered across all AODs.",
            new AssistantTable(["Employee", "Asset", "Amount", "Recovered", "Outstanding", "Status"], table, rows.Count), Evidence: Evidence("AOD records", rows.Count),
            Suggestions: ["Repeat incidents", "Loss and theft this year"]);
    }

    // ---------- Faults and warranty claims ----------

    private async Task<AssistantResult> FaultsAsync(Run run)
    {
        var query = db.MaintenanceCases.AsNoTracking().Join(Filtered(run, byAcquisition: false), c => c.AssetId, a => a.AssetId, (c, a) => new { Case = c, Asset = a });
        query = run.Filters.Period is { } period
            ? query.Where(x => x.Case.ReportedAt >= period.FromUtc && x.Case.ReportedAt < period.ToUtc)
            : query.Where(x => x.Case.Status != nameof(CaseStatus.Completed));
        var rows = await query.OrderByDescending(x => x.Case.ReportedAt).ToListAsync();
        var when = run.Filters.Period is null ? "open" : $"reported {PeriodPhrase(run.Filters.Period)}";
        if (rows.Count == 0) return new($"There are no fault cases {when}.", Evidence: Evidence("Fault cases", 0), Suggestions: ["Warranty claims in progress"]);

        if (run.Plan.GroupBy is not null || run.Plan.Ranking != Ranking.None)
        {
            // "Type" in a fault question means the fault classification; other dimensions group by the asset.
            var dimension = run.Plan.GroupBy is Dimension.Make or Dimension.Model or Dimension.Location or Dimension.Region or Dimension.Department or Dimension.Employee
                ? run.Plan.GroupBy.Value : Dimension.Classification;
            var groups = rows.GroupBy(x => dimension switch
                {
                    Dimension.Make => x.Asset.Make ?? "Not recorded",
                    Dimension.Model => x.Asset.Model ?? "Not recorded",
                    Dimension.Location => Label(Dimension.Location, x.Asset.LocationId, run.Vocabulary),
                    Dimension.Region => x.Asset.Region ?? "Not recorded",
                    Dimension.Department => Label(Dimension.Department, x.Asset.DepartmentId, run.Vocabulary),
                    Dimension.Employee => x.Asset.EmployeeName ?? "Not assigned",
                    _ => Humanise(x.Case.Classification)
                })
                .Select(g => new Group(g.Key, g.Count(), 0)).ToList();
            return Ranked(run with { Plan = run.Plan with { ByCost = false } }, groups, $"{when} fault cases", DimensionName(dimension), "Fault cases", rows.Count, ["Show the fault cases"]);
        }

        var accidental = rows.Count(x => x.Case.CostRecoveryReview);
        var types = rows.GroupBy(x => x.Case.Classification).OrderByDescending(g => g.Count()).Select(g => $"{g.Count():N0} {Humanise(g.Key).ToLowerInvariant()}").ToList();
        var table = rows.Take(MaxRows).Select(x => (IReadOnlyList<string?>)[$"{x.Asset.AssetNo} · {AssetStatusRules.Describe(x.Asset)}", x.Case.ZendeskTicketId, Humanise(x.Case.Classification),
            x.Case.RepairabilityDecision is null ? "Awaiting IT" : Humanise(x.Case.RepairabilityDecision), x.Case.Outcome is null ? "Pending" : Humanise(x.Case.Outcome), Date(x.Case.ReportedAt)]).ToList();
        return new($"There {(rows.Count == 1 ? "is" : "are")} {Count(rows.Count, "fault case")} {when}: {JoinWithAnd(types)}."
            + (accidental > 0 ? $" {Count(accidental, "case")} of accidental damage {(accidental == 1 ? "is" : "are")} flagged for cost-recovery review." : ""),
            new AssistantTable(["Asset", "Zendesk", "Classification", "IT diagnosis", "Outcome", "Reported"], table, rows.Count),
            Sources: AssetSources(rows.Select(x => x.Asset)), Evidence: Evidence("Fault cases", rows.Count), Suggestions: ["Faults by type", "Warranty claims in progress"]);
    }

    private async Task<AssistantResult> WarrantyClaimsAsync(Run run)
    {
        var rows = await db.WarrantyClaims.AsNoTracking().Where(c => c.Status != nameof(CaseStatus.Completed))
            .Join(Filtered(run, byAcquisition: false), c => c.AssetId, a => a.AssetId, (c, a) => new { Claim = c, Asset = a })
            .OrderBy(x => x.Claim.DispatchDate).ToListAsync();
        if (rows.Count == 0) return new("There are no warranty claims in progress.", Evidence: Evidence("Warranty claims", 0), Suggestions: ["Warranty expiries next quarter"]);

        var late = rows.Count(x => x.Claim.ExpectedReturnDate < run.Today);
        var table = rows.Take(MaxRows).Select(x => (IReadOnlyList<string?>)[$"{x.Asset.AssetNo} · {AssetStatusRules.Describe(x.Asset)}", x.Claim.VendorName, Date(x.Claim.DispatchDate),
            Date(x.Claim.ExpectedReturnDate), ((int)(run.Today - x.Claim.DispatchDate.Date).TotalDays).ToString()]).ToList();
        return new($"{Count(rows.Count, "warranty claim")} {(rows.Count == 1 ? "is" : "are")} in progress; these assets show as In Repair."
            + (late > 0 ? $" {Count(late, "claim")} {(late == 1 ? "is" : "are")} past the expected return date." : ""),
            new AssistantTable(["Asset", "Vendor", "Dispatched", "Expected back", "Days out"], table, rows.Count),
            Sources: AssetSources(rows.Select(x => x.Asset)), Evidence: Evidence("Warranty claims", rows.Count), Suggestions: ["Warranty expiries next quarter", "Open fault cases"]);
    }

    // ---------- Onboarding, offboarding, transfers, swaps, take-home, disposal ----------

    private async Task<AssistantResult> OnboardingAsync(Run run)
    {
        if (!run.User.HasAny(OperatorRoles)) return NoAccess("New-hire information");

        var query = OnboardingService.OpenCases(db.OnboardingCases.AsNoTracking());
        if (run.Filters.Period is { } period) query = query.Where(c => c.StartDate >= period.FromUtc && c.StartDate < period.ToUtc);
        var cases = await query.OrderBy(c => c.StartDate).ToListAsync();
        var when = run.Filters.Period is null ? "" : $" starting {PeriodPhrase(run.Filters.Period)}";
        if (cases.Count == 0) return new($"There are no open onboarding cases{when}.", Evidence: Evidence("Onboarding cases", 0));

        var shortfalls = await onboarding.ShortfallsAsync(cases);
        var waiting = cases.Where(c => shortfalls[c.CaseId].Count > 0).ToList();
        var needs = waiting.SelectMany(c => shortfalls[c.CaseId]).GroupBy(s => s.AssetType).Select(g => $"{g.Sum(s => s.Quantity)} x {Humanise(g.Key.ToString()).ToLowerInvariant()}").ToList();
        var table = cases.Take(MaxRows).Select(c => (IReadOnlyList<string?>)[c.EmployeeName, c.JobRole, Date(c.StartDate), c.IsConfirmed ? "Confirmed" : "Provisional",
            c.IsShortNotice ? "Yes" : "No", shortfalls[c.CaseId].Count == 0 ? "Kit reserved" : string.Join(", ", shortfalls[c.CaseId].Select(s => $"{s.Quantity} x {Humanise(s.AssetType.ToString())}"))]).ToList();
        return new($"{Count(cases.Count, "new hire case")}{when} {(cases.Count == 1 ? "is" : "are")} open. {cases.Count(c => c.IsShortNotice):N0} {(cases.Count(c => c.IsShortNotice) == 1 ? "is" : "are")} short notice"
            + (waiting.Count == 0 ? " and every kit is fully reserved." : $", and {Count(waiting.Count, "case")} {(waiting.Count == 1 ? "is" : "are")} waiting for stock ({JoinWithAnd(needs)})."),
            new AssistantTable(["New hire", "Role", "Start date", "Oracle", "Short notice", "Kit"], table, cases.Count), Evidence: Evidence("Onboarding cases", cases.Count),
            Suggestions: ["Show stock levels", "New hires starting next month"]);
    }

    private async Task<AssistantResult> OffboardingAsync(Run run)
    {
        if (!run.User.HasAny(OperatorRoles)) return NoAccess("Exit information");

        var cases = await db.OffboardingCases.AsNoTracking().Where(c => c.Status != nameof(CaseStatus.Completed) && c.Status != nameof(CaseStatus.Cancelled))
            .OrderBy(c => c.ExitDate).ToListAsync();
        if (cases.Count == 0) return new("There are no open exit cases.", Evidence: Evidence("Offboarding cases", 0));

        var ids = cases.Select(c => c.CaseId).ToList();
        var items = await db.OffboardingItems.AsNoTracking().Where(i => ids.Contains(i.CaseId))
            .Join(db.Assets, i => i.AssetId, a => a.AssetId, (i, a) => new { i.CaseId, i.Resolution, a.AssetType }).ToListAsync();
        bool Open(string? resolution) => resolution is null || resolution == nameof(OffboardingItemResolution.Escalated);
        var names = run.Vocabulary.Employees.GroupBy(e => e.Id).ToDictionary(g => g.Key, g => g.First().Label);
        var laptopsOut = items.Count(i => i.AssetType == nameof(AssetType.Laptop) && Open(i.Resolution));

        var table = cases.Select(c => (IReadOnlyList<string?>)[names.GetValueOrDefault(c.EmployeeId, c.EmployeeId), Date(c.ExitDate),
            items.Count(i => i.CaseId == c.CaseId).ToString(), items.Count(i => i.CaseId == c.CaseId && Open(i.Resolution)).ToString(),
            items.Any(i => i.CaseId == c.CaseId && i.AssetType == nameof(AssetType.Laptop) && Open(i.Resolution)) ? "Outstanding" : "Recovered"]).ToList();
        return new($"{Count(cases.Count, "exit case")} {(cases.Count == 1 ? "is" : "are")} open. "
            + (laptopsOut == 0 ? "All laptops have been recovered." : $"{Count(laptopsOut, "laptop")} {(laptopsOut == 1 ? "is" : "are")} still outstanding, which blocks completion."),
            new AssistantTable(["Employee", "Exit date", "Assets", "Still to resolve", "Laptop"], table, cases.Count), Evidence: Evidence("Offboarding cases", cases.Count),
            Suggestions: ["Assets held for reassignment", "What needs my attention?"]);
    }

    private async Task<AssistantResult> TransfersAsync(Run run)
    {
        var rows = await db.AssetTransfers.AsNoTracking().Where(t => t.Status == nameof(CaseStatus.PendingApproval))
            .Join(Filtered(run, byAcquisition: false), t => t.AssetId, a => a.AssetId, (t, a) => new { Transfer = t, Asset = a })
            .OrderBy(x => x.Transfer.RequestedAt).ToListAsync();
        if (rows.Count == 0) return new("No transfers are waiting for approval.", Evidence: Evidence("Transfers", 0));

        var table = rows.Take(MaxRows).Select(x => (IReadOnlyList<string?>)[$"{x.Asset.AssetNo} · {AssetStatusRules.Describe(x.Asset)}", Humanise(x.Transfer.TransferType),
            $"{x.Transfer.FromValue ?? "-"} → {x.Transfer.TargetId}", Date(x.Transfer.RequestedAt), ((int)(run.Today - x.Transfer.RequestedAt.Date).TotalDays).ToString()]).ToList();
        return new($"{Count(rows.Count, "transfer")} {(rows.Count == 1 ? "is" : "are")} waiting for manager approval. The oldest has waited {(int)(run.Today - rows[0].Transfer.RequestedAt.Date).TotalDays} days.",
            new AssistantTable(["Asset", "Type", "From → to", "Requested", "Days waiting"], table, rows.Count),
            Sources: AssetSources(rows.Select(x => x.Asset)), Evidence: Evidence("Transfers", rows.Count));
    }

    private async Task<AssistantResult> SwapsAsync(Run run)
    {
        var swaps = await db.EmergencySwaps.AsNoTracking().Where(s => s.Status == nameof(CaseStatus.Open))
            .Join(run.Assets, s => s.TemporaryAssetId, a => a.AssetId, (s, a) => new { Swap = s, Asset = a })
            .OrderBy(x => x.Swap.ResolveBy).ToListAsync();
        if (swaps.Count == 0) return new("There are no emergency swaps awaiting formal resolution.", Evidence: Evidence("Emergency swaps", 0));

        var now = DateTime.UtcNow;
        var escalated = swaps.Count(x => x.Swap.ResolveBy < now);
        var names = run.Vocabulary.Employees.GroupBy(e => e.Id).ToDictionary(g => g.Key, g => g.First().Label);
        var table = swaps.Select(x => (IReadOnlyList<string?>)[names.GetValueOrDefault(x.Swap.EmployeeId, x.Swap.EmployeeId), $"{x.Asset.AssetNo} · {AssetStatusRules.Describe(x.Asset)}",
            Date(x.Swap.ReportedAt), Date(x.Swap.ResolveBy), x.Swap.ResolveBy < now ? "Escalated" : "On track"]).ToList();
        return new($"{Count(swaps.Count, "emergency swap")} {(swaps.Count == 1 ? "is" : "are")} awaiting formal resolution."
            + (escalated > 0 ? $" {escalated:N0} {(escalated == 1 ? "is" : "are")} past the resolution window and escalated to Fixed Assets." : " All are within the resolution window."),
            new AssistantTable(["Employee", "Temporary asset", "Reported", "Resolve by", "Status"], table, swaps.Count), Evidence: Evidence("Emergency swaps", swaps.Count));
    }

    private async Task<AssistantResult> TakeHomeAsync(Run run)
    {
        var rows = await db.TakeHomes.AsNoTracking()
            .Where(t => t.ReturnedAt == null || (t.DamageReviewRequired && t.DamageReviewOutcome == null))
            .Join(Filtered(run with { Plan = run.Plan with { Filters = run.Filters with { AtHome = null } } }, byAcquisition: false), t => t.AssetId, a => a.AssetId, (t, a) => new { TakeHome = t, Asset = a })
            .OrderByDescending(x => x.TakeHome.IssuedAt).ToListAsync();
        var atHome = rows.Where(x => x.TakeHome.ReturnedAt == null).ToList();
        var reviews = rows.Count(x => x.TakeHome.ReturnedAt != null);
        if (rows.Count == 0) return new("No screens are at home and there are no open damage reviews.", Evidence: Evidence("Take-home screens", 0));

        var names = run.Vocabulary.Employees.GroupBy(e => e.Id).ToDictionary(g => g.Key, g => g.First().Label);
        var table = rows.Take(MaxRows).Select(x => (IReadOnlyList<string?>)[$"{x.Asset.AssetNo} · {AssetStatusRules.Describe(x.Asset)}", names.GetValueOrDefault(x.TakeHome.EmployeeId, x.TakeHome.EmployeeId),
            Date(x.TakeHome.IssuedAt), Humanise(x.TakeHome.IssueCondition), x.TakeHome.ReturnCondition is null ? "-" : Humanise(x.TakeHome.ReturnCondition),
            x.TakeHome.ReturnedAt is null ? "At home" : "Damage review"]).ToList();
        return new($"{Count(atHome.Count, "screen")} {(atHome.Count == 1 ? "is" : "are")} at home." + (reviews > 0 ? $" {Count(reviews, "damage review")} {(reviews == 1 ? "is" : "are")} open." : ""),
            new AssistantTable(["Screen", "Employee", "Issued", "Issue condition", "Return condition", "Status"], table, rows.Count),
            Sources: AssetSources(rows.Select(x => x.Asset)), Evidence: Evidence("Take-home screens", rows.Count));
    }

    private async Task<AssistantResult> DisposalAsync(Run run)
    {
        var pending = await Filtered(run with { Plan = run.Plan with { Filters = run.Filters with { Lifecycle = null } } }, byAcquisition: false)
            .Where(a => a.LifecycleState == nameof(LifecycleState.Retired) && !db.Disposals.Any(d => d.AssetId == a.AssetId))
            .OrderBy(a => a.UpdatedAtUtc).ToListAsync();
        var disposedQuery = db.Disposals.AsNoTracking().Where(d => run.Assets.Any(a => a.AssetId == d.AssetId));
        if (run.Filters.Period is { } period) disposedQuery = disposedQuery.Where(d => d.DisposedOn >= period.FromUtc && d.DisposedOn < period.ToUtc);
        var disposed = await disposedQuery.CountAsync();
        var when = run.Filters.Period is null ? "in total" : PeriodPhrase(run.Filters.Period);

        var table = pending.Take(MaxRows).Select(a => (IReadOnlyList<string?>)[a.AssetNo, AssetStatusRules.Describe(a), Location(a, run.Vocabulary), $"Since {Date(a.UpdatedAtUtc)}"]).ToList();
        return new((pending.Count == 0 ? "Every retired asset has a recorded final disposition." : $"{Count(pending.Count, "retired asset")} {(pending.Count == 1 ? "has" : "have")} no recorded final disposition yet.")
            + $" {Count(disposed, "asset")} {(disposed == 1 ? "was" : "were")} disposed {when}.",
            pending.Count == 0 ? null : new AssistantTable(["Asset", "Make and model", "Location", "Retired"], table, pending.Count),
            Sources: AssetSources(pending), Evidence: Evidence("Disposals", pending.Count + disposed));
    }

    // ---------- Alerts and dashboards ----------

    private async Task<AssistantResult> AlertsAsync(Run run)
    {
        var list = await alerts.ListAsync(run.Assets, includeOperational: run.User.HasAny(Roles.FixedAssets, Roles.OfficeManager, Roles.Administrator));
        if (list.Count == 0) return new("Nothing needs your attention right now.", Evidence: Evidence("Alerts", 0));

        var high = list.Count(a => a.Severity == "High");
        var table = list.Take(MaxRows).Select(a => (IReadOnlyList<string?>)[a.Severity, a.Title, a.Detail, Date(a.DueDate)]).ToList();
        var top = list.GroupBy(a => a.Type).OrderByDescending(g => g.Count()).Take(3).Select(g => $"{g.Count():N0} {Humanise(g.Key).ToLowerInvariant()}").ToList();
        return new($"You have {Count(list.Count, "alert")}, {high:N0} high priority: {JoinWithAnd(top)}.",
            new AssistantTable(["Priority", "Alert", "Details", "Due"], table, list.Count), Evidence: Evidence("Alerts (calculated now)", list.Count),
            Suggestions: ["Warranty expiries next month", "Show stock levels", "Emergency swaps"]);
    }

    private static readonly (string Key, string Name, string Description, bool Management)[] Dashboards =
    [
        ("operational", "Operational dashboard", "Stock, onboarding, offboarding, losses, warranty, repairs, audit results and utilisation", true),
        ("management", "Management dashboard", "Risk, incident trends, financial exposure and repeated negligence", true),
        ("stock", "Stock dashboard", "Available, reserved and damaged stock against minimum levels", false),
        ("warranty", "Warranty dashboard", "Assets going out of warranty in the next 90 days", false),
        ("audit", "Audit dashboard", "Open audit exceptions by location", false),
        ("incidents", "Loss and theft dashboard", "Incidents by month with the cost of assets involved", false)
    ];

    private static AssistantResult DashboardList(Run run)
    {
        var available = Dashboards.Where(d => !d.Management || run.User.HasAny(ManagementRoles)).ToList();
        return new($"I can open {Count(available.Count, "dashboard")} for you. Pick one below or ask, for example, \"open the {available[0].Key} dashboard\".",
            new AssistantTable(["Dashboard", "What it shows"], available.Select(d => (IReadOnlyList<string?>)[d.Name, d.Description]).ToList(), available.Count),
            Suggestions: available.Select(d => $"Open the {d.Key} dashboard").ToList());
    }

    private async Task<AssistantResult> DashboardOpenAsync(Run run)
    {
        var key = run.Plan.Dashboard switch
        {
            "operations" => "operational",
            "risk" => "management",
            "incident" or "loss" or "losses" => "incidents",
            var k => k
        };

        switch (key)
        {
            case "operational":
                if (!run.User.HasAny(ManagementRoles)) return NoAccess("The operational dashboard");
                var o = await dashboards.OperationalAsync(run.Assets);
                return new($"Operational dashboard: {o.TotalAssets:N0} assets, {o.UtilisationPercent}% in use, {o.FlaggedForAudit:N0} flagged for audit and {o.OpenIncidents:N0} open loss or theft cases.",
                    Kpis([("Total assets", o.TotalAssets.ToString("N0")), ("Added this month", o.AddedThisMonth.ToString("N0")), ("Flagged for audit", o.FlaggedForAudit.ToString("N0")),
                        ("Screens and assets at home", o.AssetsAtHome.ToString("N0")), ("Open loss and theft cases", o.OpenIncidents.ToString("N0")), ("Loss exposure", Money(o.LossExposure)),
                        ("Warranty expiring (90 days)", o.WarrantyAlerts.ToString("N0")), ("Warranty claims in progress", o.ActiveWarrantyClaims.ToString("N0")), ("Open repairs", o.OpenRepairs.ToString("N0")),
                        ("Open audit discrepancies", o.OpenAuditDiscrepancies.ToString("N0")), ("Utilisation", $"{o.UtilisationPercent}%"),
                        ("New hires open / kits ready", $"{o.Onboarding.OpenCases} / {o.Onboarding.KitsFullyReserved}"), ("Short-notice hires", o.Onboarding.ShortNotice.ToString("N0")),
                        ("Exit cases open", o.Offboarding.OpenCases.ToString("N0")), ("Laptops still to recover", o.Offboarding.LaptopRecoveriesOutstanding.ToString("N0"))]),
                    new AssistantChart("bar", "Assets by status", "Assets", o.ByOperationalStatus.Select(s => new AssistantChartPoint(Humanise(s.Label), s.Count)).ToList()),
                    Evidence: Evidence("Operational dashboard", o.TotalAssets), Suggestions: ["Open the management dashboard", "What needs my attention?"]);

            case "management":
                if (!run.User.HasAny(ManagementRoles)) return NoAccess("The management dashboard");
                var m = await dashboards.ManagementAsync(run.Assets);
                return new($"Management dashboard: {m.Risk.High:N0} high-risk assets, {Money(m.OpenAodValue)} outstanding on AODs and {m.EmployeesWithRepeatIncidents:N0} employees with repeat incidents.",
                    Kpis([("High / medium / low risk", $"{m.Risk.High} / {m.Risk.Medium} / {m.Risk.Low}"), ("Total recorded asset value", Money(m.TotalAssetValue)),
                        ("Lost or stolen value", Money(m.LostOrStolenValue)), ("Open AOD value", Money(m.OpenAodValue)), ("Recovered on AODs", Money(m.RecoveredAodValue)),
                        ("Employees with repeat incidents", m.EmployeesWithRepeatIncidents.ToString("N0")), ("Laptops in use (off-site daily)", m.LaptopsOffSite.ToString("N0"))]),
                    new AssistantChart("line", "Loss and theft incidents by month", "Incidents", m.IncidentTrend.Select(p => new AssistantChartPoint(p.Period, p.Value)).ToList()),
                    Evidence: Evidence("Management dashboard", m.Risk.Total), Suggestions: ["Repeat incidents", "Outstanding AOD balance", "Open the operational dashboard"]);

            case "stock":
                return await StockAsync(run with { Plan = run.Plan with { WantsChart = true } });
            case "warranty":
                return await WarrantyExpiringAsync(run with { Plan = run.Plan with { Filters = run.Filters with { Period = new DateRange(DateOnly.FromDateTime(run.Today), DateOnly.FromDateTime(run.Today).AddDays(91), "the next 90 days") } } });
            case "audit":
                return await AuditExceptionsAsync(run with { Plan = run.Plan with { GroupBy = Dimension.Location, WantsChart = true } });
            case "incidents":
                return await IncidentsAsync(run with { Plan = run.Plan with { GroupBy = Dimension.Month, WantsChart = true } });
            case "onboarding":
                return await OnboardingAsync(run);
            case "offboarding":
                return await OffboardingAsync(run);
            default:
                return DashboardList(run);
        }
    }

    private static AssistantTable Kpis(IReadOnlyList<(string Name, string Value)> items) =>
        new(["Measure", "Value"], items.Select(i => (IReadOnlyList<string?>)[i.Name, i.Value]).ToList(), items.Count);
}
