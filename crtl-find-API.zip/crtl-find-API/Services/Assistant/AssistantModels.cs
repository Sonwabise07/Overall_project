using CtrlFind.Contracts;

namespace CtrlFind.Services.Assistant;

public enum AssistantIntent
{
    Greeting, Help, Thanks, OutOfScope, Clarify, ShowAsChart,
    AssetCount, AssetList, AssetDetail, AssetBreakdown, AssetHistory, AssetHolder, EmployeeAssets,
    StockLevels, WarrantyExpiring, OutOfWarranty,
    CostSummary, CostComparison, AcquisitionTrend,
    UnconfirmedAssets, OverdueConfirmations, AuditExceptions,
    Incidents, RepeatIncidents, AodOutstanding,
    Faults, WarrantyClaims, Onboarding, Offboarding, PendingTransfers, EmergencySwaps, TakeHome, PendingDisposal,
    Alerts, DashboardList, DashboardOpen
}

public enum Dimension { Location, Region, Department, Employee, AssetType, Status, Lifecycle, Make, Model, Month, Classification }

public enum Ranking { None, Most, Least }

// To is exclusive.
public sealed record DateRange(DateOnly From, DateOnly To, string Label)
{
    public DateTime FromUtc => DateTime.SpecifyKind(From.ToDateTime(TimeOnly.MinValue), DateTimeKind.Utc);
    public DateTime ToUtc => DateTime.SpecifyKind(To.ToDateTime(TimeOnly.MinValue), DateTimeKind.Utc);
}

public sealed record AssistantFilters
{
    public AssetType? AssetType { get; init; }
    public LifecycleState? Lifecycle { get; init; }
    public OperationalStatus? Status { get; init; }
    public string? LocationId { get; init; }
    public string? Region { get; init; }
    public string? DepartmentId { get; init; }
    public string? EmployeeId { get; init; }
    public string? Make { get; init; }
    public string? AssetId { get; init; }
    public string? UnknownIdentifier { get; init; }
    public bool? Assigned { get; init; }
    public bool? AtHome { get; init; }
    public IncidentType? IncidentType { get; init; }
    public DateRange? Period { get; init; }
    public DateRange? ComparePeriod { get; init; }

    public bool IsEmpty => this == new AssistantFilters();

    // Later values replace earlier ones, so a follow-up such as "what about Durban?" swaps the location only.
    public AssistantFilters Merge(AssistantFilters next) => new()
    {
        AssetType = next.AssetType ?? AssetType,
        Lifecycle = next.Lifecycle ?? Lifecycle,
        Status = next.Status ?? Status,
        LocationId = next.LocationId ?? (next.Region is null ? LocationId : null),
        Region = next.Region ?? (next.LocationId is null ? Region : null),
        DepartmentId = next.DepartmentId ?? DepartmentId,
        EmployeeId = next.EmployeeId ?? EmployeeId,
        Make = next.Make ?? Make,
        AssetId = next.AssetId ?? AssetId,
        UnknownIdentifier = next.UnknownIdentifier,
        Assigned = next.Assigned ?? Assigned,
        AtHome = next.AtHome ?? AtHome,
        IncidentType = next.IncidentType ?? IncidentType,
        Period = next.Period ?? Period,
        ComparePeriod = next.ComparePeriod ?? ComparePeriod
    };
}

public sealed record AssistantPlan(
    AssistantIntent Intent,
    AssistantFilters Filters,
    Dimension? GroupBy = null,
    bool ByCost = false,
    Ranking Ranking = Ranking.None,
    int? Top = null,
    bool WantsChart = false,
    string? Clarification = null,
    string? Dashboard = null,
    string? Topic = null);

// What a handler produces; the service adds conversation details.
public sealed record AssistantResult(
    string Answer,
    AssistantTable? Table = null,
    AssistantChart? Chart = null,
    IReadOnlyList<AssistantSource>? Sources = null,
    IReadOnlyList<string>? Suggestions = null,
    string? Evidence = null,
    bool Unsupported = false);

// Who is asking: assets are already scoped to the user's role (BRD Section 5).
public sealed record AssistantUser(string UserId, string? EmployeeId, IReadOnlyCollection<string> Roles)
{
    public bool HasAny(params string[] roles) => roles.Any(Roles.Contains);
}
