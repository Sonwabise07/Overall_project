using CtrlFind.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace CtrlFind.Services.Assistant;

public sealed record VocabularyEntry(string Phrase, string Id, string Label);

// Names the assistant recognises, read from the database so new locations,
// departments and employees are understood without code changes.
public sealed record Vocabulary(
    IReadOnlyList<VocabularyEntry> Locations,
    IReadOnlyList<VocabularyEntry> Regions,
    IReadOnlyList<VocabularyEntry> Departments,
    IReadOnlyList<VocabularyEntry> Employees,
    IReadOnlyList<VocabularyEntry> Makes,
    IReadOnlyDictionary<string, string> LocationNames,
    IReadOnlyDictionary<string, string> DepartmentNames);

public sealed class AssistantVocabulary(ApplicationDbContext db, IMemoryCache cache)
{
    private const string CacheKey = "assistant:vocabulary";
    private static readonly string[] LocationSuffixes = [" head office", " office", " hq", " campus", " branch"];

    public async Task<Vocabulary> GetAsync() =>
        (await cache.GetOrCreateAsync(CacheKey, async entry =>
        {
            entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(5);
            return await LoadAsync();
        }))!;

    private async Task<Vocabulary> LoadAsync()
    {
        var locations = await db.Locations.AsNoTracking().ToListAsync();
        var departments = await db.Departments.AsNoTracking().ToListAsync();
        var employees = await db.Employees.AsNoTracking().Where(e => e.IsActive).Select(e => new { e.EmployeeId, e.FullName }).ToListAsync();
        var makes = await db.Assets.AsNoTracking().Where(a => a.Make != null).Select(a => a.Make!).Distinct().ToListAsync();

        var locationEntries = new List<VocabularyEntry>();
        foreach (var l in locations)
        {
            var phrases = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { l.Name, l.LocationId };
            if (!string.IsNullOrWhiteSpace(l.Building)) phrases.Add(l.Building);
            foreach (var suffix in LocationSuffixes)
            {
                if (l.Name.EndsWith(suffix, StringComparison.OrdinalIgnoreCase)) phrases.Add(l.Name[..^suffix.Length]);
                if (l.Building?.EndsWith(suffix, StringComparison.OrdinalIgnoreCase) == true) phrases.Add(l.Building[..^suffix.Length]);
            }
            locationEntries.AddRange(phrases.Where(p => p.Length > 2).Select(p => new VocabularyEntry(p.ToLowerInvariant(), l.LocationId, l.Name)));
        }

        var regionEntries = locations.Where(l => !string.IsNullOrWhiteSpace(l.Region)).Select(l => l.Region!).Distinct()
            .Select(r => new VocabularyEntry(r.ToLowerInvariant(), r, r)).ToList();

        var departmentEntries = departments.SelectMany(d => new[] { d.Name, d.DepartmentId }.Distinct(StringComparer.OrdinalIgnoreCase)
            .Where(p => p.Length > 1)
            .Select(p => new VocabularyEntry(p.ToLowerInvariant(), d.DepartmentId, d.Name))).ToList();

        var employeeEntries = employees.SelectMany(e => new[] { e.FullName, e.EmployeeId }
            .Select(p => new VocabularyEntry(p.ToLowerInvariant(), e.EmployeeId, e.FullName))).ToList();

        return new Vocabulary(
            Longest(locationEntries), Longest(regionEntries), Longest(departmentEntries), Longest(employeeEntries),
            Longest(makes.Where(m => m.Length > 1).Select(m => new VocabularyEntry(m.ToLowerInvariant(), m, m))),
            locations.ToDictionary(l => l.LocationId, l => l.Name),
            departments.ToDictionary(d => d.DepartmentId, d => d.Name));
    }

    // Longest phrases are matched first so "cape town head office" wins over "cape town".
    private static List<VocabularyEntry> Longest(IEnumerable<VocabularyEntry> entries) =>
        entries.DistinctBy(e => e.Phrase).OrderByDescending(e => e.Phrase.Length).ToList();
}
