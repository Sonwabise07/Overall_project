using System.Linq.Expressions;
using CtrlFind.Contracts;
using CtrlFind.Infrastructure.Persistence;
using CtrlFind.Infrastructure.Persistence.Entities;
using Microsoft.EntityFrameworkCore;
using static CtrlFind.Services.Assistant.AssistantText;

namespace CtrlFind.Services.Assistant;

// Answers each supported question type with a read-only EF Core query over the user's scoped assets.
// Figures come only from stored data; an empty result is reported as empty (BR-8.15-01 to BR-8.15-04).
public sealed partial class AssistantQueryRunner(
    ApplicationDbContext db,
    AssetLifecycleService lifecycle,
    DashboardService dashboards,
    AlertService alerts,
    OnboardingService onboarding)
{
    private const int MaxRows = 25;
    private const string AssetSource = "Asset register";
    private static readonly string[] Inactive = [nameof(LifecycleState.Disposed)];

    private sealed record Run(AssistantPlan Plan, IQueryable<AssetEntity> Assets, AssistantUser User, Vocabulary Vocabulary)
    {
        public AssistantFilters Filters => Plan.Filters;
        public DateTime Today => DateTime.UtcNow.Date;
    }

    public Task<AssistantResult> RunAsync(AssistantPlan plan, IQueryable<AssetEntity> scopedAssets, AssistantUser user, Vocabulary vocabulary)
    {
        var run = new Run(plan, scopedAssets, user, vocabulary);
        return plan.Intent switch
        {
            AssistantIntent.AssetCount => AssetCountAsync(run),
            AssistantIntent.AssetList => AssetListAsync(run),
            AssistantIntent.AssetDetail => AssetDetailAsync(run),
            AssistantIntent.AssetHistory => AssetHistoryAsync(run),
            AssistantIntent.AssetHolder => AssetHolderAsync(run),
            AssistantIntent.EmployeeAssets => EmployeeAssetsAsync(run),
            AssistantIntent.AssetBreakdown => BreakdownAsync(run),
            AssistantIntent.StockLevels => StockAsync(run),
            AssistantIntent.WarrantyExpiring => WarrantyExpiringAsync(run),
            AssistantIntent.OutOfWarranty => OutOfWarrantyAsync(run),
            AssistantIntent.CostSummary => CostSummaryAsync(run),
            AssistantIntent.CostComparison => CostComparisonAsync(run),
            AssistantIntent.AcquisitionTrend => AcquisitionTrendAsync(run),
            AssistantIntent.UnconfirmedAssets => UnconfirmedAsync(run),
            AssistantIntent.OverdueConfirmations => OverdueConfirmationsAsync(run),
            AssistantIntent.AuditExceptions => AuditExceptionsAsync(run),
            AssistantIntent.Incidents => IncidentsAsync(run),
            AssistantIntent.RepeatIncidents => RepeatIncidentsAsync(run),
            AssistantIntent.AodOutstanding => AodAsync(run),
            AssistantIntent.Faults => FaultsAsync(run),
            AssistantIntent.WarrantyClaims => WarrantyClaimsAsync(run),
            AssistantIntent.Onboarding => OnboardingAsync(run),
            AssistantIntent.Offboarding => OffboardingAsync(run),
            AssistantIntent.PendingTransfers => TransfersAsync(run),
            AssistantIntent.EmergencySwaps => SwapsAsync(run),
            AssistantIntent.TakeHome => TakeHomeAsync(run),
            AssistantIntent.PendingDisposal => DisposalAsync(run),
            AssistantIntent.Alerts => AlertsAsync(run),
            AssistantIntent.DashboardList => Task.FromResult(DashboardList(run)),
            AssistantIntent.DashboardOpen => DashboardOpenAsync(run),
            _ => Task.FromResult(new AssistantResult("I can't answer that yet.", Unsupported: true))
        };
    }

    // ---------- Asset register ----------

    private async Task<AssistantResult> AssetCountAsync(Run run)
    {
        var query = Filtered(run, byAcquisition: true);
        var total = await query.CountAsync();
        var scope = Scope(run.Filters, run.Vocabulary, includePeriod: true);
        var answer = total == 0
            ? $"There are no {Noun(run.Filters.AssetType)}{scope}."
            : $"There {(total == 1 ? "is" : "are")} {CountOf(total, run.Filters.AssetType)}{scope}.";

        if (total > 0 && run.Filters.Lifecycle is null && run.Filters.Status is null)
        {
            var byStatus = await query.GroupBy(a => a.OperationalStatus).Select(g => new { g.Key, Count = g.Count() }).ToListAsync();
            answer += " " + JoinWithAnd(byStatus.OrderByDescending(s => s.Count).Select(s => $"{s.Count:N0} {Humanise(s.Key).ToLowerInvariant()}").ToList()) + ".";
        }

        return new(answer, Evidence: Evidence(AssetSource, total),
            Suggestions: total == 0 ? ["How many assets do we have?", "Show stock levels"] : [$"Show the {Noun(run.Filters.AssetType)}", $"{Capital(Noun(run.Filters.AssetType))} by location", $"{Capital(Noun(run.Filters.AssetType))} by status"]);
    }

    private async Task<AssistantResult> AssetListAsync(Run run)
    {
        var query = Filtered(run, byAcquisition: true);
        var total = await query.CountAsync();
        var assets = await query.OrderBy(a => a.AssetNo).Take(MaxRows).ToListAsync();
        var scope = Scope(run.Filters, run.Vocabulary, includePeriod: true);

        if (total == 0) return new($"I found no {Noun(run.Filters.AssetType)}{scope}.", Evidence: Evidence(AssetSource, 0), Suggestions: ["How many assets do we have?"]);

        var answer = total > MaxRows
            ? $"I found {CountOf(total, run.Filters.AssetType)}{scope}. Here are the first {MaxRows}, by asset number."
            : $"I found {CountOf(total, run.Filters.AssetType)}{scope}.";
        return new(answer, AssetTable(assets, total, run.Vocabulary), Sources: AssetSources(assets), Evidence: Evidence(AssetSource, total),
            Suggestions: [$"{Capital(Noun(run.Filters.AssetType))} by location", "Show this as a chart", $"Tell me about {assets[0].AssetNo}"]);
    }

    private async Task<AssistantResult> AssetDetailAsync(Run run)
    {
        if (await FindAssetAsync(run) is not { } asset) return NotFound(run);

        var assignment = await db.AssetAssignments.AsNoTracking().Where(a => a.AssetId == asset.AssetId && a.ReturnedAt == null).OrderByDescending(a => a.AssignedAt).FirstOrDefaultAsync();
        var department = asset.DepartmentId is null ? null : run.Vocabulary.DepartmentNames.GetValueOrDefault(asset.DepartmentId, asset.DepartmentId);
        var type = Enums.Parse<AssetType>(asset.AssetType);
        var warranty = asset.WarrantyEnd is null ? "no warranty end date recorded"
            : asset.WarrantyEnd < run.Today ? $"warranty expired on {Date(asset.WarrantyEnd)}"
            : $"warranty ends {Date(asset.WarrantyEnd)} ({(int)(asset.WarrantyEnd.Value - run.Today).TotalDays} days left)";
        var holder = asset.EmployeeName is null ? $"not assigned to anyone and {Humanise(asset.LifecycleState).ToLowerInvariant()}" : $"assigned to {asset.EmployeeName}{(department is null ? "" : $" in {department}")}";

        var rows = new List<IReadOnlyList<string?>>
        {
            Row("Asset number", asset.AssetNo), Row("Asset tag", asset.AssetTag), Row("Serial number", asset.SerialNumber),
            Row("Type", Humanise(asset.AssetType)), Row("Make and model", AssetStatusRules.Describe(asset)),
            Row("Lifecycle state", Humanise(asset.LifecycleState)), Row("Operational status", Humanise(asset.OperationalStatus)),
            Row("Assigned to", asset.EmployeeName ?? "Not assigned"), Row("Since", assignment is null ? null : Date(assignment.AssignedAt)),
            Row("Department", department), Row("Location", Location(asset, run.Vocabulary)), Row("Condition", Humanise(asset.Condition)),
            Row("Purchase cost (Pastel)", asset.PurchaseCost is null ? "Not recorded" : Money(asset.PurchaseCost.Value)),
            Row("Acquired", Date(asset.AcquisitionDate)), Row("Warranty end", Date(asset.WarrantyEnd)), Row("Warranty vendor", asset.WarrantyVendor),
            Row("Last audit", asset.LastAuditDate is null ? "Never audited" : $"{Date(asset.LastAuditDate)} · {Humanise(asset.AuditOutcome)}")
        };
        if (type == AssetType.Laptop)
        {
            rows.Add(Row("Encryption", asset.EncryptionStatus ?? "Not recorded"));
            rows.Add(Row("Custody agreement", asset.CustodyAgreementSigned ? "Signed" : "Not signed"));
            rows.Add(Row("Health", AssetStatusRules.LaptopHealth(asset, run.Today, lifecycle.Rules.LaptopAgeingYears).ToString()));
        }

        var answer = $"{asset.AssetNo} is a {AssetStatusRules.Describe(asset)} {Noun(type, false)}, {holder}. Its {warranty}.";
        return new(answer, new AssistantTable(["Field", "Value"], rows.Where(r => r[1] is not null).ToList(), rows.Count),
            Sources: [new("Asset", asset.AssetId, asset.AssetNo)], Evidence: Evidence(AssetSource, 1),
            Suggestions: [$"Show the history of {asset.AssetNo}", $"Who has {asset.AssetNo}?", "What needs my attention?"]);
    }

    private async Task<AssistantResult> AssetHistoryAsync(Run run)
    {
        if (await FindAssetAsync(run) is not { } asset) return NotFound(run);

        var events = await db.AssetHistory.AsNoTracking().Where(h => h.AssetId == asset.AssetId).OrderByDescending(h => h.ChangedAt).ToListAsync();
        if (events.Count == 0) return new($"{asset.AssetNo} has no recorded history events.", Sources: [new("Asset", asset.AssetId, asset.AssetNo)]);

        var latest = events[0];
        var rows = events.Take(MaxRows).Select(h => (IReadOnlyList<string?>)[Date(h.ChangedAt), Humanise(h.Action), h.Summary, h.ChangedBy]).ToList();
        return new($"{asset.AssetNo} has {Count(events.Count, "recorded event")}. The latest was \"{Humanise(latest.Action).ToLowerInvariant()}\" on {Date(latest.ChangedAt)}.",
            new AssistantTable(["Date", "Event", "Details", "By"], rows, events.Count),
            Sources: [new("Asset", asset.AssetId, asset.AssetNo)], Evidence: Evidence("Asset history (permanent record)", events.Count),
            Suggestions: [$"Tell me about {asset.AssetNo}", $"Who has {asset.AssetNo}?"]);
    }

    private async Task<AssistantResult> AssetHolderAsync(Run run)
    {
        if (await FindAssetAsync(run) is not { } asset) return NotFound(run);

        if (asset.EmployeeId is null)
            return new($"{asset.AssetNo} ({AssetStatusRules.Describe(asset)}) is not assigned to anyone. It is {Humanise(asset.LifecycleState).ToLowerInvariant()} at {Location(asset, run.Vocabulary)}.",
                Sources: [new("Asset", asset.AssetId, asset.AssetNo)], Suggestions: [$"Show the history of {asset.AssetNo}"]);

        var since = await db.AssetAssignments.AsNoTracking().Where(a => a.AssetId == asset.AssetId && a.ReturnedAt == null).MaxAsync(a => (DateTime?)a.AssignedAt);
        var department = asset.DepartmentId is null ? "" : $" ({run.Vocabulary.DepartmentNames.GetValueOrDefault(asset.DepartmentId, asset.DepartmentId)})";
        return new($"{asset.AssetNo} ({AssetStatusRules.Describe(asset)}) is assigned to {asset.EmployeeName}{department}{(since is null ? "" : $" since {Date(since)}")}. Location: {Location(asset, run.Vocabulary)}.",
            Sources: [new("Asset", asset.AssetId, asset.AssetNo)], Evidence: Evidence("Assignments", 1),
            Suggestions: [$"What else does {asset.EmployeeName} have?", $"Show the history of {asset.AssetNo}"]);
    }

    private async Task<AssistantResult> EmployeeAssetsAsync(Run run)
    {
        var employeeId = run.Filters.EmployeeId!;
        var name = employeeId == run.User.EmployeeId ? "You" : EmployeeName(employeeId, run.Vocabulary);
        var assets = await run.Assets.Where(a => a.EmployeeId == employeeId && !Inactive.Contains(a.LifecycleState)).OrderBy(a => a.AssetType).ThenBy(a => a.AssetNo).ToListAsync();

        if (assets.Count == 0) return new($"{name} {(name == "You" ? "have" : "has")} no assets assigned in the records you can see.", Evidence: Evidence("Assignments", 0));

        var kit = JoinWithAnd(assets.GroupBy(a => a.AssetType).Select(g => CountOf(g.Count(), Enums.Parse<AssetType>(g.Key))).ToList());
        return new($"{name} {(name == "You" ? "have" : "has")} {Count(assets.Count, "asset")}: {kit}.", AssetTable(assets, assets.Count, run.Vocabulary),
            Sources: AssetSources(assets), Evidence: Evidence("Assignments", assets.Count),
            Suggestions: [$"Tell me about {assets[0].AssetNo}", "Which assets need attention?"]);
    }

    private async Task<AssistantResult> BreakdownAsync(Run run)
    {
        var dimension = run.Plan.GroupBy ?? Dimension.AssetType;
        var query = Filtered(run, byAcquisition: true);
        var groups = dimension == Dimension.Month
            ? (await query.Where(a => a.AcquisitionDate != null)
                .GroupBy(a => new { a.AcquisitionDate!.Value.Year, a.AcquisitionDate.Value.Month })
                .Select(g => new { g.Key.Year, g.Key.Month, Count = g.Count(), Cost = g.Sum(a => a.PurchaseCost ?? 0) }).ToListAsync())
                .Select(g => new Group($"{g.Year}-{g.Month:00}", g.Count, g.Cost)).OrderBy(g => g.Label).ToList()
            : (await query.GroupBy(KeyOf(dimension)).Select(g => new { g.Key, Count = g.Count(), Cost = g.Sum(a => a.PurchaseCost ?? 0) }).ToListAsync())
                .Select(g => new Group(Label(dimension, g.Key, run.Vocabulary), g.Count, g.Cost)).ToList();

        return Ranked(run, groups, Noun(run.Filters.AssetType), DimensionName(dimension), AssetSource, groups.Sum(g => g.Count),
            [$"Show the {Noun(run.Filters.AssetType)}", $"{Capital(Noun(run.Filters.AssetType))} by status"]);
    }

    private async Task<AssistantResult> StockAsync(Run run)
    {
        var located = run.Filters.LocationId is not null || run.Filters.Region is not null || run.Filters.Make is not null;
        var summary = located ? await LocalStockAsync(run) : (await AssetQueries.SummariseStockByTypeAsync(db))
            .Where(s => run.Filters.AssetType is null || s.AssetType == run.Filters.AssetType).ToList();
        var where = located ? Scope(run.Filters with { AssetType = null, Lifecycle = null }, run.Vocabulary) : string.Empty;
        if (summary.Count == 0)
            return new($"There is no {Noun(run.Filters.AssetType, false)} stock on record{where}.", Evidence: Evidence("Stock and storeroom", 0), Suggestions: ["Show stock levels"]);

        var rows = summary.Select(s => (IReadOnlyList<string?>)[Humanise(s.AssetType.ToString()), s.Available.ToString(), s.Reserved.ToString(), s.Damaged.ToString(),
            s.MinimumThreshold?.ToString() ?? "Not set", Humanise(s.Alert)]).ToList();
        var table = new AssistantTable(["Asset type", "Available", "Reserved", "Damaged", "Minimum", "Status"], rows, rows.Count);
        var chart = new AssistantChart("bar", "Available spare stock", "Units", summary.Select(s => new AssistantChartPoint(Humanise(s.AssetType.ToString()), s.Available)).ToList());

        string answer;
        if (run.Filters.AssetType is not null)
        {
            var s = summary[0];
            answer = $"{s.Available:N0} {Noun(s.AssetType, s.Available != 1)} {(s.Available == 1 ? "is" : "are")} available as spare stock{where}, {s.Reserved:N0} reserved for new hires and {s.Damaged:N0} damaged. "
                + (s.Alert == "Healthy" ? "Stock is healthy." : s.Alert == "NoStock" ? "There is no available stock." : $"Stock is low (minimum {s.MinimumThreshold}).");
        }
        else
        {
            var low = summary.Where(s => s.Alert != "Healthy").Select(s => $"{Humanise(s.AssetType.ToString())} ({Humanise(s.Alert).ToLowerInvariant()})").ToList();
            answer = $"There are {summary.Sum(s => s.Available):N0} spare units available{where} across {Count(summary.Count, "asset type")}, with {summary.Sum(s => s.Reserved):N0} reserved for new hires. "
                + (low.Count == 0 ? "All types are above their minimum." : $"Needs attention: {JoinWithAnd(low)}.");
        }

        return new(answer, table, run.Plan.WantsChart || run.Filters.AssetType is null ? chart : null, Evidence: Evidence("Stock and storeroom", summary.Sum(s => s.Available + s.Reserved + s.Damaged)),
            Suggestions: ["Which new hires are waiting for stock?", "Show available laptops", "Stock by storeroom dashboard"]);
    }

    // Stock at a place: minimum thresholds are company-wide, so they are not applied here.
    private static async Task<List<StockTypeSummaryDto>> LocalStockAsync(Run run)
    {
        string[] stockStates = [nameof(LifecycleState.InStorage), nameof(LifecycleState.Reserved)];
        var rows = await Filtered(run with { Plan = run.Plan with { Filters = run.Filters with { Lifecycle = null } } }, byAcquisition: false)
            .Where(a => stockStates.Contains(a.LifecycleState))
            .GroupBy(a => new { a.AssetType, a.LifecycleState, Damaged = a.Condition == nameof(ConditionStatus.Damaged) })
            .Select(g => new { g.Key.AssetType, g.Key.LifecycleState, g.Key.Damaged, Count = g.Count() })
            .ToListAsync();

        return rows.GroupBy(r => r.AssetType).OrderBy(g => g.Key).Select(g =>
        {
            var available = g.Where(r => r.LifecycleState == nameof(LifecycleState.InStorage) && !r.Damaged).Sum(r => r.Count);
            var reserved = g.Where(r => r.LifecycleState == nameof(LifecycleState.Reserved)).Sum(r => r.Count);
            var damaged = g.Where(r => r.LifecycleState == nameof(LifecycleState.InStorage) && r.Damaged).Sum(r => r.Count);
            return new StockTypeSummaryDto(Enums.Parse<AssetType>(g.Key), available, reserved, damaged, null, available == 0 ? "NoStock" : "Healthy");
        }).ToList();
    }

    private async Task<AssistantResult> WarrantyExpiringAsync(Run run)
    {
        var period = run.Filters.Period!;
        var query = Filtered(run, byAcquisition: false).Where(a => a.WarrantyEnd != null && a.WarrantyEnd >= period.FromUtc && a.WarrantyEnd < period.ToUtc
            && a.OperationalStatus != nameof(OperationalStatus.Retired));
        if (run.Plan.GroupBy is { } dimension) return await GroupedAsync(run, query, dimension, $"{Noun(run.Filters.AssetType)} going out of warranty {PeriodPhrase(period)}");

        var total = await query.CountAsync();
        var assets = await query.OrderBy(a => a.WarrantyEnd).Take(MaxRows).ToListAsync();
        var scope = Scope(run.Filters with { Period = null }, run.Vocabulary);
        if (total == 0) return new($"No {Noun(run.Filters.AssetType)}{scope} go out of warranty {PeriodPhrase(period)}.", Evidence: Evidence(AssetSource, 0),
            Suggestions: ["Which assets are out of warranty?", "Warranty expiries in the next 6 months"]);

        var first = assets[0];
        var rows = assets.Select(a => (IReadOnlyList<string?>)[a.AssetNo, AssetStatusRules.Describe(a), Date(a.WarrantyEnd), ((int)(a.WarrantyEnd!.Value - run.Today).TotalDays).ToString(), a.WarrantyVendor, a.EmployeeName ?? "Not assigned"]).ToList();
        return new($"{CountOf(total, run.Filters.AssetType)}{scope} go out of warranty {PeriodPhrase(period)}. The first is {first.AssetNo} ({AssetStatusRules.Describe(first)}) on {Date(first.WarrantyEnd)}.",
            new AssistantTable(["Asset", "Make and model", "Warranty end", "Days left", "Vendor", "Assigned to"], rows, total),
            Sources: AssetSources(assets), Evidence: Evidence(AssetSource, total), Suggestions: ["Show this by month", "Which assets are out of warranty?", "Warranty claims in progress"]);
    }

    private async Task<AssistantResult> OutOfWarrantyAsync(Run run)
    {
        var query = Filtered(run, byAcquisition: false).Where(a => a.WarrantyEnd != null && a.WarrantyEnd < run.Today && a.OperationalStatus != nameof(OperationalStatus.Retired));
        if (run.Plan.GroupBy is { } dimension) return await GroupedAsync(run, query, dimension, $"{Noun(run.Filters.AssetType)} out of warranty");

        var total = await query.CountAsync();
        var inUse = await query.CountAsync(a => a.OperationalStatus == nameof(OperationalStatus.InUse));
        var assets = await query.OrderBy(a => a.WarrantyEnd).Take(MaxRows).ToListAsync();
        var scope = Scope(run.Filters, run.Vocabulary);
        if (total == 0) return new($"No {Noun(run.Filters.AssetType)}{scope} are out of warranty.", Evidence: Evidence(AssetSource, 0));

        var rows = assets.Select(a => (IReadOnlyList<string?>)[a.AssetNo, AssetStatusRules.Describe(a), Date(a.WarrantyEnd), Humanise(a.OperationalStatus), a.EmployeeName ?? "Not assigned"]).ToList();
        return new($"{CountOf(total, run.Filters.AssetType)}{scope} {(total == 1 ? "is" : "are")} out of warranty, {inUse:N0} of them still in use.",
            new AssistantTable(["Asset", "Make and model", "Warranty ended", "Status", "Assigned to"], rows, total),
            Sources: AssetSources(assets), Evidence: Evidence(AssetSource, total), Suggestions: ["Out of warranty by location", "Warranty expiries next quarter"]);
    }

    private async Task<AssistantResult> CostSummaryAsync(Run run)
    {
        var query = Filtered(run, byAcquisition: true);
        var total = await query.CountAsync();
        var withCost = await query.CountAsync(a => a.PurchaseCost != null);
        var sum = await query.SumAsync(a => a.PurchaseCost ?? 0);
        var scope = Scope(run.Filters, run.Vocabulary, includePeriod: true);

        if (total == 0) return new($"There are no {Noun(run.Filters.AssetType)}{scope}, so there is no cost to report.", Evidence: Evidence(AssetSource, 0));
        if (withCost == 0) return new($"None of the {CountOf(total, run.Filters.AssetType)}{scope} has a purchase cost recorded from Pastel, so I can't give a total.", Evidence: Evidence(AssetSource, total));

        var missing = total - withCost;
        return new($"The recorded purchase cost of {CountOf(withCost, run.Filters.AssetType)}{scope} is {Money(sum)}."
            + (missing > 0 ? $" {Count(missing, "asset")} {(missing == 1 ? "has" : "have")} no cost recorded and {(missing == 1 ? "is" : "are")} not included." : "")
            + " Costs come from Pastel; this is not a depreciated value.",
            Evidence: Evidence(AssetSource, total), Suggestions: ["Cost by department", "Compare purchases this quarter with last quarter", "Monthly purchase trend"]);
    }

    private async Task<AssistantResult> CostComparisonAsync(Run run)
    {
        var current = run.Filters.Period!;
        var previous = run.Filters.ComparePeriod!;
        var baseQuery = Filtered(run with { Plan = run.Plan with { Filters = run.Filters with { Period = null } } }, byAcquisition: false);

        async Task<(int Count, decimal Cost)> TotalsAsync(DateRange range)
        {
            var q = baseQuery.Where(a => a.AcquisitionDate >= range.FromUtc && a.AcquisitionDate < range.ToUtc);
            return (await q.CountAsync(), await q.SumAsync(a => a.PurchaseCost ?? 0));
        }

        var a = await TotalsAsync(current);
        var b = await TotalsAsync(previous);
        var noun = Noun(run.Filters.AssetType);
        if (a.Count == 0 && b.Count == 0)
            return new($"No {noun} with a recorded cost were acquired in {current.Label} or {previous.Label}.", Evidence: Evidence(AssetSource, 0));

        var change = b.Cost == 0 ? null : (decimal?)Math.Round((a.Cost - b.Cost) * 100 / b.Cost, 1);
        var direction = change switch { null => "", > 0 => $", up {change}%", < 0 => $", down {Math.Abs(change.Value)}%", _ => ", no change" };
        var chart = new AssistantChart("bar", $"Purchase cost: {previous.Label} vs {current.Label}", "Rand",
            [new(previous.Label, b.Cost), new(current.Label, a.Cost)]);
        var table = new AssistantTable(["Period", $"{Capital(noun)} acquired", "Recorded cost"],
            [[previous.Label, b.Count.ToString(), Money(b.Cost)], [current.Label, a.Count.ToString(), Money(a.Cost)]], 2);

        return new($"{Capital(noun)} acquired in {current.Label} cost {Money(a.Cost)} ({a.Count:N0} items), compared with {Money(b.Cost)} ({b.Count:N0} items) in {previous.Label}{direction}.",
            table, chart, Evidence: Evidence("Asset register purchase costs (Pastel)", a.Count + b.Count), Suggestions: ["Monthly purchase trend", "Cost by department"]);
    }

    private async Task<AssistantResult> AcquisitionTrendAsync(Run run)
    {
        var to = run.Filters.Period?.To ?? DateOnly.FromDateTime(run.Today).AddDays(1);
        var from = run.Filters.Period?.From ?? new DateOnly(to.Year, to.Month, 1).AddMonths(-11);
        var range = new DateRange(from, to, run.Filters.Period?.Label ?? "the last 12 months");
        var rows = await Filtered(run with { Plan = run.Plan with { Filters = run.Filters with { Period = null } } }, byAcquisition: false)
            .Where(a => a.AcquisitionDate >= range.FromUtc && a.AcquisitionDate < range.ToUtc)
            .GroupBy(a => new { a.AcquisitionDate!.Value.Year, a.AcquisitionDate.Value.Month })
            .Select(g => new { g.Key.Year, g.Key.Month, Count = g.Count(), Cost = g.Sum(a => a.PurchaseCost ?? 0) })
            .ToListAsync();

        var months = new List<DateOnly>();
        for (var m = new DateOnly(from.Year, from.Month, 1); m < to && months.Count < 36; m = m.AddMonths(1)) months.Add(m);
        var points = months.Select(m =>
        {
            var row = rows.FirstOrDefault(r => r.Year == m.Year && r.Month == m.Month);
            return new AssistantChartPoint(m.ToString("MMM yyyy"), run.Plan.ByCost ? row?.Cost ?? 0 : row?.Count ?? 0);
        }).ToList();

        var totalCount = rows.Sum(r => r.Count);
        if (totalCount == 0) return new($"No {Noun(run.Filters.AssetType)} were acquired in {range.Label}.", Evidence: Evidence(AssetSource, 0));

        var busiest = points.MaxBy(p => p.Value)!;
        var valueLabel = run.Plan.ByCost ? "Recorded cost (R)" : "Assets acquired";
        var summary = run.Plan.ByCost
            ? $"Purchases in {range.Label} cost {Money(rows.Sum(r => r.Cost))} in total. The highest month was {busiest.Label} ({Money(busiest.Value)})."
            : $"{CountOf(totalCount, run.Filters.AssetType)} were acquired in {range.Label}. The busiest month was {busiest.Label} ({Number(busiest.Value)}).";
        return new(summary,
            new AssistantTable(["Month", valueLabel], points.Select(p => (IReadOnlyList<string?>)[p.Label, run.Plan.ByCost ? Money(p.Value) : Number(p.Value)]).ToList(), points.Count),
            new AssistantChart("line", $"Monthly {(run.Plan.ByCost ? "purchase cost" : "acquisitions")}", valueLabel, points),
            Evidence: Evidence(AssetSource, totalCount), Suggestions: ["Compare purchases this year with last year", "Cost by department"]);
    }

    // ---------- Shared helpers ----------

    private sealed record Group(string Label, int Count, decimal Cost);

    // Answers "which X has the most Y" and plain breakdowns with a table and a chart (BR-8.15-04).
    private AssistantResult Ranked(Run run, List<Group> groups, string noun, string dimensionName, string source, int records, IReadOnlyList<string> suggestions)
    {
        if (groups.Count == 0)
            return new($"There are no {noun}{Scope(run.Filters, run.Vocabulary, includePeriod: true)} to break down.", Evidence: Evidence(source, 0));

        var byCost = run.Plan.ByCost;
        decimal Value(Group g) => byCost ? g.Cost : g.Count;
        string Show(Group g) => byCost ? Money(g.Cost) : g.Count.ToString("N0");

        var ordered = run.Plan.Ranking == Ranking.Least ? groups.OrderBy(Value).ThenBy(g => g.Label).ToList()
            : dimensionName == "month" ? groups : groups.OrderByDescending(Value).ThenBy(g => g.Label).ToList();
        var shown = run.Plan.Top is { } top ? ordered.Take(top).ToList() : ordered;
        var scope = Scope(run.Filters, run.Vocabulary, includePeriod: true);

        string answer;
        if (run.Plan.Ranking != Ranking.None && shown.Count > 0 && run.Plan.Top is null or 1)
        {
            var leader = shown[0];
            var word = run.Plan.Ranking == Ranking.Least ? (byCost ? "lowest cost" : "fewest") : (byCost ? "highest cost" : "most");
            var others = ordered.Skip(1).Take(2).Select(g => $"{g.Label} ({Show(g)})").ToList();
            answer = $"{leader.Label} has the {word} {noun}{scope} ({Show(leader)})" + (others.Count > 0 ? $", followed by {JoinWithAnd(others)}." : ".");
            var ties = ordered.Skip(1).Count(g => Value(g) == Value(leader));
            if (ties > 0) answer += $" {Count(ties, "other " + dimensionName)} {(ties == 1 ? "has" : "have")} the same figure.";
        }
        else
        {
            answer = $"Here {(byCost ? "is the recorded cost of" : "are")} {noun}{scope} by {dimensionName}, across {Count(groups.Count, dimensionName)} ({(byCost ? Money(groups.Sum(g => g.Cost)) : groups.Sum(g => g.Count).ToString("N0"))} in total).";
        }

        var columns = byCost ? new[] { Capital(dimensionName), Capital(noun), "Recorded cost" } : new[] { Capital(dimensionName), Capital(noun) };
        var rows = shown.Select(g => (IReadOnlyList<string?>)(byCost ? [g.Label, g.Count.ToString("N0"), Money(g.Cost)] : [g.Label, g.Count.ToString("N0")])).ToList();
        var chart = new AssistantChart(dimensionName == "month" ? "line" : "bar", $"{Capital(noun)} by {dimensionName}", byCost ? "Rand" : Capital(noun),
            shown.Take(12).Select(g => new AssistantChartPoint(g.Label, Value(g))).ToList());
        return new(answer, new AssistantTable(columns, rows, groups.Count), chart, Evidence: Evidence(source, records), Suggestions: suggestions);
    }

    private async Task<AssistantResult> GroupedAsync(Run run, IQueryable<AssetEntity> query, Dimension dimension, string noun)
    {
        var groups = (await query.GroupBy(KeyOf(dimension)).Select(g => new { g.Key, Count = g.Count(), Cost = g.Sum(a => a.PurchaseCost ?? 0) }).ToListAsync())
            .Select(g => new Group(Label(dimension, g.Key, run.Vocabulary), g.Count, g.Cost)).ToList();
        return Ranked(run, groups, noun, DimensionName(dimension), AssetSource, groups.Sum(g => g.Count), ["Show the list", "What needs my attention?"]);
    }

    // Applies the plan's filters to the user's scoped assets. Disposed assets are left out unless asked for.
    private static IQueryable<AssetEntity> Filtered(Run run, bool byAcquisition)
    {
        var f = run.Filters;
        var q = run.Assets;
        if (f.Lifecycle != LifecycleState.Disposed) q = q.Where(a => !Inactive.Contains(a.LifecycleState));
        if (f.AssetType is { } type) { var v = type.ToString(); q = q.Where(a => a.AssetType == v); }
        if (f.Lifecycle is { } state) { var v = state.ToString(); q = q.Where(a => a.LifecycleState == v); }
        if (f.Status is { } status) { var v = status.ToString(); q = q.Where(a => a.OperationalStatus == v); }
        if (f.LocationId is { } location) q = q.Where(a => a.LocationId == location);
        if (f.Region is { } region) q = q.Where(a => a.Region == region);
        if (f.DepartmentId is { } department) q = q.Where(a => a.DepartmentId == department);
        if (f.EmployeeId is { } employee) q = q.Where(a => a.EmployeeId == employee);
        if (f.Make is { } make) q = q.Where(a => a.Make == make);
        if (f.AssetId is { } assetId) q = q.Where(a => a.AssetId == assetId);
        if (f.Assigned == true) q = q.Where(a => a.EmployeeId != null);
        if (f.Assigned == false) q = q.Where(a => a.EmployeeId == null);
        if (f.AtHome == true) q = q.Where(a => a.LocationSubStatus == nameof(LocationSubStatus.AtHome));
        if (byAcquisition && f.Period is { } period) q = q.Where(a => a.AcquisitionDate >= period.FromUtc && a.AcquisitionDate < period.ToUtc);
        return q;
    }

    private static Expression<Func<AssetEntity, string?>> KeyOf(Dimension dimension) => dimension switch
    {
        Dimension.Location => a => a.LocationId,
        Dimension.Region => a => a.Region,
        Dimension.Department => a => a.DepartmentId,
        Dimension.Employee => a => a.EmployeeName,
        Dimension.Status => a => a.OperationalStatus,
        Dimension.Lifecycle => a => a.LifecycleState,
        Dimension.Make => a => a.Make,
        Dimension.Model => a => a.Model,
        _ => a => a.AssetType
    };

    private static string Label(Dimension dimension, string? key, Vocabulary vocabulary) => dimension switch
    {
        _ when key is null => dimension == Dimension.Employee ? "Not assigned" : "Not recorded",
        Dimension.Location => vocabulary.LocationNames.GetValueOrDefault(key, key),
        Dimension.Department => vocabulary.DepartmentNames.GetValueOrDefault(key, key),
        Dimension.Status or Dimension.Lifecycle or Dimension.AssetType or Dimension.Classification => Humanise(key),
        _ => key
    };

    private static string DimensionName(Dimension dimension) => dimension switch
    {
        Dimension.AssetType => "asset type",
        Dimension.Lifecycle => "lifecycle state",
        Dimension.Classification => "fault type",
        var d => d.ToString().ToLowerInvariant()
    };

    private async Task<AssetEntity?> FindAssetAsync(Run run) =>
        run.Filters.AssetId is null ? null : await run.Assets.FirstOrDefaultAsync(a => a.AssetId == run.Filters.AssetId);

    private static AssistantResult NotFound(Run run) => new(
        run.Filters.UnknownIdentifier is { } id
            ? $"I couldn't find an asset with the number, tag or serial \"{id}\" in the records you can see. Check the value and try again."
            : "Which asset do you mean? Give its asset number, tag or serial number.",
        Suggestions: ["Show all laptops", "How many assets do we have?"]);

    private static AssistantTable AssetTable(IReadOnlyList<AssetEntity> assets, int total, Vocabulary vocabulary) => new(
        ["Asset", "Type", "Make and model", "Status", "Assigned to", "Location", "Warranty end"],
        assets.Select(a => (IReadOnlyList<string?>)[a.AssetNo, Humanise(a.AssetType), AssetStatusRules.Describe(a), Humanise(a.LifecycleState),
            a.EmployeeName ?? "Not assigned", Location(a, vocabulary), Date(a.WarrantyEnd)]).ToList(),
        total);

    private static IReadOnlyList<AssistantSource> AssetSources(IEnumerable<AssetEntity> assets) =>
        assets.Take(MaxRows).Select(a => new AssistantSource("Asset", a.AssetId, a.AssetNo)).ToList();

    private static IReadOnlyList<string?> Row(string field, string? value) => [field, string.IsNullOrWhiteSpace(value) ? null : value];

    private static string Capital(string text) => text.Length == 0 ? text : char.ToUpperInvariant(text[0]) + text[1..];
}
