using CtrlFind.Contracts;
using CtrlFind.Infrastructure.Persistence;
using CtrlFind.Infrastructure.Persistence.Entities;
using Microsoft.EntityFrameworkCore;

namespace CtrlFind.Services;

// Figures for the operational and management dashboards (BR-8.14-01 to BR-8.14-04).
// Every figure comes from stored data; nothing is estimated.
public sealed class DashboardService(ApplicationDbContext db, OnboardingService onboarding, AssetLifecycleService lifecycle)
{
    private static readonly string[] Gone = [nameof(LifecycleState.Disposed)];
    private static readonly string[] LostStates = [nameof(LifecycleState.Lost), nameof(LifecycleState.Stolen)];

    public async Task<OperationalDashboardDto> OperationalAsync(IQueryable<AssetEntity> scopedAssets)
    {
        var now = DateTime.UtcNow;
        var today = now.Date;
        var monthStart = new DateTime(now.Year, now.Month, 1, 0, 0, 0, DateTimeKind.Utc);
        var active = scopedAssets.Where(a => !Gone.Contains(a.LifecycleState));
        var confirmed = nameof(AuditOutcome.Confirmed);

        var total = await active.CountAsync();
        var added = await active.CountAsync(a => a.CreatedAtUtc >= monthStart);
        var flagged = await active.CountAsync(a => (a.AuditOutcome != null && a.AuditOutcome != confirmed) || a.LifecycleState == nameof(LifecycleState.UnderInvestigation));
        var atHome = await active.CountAsync(a => a.LocationSubStatus == nameof(LocationSubStatus.AtHome));

        var retiredStates = new[] { nameof(OperationalStatus.Retired) };
        var outOfWarranty = await active.CountAsync(a => a.WarrantyEnd != null && a.WarrantyEnd < today && !retiredStates.Contains(a.OperationalStatus));
        var overdueService = await db.MaintenanceLogs.AsNoTracking()
            .Where(l => active.Any(a => a.AssetId == l.AssetId))
            .GroupBy(l => l.AssetId)
            .CountAsync(g => g.Max(l => l.NextDueDate) < today);

        var byStatus = await active.GroupBy(a => a.OperationalStatus).Select(g => new CountByLabelDto(g.Key, g.Count())).ToListAsync();
        var byType = await active.GroupBy(a => a.AssetType).Select(g => new CountByLabelDto(g.Key, g.Count())).OrderByDescending(x => x.Count).ToListAsync();

        var openCases = await OnboardingService.OpenCases(db.OnboardingCases.AsNoTracking()).ToListAsync();
        var shortfalls = await onboarding.ShortfallsAsync(openCases);
        var onboardingReadiness = new OnboardingReadinessDto(
            openCases.Count,
            openCases.Count(c => c.IsConfirmed && shortfalls[c.CaseId].Count == 0),
            openCases.Count(c => c.IsShortNotice),
            openCases.Count(c => shortfalls[c.CaseId].Count > 0));

        var openOffboarding = db.OffboardingCases.AsNoTracking().Where(c => c.Status != nameof(CaseStatus.Completed) && c.Status != nameof(CaseStatus.Cancelled));
        var laptopsOutstanding = await db.OffboardingItems.AsNoTracking()
            .Where(i => openOffboarding.Any(c => c.CaseId == i.CaseId) && (i.Resolution == null || i.Resolution == nameof(OffboardingItemResolution.Escalated)))
            .Join(db.Assets, i => i.AssetId, a => a.AssetId, (i, a) => a.AssetType)
            .CountAsync(t => t == nameof(AssetType.Laptop));
        var offboarding = new OffboardingRecoveryDto(
            await openOffboarding.CountAsync(),
            await db.OffboardingCases.CountAsync(c => c.Status == nameof(CaseStatus.Completed) && c.CompletedAt >= monthStart),
            laptopsOutstanding);

        var openIncidents = await db.Incidents.CountAsync(i => i.Status != nameof(CaseStatus.Completed) && active.Any(a => a.AssetId == i.AssetId));
        var lossExposure = await active.Where(a => LostStates.Contains(a.LifecycleState)).SumAsync(a => a.PurchaseCost ?? 0);
        var warrantyAlerts = (await AssetQueries.WarrantyExpiringAsync(active, 90, lifecycle.Rules.WarrantyAlertDays)).Count;
        var activeClaims = await db.WarrantyClaims.CountAsync(c => c.Status != nameof(CaseStatus.Completed));
        var openRepairs = await db.MaintenanceCases.CountAsync(c => c.Status != nameof(CaseStatus.Completed));

        var discrepancies = db.AuditItems.AsNoTracking().Where(i => i.Outcome != null && i.Outcome != confirmed && i.Outcome != nameof(AuditOutcome.AwaitingConfirmation));
        var openDiscrepancies = await discrepancies.CountAsync(i => i.ResolvedAt == null);
        var resolvedDiscrepancies = await discrepancies.CountAsync(i => i.ResolvedAt != null);

        var inUse = byStatus.Where(s => s.Label == nameof(OperationalStatus.InUse)).Sum(s => s.Count);
        var inStorage = byStatus.Where(s => s.Label == nameof(OperationalStatus.InStorage)).Sum(s => s.Count);
        var utilisation = inUse + inStorage == 0 ? 0 : Math.Round(inUse * 100m / (inUse + inStorage), 1);

        return new OperationalDashboardDto(total, added, flagged, atHome, outOfWarranty + overdueService, byStatus, byType,
            await AssetQueries.SummariseStockByTypeAsync(db), onboardingReadiness, offboarding, openIncidents, lossExposure,
            warrantyAlerts, activeClaims, openRepairs, openDiscrepancies, resolvedDiscrepancies, utilisation,
            await RiskAsync(active), await RecentActivityAsync(scopedAssets));
    }

    public async Task<ManagementDashboardDto> ManagementAsync(IQueryable<AssetEntity> scopedAssets)
    {
        var now = DateTime.UtcNow;
        var active = scopedAssets.Where(a => !Gone.Contains(a.LifecycleState));
        var incidents = db.Incidents.AsNoTracking().Where(i => scopedAssets.Any(a => a.AssetId == i.AssetId));

        var yearAgo = new DateTime(now.Year, now.Month, 1, 0, 0, 0, DateTimeKind.Utc).AddMonths(-11);
        var incidentDates = await incidents.Where(i => i.IncidentDate >= yearAgo).Select(i => i.IncidentDate).ToListAsync();
        var incidentTrend = Months(yearAgo, 12).Select(m => new TrendPointDto(m.ToString("yyyy-MM"), incidentDates.Count(d => d.Year == m.Year && d.Month == m.Month))).ToList();

        var halfYear = yearAgo.AddMonths(6);
        var checks = await db.AuditItems.AsNoTracking()
            .Where(i => i.CheckedAt >= halfYear && i.Outcome != null && i.Outcome != nameof(AuditOutcome.AwaitingConfirmation))
            .Select(i => new { i.CheckedAt, i.Outcome })
            .ToListAsync();
        var compliance = Months(halfYear, 6).Select(m =>
        {
            var month = checks.Where(c => c.CheckedAt!.Value.Year == m.Year && c.CheckedAt.Value.Month == m.Month).ToList();
            var value = month.Count == 0 ? 0 : Math.Round(month.Count(c => c.Outcome == nameof(AuditOutcome.Confirmed)) * 100m / month.Count, 1);
            return new TrendPointDto(m.ToString("yyyy-MM"), value);
        }).ToList();

        var byEmployee = await incidents.GroupBy(i => i.ReportedByEmployeeId)
            .Select(g => new { g.Key, Count = g.Count() }).OrderByDescending(x => x.Count).Take(10).ToListAsync();
        var employeeIds = byEmployee.Select(x => x.Key).ToList();
        var names = await db.Employees.AsNoTracking().Where(e => employeeIds.Contains(e.EmployeeId)).ToDictionaryAsync(e => e.EmployeeId, e => e.FullName);

        var byLocation = await incidents.Join(db.Assets, i => i.AssetId, a => a.AssetId, (i, a) => a.Building ?? a.Region ?? "Unknown")
            .GroupBy(l => l).Select(g => new CountByLabelDto(g.Key, g.Count())).OrderByDescending(x => x.Count).ToListAsync();
        var byAssetType = await incidents.Join(db.Assets, i => i.AssetId, a => a.AssetId, (i, a) => a.AssetType)
            .GroupBy(t => t).Select(g => new CountByLabelDto(g.Key, g.Count())).OrderByDescending(x => x.Count).ToListAsync();

        var aods = db.AodRecords.AsNoTracking().Where(a => a.Status != "Cancelled");
        var openAod = await aods.Where(a => a.Status != "Recovered").SumAsync(a => a.Amount - a.RecoveredAmount);
        var recoveredAod = await aods.SumAsync(a => a.RecoveredAmount);

        var repeat = await db.Incidents.GroupBy(i => i.ReportedByEmployeeId).CountAsync(g => g.Count() >= lifecycle.Rules.RepeatIncidentThreshold);
        var laptopsOut = await active.CountAsync(a => a.AssetType == nameof(AssetType.Laptop) && a.OperationalStatus == nameof(OperationalStatus.InUse));

        return new ManagementDashboardDto(
            await RiskAsync(active), incidentTrend, compliance,
            byEmployee.Select(x => new CountByLabelDto(names.GetValueOrDefault(x.Key) ?? x.Key, x.Count)).ToList(), byLocation, byAssetType,
            await active.SumAsync(a => a.PurchaseCost ?? 0),
            await active.Where(a => LostStates.Contains(a.LifecycleState)).SumAsync(a => a.PurchaseCost ?? 0),
            openAod, recoveredAod, repeat, laptopsOut, await FlaggedItemsAsync(active));
    }

    public async Task<RiskDistributionDto> RiskAsync(IQueryable<AssetEntity> assets)
    {
        var inScope = await assets.Where(a => a.OperationalStatus == nameof(OperationalStatus.InUse) || a.OperationalStatus == nameof(OperationalStatus.InStorage)).ToListAsync();
        var holders = inScope.Where(a => a.EmployeeId != null).Select(a => a.EmployeeId!).Distinct().ToList();
        var withIncidents = (await db.Incidents.AsNoTracking().Where(i => holders.Contains(i.ReportedByEmployeeId)).Select(i => i.ReportedByEmployeeId).Distinct().ToListAsync()).ToHashSet();

        var levels = inScope.Select(a => AssetStatusRules.RiskLevel(a, a.EmployeeId is not null && withIncidents.Contains(a.EmployeeId), DateTime.UtcNow, lifecycle.Rules.LaptopAgeingYears)).ToList();
        return new RiskDistributionDto(levels.Count(l => l == "High"), levels.Count(l => l == "Medium"), levels.Count(l => l == "Low"), levels.Count);
    }

    private async Task<IReadOnlyList<RecentActivityDto>> RecentActivityAsync(IQueryable<AssetEntity> assets)
    {
        var rows = await db.AssetHistory.AsNoTracking()
            .Where(h => assets.Any(a => a.AssetId == h.AssetId))
            .OrderByDescending(h => h.ChangedAt).Take(8)
            .Join(db.Assets, h => h.AssetId, a => a.AssetId, (h, a) => new { History = h, Asset = a })
            .ToListAsync();
        return rows.Select(r => new RecentActivityDto(r.Asset.AssetId, r.Asset.AssetNo, AssetStatusRules.Describe(r.Asset), r.History.Action,
            r.History.Summary, r.Asset.EmployeeName, new DateTimeOffset(DateTime.SpecifyKind(r.History.ChangedAt, DateTimeKind.Utc)))).ToList();
    }

    // Flagged items show the asset's latest photo inline when one exists (BR-8.14-04).
    private async Task<IReadOnlyList<FlaggedItemDto>> FlaggedItemsAsync(IQueryable<AssetEntity> assets)
    {
        var confirmed = nameof(AuditOutcome.Confirmed);
        var flagged = await assets
            .Where(a => (a.AuditOutcome != null && a.AuditOutcome != confirmed) || a.LifecycleState == nameof(LifecycleState.UnderInvestigation) || LostStates.Contains(a.LifecycleState))
            .OrderByDescending(a => a.UpdatedAtUtc).Take(10)
            .Select(a => new
            {
                Asset = a,
                Photo = db.AssetDocuments.Where(d => d.AssetId == a.AssetId && d.DocumentType == nameof(DocumentType.Photo))
                    .OrderByDescending(d => d.UploadedAt).Select(d => d.DownloadUrl).FirstOrDefault()
            })
            .ToListAsync();

        return flagged.Select(f => new FlaggedItemDto(f.Asset.AssetId, f.Asset.AssetNo, AssetStatusRules.Describe(f.Asset),
            LostStates.Contains(f.Asset.LifecycleState) ? f.Asset.LifecycleState
            : f.Asset.AuditOutcome is not null && f.Asset.AuditOutcome != confirmed ? f.Asset.AuditOutcome
            : "Under investigation", f.Photo)).ToList();
    }

    private static IEnumerable<DateTime> Months(DateTime start, int count) => Enumerable.Range(0, count).Select(start.AddMonths);
}
