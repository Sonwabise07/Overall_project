using CtrlFind.Contracts;
using CtrlFind.Infrastructure.Persistence;
using CtrlFind.Infrastructure.Persistence.Entities;
using Microsoft.EntityFrameworkCore;

namespace CtrlFind.Services;

// Time-based alerts calculated from current data each time they are read (DEC-007).
public sealed class AlertService(ApplicationDbContext db, AssetLifecycleService lifecycle)
{
    public async Task<IReadOnlyList<AlertDto>> ListAsync(IQueryable<AssetEntity> assets, bool includeOperational)
    {
        var now = DateTime.UtcNow;
        var alerts = new List<AlertDto>();

        var alertDays = lifecycle.Rules.WarrantyAlertDays;
        var expiring = await AssetQueries.WarrantyExpiringAsync(assets, alertDays.DefaultIfEmpty(90).Max(), alertDays);
        alerts.AddRange(expiring.Where(w => w.AlertStage != "NotYetDue").Select(w => new AlertDto("WarrantyExpiry", w.DaysLeft <= 30 ? "High" : "Medium",
            $"Warranty expires in {w.DaysLeft} days", $"{w.AssetNo} · {w.Make} {w.Model}".Trim(), w.AssetId, w.WarrantyEnd)));

        var holds = await assets.Where(a => a.LifecycleState == nameof(LifecycleState.HeldForReassignment) && a.HoldExpiresAt != null && a.HoldExpiresAt < now)
            .Select(a => new { a.AssetId, a.AssetNo, a.HoldExpiresAt }).ToListAsync();
        alerts.AddRange(holds.Select(h => new AlertDto("HoldExpired", "Medium", "Return held asset to storage",
            $"{h.AssetNo} was held for reassignment until {h.HoldExpiresAt:dd MMM yyyy}.", h.AssetId, DateOnly.FromDateTime(h.HoldExpiresAt!.Value))));

        var due = now.AddDays(14);
        var services = await db.MaintenanceLogs.AsNoTracking()
            .Where(l => l.NextDueDate != null && assets.Any(a => a.AssetId == l.AssetId))
            .GroupBy(l => l.AssetId)
            .Select(g => new { AssetId = g.Key, NextDue = g.Max(l => l.NextDueDate) })
            .Where(x => x.NextDue <= due)
            .ToListAsync();
        alerts.AddRange(services.Select(s => new AlertDto("MaintenanceDue", "Low", "Maintenance due", $"Service due {s.NextDue:dd MMM yyyy}.", s.AssetId, DateOnly.FromDateTime(s.NextDue!.Value))));

        if (includeOperational)
        {
            var overdueSwaps = await db.EmergencySwaps.AsNoTracking()
                .Where(s => s.Status == nameof(CaseStatus.Open) && s.ResolveBy < now)
                .Select(s => new { s.SwapId, s.TemporaryAssetId, s.ResolveBy }).ToListAsync();
            alerts.AddRange(overdueSwaps.Select(s => new AlertDto("EmergencySwapEscalated", "High", "Emergency swap past its resolution window",
                $"Swap {s.SwapId} was due by {s.ResolveBy:dd MMM yyyy}. Escalated to Fixed Assets.", s.TemporaryAssetId, DateOnly.FromDateTime(s.ResolveBy))));

            alerts.AddRange(AssetQueries.StockAlerts(await AssetQueries.SummariseStockByTypeAsync(db)));

            var shortNotice = await OnboardingService.OpenCases(db.OnboardingCases.AsNoTracking()).Where(c => c.IsShortNotice)
                .Select(c => new { c.EmployeeName, c.StartDate }).ToListAsync();
            alerts.AddRange(shortNotice.Select(c => new AlertDto("ShortNotice", "Medium", "Short-notice new hire",
                $"{c.EmployeeName} starts {c.StartDate:dd MMM yyyy}.", null, DateOnly.FromDateTime(c.StartDate))));
        }

        return alerts
            .OrderBy(a => a.Severity switch { "High" => 0, "Medium" => 1, _ => 2 })
            .ThenBy(a => a.DueDate)
            .ToList();
    }
}
