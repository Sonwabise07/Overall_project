using System.Text.Json;
using CtrlFind.Contracts;
using CtrlFind.Infrastructure.Persistence;
using CtrlFind.Infrastructure.Persistence.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace CtrlFind.Services;

public sealed record RuleViolation(int Status, string Code, string Message);

// Shared asset operations used by several workflows. Changes are added to the context;
// callers save them (inside their own transaction) so history is written with the change (DEC-016).
public sealed class AssetLifecycleService(ApplicationDbContext db, IOptions<AssetRulesOptions> options)
{
    public AssetRulesOptions Rules => options.Value;

    public void RecordHistory(string assetId, string action, string summary, string userId, object? oldValue = null, object? newValue = null) =>
        db.AssetHistory.Add(new AssetHistoryEntity
        {
            AssetId = assetId,
            Action = action,
            Summary = summary,
            DetailsJson = oldValue is null && newValue is null ? null : JsonSerializer.Serialize(new { OldValue = oldValue, NewValue = newValue }),
            ChangedBy = userId,
            ChangedAt = DateTime.UtcNow
        });

    public void ChangeState(AssetEntity asset, LifecycleState state, string userId, string summary)
    {
        var oldState = asset.LifecycleState;
        if (oldState == state.ToString()) return;
        AssetStatusRules.Apply(asset, state);
        RecordHistory(asset.AssetId, "LifecycleChanged", summary, userId,
            new { LifecycleState = oldState }, new { LifecycleState = asset.LifecycleState, asset.OperationalStatus });
    }

    // BR-8.3-02 and BR-8.3-03: a laptop needs its own custody agreement, and a prior negligent loss
    // needs manager acknowledgement before release.
    public async Task<RuleViolation?> CheckLaptopReleaseAsync(AssetEntity asset, string employeeId, string? custodyDocumentId, bool managerAcknowledged)
    {
        if (asset.AssetType != nameof(AssetType.Laptop)) return null;

        if (string.IsNullOrWhiteSpace(custodyDocumentId))
            return new(409, "CUSTODY_AGREEMENT_REQUIRED", "A custody agreement signed for this laptop's serial number is required before release.");

        var agreementExists = await db.AssetDocuments.AnyAsync(d =>
            d.DocumentId == custodyDocumentId && d.AssetId == asset.AssetId && d.DocumentType == nameof(DocumentType.CustodyAgreement));
        if (!agreementExists)
            return new(409, "CUSTODY_AGREEMENT_REQUIRED", "The custody agreement must be uploaded against this laptop.");

        var alreadyUsed = await db.AssetAssignments.AnyAsync(a => a.AssetId == asset.AssetId && a.CustodyAgreementReference == custodyDocumentId);
        if (alreadyUsed)
            return new(409, "CUSTODY_AGREEMENT_REQUIRED", "This custody agreement belongs to an earlier assignment. A new agreement is required.");

        if (Rules.PriorNegligenceRequiresManagerAcknowledgement && !managerAcknowledged)
        {
            var priorNegligence = await db.Incidents.AnyAsync(i =>
                i.ReportedByEmployeeId == employeeId && i.NegligenceStatus == nameof(NegligenceStatus.Negligent));
            if (priorNegligence)
                return new(409, "MANAGER_ACKNOWLEDGEMENT_REQUIRED", "This employee has a prior negligent-loss record. Manager acknowledgement is required.");
        }

        return null;
    }

    public AssetAssignmentEntity Assign(AssetEntity asset, EmployeeEntity employee, LocationEntity location, DateOnly assignmentDate,
        string? custodyDocumentId, string? desk, ConditionStatus? condition, string? notes, string userId)
    {
        var oldValue = new { asset.EmployeeId, asset.LocationId, asset.StoreroomId, asset.LifecycleState };
        LeaveStoreroom(asset, "Issued");

        var assignment = new AssetAssignmentEntity
        {
            AssetId = asset.AssetId,
            EmployeeId = employee.EmployeeId,
            EmployeeName = employee.FullName,
            LocationId = location.LocationId,
            AssignedAt = DateTime.SpecifyKind(assignmentDate.ToDateTime(TimeOnly.MinValue), DateTimeKind.Utc),
            CustodyAgreementReference = custodyDocumentId,
            AssignedBy = userId,
            Notes = notes
        };
        db.AssetAssignments.Add(assignment);

        asset.EmployeeId = employee.EmployeeId;
        asset.EmployeeName = employee.FullName;
        asset.DepartmentId = employee.DepartmentId ?? asset.DepartmentId;
        ApplyLocation(asset, location);
        asset.Desk = desk;
        asset.LocationSubStatus = nameof(LocationSubStatus.InOffice);
        asset.Condition = condition?.ToString() ?? asset.Condition;
        asset.CustodyAgreementSigned = custodyDocumentId is not null;
        asset.HoldExpiresAt = null;
        AssetStatusRules.Apply(asset, LifecycleState.Assigned);

        RecordHistory(asset.AssetId, "AssetAssigned", $"Assigned to {employee.FullName}.", userId, oldValue,
            new { assignment.EmployeeId, assignment.LocationId, asset.Desk, CustodyAgreement = custodyDocumentId, Condition = asset.Condition });
        return assignment;
    }

    public async Task CloseActiveAssignmentAsync(AssetEntity asset)
    {
        var active = await db.AssetAssignments.Where(a => a.AssetId == asset.AssetId && a.ReturnedAt == null).ToListAsync();
        foreach (var assignment in active) assignment.ReturnedAt = DateTime.UtcNow;
        asset.EmployeeId = null;
        asset.EmployeeName = null;
        asset.CustodyAgreementSigned = false;
    }

    public async Task ReturnToStorageAsync(AssetEntity asset, StoreroomEntity storeroom, ConditionStatus condition, string userId, string summary)
    {
        var oldValue = new { asset.EmployeeId, asset.LocationId, asset.LifecycleState, asset.Condition };
        await CloseActiveAssignmentAsync(asset);

        var location = storeroom.LocationId is null ? null : await db.Locations.FirstOrDefaultAsync(l => l.LocationId == storeroom.LocationId);
        if (location is not null) ApplyLocation(asset, location);
        asset.StoreroomId = storeroom.StoreroomId;
        asset.Desk = null;
        asset.LocationSubStatus = nameof(LocationSubStatus.InOffice);
        asset.Condition = condition.ToString();
        asset.HoldExpiresAt = null;
        AssetStatusRules.Apply(asset, LifecycleState.InStorage);

        db.StockMovements.Add(new StockMovementEntity { StoreroomId = storeroom.StoreroomId, AssetId = asset.AssetId, Direction = "In", Reason = "Returned" });
        RecordHistory(asset.AssetId, "AssetReturned", summary, userId, oldValue,
            new { asset.StoreroomId, asset.LifecycleState, asset.Condition });
    }

    // After a repair or warranty claim the asset goes back to its holder, or to storage.
    public async Task RestoreAfterRepairAsync(AssetEntity asset, string userId, string summary)
    {
        var assigned = await db.AssetAssignments.AnyAsync(a => a.AssetId == asset.AssetId && a.ReturnedAt == null);
        ChangeState(asset, assigned ? LifecycleState.Assigned : LifecycleState.InStorage, userId, summary);
    }

    public async Task RetireAsync(AssetEntity asset, string userId, string summary)
    {
        await CloseActiveAssignmentAsync(asset);
        LeaveStoreroom(asset, "Retired");
        ChangeState(asset, LifecycleState.Retired, userId, summary);
    }

    public void LeaveStoreroom(AssetEntity asset, string reason)
    {
        if (asset.StoreroomId is null) return;
        db.StockMovements.Add(new StockMovementEntity { StoreroomId = asset.StoreroomId, AssetId = asset.AssetId, Direction = "Out", Reason = reason });
        asset.StoreroomId = null;
    }

    public static void ApplyLocation(AssetEntity asset, LocationEntity location)
    {
        asset.LocationId = location.LocationId;
        asset.Region = location.Region;
        asset.Building = location.Building;
        asset.Floor = location.Floor;
    }

    // Audience is a role name or "employee:{EmployeeId}".
    public void Notify(string audience, string type, string title, string message, string? assetId = null) =>
        db.Notifications.Add(new NotificationEntity { Audience = audience, Type = type, Title = title, Message = message, AssetId = assetId });

    public static string EmployeeAudience(string employeeId) => $"employee:{employeeId}";

    public async Task<string> NextAssetNumberAsync()
    {
        // NEXT VALUE FOR cannot be wrapped in a derived table, so the query is not composed.
        var values = await db.Database.SqlQuery<long>($"SELECT NEXT VALUE FOR dbo.AssetNumbers AS [Value]").ToListAsync();
        return $"AST-{values[0]:D6}";
    }
}
