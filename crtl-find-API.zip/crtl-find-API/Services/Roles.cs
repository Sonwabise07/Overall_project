namespace CtrlFind.Services;

// Role names from BRD Section 5. Combine with commas inside [Authorize(Roles = ...)].
public static class Roles
{
    public const string Employee = "Employee";
    public const string Manager = "Manager";
    public const string OfficeManager = "Office/Building Manager";
    public const string FixedAssets = "Fixed Assets";
    public const string HelpDesk = "IT Help Desk";
    public const string Hr = "HR";
    public const string Finance = "Finance / CFO";
    public const string Administrator = "Administrator";

    public const string AssetOperators = FixedAssets + "," + OfficeManager + "," + Administrator;
    public const string Management = Manager + "," + OfficeManager + "," + FixedAssets + "," + Hr + "," + Finance + "," + Administrator;

    // Roles that see every asset; the rest are scoped (see ApiControllerBase.ScopeAssets).
    public static readonly string[] FullVisibility = [FixedAssets, Administrator, HelpDesk, Hr, Finance];
}
