using CtrlFind.Contracts;
using CtrlFind.Infrastructure.Persistence.Entities;
using CtrlFind.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CtrlFind.Controllers;

[ApiController]
[Authorize]
[Produces("application/json")]
public abstract class ApiControllerBase : ControllerBase
{
    protected string CorrelationId => HttpContext.Items["CorrelationId"]?.ToString() ?? HttpContext.TraceIdentifier;
    protected string CurrentUserId => User.FindFirst("sub")?.Value ?? "usr_unknown";
    protected string? CurrentEmployeeId => User.FindFirst("employeeId")?.Value;
    protected string[] CurrentDepartmentIds => User.FindAll("departmentIds").Select(c => c.Value).ToArray();
    protected string[] CurrentLocationIds => User.FindAll("locationIds").Select(c => c.Value).ToArray();

    protected bool HasAnyRole(params string[] roles) => roles.Any(User.IsInRole);

    // BRD Section 5: employees see their own assets, managers their department,
    // office/building managers their locations; operational roles see everything.
    protected IQueryable<AssetEntity> ScopeAssets(IQueryable<AssetEntity> query)
    {
        if (HasAnyRole(Roles.FullVisibility)) return query;

        var employeeId = CurrentEmployeeId;
        var departments = User.IsInRole(Roles.Manager) ? CurrentDepartmentIds : [];
        var locations = User.IsInRole(Roles.OfficeManager) ? CurrentLocationIds : [];
        return query.Where(a =>
            (employeeId != null && a.EmployeeId == employeeId) ||
            (a.DepartmentId != null && departments.Contains(a.DepartmentId)) ||
            (a.LocationId != null && locations.Contains(a.LocationId)));
    }

    protected ApiResponse<T> Success<T>(T data) => new(data, new(CorrelationId, DateTimeOffset.UtcNow));

    protected PageResponse<T> Page<T>(IReadOnlyList<T> data, int page, int pageSize, int total)
    {
        var totalPages = total == 0 ? 0 : (int)Math.Ceiling(total / (double)pageSize);
        return new(data, new(page, pageSize, total, totalPages, page < totalPages, page > 1, CorrelationId, DateTimeOffset.UtcNow));
    }

    protected ObjectResult Failure(int status, string code, string message, params ErrorDetail[] details) =>
        StatusCode(status, new ErrorResponse(new(code, message, details, HttpContext.TraceIdentifier)));

    protected ObjectResult Failure(RuleViolation violation) => Failure(violation.Status, violation.Code, violation.Message);

    protected ObjectResult NotFoundFailure(string code, string what) => Failure(404, code, $"The {what} was not found.");

    protected static long? ParseId(string value) => long.TryParse(value, out var id) ? id : null;

    protected static DateTime ToUtcDate(DateOnly date) => DateTime.SpecifyKind(date.ToDateTime(TimeOnly.MinValue), DateTimeKind.Utc);

    protected static DateTimeOffset AsUtc(DateTime value) => new(DateTime.SpecifyKind(value, DateTimeKind.Utc));
}
