using System.Text.Json;
using CtrlFind.Contracts;
using CtrlFind.Infrastructure.Persistence;
using CtrlFind.Infrastructure.Persistence.Entities;
using CtrlFind.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CtrlFind.Controllers;

[Route("api/v1/assets")]
public sealed class AssetsController(
    ApplicationDbContext dbContext,
    AssetLifecycleService lifecycle) : ApiControllerBase
{
    // Assets enter the register in these states; every later state comes from a workflow (DEC-019).
    private static readonly LifecycleState[] RegistrationStates =
        [LifecycleState.Ordered, LifecycleState.Received, LifecycleState.Registered, LifecycleState.InStorage];

    // States the lifecycle endpoint may set directly. The rest have their own workflow endpoints.
    private static readonly LifecycleState[] DirectStates =
        [LifecycleState.Ordered, LifecycleState.Received, LifecycleState.Registered, LifecycleState.InStorage,
         LifecycleState.OffSite, LifecycleState.UnderAudit, LifecycleState.InterEntityTransfer, LifecycleState.Retired];

    private static readonly string[] AssignableStates =
        [nameof(LifecycleState.Registered), nameof(LifecycleState.InStorage), nameof(LifecycleState.HeldForReassignment)];

    [HttpGet]
    public async Task<ActionResult<PageResponse<AssetListItemDto>>> List(
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 25,
        [FromQuery] string? sort = "assetNo:asc",
        [FromQuery] LifecycleState? lifecycleState = null,
        [FromQuery] OperationalStatus? operationalStatus = null,
        [FromQuery] AssetType? assetType = null,
        [FromQuery] string? assignedEmployeeId = null,
        [FromQuery] string? search = null,
        [FromQuery] string? department = null,
        [FromQuery] string? departmentId = null,
        [FromQuery] string? region = null,
        [FromQuery] string? locationId = null,
        [FromQuery] LocationSubStatus? subStatus = null,
        [FromQuery] DateOnly? warrantyBefore = null,
        [FromQuery] bool flagged = false)
    {
        page = Math.Max(1, page);
        pageSize = Math.Clamp(pageSize, 1, 100);

        var query = ScopeAssets(dbContext.Assets.AsNoTracking());

        if (lifecycleState is not null)
        {
            var state = lifecycleState.Value.ToString();
            query = query.Where(a => a.LifecycleState == state);
        }

        if (operationalStatus is not null)
        {
            var status = operationalStatus.Value.ToString();
            query = query.Where(a => a.OperationalStatus == status);
        }

        if (assetType is not null)
        {
            var type = assetType.Value.ToString();
            query = query.Where(a => a.AssetType == type);
        }

        if (!string.IsNullOrWhiteSpace(assignedEmployeeId))
            query = query.Where(a => a.EmployeeId == assignedEmployeeId);

        if (!string.IsNullOrWhiteSpace(departmentId))
            query = query.Where(a => a.DepartmentId == departmentId);

        if (!string.IsNullOrWhiteSpace(department))
            query = query.Where(a => dbContext.Departments.Any(d => d.DepartmentId == a.DepartmentId && d.Name == department));

        if (!string.IsNullOrWhiteSpace(region))
            query = query.Where(a => a.Region == region);

        if (!string.IsNullOrWhiteSpace(locationId))
            query = query.Where(a => a.LocationId == locationId);

        if (subStatus is not null)
        {
            var value = subStatus.Value.ToString();
            query = query.Where(a => a.LocationSubStatus == value);
        }

        if (warrantyBefore is not null)
        {
            var cutoff = warrantyBefore.Value.ToDateTime(TimeOnly.MaxValue);
            query = query.Where(a => a.WarrantyEnd != null && a.WarrantyEnd <= cutoff);
        }

        if (flagged)
        {
            var confirmed = nameof(AuditOutcome.Confirmed);
            string[] flaggedStates = [nameof(LifecycleState.UnderInvestigation), nameof(LifecycleState.Lost), nameof(LifecycleState.Stolen)];
            query = query.Where(a => (a.AuditOutcome != null && a.AuditOutcome != confirmed) || flaggedStates.Contains(a.LifecycleState));
        }

        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            query = query.Where(a =>
                a.AssetNo.Contains(term) ||
                (a.AssetTag != null && a.AssetTag.Contains(term)) ||
                (a.SerialNumber != null && a.SerialNumber.Contains(term)) ||
                (a.Make != null && a.Make.Contains(term)) ||
                (a.Model != null && a.Model.Contains(term)) ||
                (a.EmployeeName != null && a.EmployeeName.Contains(term)));
        }

        query = sort?.ToLowerInvariant() switch
        {
            "assetno:desc" => query.OrderByDescending(a => a.AssetNo),
            "warrantyend:asc" => query.OrderBy(a => a.WarrantyEnd),
            "warrantyend:desc" => query.OrderByDescending(a => a.WarrantyEnd),
            "lastaudit:asc" => query.OrderBy(a => a.LastAuditDate),
            "lastaudit:desc" => query.OrderByDescending(a => a.LastAuditDate),
            "updated:desc" => query.OrderByDescending(a => a.UpdatedAtUtc),
            _ => query.OrderBy(a => a.AssetNo)
        };

        var totalCount = await query.CountAsync();
        var rows = await query
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(a => new { Asset = a, Department = dbContext.Departments.Where(d => d.DepartmentId == a.DepartmentId).Select(d => d.Name).FirstOrDefault() })
            .ToListAsync();

        return Ok(Page(rows.Select(r => ToListItem(r.Asset, r.Department)).ToList(), page, pageSize, totalCount));
    }

    [HttpGet("{assetId}")]
    public async Task<ActionResult<ApiResponse<AssetDto>>> Get(string assetId)
    {
        var asset = await ScopeAssets(dbContext.Assets.AsNoTracking()).FirstOrDefaultAsync(a => a.AssetId == assetId);
        if (asset is null) return NotFoundFailure("ASSET_NOT_FOUND", "requested asset");

        Response.Headers.ETag = $"\"{Convert.ToBase64String(asset.RowVersion)}\"";
        return Ok(Success(await ToAssetDtoAsync(asset)));
    }

    [HttpPost]
    [Authorize(Roles = Roles.FixedAssets + "," + Roles.Administrator)]
    public async Task<ActionResult<ApiResponse<AssetDto>>> Create(CreateAssetRequest request)
    {
        var (asset, problem) = await BuildNewAssetAsync(request);
        if (problem is not null) return problem;

        dbContext.Assets.Add(asset!);
        lifecycle.RecordHistory(asset!.AssetId, "AssetRegistered", $"Asset {asset.AssetNo} registered.", CurrentUserId,
            null, new { asset.AssetNo, asset.AssetTag, asset.SerialNumber, asset.LifecycleState });
        await dbContext.SaveChangesAsync();

        Response.Headers.ETag = $"\"{Convert.ToBase64String(asset.RowVersion)}\"";
        return CreatedAtAction(nameof(Get), new { assetId = asset.AssetId }, Success(await ToAssetDtoAsync(asset)));
    }

    // BR-8.1-02: common details are shared, each unit is its own record with its own tag.
    [HttpPost("bulk")]
    [Authorize(Roles = Roles.FixedAssets + "," + Roles.Administrator)]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<AssetListItemDto>>>> BulkCreate(BulkCreateAssetsRequest request)
    {
        if (!string.IsNullOrWhiteSpace(request.Common.AssetTag) || !string.IsNullOrWhiteSpace(request.Common.SerialNumber))
            return Failure(422, "VALIDATION_ERROR", "Tags and serial numbers belong on each unit, not on the common details.");

        var duplicateTags = request.Units.GroupBy(u => u.AssetTag.Trim(), StringComparer.OrdinalIgnoreCase).Where(g => g.Count() > 1).Select(g => g.Key).ToList();
        if (duplicateTags.Count > 0)
            return Failure(422, "VALIDATION_ERROR", "Each unit needs its own asset tag.", duplicateTags.Select(t => new ErrorDetail("units", $"tag {t} is repeated")).ToArray());

        await using var transaction = await dbContext.Database.BeginTransactionAsync();
        var created = new List<AssetEntity>();
        foreach (var unit in request.Units)
        {
            var (asset, problem) = await BuildNewAssetAsync(request.Common with { AssetNo = unit.AssetNo, AssetTag = unit.AssetTag, SerialNumber = unit.SerialNumber });
            if (problem is not null) return problem;

            dbContext.Assets.Add(asset!);
            lifecycle.RecordHistory(asset!.AssetId, "AssetRegistered", $"Asset {asset.AssetNo} registered in a bulk batch of {request.Units.Count}.", CurrentUserId,
                null, new { asset.AssetNo, asset.AssetTag, asset.SerialNumber, asset.LifecycleState });
            created.Add(asset);
        }

        await dbContext.SaveChangesAsync();
        await transaction.CommitAsync();
        return Created(string.Empty, Success<IReadOnlyList<AssetListItemDto>>(created.Select(a => ToListItem(a, null)).ToList()));
    }

    [HttpPatch("{assetId}")]
    [Authorize(Roles = Roles.FixedAssets + "," + Roles.Administrator)]
    public async Task<IActionResult> Update(string assetId, UpdateAssetRequest request)
    {
        var asset = await dbContext.Assets.FirstOrDefaultAsync(a => a.AssetId == assetId);
        if (asset is null) return NotFoundFailure("ASSET_NOT_FOUND", "requested asset");

        var match = Request.Headers.IfMatch.FirstOrDefault();
        if (match is not null && match.Trim('"') != Convert.ToBase64String(asset.RowVersion))
            return Failure(412, "CONCURRENCY_CONFLICT", "The asset has changed since it was read.");

        if (request.DepartmentId is not null && !await dbContext.Departments.AnyAsync(d => d.DepartmentId == request.DepartmentId))
            return Failure(422, "VALIDATION_ERROR", "The requested department was not found.", new ErrorDetail("departmentId", "must identify an existing department"));

        LocationEntity? location = null;
        if (request.LocationId is not null)
        {
            location = await dbContext.Locations.FirstOrDefaultAsync(l => l.LocationId == request.LocationId);
            if (location is null)
                return Failure(422, "VALIDATION_ERROR", "The requested location was not found.", new ErrorDetail("locationId", "must identify an existing location"));
        }

        if (request.StoreroomId is not null && !await dbContext.Storerooms.AnyAsync(s => s.StoreroomId == request.StoreroomId))
            return Failure(422, "VALIDATION_ERROR", "The requested storeroom was not found.", new ErrorDetail("storeroomId", "must identify an existing storeroom"));

        var oldValue = new
        {
            asset.AssetTag, asset.DepartmentId, asset.LocationId, asset.Desk, asset.StoreroomId, asset.WarrantyStart,
            asset.WarrantyEnd, asset.WarrantyVendor, asset.EncryptionStatus, asset.Category, asset.CompanyEntity, asset.CostCentre, asset.Notes
        };

        if (request.AssetTag is not null) asset.AssetTag = request.AssetTag.Trim();
        if (request.DepartmentId is not null) asset.DepartmentId = request.DepartmentId;
        if (location is not null) AssetLifecycleService.ApplyLocation(asset, location);
        if (request.Desk is not null) asset.Desk = request.Desk;
        if (request.StoreroomId is not null) asset.StoreroomId = request.StoreroomId;
        if (request.WarrantyStart is not null) asset.WarrantyStart = request.WarrantyStart.Value.ToDateTime(TimeOnly.MinValue);
        if (request.WarrantyEnd is not null) asset.WarrantyEnd = request.WarrantyEnd.Value.ToDateTime(TimeOnly.MinValue);
        if (request.WarrantyVendor is not null) asset.WarrantyVendor = request.WarrantyVendor;
        if (request.EncryptionStatus is not null) asset.EncryptionStatus = request.EncryptionStatus;
        if (request.Category is not null) asset.Category = request.Category;
        if (request.CompanyEntity is not null) asset.CompanyEntity = request.CompanyEntity;
        if (request.CostCentre is not null) asset.CostCentre = request.CostCentre;
        if (request.Notes is not null) asset.Notes = request.Notes;
        asset.UpdatedAtUtc = DateTime.UtcNow;

        lifecycle.RecordHistory(assetId, "AssetUpdated", "Asset details updated.", CurrentUserId, oldValue, request);
        await dbContext.SaveChangesAsync();

        Response.Headers.ETag = $"\"{Convert.ToBase64String(asset.RowVersion)}\"";
        return Ok(Success(await ToAssetDtoAsync(asset)));
    }

    [HttpPost("{assetId}/lifecycle")]
    [Authorize(Roles = Roles.FixedAssets + "," + Roles.Administrator)]
    public async Task<ActionResult<ApiResponse<AssetDto>>> ChangeLifecycle(string assetId, ChangeLifecycleRequest request)
    {
        var asset = await dbContext.Assets.FirstOrDefaultAsync(a => a.AssetId == assetId);
        if (asset is null) return NotFoundFailure("ASSET_NOT_FOUND", "requested asset");

        if (!DirectStates.Contains(request.LifecycleState))
            return Failure(422, "USE_WORKFLOW", $"{request.LifecycleState} is set by its own workflow (assignment, onboarding, faults, incidents or disposal).");

        if (asset.EmployeeId is not null && request.LifecycleState is LifecycleState.InStorage or LifecycleState.Retired)
            return Failure(409, "ASSIGNMENT_ALREADY_ACTIVE", "Return the asset from its employee first.");

        if (request.LifecycleState == LifecycleState.InStorage && asset.StoreroomId is null)
            return Failure(422, "VALIDATION_ERROR", "Use the return endpoint to choose a storeroom.", new ErrorDetail("storeroomId", "missing"));

        if (AssetStatusRules.RequiresTag(request.LifecycleState) && string.IsNullOrWhiteSpace(asset.AssetTag))
            return Failure(422, "VALIDATION_ERROR", "The asset must be tagged before it is registered.", new ErrorDetail("assetTag", "missing"));

        lifecycle.ChangeState(asset, request.LifecycleState, CurrentUserId, request.Reason);
        await dbContext.SaveChangesAsync();
        return Ok(Success(await ToAssetDtoAsync(asset)));
    }

    [HttpPost("{assetId}/assignments")]
    [Authorize(Roles = Roles.AssetOperators)]
    public async Task<ActionResult<ApiResponse<AssignmentDto>>> Assign(string assetId, CreateAssignmentRequest request)
    {
        if (request.Condition is null)
            return Failure(422, "VALIDATION_ERROR", "A condition check is required at handover.", new ErrorDetail("condition", "missing"));

        await using var transaction = await dbContext.Database.BeginTransactionAsync();

        var asset = await dbContext.Assets.FirstOrDefaultAsync(a => a.AssetId == assetId);
        if (asset is null) return NotFoundFailure("ASSET_NOT_FOUND", "requested asset");

        if (asset.LifecycleState == nameof(LifecycleState.Reserved))
            return Failure(409, "ASSET_RESERVED", "This asset is reserved for an onboarding case. Issue it from the case.");

        if (!AssignableStates.Contains(asset.LifecycleState))
            return Failure(409, "ASSET_NOT_AVAILABLE", $"An asset in state {asset.LifecycleState} cannot be assigned.");

        if (await dbContext.AssetAssignments.AnyAsync(a => a.AssetId == assetId && a.ReturnedAt == null))
            return Failure(409, "ASSIGNMENT_ALREADY_ACTIVE", "This asset already has an active assignment.");

        var employee = await dbContext.Employees.AsNoTracking().FirstOrDefaultAsync(e => e.EmployeeId == request.EmployeeId && e.IsActive);
        if (employee is null)
            return Failure(422, "VALIDATION_ERROR", "The employee does not exist or is inactive.", new ErrorDetail("employeeId", "must identify an active employee"));

        var location = await dbContext.Locations.AsNoTracking().FirstOrDefaultAsync(l => l.LocationId == request.LocationId);
        if (location is null)
            return Failure(422, "VALIDATION_ERROR", "The requested location was not found.", new ErrorDetail("locationId", "must identify an existing location"));

        var violation = await lifecycle.CheckLaptopReleaseAsync(asset, employee.EmployeeId, request.CustodyAgreementDocumentId, request.ManagerAcknowledged);
        if (violation is not null) return Failure(violation);

        var assignment = lifecycle.Assign(asset, employee, location, request.AssignmentDate, request.CustodyAgreementDocumentId,
            request.Desk, request.Condition, request.Notes, CurrentUserId);

        await dbContext.SaveChangesAsync();
        await transaction.CommitAsync();
        return Created(string.Empty, Success(ToAssignmentDto(assignment)));
    }

    [HttpGet("{assetId}/assignments")]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<AssignmentDto>>>> Assignments(string assetId)
    {
        if (!await ScopeAssets(dbContext.Assets).AnyAsync(a => a.AssetId == assetId))
            return NotFoundFailure("ASSET_NOT_FOUND", "requested asset");

        var assignments = await dbContext.AssetAssignments.AsNoTracking()
            .Where(a => a.AssetId == assetId)
            .OrderByDescending(a => a.AssignedAt)
            .ToListAsync();

        return Ok(Success<IReadOnlyList<AssignmentDto>>(assignments.Select(a => ToAssignmentDto(a)).ToList()));
    }

    [HttpPost("{assetId}/return")]
    [Authorize(Roles = Roles.AssetOperators)]
    public async Task<ActionResult<ApiResponse<AssetDto>>> Return(string assetId, ReturnAssetRequest request)
    {
        var asset = await dbContext.Assets.FirstOrDefaultAsync(a => a.AssetId == assetId);
        if (asset is null) return NotFoundFailure("ASSET_NOT_FOUND", "requested asset");

        if (await dbContext.TakeHomes.AnyAsync(t => t.AssetId == assetId && t.ReturnedAt == null))
            return Failure(409, "TAKE_HOME_RETURN_REQUIRED", "This screen is at home. Record its return with a photo first.");

        var storeroom = await dbContext.Storerooms.AsNoTracking().FirstOrDefaultAsync(s => s.StoreroomId == request.StoreroomId);
        if (storeroom is null)
            return Failure(422, "VALIDATION_ERROR", "The requested storeroom was not found.", new ErrorDetail("storeroomId", "must identify an existing storeroom"));

        await lifecycle.ReturnToStorageAsync(asset, storeroom, request.Condition, CurrentUserId, request.Notes ?? $"Returned to {storeroom.Name}.");
        await dbContext.SaveChangesAsync();
        return Ok(Success(await ToAssetDtoAsync(asset)));
    }

    // BR-8.5-04: hold at the desk instead of returning to the storeroom.
    [HttpPost("{assetId}/hold-for-reassignment")]
    [Authorize(Roles = Roles.AssetOperators)]
    public async Task<ActionResult<ApiResponse<AssetDto>>> Hold(string assetId, HoldForReassignmentRequest request)
    {
        var expiresAt = request.ExpiresAt ?? DateTimeOffset.UtcNow.AddDays(lifecycle.Rules.HoldForReassignmentDays);
        if (expiresAt <= DateTimeOffset.UtcNow)
            return Failure(422, "VALIDATION_ERROR", "Hold expiry must be in the future.", new ErrorDetail("expiresAt", "must be in the future"));

        var asset = await dbContext.Assets.FirstOrDefaultAsync(a => a.AssetId == assetId);
        if (asset is null) return NotFoundFailure("ASSET_NOT_FOUND", "requested asset");

        var oldValue = new { asset.LifecycleState, asset.EmployeeId };
        await lifecycle.CloseActiveAssignmentAsync(asset);
        asset.HoldExpiresAt = expiresAt.UtcDateTime;
        AssetStatusRules.Apply(asset, LifecycleState.HeldForReassignment);
        lifecycle.RecordHistory(assetId, "HeldForReassignment", request.Reason ?? "Held at desk for reassignment.", CurrentUserId,
            oldValue, new { asset.LifecycleState, ExpiresAt = expiresAt });

        await dbContext.SaveChangesAsync();
        return Ok(Success(await ToAssetDtoAsync(asset)));
    }

    [HttpGet("{assetId}/history")]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<HistoryDto>>>> History(string assetId)
    {
        if (!await ScopeAssets(dbContext.Assets).AnyAsync(a => a.AssetId == assetId))
            return NotFoundFailure("ASSET_NOT_FOUND", "requested asset");

        var rows = await dbContext.AssetHistory.AsNoTracking()
            .Where(h => h.AssetId == assetId)
            .OrderByDescending(h => h.ChangedAt)
            .ToListAsync();

        return Ok(Success<IReadOnlyList<HistoryDto>>(rows.Select(ToHistoryDto).ToList()));
    }

    [HttpGet("{assetId}/documents")]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<DocumentReferenceDto>>>> Documents(string assetId)
    {
        if (!await ScopeAssets(dbContext.Assets).AnyAsync(a => a.AssetId == assetId))
            return NotFoundFailure("ASSET_NOT_FOUND", "requested asset");

        var documents = await dbContext.AssetDocuments.AsNoTracking()
            .Where(d => d.AssetId == assetId)
            .OrderByDescending(d => d.UploadedAt)
            .ToListAsync();

        return Ok(Success<IReadOnlyList<DocumentReferenceDto>>(documents.Select(DocumentsController.ToDto).ToList()));
    }

    private async Task<(AssetEntity? Asset, ObjectResult? Problem)> BuildNewAssetAsync(CreateAssetRequest request)
    {
        if (request.LifecycleState is null)
            return (null, Failure(422, "ASSET_STATUS_INVALID", "A lifecycle state is required.", new ErrorDetail("lifecycleState", "missing")));

        var state = request.LifecycleState.Value;
        if (!RegistrationStates.Contains(state))
            return (null, Failure(422, "ASSET_STATUS_INVALID", "New assets start as Ordered, Received, Registered or InStorage.", new ErrorDetail("lifecycleState", "not a registration state")));

        var errors = ValidateRegistration(request, state);
        if (errors.Count > 0)
            return (null, Failure(422, "VALIDATION_ERROR", "Mandatory asset details are missing.", errors.ToArray()));

        var assetNo = string.IsNullOrWhiteSpace(request.AssetNo) ? await lifecycle.NextAssetNumberAsync() : request.AssetNo.Trim();
        if (await dbContext.Assets.AnyAsync(a => a.AssetNo == assetNo))
            return (null, Failure(409, "ASSET_NUMBER_EXISTS", $"An asset with number {assetNo} already exists."));

        if (!string.IsNullOrWhiteSpace(request.AssetTag) && await dbContext.Assets.AnyAsync(a => a.AssetTag == request.AssetTag.Trim()))
            return (null, Failure(409, "ASSET_TAG_EXISTS", $"Tag {request.AssetTag} is already registered."));

        if (request.DepartmentId is not null && !await dbContext.Departments.AnyAsync(d => d.DepartmentId == request.DepartmentId))
            return (null, Failure(422, "VALIDATION_ERROR", "The requested department was not found.", new ErrorDetail("departmentId", "must identify an existing department")));

        StoreroomEntity? storeroom = null;
        if (request.StoreroomId is not null)
        {
            storeroom = await dbContext.Storerooms.AsNoTracking().FirstOrDefaultAsync(s => s.StoreroomId == request.StoreroomId);
            if (storeroom is null)
                return (null, Failure(422, "VALIDATION_ERROR", "The requested storeroom was not found.", new ErrorDetail("storeroomId", "must identify an existing storeroom")));
        }

        var locationId = request.LocationId ?? storeroom?.LocationId;
        var location = locationId is null ? null : await dbContext.Locations.AsNoTracking().FirstOrDefaultAsync(l => l.LocationId == locationId);
        if (locationId is not null && location is null)
            return (null, Failure(422, "VALIDATION_ERROR", "The requested location was not found.", new ErrorDetail("locationId", "must identify an existing location")));

        var now = DateTime.UtcNow;
        var asset = new AssetEntity
        {
            AssetNo = assetNo,
            AssetTag = request.AssetTag?.Trim(),
            SerialNumber = request.SerialNumber?.Trim(),
            AssetType = request.AssetType.ToString(),
            Category = request.Category,
            Make = request.Make,
            Model = request.Model,
            CompanyEntity = request.CompanyEntity,
            CostCentre = request.CostCentre,
            DepartmentId = request.DepartmentId,
            StoreroomId = request.StoreroomId,
            Desk = request.Desk,
            LocationSubStatus = nameof(LocationSubStatus.InOffice),
            PurchaseCost = request.PurchaseCost,
            PurchaseOrder = request.PurchaseOrder,
            InvoiceReference = request.InvoiceReference,
            AcquisitionDate = request.AcquisitionDate?.ToDateTime(TimeOnly.MinValue),
            WarrantyStart = request.WarrantyStart?.ToDateTime(TimeOnly.MinValue),
            WarrantyEnd = request.WarrantyEnd?.ToDateTime(TimeOnly.MinValue),
            WarrantyVendor = request.WarrantyVendor,
            EncryptionStatus = request.EncryptionStatus,
            Condition = (request.Condition ?? ConditionStatus.New).ToString(),
            Notes = request.Notes,
            CreatedAtUtc = now,
            UpdatedAtUtc = now
        };
        if (location is not null) AssetLifecycleService.ApplyLocation(asset, location);
        AssetStatusRules.Apply(asset, state);

        if (storeroom is not null)
            dbContext.StockMovements.Add(new StockMovementEntity { StoreroomId = storeroom.StoreroomId, AssetId = asset.AssetId, Direction = "In", Reason = "Registered" });

        return (asset, null);
    }

    // BR-7-01, BR-7-02, BR-8.1-01 and BR-8.3-01.
    private static List<ErrorDetail> ValidateRegistration(CreateAssetRequest r, LifecycleState state)
    {
        var errors = new List<ErrorDetail>();
        void Require(string? value, string field)
        {
            if (string.IsNullOrWhiteSpace(value)) errors.Add(new(field, "required"));
        }

        if (r.PurchaseCost < 0) errors.Add(new("purchaseCost", "must be zero or greater"));
        if (r.WarrantyStart > r.WarrantyEnd) errors.Add(new("warrantyEnd", "must be on or after the warranty start"));

        if (!AssetStatusRules.RequiresTag(state)) return errors;

        Require(r.AssetTag, "assetTag");
        Require(r.SerialNumber, "serialNumber");
        Require(r.Category, "category");
        Require(r.Make, "make");
        Require(r.Model, "model");
        Require(r.CompanyEntity, "companyEntity");
        Require(r.CostCentre, "costCentre");
        Require(r.PurchaseOrder, "purchaseOrder");
        Require(r.InvoiceReference, "invoiceReference");
        Require(r.StoreroomId, "storeroomId");
        if (r.AcquisitionDate is null) errors.Add(new("acquisitionDate", "required"));
        if (r.WarrantyStart is null) errors.Add(new("warrantyStart", "required"));
        if (r.WarrantyEnd is null) errors.Add(new("warrantyEnd", "required"));

        if (r.AssetType == AssetType.Laptop) Require(r.EncryptionStatus, "encryptionStatus");
        return errors;
    }

    private async Task<AssetDto> ToAssetDtoAsync(AssetEntity asset)
    {
        var activeAssignment = await dbContext.AssetAssignments.AsNoTracking()
            .Where(a => a.AssetId == asset.AssetId && a.ReturnedAt == null)
            .OrderByDescending(a => a.AssignedAt)
            .FirstOrDefaultAsync();

        string? managerName = null;
        if (activeAssignment is not null)
        {
            managerName = await dbContext.Employees.AsNoTracking()
                .Where(e => e.EmployeeId == activeAssignment.EmployeeId)
                .Join(dbContext.Employees, e => e.ManagerEmployeeId, m => m.EmployeeId, (_, m) => m.FullName)
                .FirstOrDefaultAsync();
        }

        var department = asset.DepartmentId is null
            ? null
            : await dbContext.Departments.AsNoTracking().Where(d => d.DepartmentId == asset.DepartmentId).Select(d => d.Name).FirstOrDefaultAsync();

        var location = asset.LocationId is null && asset.StoreroomId is null
            ? null
            : new LocationDto(asset.LocationId ?? string.Empty, asset.Region ?? string.Empty, asset.Building ?? string.Empty,
                asset.Floor, asset.DepartmentId, asset.Desk, asset.StoreroomId, Enums.ParseOrNull<LocationSubStatus>(asset.LocationSubStatus));

        var assetType = Enums.Parse<AssetType>(asset.AssetType);
        var laptopControls = assetType == AssetType.Laptop
            ? new LaptopControlsDto(asset.EncryptionStatus ?? "Unknown", asset.CustodyAgreementSigned,
                AssetStatusRules.LaptopHealth(asset, DateTime.UtcNow, lifecycle.Rules.LaptopAgeingYears))
            : null;

        return new AssetDto(
            AssetId: asset.AssetId,
            AssetNo: asset.AssetNo,
            AssetTag: asset.AssetTag,
            SerialNumber: asset.SerialNumber,
            AssetType: assetType,
            Category: asset.Category,
            Make: asset.Make,
            Model: asset.Model,
            CompanyEntity: asset.CompanyEntity,
            CostCentre: asset.CostCentre,
            Department: department,
            Location: location,
            Assignment: activeAssignment is null ? null : ToAssignmentDto(activeAssignment, managerName),
            Status: new AssetStatusDto(Enums.Parse<LifecycleState>(asset.LifecycleState), Enums.Parse<OperationalStatus>(asset.OperationalStatus)),
            Financial: new FinancialDto(asset.PurchaseCost, asset.PurchaseOrder, asset.InvoiceReference),
            Lifecycle: new LifecycleDto(ToDateOnly(asset.AcquisitionDate), ToDateOnly(asset.WarrantyStart), ToDateOnly(asset.WarrantyEnd), asset.WarrantyVendor),
            AuditData: new AuditDataDto(ToDateOnly(asset.LastAuditDate), Enums.ParseOrNull<AuditOutcome>(asset.AuditOutcome)),
            LaptopControls: laptopControls,
            Notes: asset.Notes,
            CreatedAt: AsUtc(asset.CreatedAtUtc),
            UpdatedAt: AsUtc(asset.UpdatedAtUtc),
            Version: asset.RowVersion.Length >= 4 ? unchecked((int)BitConverter.ToUInt32(asset.RowVersion, asset.RowVersion.Length - 4)) : 0,
            Condition: Enums.ParseOrNull<ConditionStatus>(asset.Condition),
            HoldExpiresAt: asset.HoldExpiresAt is null ? null : AsUtc(asset.HoldExpiresAt.Value));
    }

    internal static AssetListItemDto ToListItem(AssetEntity asset, string? department) => new(
        asset.AssetId,
        asset.AssetNo,
        asset.AssetTag,
        asset.SerialNumber,
        Enums.Parse<AssetType>(asset.AssetType),
        asset.Make,
        asset.Model,
        Enums.Parse<LifecycleState>(asset.LifecycleState),
        Enums.Parse<OperationalStatus>(asset.OperationalStatus),
        asset.EmployeeId,
        asset.EmployeeName,
        LocationSummary(asset),
        ToDateOnly(asset.WarrantyEnd),
        ToDateOnly(asset.LastAuditDate),
        Enums.ParseOrNull<LocationSubStatus>(asset.LocationSubStatus),
        Enums.ParseOrNull<AuditOutcome>(asset.AuditOutcome),
        department);

    internal static string? LocationSummary(AssetEntity asset)
    {
        if (asset.LocationSubStatus == nameof(LocationSubStatus.AtHome)) return "At home";
        var parts = new[] { asset.Region, asset.Building, asset.Floor is null ? null : $"Fl {asset.Floor}", asset.Desk, asset.StoreroomId }
            .Where(p => !string.IsNullOrWhiteSpace(p))
            .ToList();
        return parts.Count == 0 ? null : string.Join(" · ", parts);
    }

    private static AssignmentDto ToAssignmentDto(AssetAssignmentEntity a, string? managerName = null) => new(
        a.AssignmentId.ToString(),
        a.AssetId,
        a.EmployeeId,
        a.EmployeeName,
        a.LocationId ?? string.Empty,
        DateOnly.FromDateTime(a.AssignedAt),
        a.CustodyAgreementReference,
        a.Notes,
        a.ReturnedAt is null ? null : AsUtc(a.ReturnedAt.Value),
        managerName);

    private static HistoryDto ToHistoryDto(AssetHistoryEntity h)
    {
        object? oldValue = null, newValue = null;
        if (!string.IsNullOrWhiteSpace(h.DetailsJson))
        {
            using var document = JsonDocument.Parse(h.DetailsJson);
            var root = document.RootElement;
            if (root.ValueKind == JsonValueKind.Object && (root.TryGetProperty("OldValue", out _) || root.TryGetProperty("NewValue", out _)))
            {
                if (root.TryGetProperty("OldValue", out var o)) oldValue = o.Clone();
                if (root.TryGetProperty("NewValue", out var n)) newValue = n.Clone();
            }
            else
            {
                newValue = root.Clone();
            }
        }

        return new HistoryDto(h.HistoryId.ToString(), h.AssetId, h.Action, oldValue, newValue, h.ChangedBy ?? string.Empty, AsUtc(h.ChangedAt), h.Summary);
    }

    private static DateOnly? ToDateOnly(DateTime? value) => value is null ? null : DateOnly.FromDateTime(value.Value);
}
