using CtrlFind.Contracts;
using CtrlFind.Infrastructure.Persistence;
using CtrlFind.Infrastructure.Persistence.Entities;
using CtrlFind.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CtrlFind.Controllers;

// Section 8.2: monitors issued for home use. No approval step is defined in the BRD (OQ-01, DEC-021).
[Route("api/v1/take-home")]
public sealed class TakeHomeController(ApplicationDbContext dbContext, AssetLifecycleService lifecycle) : ApiControllerBase
{
    [HttpGet]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<TakeHomeDto>>>> List([FromQuery] bool openOnly = false)
    {
        var assets = ScopeAssets(dbContext.Assets.AsNoTracking());
        var query = dbContext.TakeHomes.AsNoTracking().Where(t => assets.Any(a => a.AssetId == t.AssetId));
        if (openOnly) query = query.Where(t => t.ReturnedAt == null || (t.DamageReviewRequired && t.DamageReviewOutcome == null));

        var rows = await query.OrderByDescending(t => t.IssuedAt).Take(200).ToListAsync();
        return Ok(Success(await ToDtosAsync(rows)));
    }

    // BR-8.2-01 and BR-8.2-02: photo, condition rating and acknowledgement before the screen leaves.
    [HttpPost("issue")]
    [Authorize(Roles = Roles.AssetOperators)]
    public async Task<ActionResult<ApiResponse<TakeHomeDto>>> Issue(TakeHomeIssueRequest request)
    {
        if (!request.EmployeeAcknowledged)
            return Failure(422, "VALIDATION_ERROR", "The employee must acknowledge the hand-over.", new ErrorDetail("employeeAcknowledged", "required"));

        await using var transaction = await dbContext.Database.BeginTransactionAsync();

        var asset = await dbContext.Assets.FirstOrDefaultAsync(a => a.AssetId == request.AssetId);
        if (asset is null) return NotFoundFailure("ASSET_NOT_FOUND", "requested asset");
        if (asset.AssetType != nameof(AssetType.Monitor))
            return Failure(422, "SCREEN_ONLY", "Home-use tracking applies only to monitors and screens.");
        if (await dbContext.TakeHomes.AnyAsync(t => t.AssetId == asset.AssetId && t.ReturnedAt == null))
            return Failure(409, "ALREADY_AT_HOME", "This screen is already issued for home use.");
        if (asset.EmployeeId is not null && asset.EmployeeId != request.EmployeeId)
            return Failure(409, "ASSIGNMENT_ALREADY_ACTIVE", "This screen is assigned to another employee.");

        var photo = await PhotoProblemAsync(asset.AssetId, request.IssuePhotoDocumentId, "issuePhotoDocumentId");
        if (photo is not null) return photo;

        var employee = await dbContext.Employees.AsNoTracking().FirstOrDefaultAsync(e => e.EmployeeId == request.EmployeeId && e.IsActive);
        if (employee is null)
            return Failure(422, "VALIDATION_ERROR", "The employee does not exist or is inactive.", new ErrorDetail("employeeId", "must identify an active employee"));

        if (asset.EmployeeId is null)
        {
            var location = await dbContext.Locations.AsNoTracking().FirstOrDefaultAsync(l => l.LocationId == (employee.LocationId ?? asset.LocationId));
            if (location is null) return Failure(422, "VALIDATION_ERROR", "The employee has no office location on record.");
            lifecycle.Assign(asset, employee, location, DateOnly.FromDateTime(DateTime.UtcNow), null, null, request.IssueCondition, "Issued for home use", CurrentUserId);
        }

        var takeHome = new TakeHomeEntity
        {
            AssetId = asset.AssetId,
            EmployeeId = employee.EmployeeId,
            IssueCondition = request.IssueCondition.ToString(),
            IssuePhotoDocumentId = request.IssuePhotoDocumentId,
            AcknowledgedAt = DateTime.UtcNow,
            Notes = request.Notes
        };
        dbContext.TakeHomes.Add(takeHome);

        asset.Condition = request.IssueCondition.ToString();
        asset.LocationSubStatus = nameof(LocationSubStatus.AtHome);
        lifecycle.ChangeState(asset, LifecycleState.AtHome, CurrentUserId, $"Issued for home use to {employee.FullName} in {request.IssueCondition} condition.");

        await dbContext.SaveChangesAsync();
        await transaction.CommitAsync();
        return Created(string.Empty, Success((await ToDtosAsync([takeHome]))[0]));
    }

    // BR-8.2-03 and BR-8.2-04: new photo, reassessment and comparison on return.
    [HttpPost("{takeHomeId}/return")]
    [Authorize(Roles = Roles.AssetOperators)]
    public async Task<ActionResult<ApiResponse<TakeHomeDto>>> Return(string takeHomeId, TakeHomeReturnRequest request)
    {
        var id = ParseId(takeHomeId);
        var takeHome = id is null ? null : await dbContext.TakeHomes.FirstOrDefaultAsync(t => t.TakeHomeId == id);
        if (takeHome is null) return NotFoundFailure("TAKE_HOME_NOT_FOUND", "take-home record");
        if (takeHome.ReturnedAt is not null) return Failure(409, "ALREADY_RETURNED", "This screen has already been returned.");

        var photo = await PhotoProblemAsync(takeHome.AssetId, request.ReturnPhotoDocumentId, "returnPhotoDocumentId");
        if (photo is not null) return photo;
        if (request.ReturnPhotoDocumentId == takeHome.IssuePhotoDocumentId)
            return Failure(422, "VALIDATION_ERROR", "A new photo is required on return.", new ErrorDetail("returnPhotoDocumentId", "same as issue photo"));

        var asset = await dbContext.Assets.FirstAsync(a => a.AssetId == takeHome.AssetId);
        var issued = Enums.Parse<ConditionStatus>(takeHome.IssueCondition);
        var deteriorated = AssetStatusRules.IsDeterioration(issued, request.ReturnCondition);

        takeHome.ReturnedAt = DateTime.UtcNow;
        takeHome.ReturnCondition = request.ReturnCondition.ToString();
        takeHome.ReturnPhotoDocumentId = request.ReturnPhotoDocumentId;
        takeHome.DamageReviewRequired = deteriorated;
        takeHome.Notes = request.Notes ?? takeHome.Notes;

        asset.Condition = request.ReturnCondition.ToString();
        asset.LocationSubStatus = nameof(LocationSubStatus.InOffice);
        var summary = deteriorated
            ? $"Returned from home: issued as {issued}, returned as {request.ReturnCondition}. Damage review required."
            : $"Returned from home in {request.ReturnCondition} condition.";
        lifecycle.ChangeState(asset, asset.EmployeeId is null ? LifecycleState.InStorage : LifecycleState.Assigned, CurrentUserId, summary);

        if (deteriorated)
            lifecycle.Notify(Roles.FixedAssets, "DamageReview", "Damage review required", $"{asset.AssetNo}: issued as {issued}, returned as {request.ReturnCondition}.", asset.AssetId);

        await dbContext.SaveChangesAsync();
        return Ok(Success((await ToDtosAsync([takeHome]))[0]));
    }

    [HttpPost("{takeHomeId}/damage-review")]
    [Authorize(Roles = Roles.FixedAssets + "," + Roles.Administrator)]
    public async Task<ActionResult<ApiResponse<TakeHomeDto>>> ResolveDamageReview(string takeHomeId, ResolveDamageReviewRequest request)
    {
        var id = ParseId(takeHomeId);
        var takeHome = id is null ? null : await dbContext.TakeHomes.FirstOrDefaultAsync(t => t.TakeHomeId == id);
        if (takeHome is null) return NotFoundFailure("TAKE_HOME_NOT_FOUND", "take-home record");
        if (!takeHome.DamageReviewRequired || takeHome.DamageReviewOutcome is not null)
            return Failure(409, "NO_DAMAGE_REVIEW", "There is no open damage review for this screen.");

        takeHome.DamageReviewOutcome = request.Outcome;
        lifecycle.RecordHistory(takeHome.AssetId, "DamageReviewed", $"Damage review: {request.Outcome}", CurrentUserId);
        await dbContext.SaveChangesAsync();
        return Ok(Success((await ToDtosAsync([takeHome]))[0]));
    }

    private async Task<ObjectResult?> PhotoProblemAsync(string assetId, string documentId, string field)
    {
        var exists = await dbContext.AssetDocuments.AnyAsync(d => d.DocumentId == documentId && d.AssetId == assetId && d.DocumentType == nameof(DocumentType.Photo));
        return exists ? null : Failure(422, "PHOTO_REQUIRED", "Upload a photo of the screen against this asset first.", new ErrorDetail(field, "must be a photo of this asset"));
    }

    private async Task<IReadOnlyList<TakeHomeDto>> ToDtosAsync(IReadOnlyList<TakeHomeEntity> rows)
    {
        var assetIds = rows.Select(r => r.AssetId).Distinct().ToList();
        var employeeIds = rows.Select(r => r.EmployeeId).Distinct().ToList();
        var assets = await dbContext.Assets.AsNoTracking().Where(a => assetIds.Contains(a.AssetId)).ToDictionaryAsync(a => a.AssetId);
        var names = await dbContext.Employees.AsNoTracking().Where(e => employeeIds.Contains(e.EmployeeId)).ToDictionaryAsync(e => e.EmployeeId, e => e.FullName);

        return rows.Select(t =>
        {
            var asset = assets[t.AssetId];
            var status = t.ReturnedAt is null ? "AtHome"
                : t.DamageReviewRequired && t.DamageReviewOutcome is null ? "DamageReview"
                : "Returned";
            return new TakeHomeDto(t.TakeHomeId.ToString(), t.AssetId, asset.AssetNo, AssetStatusRules.Describe(asset), t.EmployeeId, names.GetValueOrDefault(t.EmployeeId),
                AsUtc(t.IssuedAt), Enums.Parse<ConditionStatus>(t.IssueCondition), t.IssuePhotoDocumentId, AsUtc(t.AcknowledgedAt),
                t.ReturnedAt is null ? null : AsUtc(t.ReturnedAt.Value), Enums.ParseOrNull<ConditionStatus>(t.ReturnCondition), t.ReturnPhotoDocumentId,
                t.DamageReviewRequired, t.DamageReviewOutcome, status);
        }).ToList();
    }
}

// Section 8.6: same-day or weekend replacement, logged without prior approval.
[Route("api/v1/emergency-swaps")]
public sealed class EmergencySwapsController(ApplicationDbContext dbContext, AssetLifecycleService lifecycle) : ApiControllerBase
{
    [HttpGet]
    [Authorize(Roles = Roles.AssetOperators + "," + Roles.HelpDesk)]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<EmergencySwapDto>>>> List([FromQuery] bool openOnly = false)
    {
        var query = dbContext.EmergencySwaps.AsNoTracking();
        if (openOnly) query = query.Where(s => s.Status == nameof(CaseStatus.Open));
        var swaps = await query.OrderByDescending(s => s.ReportedAt).Take(200).ToListAsync();
        return Ok(Success(await ToDtosAsync(swaps)));
    }

    [HttpPost]
    [Authorize(Roles = Roles.AssetOperators + "," + Roles.HelpDesk)]
    public async Task<ActionResult<ApiResponse<EmergencySwapDto>>> Create(CreateEmergencySwapRequest request)
    {
        await using var transaction = await dbContext.Database.BeginTransactionAsync();

        var employee = await dbContext.Employees.AsNoTracking().FirstOrDefaultAsync(e => e.EmployeeId == request.EmployeeId && e.IsActive);
        if (employee is null)
            return Failure(422, "VALIDATION_ERROR", "The employee does not exist or is inactive.", new ErrorDetail("employeeId", "must identify an active employee"));

        var temporary = await dbContext.Assets.FirstOrDefaultAsync(a => a.AssetId == request.TemporaryAssetId);
        if (temporary is null) return NotFoundFailure("ASSET_NOT_FOUND", "temporary asset");
        if (temporary.LifecycleState != nameof(LifecycleState.InStorage))
            return Failure(409, "ASSET_NOT_AVAILABLE", "The temporary asset must come from available stock.");

        var original = request.OriginalAssetId is null ? null : await dbContext.Assets.AsNoTracking().FirstOrDefaultAsync(a => a.AssetId == request.OriginalAssetId);
        if (request.OriginalAssetId is not null && original is null) return NotFoundFailure("ASSET_NOT_FOUND", "original asset");

        // BR-8.3-02 still applies to laptops; a digital agreement can be signed on the spot.
        var violation = await lifecycle.CheckLaptopReleaseAsync(temporary, employee.EmployeeId, request.CustodyAgreementDocumentId, managerAcknowledged: false);
        if (violation is not null) return Failure(violation);

        var locationId = original?.LocationId ?? employee.LocationId ?? temporary.LocationId;
        var location = await dbContext.Locations.AsNoTracking().FirstOrDefaultAsync(l => l.LocationId == locationId);
        if (location is null) return Failure(422, "VALIDATION_ERROR", "No office location is on record for this employee.");

        lifecycle.Assign(temporary, employee, location, DateOnly.FromDateTime(request.ReportedAt.UtcDateTime), request.CustodyAgreementDocumentId,
            original?.Desk, Enums.ParseOrNull<ConditionStatus>(temporary.Condition), "Emergency swap", CurrentUserId);

        var swap = new EmergencySwapEntity
        {
            EmployeeId = employee.EmployeeId,
            OriginalAssetId = original?.AssetId,
            TemporaryAssetId = temporary.AssetId,
            IssueDescription = request.IssueDescription,
            ReportedAt = request.ReportedAt.UtcDateTime,
            ResolveBy = request.ReportedAt.UtcDateTime.AddDays(lifecycle.Rules.EmergencySwapResolutionDays),
            Status = nameof(CaseStatus.Open),
            CreatedBy = CurrentUserId
        };
        dbContext.EmergencySwaps.Add(swap);
        lifecycle.RecordHistory(temporary.AssetId, "EmergencySwap", $"Issued as an emergency swap to {employee.FullName}.", CurrentUserId,
            null, new { OriginalAssetId = original?.AssetId, request.IssueDescription });
        lifecycle.Notify(Roles.FixedAssets, "EmergencySwap", "Emergency swap logged",
            $"{temporary.AssetNo} issued to {employee.FullName}. Formal resolution due by {swap.ResolveBy:dd MMM yyyy}.", temporary.AssetId);

        await dbContext.SaveChangesAsync();
        await transaction.CommitAsync();
        return Created(string.Empty, Success((await ToDtosAsync([swap]))[0]));
    }

    // BR-8.6-02: resolution is recorded, including for escalated cases.
    [HttpPost("{swapId}/resolve")]
    [Authorize(Roles = Roles.FixedAssets + "," + Roles.Administrator)]
    public async Task<ActionResult<ApiResponse<EmergencySwapDto>>> Resolve(string swapId, ResolveEmergencySwapRequest request)
    {
        var id = ParseId(swapId);
        var swap = id is null ? null : await dbContext.EmergencySwaps.FirstOrDefaultAsync(s => s.SwapId == id);
        if (swap is null) return NotFoundFailure("EMERGENCY_SWAP_NOT_FOUND", "emergency swap");
        if (swap.Status != nameof(CaseStatus.Open)) return Failure(409, "CASE_CLOSED", "This swap is already resolved.");

        swap.Status = nameof(CaseStatus.Completed);
        swap.Resolution = request.Resolution;
        swap.ResolvedAt = DateTime.UtcNow;
        lifecycle.RecordHistory(swap.TemporaryAssetId, "EmergencySwapResolved", request.Resolution, CurrentUserId);
        await dbContext.SaveChangesAsync();
        return Ok(Success((await ToDtosAsync([swap]))[0]));
    }

    private async Task<IReadOnlyList<EmergencySwapDto>> ToDtosAsync(IReadOnlyList<EmergencySwapEntity> swaps)
    {
        var employeeIds = swaps.Select(s => s.EmployeeId).Distinct().ToList();
        var assetIds = swaps.Select(s => s.TemporaryAssetId).Distinct().ToList();
        var names = await dbContext.Employees.AsNoTracking().Where(e => employeeIds.Contains(e.EmployeeId)).ToDictionaryAsync(e => e.EmployeeId, e => e.FullName);
        var numbers = await dbContext.Assets.AsNoTracking().Where(a => assetIds.Contains(a.AssetId)).ToDictionaryAsync(a => a.AssetId, a => a.AssetNo);
        var now = DateTime.UtcNow;

        return swaps.Select(s => new EmergencySwapDto(s.SwapId.ToString(), s.EmployeeId, names.GetValueOrDefault(s.EmployeeId), s.OriginalAssetId,
            s.TemporaryAssetId, numbers.GetValueOrDefault(s.TemporaryAssetId), s.IssueDescription, AsUtc(s.ReportedAt), AsUtc(s.ResolveBy),
            Enums.Parse<CaseStatus>(s.Status), s.Status == nameof(CaseStatus.Open) && now > s.ResolveBy, s.Resolution,
            s.ResolvedAt is null ? null : AsUtc(s.ResolvedAt.Value), FixedAssetsNotified: true)).ToList();
    }
}

// Final disposition so retired assets do not stay in storage without a record (BRD 2.2 step 8).
[Route("api/v1/disposals")]
[Authorize(Roles = Roles.FixedAssets + "," + Roles.Finance + "," + Roles.Administrator)]
public sealed class DisposalsController(ApplicationDbContext dbContext, AssetLifecycleService lifecycle) : ApiControllerBase
{
    [HttpGet]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<DisposalDto>>>> List()
    {
        var rows = await dbContext.Disposals.AsNoTracking().OrderByDescending(d => d.DisposedOn).Take(200)
            .Join(dbContext.Assets, d => d.AssetId, a => a.AssetId, (d, a) => new { Disposal = d, Asset = a })
            .ToListAsync();
        return Ok(Success<IReadOnlyList<DisposalDto>>(rows.Select(r => new DisposalDto(r.Disposal.DisposalId.ToString(), r.Asset.AssetId, r.Asset.AssetNo,
            AssetStatusRules.Describe(r.Asset), r.Disposal.Reason, r.Disposal.Method, r.Disposal.DataWipeConfirmed,
            DateOnly.FromDateTime(r.Disposal.DisposedOn), r.Disposal.RecordedBy)).ToList()));
    }

    [HttpGet("pending")]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<PendingDispositionDto>>>> Pending()
    {
        var assets = await dbContext.Assets.AsNoTracking()
            .Where(a => a.LifecycleState == nameof(LifecycleState.Retired) && !dbContext.Disposals.Any(d => d.AssetId == a.AssetId))
            .OrderBy(a => a.UpdatedAtUtc)
            .ToListAsync();
        return Ok(Success<IReadOnlyList<PendingDispositionDto>>(assets.Select(a =>
            new PendingDispositionDto(a.AssetId, a.AssetNo, AssetStatusRules.Describe(a), a.Notes ?? "Retired", AsUtc(a.UpdatedAtUtc))).ToList()));
    }

    [HttpPost]
    [Authorize(Roles = Roles.FixedAssets + "," + Roles.Administrator)]
    public async Task<ActionResult<ApiResponse<DisposalDto>>> Create(CreateDisposalRequest request)
    {
        var asset = await dbContext.Assets.FirstOrDefaultAsync(a => a.AssetId == request.AssetId);
        if (asset is null) return NotFoundFailure("ASSET_NOT_FOUND", "requested asset");
        if (asset.LifecycleState != nameof(LifecycleState.Retired))
            return Failure(409, "RETIRE_FIRST", "Only retired assets can be disposed.");

        if (AssetStatusRules.NeedsDataWipe(Enums.Parse<AssetType>(asset.AssetType)) && !request.DataWipeConfirmed)
            return Failure(422, "DATA_WIPE_REQUIRED", "Confirm the data wipe before disposing of a device that stores data.", new ErrorDetail("dataWipeConfirmed", "required"));

        if (request.CertificateDocumentId is not null && !await dbContext.AssetDocuments.AnyAsync(d => d.DocumentId == request.CertificateDocumentId && d.AssetId == asset.AssetId))
            return Failure(422, "VALIDATION_ERROR", "The certificate must be uploaded against this asset.", new ErrorDetail("certificateDocumentId", "not found"));

        var disposal = new DisposalEntity
        {
            AssetId = asset.AssetId,
            Reason = request.Reason,
            Method = request.Method,
            DataWipeConfirmed = request.DataWipeConfirmed,
            CertificateDocumentId = request.CertificateDocumentId,
            DisposedOn = ToUtcDate(request.DisposedOn),
            Notes = request.Notes,
            RecordedBy = CurrentUserId
        };
        dbContext.Disposals.Add(disposal);
        lifecycle.LeaveStoreroom(asset, "Disposed");
        lifecycle.ChangeState(asset, LifecycleState.Disposed, CurrentUserId, $"Disposed: {request.Method}. {request.Reason}");

        await dbContext.SaveChangesAsync();
        return Created(string.Empty, Success(new DisposalDto(disposal.DisposalId.ToString(), asset.AssetId, asset.AssetNo, AssetStatusRules.Describe(asset),
            disposal.Reason, disposal.Method, disposal.DataWipeConfirmed, request.DisposedOn, disposal.RecordedBy)));
    }
}
