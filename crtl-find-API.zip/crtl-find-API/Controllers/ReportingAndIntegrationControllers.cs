using System.Globalization;
using System.Text;
using CtrlFind.Contracts;
using CtrlFind.Infrastructure.Persistence;
using CtrlFind.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CtrlFind.Controllers;

[Route("api/v1/reports")]
[Authorize(Roles = Roles.Management)]
public sealed class ReportsController(ApplicationDbContext dbContext, DashboardService dashboards) : ApiControllerBase
{
    [HttpGet("operational-dashboard")]
    public async Task<ActionResult<ApiResponse<OperationalDashboardDto>>> Operational() =>
        Ok(Success(await dashboards.OperationalAsync(ScopeAssets(dbContext.Assets.AsNoTracking()))));

    [HttpGet("management-dashboard")]
    public async Task<ActionResult<ApiResponse<ManagementDashboardDto>>> Management() =>
        Ok(Success(await dashboards.ManagementAsync(ScopeAssets(dbContext.Assets.AsNoTracking()))));
}

// Power BI-ready output (BR-8.14-04): flat CSV datasets that Power BI reads directly.
[Route("api/v1/exports")]
[Authorize(Roles = Roles.Finance + "," + Roles.FixedAssets + "," + Roles.Administrator)]
public sealed class ExportsController(ApplicationDbContext dbContext) : ApiControllerBase
{
    private static readonly string[] Datasets = ["assets", "assignments", "incidents", "audits", "maintenance"];

    [HttpPost("powerbi")]
    public ActionResult<ApiResponse<object>> PowerBi() =>
        Ok(Success<object>(new { datasets = Datasets.Select(d => new { name = d, url = $"/api/v1/exports/powerbi/{d}.csv" }), generatedAt = DateTimeOffset.UtcNow }));

    [HttpGet("powerbi/{dataset}.csv")]
    public async Task<IActionResult> Dataset(string dataset)
    {
        IEnumerable<IReadOnlyList<object?>> rows;
        string[] header;
        switch (dataset.ToLowerInvariant())
        {
            case "assets":
                header = ["AssetId", "AssetNo", "AssetTag", "SerialNumber", "AssetType", "Make", "Model", "LifecycleState", "OperationalStatus", "LocationSubStatus",
                    "EmployeeId", "DepartmentId", "Region", "Building", "Floor", "PurchaseCost", "AcquisitionDate", "WarrantyEnd", "LastAuditDate", "AuditOutcome"];
                rows = (await dbContext.Assets.AsNoTracking().OrderBy(a => a.AssetNo).ToListAsync()).Select(a => (IReadOnlyList<object?>)
                    [a.AssetId, a.AssetNo, a.AssetTag, a.SerialNumber, a.AssetType, a.Make, a.Model, a.LifecycleState, a.OperationalStatus, a.LocationSubStatus,
                     a.EmployeeId, a.DepartmentId, a.Region, a.Building, a.Floor, a.PurchaseCost, a.AcquisitionDate, a.WarrantyEnd, a.LastAuditDate, a.AuditOutcome]);
                break;
            case "assignments":
                header = ["AssignmentId", "AssetId", "EmployeeId", "EmployeeName", "LocationId", "AssignedAt", "ReturnedAt"];
                rows = (await dbContext.AssetAssignments.AsNoTracking().ToListAsync()).Select(a => (IReadOnlyList<object?>)
                    [a.AssignmentId, a.AssetId, a.EmployeeId, a.EmployeeName, a.LocationId, a.AssignedAt, a.ReturnedAt]);
                break;
            case "incidents":
                header = ["IncidentId", "AssetId", "IncidentType", "EmployeeId", "IncidentDate", "NegligenceStatus", "Status", "EscalatedToHr"];
                rows = (await dbContext.Incidents.AsNoTracking().ToListAsync()).Select(i => (IReadOnlyList<object?>)
                    [i.IncidentId, i.AssetId, i.IncidentType, i.ReportedByEmployeeId, i.IncidentDate, i.NegligenceStatus, i.Status, i.EscalatedToHr]);
                break;
            case "audits":
                header = ["AuditId", "AuditItemId", "AssetId", "Method", "Outcome", "CheckedAt", "RequiresInvestigation", "ResolvedAt"];
                rows = (await dbContext.AuditItems.AsNoTracking().ToListAsync()).Select(i => (IReadOnlyList<object?>)
                    [i.AuditId, i.AuditItemId, i.AssetId, i.Method, i.Outcome, i.CheckedAt, i.RequiresInvestigation, i.ResolvedAt]);
                break;
            case "maintenance":
                header = ["CaseId", "AssetId", "Classification", "ZendeskTicketId", "ReportedAt", "RepairabilityDecision", "Outcome", "Status", "ClosedAt"];
                rows = (await dbContext.MaintenanceCases.AsNoTracking().ToListAsync()).Select(c => (IReadOnlyList<object?>)
                    [c.CaseId, c.AssetId, c.Classification, c.ZendeskTicketId, c.ReportedAt, c.RepairabilityDecision, c.Outcome, c.Status, c.ClosedAt]);
                break;
            default:
                return NotFoundFailure("DATASET_NOT_FOUND", "dataset");
        }

        var csv = new StringBuilder().AppendLine(string.Join(',', header));
        foreach (var row in rows) csv.AppendLine(string.Join(',', row.Select(Csv)));
        return File(Encoding.UTF8.GetBytes(csv.ToString()), "text/csv", $"{dataset}.csv");
    }

    private static string Csv(object? value)
    {
        var text = value switch
        {
            null => string.Empty,
            DateTime d => d.ToString("yyyy-MM-dd'T'HH:mm:ss", CultureInfo.InvariantCulture),
            decimal m => m.ToString(CultureInfo.InvariantCulture),
            _ => Convert.ToString(value, CultureInfo.InvariantCulture) ?? string.Empty
        };
        return text.IndexOfAny([',', '"', '\n', '\r']) >= 0 ? $"\"{text.Replace("\"", "\"\"")}\"" : text;
    }
}

// Integration boundaries (DEC-022). Pastel cost is applied; the other systems are received and recorded
// until their interface specifications are confirmed.
[Route("api/v1/integrations")]
[Authorize(Roles = Roles.Administrator)]
public sealed class IntegrationsController(ApplicationDbContext dbContext, AssetLifecycleService lifecycle) : ApiControllerBase
{
    [HttpPost("oracle/sync")]
    public ActionResult<ApiResponse<object>> Oracle(IntegrationRequest request) => Accepted(Receipt("Oracle", request, "Recorded. Use the onboarding and offboarding endpoints with Source = Oracle."));

    // Purchase cost is read from Pastel and never entered by hand (BR-7-01, Section 8.16).
    // Data: { "invoiceReference": "INV-123", "purchaseCost": 18500.00 }
    [HttpPost("pastel/sync")]
    public async Task<ActionResult<ApiResponse<object>>> Pastel(IntegrationRequest request)
    {
        var invoice = request.Data.GetValueOrDefault("invoiceReference")?.ToString();
        if (string.IsNullOrWhiteSpace(invoice) || !decimal.TryParse(request.Data.GetValueOrDefault("purchaseCost")?.ToString(), NumberStyles.Number, CultureInfo.InvariantCulture, out var cost) || cost < 0)
            return Failure(422, "VALIDATION_ERROR", "Send invoiceReference and a non-negative purchaseCost.");

        var assets = await dbContext.Assets.Where(a => a.InvoiceReference == invoice).ToListAsync();
        foreach (var asset in assets)
        {
            lifecycle.RecordHistory(asset.AssetId, "PastelCostUpdated", $"Purchase cost R {cost:N2} read from Pastel.", CurrentUserId,
                new { asset.PurchaseCost }, new { PurchaseCost = cost });
            asset.PurchaseCost = cost;
            asset.UpdatedAtUtc = DateTime.UtcNow;
        }

        await dbContext.SaveChangesAsync();
        return Ok(Receipt("Pastel", request, $"{assets.Count} asset(s) updated."));
    }

    [HttpPost("zendesk/events")]
    public ActionResult<ApiResponse<object>> Zendesk(IntegrationRequest request) => Accepted(Receipt("Zendesk", request, "Recorded."));

    // Not sent until OQ-04 confirms Atom is outbound (DEC-015).
    [HttpPost("atom/outbox")]
    public ActionResult<ApiResponse<object>> Atom(IntegrationRequest request) => Accepted(Receipt("Atom", request, "Atom outbound sync is not configured."));

    private ApiResponse<object> Receipt(string system, IntegrationRequest request, string status) => Success<object>(new
    {
        receiptId = Guid.NewGuid().ToString("N"), system, status, request.SourceReference, receivedAt = DateTimeOffset.UtcNow
    });
}
