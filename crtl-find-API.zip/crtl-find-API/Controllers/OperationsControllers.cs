using CtrlFind.Contracts;
using CtrlFind.Infrastructure.Persistence;
using CtrlFind.Infrastructure.Persistence.Entities;
using CtrlFind.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CtrlFind.Controllers;

[Route("api/v1/incidents")]
public sealed class IncidentsController(ApplicationDbContext dbContext, AssetLifecycleService lifecycle) : ApiControllerBase
{
    [HttpGet]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<IncidentDto>>>> List([FromQuery] bool openOnly = false, [FromQuery] string? employeeId = null)
    {
        var query = Scoped();
        if (openOnly) query = query.Where(i => i.Status != nameof(CaseStatus.Completed));
        if (!string.IsNullOrWhiteSpace(employeeId)) query = query.Where(i => i.ReportedByEmployeeId == employeeId);

        var incidents = await query.OrderByDescending(i => i.IncidentDate).Take(200).ToListAsync();
        return Ok(Success(await ToDtosAsync(incidents)));
    }

    [HttpGet("{incidentId}")]
    public async Task<ActionResult<ApiResponse<IncidentDto>>> Get(string incidentId)
    {
        var id = ParseId(incidentId);
        var incident = id is null ? null : await Scoped().FirstOrDefaultAsync(i => i.IncidentId == id);
        return incident is null ? NotFoundFailure("INCIDENT_NOT_FOUND", "incident") : Ok(Success((await ToDtosAsync([incident]))[0]));
    }

    // BR-8.10-01 (police case number optional, DEC-010), BR-8.3-05 and BR-8.10-04.
    [HttpPost]
    public async Task<ActionResult<ApiResponse<IncidentDto>>> Create(CreateIncidentRequest request)
    {
        await using var transaction = await dbContext.Database.BeginTransactionAsync();

        var asset = await ScopeAssets(dbContext.Assets).FirstOrDefaultAsync(a => a.AssetId == request.AssetId);
        if (asset is null) return NotFoundFailure("ASSET_NOT_FOUND", "requested asset");

        if (await dbContext.Incidents.AnyAsync(i => i.AssetId == request.AssetId && i.Status != nameof(CaseStatus.Completed)))
            return Failure(409, "INCIDENT_OPEN", "This asset already has an open loss or theft case.");

        var incident = new IncidentEntity
        {
            AssetId = asset.AssetId,
            IncidentType = request.IncidentType.ToString(),
            ReportedByEmployeeId = request.ReportedByEmployeeId,
            IncidentDate = ToUtcDate(request.IncidentDate),
            LocationDescription = request.LocationDescription,
            Statement = request.Description,
            PoliceCaseNumber = string.IsNullOrWhiteSpace(request.PoliceCaseNumber) ? null : request.PoliceCaseNumber.Trim(),
            NegligenceStatus = nameof(NegligenceStatus.UnderInvestigation),
            Status = nameof(CaseStatus.Open)
        };
        dbContext.Incidents.Add(incident);

        lifecycle.ChangeState(asset, request.IncidentType == IncidentType.Theft ? LifecycleState.Stolen : LifecycleState.Lost, CurrentUserId,
            $"{request.IncidentType} reported on {request.IncidentDate:dd MMM yyyy} at {request.LocationDescription}.");
        lifecycle.Notify(Roles.FixedAssets, "LossReported", $"{request.IncidentType} reported", $"{asset.AssetNo} ({AssetStatusRules.Describe(asset)}) reported {request.IncidentType.ToString().ToLowerInvariant()}.", asset.AssetId);

        var previous = await dbContext.Incidents.CountAsync(i => i.ReportedByEmployeeId == request.ReportedByEmployeeId);
        if (previous + 1 >= lifecycle.Rules.RepeatIncidentThreshold)
        {
            incident.EscalatedToHr = true;
            var message = $"{request.ReportedByEmployeeId} has {previous + 1} recorded loss or theft incidents. Escalated for review.";
            lifecycle.Notify(Roles.Hr, "RepeatIncidents", "Repeat incidents", message, asset.AssetId);
            lifecycle.Notify(Roles.Manager, "RepeatIncidents", "Repeat incidents", message, asset.AssetId);
        }

        await dbContext.SaveChangesAsync();
        await transaction.CommitAsync();
        return Created(string.Empty, Success((await ToDtosAsync([incident]))[0]));
    }

    // BR-8.10-02 and BR-8.10-03: marking a case Negligent creates the AOD (DEC-009).
    [HttpPost("{incidentId}/negligence-decision")]
    [Authorize(Roles = Roles.Hr + "," + Roles.FixedAssets + "," + Roles.Administrator)]
    public async Task<ActionResult<ApiResponse<IncidentDto>>> Decide(string incidentId, NegligenceDecisionRequest request)
    {
        var id = ParseId(incidentId);
        var incident = id is null ? null : await dbContext.Incidents.FirstOrDefaultAsync(i => i.IncidentId == id);
        if (incident is null) return NotFoundFailure("INCIDENT_NOT_FOUND", "incident");

        var asset = await dbContext.Assets.AsNoTracking().FirstAsync(a => a.AssetId == incident.AssetId);
        var aod = await dbContext.AodRecords.FirstOrDefaultAsync(a => a.IncidentId == incident.IncidentId);

        if (request.NegligenceStatus == NegligenceStatus.Negligent && aod is null)
        {
            var amount = request.AodAmount ?? asset.PurchaseCost;
            if (amount is null or <= 0)
                return Failure(422, "AOD_AMOUNT_REQUIRED", "No purchase cost is recorded for this asset. Enter the AOD amount.", new ErrorDetail("aodAmount", "required"));

            dbContext.AodRecords.Add(new AodRecordEntity
            {
                IncidentId = incident.IncidentId,
                EmployeeId = incident.ReportedByEmployeeId,
                AssetId = incident.AssetId,
                Amount = amount.Value,
                RecoveryTerms = string.IsNullOrWhiteSpace(request.RecoveryTerms) ? "To be agreed with HR." : request.RecoveryTerms,
                Status = "Open"
            });
            lifecycle.Notify(Roles.Hr, "AodGenerated", "AOD generated", $"AOD of R {amount:N2} for {asset.AssetNo} linked to {incident.ReportedByEmployeeId}.", asset.AssetId);
            lifecycle.Notify(AssetLifecycleService.EmployeeAudience(incident.ReportedByEmployeeId), "AodGenerated", "Acknowledgement of Debt",
                $"An Acknowledgement of Debt of R {amount:N2} was raised for {asset.AssetNo}.", asset.AssetId);
        }
        else if (request.NegligenceStatus != NegligenceStatus.Negligent && aod is not null && aod.RecoveredAmount == 0)
        {
            aod.Status = "Cancelled";
        }

        incident.NegligenceStatus = request.NegligenceStatus.ToString();
        incident.DecisionReason = request.DecisionReason;
        incident.DecidedBy = CurrentUserId;
        incident.Status = request.NegligenceStatus == NegligenceStatus.UnderInvestigation ? nameof(CaseStatus.InProgress) : nameof(CaseStatus.Completed);
        lifecycle.RecordHistory(incident.AssetId, "NegligenceDecided", $"Negligence: {request.NegligenceStatus}. {request.DecisionReason}", CurrentUserId);

        await dbContext.SaveChangesAsync();
        return Ok(Success((await ToDtosAsync([incident]))[0]));
    }

    private IQueryable<IncidentEntity> Scoped()
    {
        var assets = ScopeAssets(dbContext.Assets);
        var me = CurrentEmployeeId;
        return dbContext.Incidents.AsNoTracking().Where(i => i.ReportedByEmployeeId == me || assets.Any(a => a.AssetId == i.AssetId));
    }

    private async Task<IReadOnlyList<IncidentDto>> ToDtosAsync(IReadOnlyList<IncidentEntity> incidents)
    {
        var assetIds = incidents.Select(i => i.AssetId).Distinct().ToList();
        var employeeIds = incidents.Select(i => i.ReportedByEmployeeId).Distinct().ToList();
        var incidentIds = incidents.Select(i => i.IncidentId).ToList();

        var assets = await dbContext.Assets.AsNoTracking().Where(a => assetIds.Contains(a.AssetId)).ToDictionaryAsync(a => a.AssetId);
        var names = await dbContext.Employees.AsNoTracking().Where(e => employeeIds.Contains(e.EmployeeId)).ToDictionaryAsync(e => e.EmployeeId, e => e.FullName);
        var counts = await dbContext.Incidents.AsNoTracking().Where(i => employeeIds.Contains(i.ReportedByEmployeeId))
            .GroupBy(i => i.ReportedByEmployeeId).Select(g => new { g.Key, Count = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.Count);
        var aods = await dbContext.AodRecords.AsNoTracking().Where(a => incidentIds.Contains(a.IncidentId) && a.Status != "Cancelled")
            .ToDictionaryAsync(a => a.IncidentId, a => a.AodId.ToString());

        return incidents.Select(i =>
        {
            var asset = assets[i.AssetId];
            var type = Enums.Parse<IncidentType>(i.IncidentType);
            var request = new CreateIncidentRequest(i.AssetId, type, i.ReportedByEmployeeId, DateOnly.FromDateTime(i.IncidentDate),
                i.LocationDescription, i.Statement, i.PoliceCaseNumber, null);
            var cost = asset.AssetType == nameof(AssetType.Laptop) ? asset.PurchaseCost : null;
            return new IncidentDto(i.IncidentId.ToString(), i.AssetId, type, Enums.Parse<CaseStatus>(i.Status), Enums.Parse<NegligenceStatus>(i.NegligenceStatus),
                i.PoliceCaseNumber, aods.GetValueOrDefault(i.IncidentId), AsUtc(i.CreatedAt), request,
                asset.AssetNo, AssetStatusRules.Describe(asset), names.GetValueOrDefault(i.ReportedByEmployeeId), cost,
                i.EscalatedToHr, counts.GetValueOrDefault(i.ReportedByEmployeeId));
        }).ToList();
    }
}

[Route("api/v1/aod-records")]
[Authorize(Roles = Roles.Hr + "," + Roles.Finance + "," + Roles.FixedAssets + "," + Roles.Administrator)]
public sealed class AodController(ApplicationDbContext dbContext, AssetLifecycleService lifecycle) : ApiControllerBase
{
    [HttpGet]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<AodDto>>>> List([FromQuery] bool openOnly = false)
    {
        var query = dbContext.AodRecords.AsNoTracking().Where(a => a.Status != "Cancelled");
        if (openOnly) query = query.Where(a => a.Status != "Recovered");
        var records = await query.OrderByDescending(a => a.CreatedAt).Take(200).ToListAsync();
        return Ok(Success<IReadOnlyList<AodDto>>(records.Select(ToDto).ToList()));
    }

    [HttpGet("{aodId}")]
    public async Task<ActionResult<ApiResponse<AodDto>>> Get(string aodId)
    {
        var id = ParseId(aodId);
        var record = id is null ? null : await dbContext.AodRecords.AsNoTracking().FirstOrDefaultAsync(a => a.AodId == id);
        return record is null ? NotFoundFailure("AOD_NOT_FOUND", "AOD record") : Ok(Success(ToDto(record)));
    }

    // BR-8.10-03: recovery is tracked against the AOD.
    [HttpPost("{aodId}/payments")]
    [Authorize(Roles = Roles.Hr + "," + Roles.Finance + "," + Roles.Administrator)]
    public async Task<ActionResult<ApiResponse<AodDto>>> RecordPayment(string aodId, RecordAodPaymentRequest request)
    {
        var id = ParseId(aodId);
        var record = id is null ? null : await dbContext.AodRecords.FirstOrDefaultAsync(a => a.AodId == id);
        if (record is null) return NotFoundFailure("AOD_NOT_FOUND", "AOD record");
        if (record.Status is "Cancelled" or "Recovered") return Failure(409, "AOD_CLOSED", $"This AOD is {record.Status}.");
        if (record.RecoveredAmount + request.Amount > record.Amount)
            return Failure(422, "VALIDATION_ERROR", $"The payment exceeds the outstanding balance of R {record.Amount - record.RecoveredAmount:N2}.");

        dbContext.AodPayments.Add(new AodPaymentEntity { AodId = record.AodId, Amount = request.Amount, PaidOn = ToUtcDate(request.PaidOn), Reference = request.Reference, RecordedBy = CurrentUserId });
        record.RecoveredAmount += request.Amount;
        record.Status = record.RecoveredAmount >= record.Amount ? "Recovered" : "InRecovery";
        lifecycle.RecordHistory(record.AssetId, "AodPayment", $"AOD payment of R {request.Amount:N2} recorded.", CurrentUserId);

        await dbContext.SaveChangesAsync();
        return Ok(Success(ToDto(record)));
    }

    private static AodDto ToDto(AodRecordEntity a) =>
        new(a.AodId.ToString(), a.IncidentId.ToString(), a.Amount, a.RecoveryTerms, a.RecoveredAmount, a.Status, a.EmployeeId, a.AssetId);
}

// BR-8.12-01 to BR-8.12-04. Closing rules: DEC-013.
[Route("api/v1/audits")]
public sealed class AuditsController(ApplicationDbContext dbContext, AssetLifecycleService lifecycle) : ApiControllerBase
{
    private const string Auditors = Roles.Manager + "," + Roles.AssetOperators;

    private static readonly string[] Auditable =
        [nameof(LifecycleState.Registered), nameof(LifecycleState.InStorage), nameof(LifecycleState.Reserved), nameof(LifecycleState.Assigned),
         nameof(LifecycleState.AtHome), nameof(LifecycleState.OffSite), nameof(LifecycleState.HeldForReassignment), nameof(LifecycleState.UnderAudit),
         nameof(LifecycleState.UnderInvestigation)];

    [HttpGet]
    [Authorize(Roles = Auditors)]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<AuditDto>>>> List()
    {
        var audits = await dbContext.Audits.AsNoTracking().OrderByDescending(a => a.CreatedAt).Take(50).ToListAsync();
        var result = new List<AuditDto>();
        foreach (var audit in audits) result.Add(await ToDtoAsync(audit));
        return Ok(Success<IReadOnlyList<AuditDto>>(result));
    }

    [HttpGet("{auditId}")]
    [Authorize(Roles = Auditors)]
    public async Task<ActionResult<ApiResponse<AuditDto>>> Get(string auditId)
    {
        var audit = await FindAsync(auditId);
        return audit is null ? NotFoundFailure("AUDIT_NOT_FOUND", "audit") : Ok(Success(await ToDtoAsync(audit)));
    }

    [HttpPost]
    [Authorize(Roles = Auditors)]
    public async Task<ActionResult<ApiResponse<AuditDto>>> Create(CreateAuditRequest request)
    {
        if (request.ScheduledEndDate < request.ScheduledStartDate)
            return Failure(422, "VALIDATION_ERROR", "Scheduled end date must not precede the start date.");
        if ((request.LocationIds?.Length ?? 0) == 0 && (request.DepartmentIds?.Length ?? 0) == 0)
            return Failure(422, "VALIDATION_ERROR", "An audit is initiated by location or business unit.", new ErrorDetail("locationIds", "choose at least one location or department"));

        var audit = new AuditEntity
        {
            AuditName = request.AuditName,
            LocationIds = Join(request.LocationIds),
            DepartmentIds = Join(request.DepartmentIds),
            AssetTypes = Join(request.AssetTypes?.Select(t => t.ToString())),
            ScheduledStartDate = ToUtcDate(request.ScheduledStartDate),
            ScheduledEndDate = ToUtcDate(request.ScheduledEndDate),
            FullScope = request.FullScope,
            Notes = request.Notes,
            CreatedBy = CurrentUserId
        };
        dbContext.Audits.Add(audit);
        await dbContext.SaveChangesAsync();

        foreach (var (asset, reason) in await SelectScopeAsync(request))
        {
            var remote = asset.LocationSubStatus == nameof(LocationSubStatus.AtHome) || asset.LifecycleState is nameof(LifecycleState.OffSite) or nameof(LifecycleState.AtHome);
            dbContext.AuditItems.Add(new AuditItemEntity
            {
                AuditId = audit.AuditId,
                AssetId = asset.AssetId,
                Method = remote ? nameof(AuditMethod.SelfConfirmation) : nameof(AuditMethod.PhysicalScan),
                ReasonFlagged = reason
            });
        }

        await dbContext.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { auditId = audit.AuditId }, Success(await ToDtoAsync(audit)));
    }

    // BR-8.12-03: the scanned tag is compared with the visible serial number.
    [HttpPost("{auditId}/scan")]
    [Authorize(Roles = Auditors)]
    public async Task<ActionResult<ApiResponse<AuditScanResponseDto>>> Scan(string auditId, AuditScanRequest request)
    {
        var audit = await FindAsync(auditId);
        if (audit is null) return NotFoundFailure("AUDIT_NOT_FOUND", "audit");
        if (audit.Status == nameof(AuditStatus.Closed)) return Failure(409, "AUDIT_CLOSED", "This audit is closed.");

        var asset = await dbContext.Assets.FirstOrDefaultAsync(a => a.AssetTag == request.AssetTag.Trim());
        var item = asset is null ? null : await dbContext.AuditItems.FirstOrDefaultAsync(i => i.AuditId == audit.AuditId && i.AssetId == asset.AssetId);
        if (item is null)
        {
            item = new AuditItemEntity { AuditId = audit.AuditId, AssetId = asset?.AssetId, Method = nameof(AuditMethod.PhysicalScan), ReasonFlagged = "Found during scan" };
            dbContext.AuditItems.Add(item);
        }

        var serialMismatch = asset is not null && !string.Equals(asset.SerialNumber, request.SerialNumber.Trim(), StringComparison.OrdinalIgnoreCase);
        var locationMismatch = asset is not null && asset.LocationId != request.ScannedLocationId;
        var outcome = asset is null ? AuditOutcome.NotFound
            : serialMismatch ? AuditOutcome.SerialMismatch
            : locationMismatch ? AuditOutcome.LocationMismatch
            : request.ConditionStatus == ConditionStatus.Damaged ? AuditOutcome.ConditionMismatch
            : AuditOutcome.Confirmed;

        item.Outcome = outcome.ToString();
        item.ScannedTag = request.AssetTag;
        item.ScannedSerial = request.SerialNumber;
        item.ScannedLocationId = request.ScannedLocationId;
        item.Condition = request.ConditionStatus.ToString();
        item.RequiresInvestigation = serialMismatch;
        item.CheckedBy = CurrentUserId;
        item.CheckedAt = request.ScannedAt.UtcDateTime;

        if (asset is not null)
        {
            asset.LastAuditDate = request.ScannedAt.UtcDateTime;
            asset.AuditOutcome = outcome.ToString();
            asset.Condition = request.ConditionStatus.ToString();
            lifecycle.RecordHistory(asset.AssetId, "AuditScan", $"Audit '{audit.AuditName}': {outcome}.", CurrentUserId, null,
                new { request.AssetTag, request.SerialNumber, request.ScannedLocationId, Outcome = outcome.ToString() });
            if (serialMismatch)
                lifecycle.Notify(Roles.FixedAssets, "TamperAlert", "Tamper alert", $"Tag {request.AssetTag} was scanned on serial {request.SerialNumber}; {asset.AssetNo} is registered as {asset.SerialNumber}.", asset.AssetId);
        }

        audit.Status = serialMismatch ? nameof(AuditStatus.UnderReview) : audit.Status == nameof(AuditStatus.UnderReview) ? audit.Status : nameof(AuditStatus.InProgress);
        await dbContext.SaveChangesAsync();
        return Ok(Success(ToItemDto(item, asset?.AssetNo)));
    }

    // Remote (At Home / Off-Site) assets are sent a self-confirmation request.
    [HttpPost("{auditId}/self-confirmations")]
    [Authorize(Roles = Auditors)]
    public async Task<ActionResult<ApiResponse<AuditDto>>> SendSelfConfirmations(string auditId)
    {
        var audit = await FindAsync(auditId);
        if (audit is null) return NotFoundFailure("AUDIT_NOT_FOUND", "audit");

        var items = await dbContext.AuditItems
            .Where(i => i.AuditId == audit.AuditId && i.Method == nameof(AuditMethod.SelfConfirmation) && i.Outcome == null)
            .Join(dbContext.Assets, i => i.AssetId, a => a.AssetId, (i, a) => new { Item = i, a.AssetNo, a.EmployeeId, a.AssetId })
            .ToListAsync();

        foreach (var row in items)
        {
            row.Item.Outcome = nameof(AuditOutcome.AwaitingConfirmation);
            if (row.EmployeeId is not null)
                lifecycle.Notify(AssetLifecycleService.EmployeeAudience(row.EmployeeId), "SelfConfirmation", "Please confirm your asset",
                    $"Confirm you still have {row.AssetNo} by entering its serial number.", row.AssetId);
        }

        audit.SelfConfirmationsSent = true;
        audit.Status = nameof(AuditStatus.InProgress);
        await dbContext.SaveChangesAsync();
        return Accepted(Success(await ToDtoAsync(audit)));
    }

    // The signed-in employee's assets that are waiting for remote confirmation.
    [HttpGet("~/api/v1/self-confirmations")]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<AuditScanResponseDto>>>> MyConfirmations()
    {
        var me = CurrentEmployeeId;
        var rows = await dbContext.AuditItems.AsNoTracking()
            .Where(i => i.Outcome == nameof(AuditOutcome.AwaitingConfirmation))
            .Join(dbContext.Assets.Where(a => a.EmployeeId == me), i => i.AssetId, a => a.AssetId, (i, a) => new { Item = i, a.AssetNo })
            .ToListAsync();
        return Ok(Success<IReadOnlyList<AuditScanResponseDto>>(rows.Select(r => ToItemDto(r.Item, r.AssetNo)).ToList()));
    }

    [HttpPost("{auditId}/items/{itemId}/confirm")]
    [Authorize(Roles = Roles.Employee + "," + Roles.Manager + "," + Roles.AssetOperators)]
    public async Task<ActionResult<ApiResponse<AuditScanResponseDto>>> Confirm(string auditId, string itemId, SelfConfirmationRequest request)
    {
        var (item, asset) = await FindItemAsync(auditId, itemId);
        if (item is null || asset is null) return NotFoundFailure("AUDIT_ITEM_NOT_FOUND", "audit item");
        if (asset.EmployeeId != CurrentEmployeeId && !HasAnyRole(Roles.FixedAssets, Roles.Administrator))
            return Failure(403, "FORBIDDEN", "Only the asset holder can confirm this asset.");
        if (item.Outcome != nameof(AuditOutcome.AwaitingConfirmation))
            return Failure(409, "NOT_AWAITING_CONFIRMATION", "This asset is not waiting for confirmation.");

        var mismatch = !string.Equals(asset.SerialNumber, request.SerialNumber.Trim(), StringComparison.OrdinalIgnoreCase);
        item.Outcome = (mismatch ? AuditOutcome.SerialMismatch : AuditOutcome.Confirmed).ToString();
        item.ScannedSerial = request.SerialNumber;
        item.Condition = request.ConditionStatus.ToString();
        item.RequiresInvestigation = mismatch;
        item.CheckedBy = CurrentUserId;
        item.CheckedAt = DateTime.UtcNow;

        asset.LastAuditDate = DateTime.UtcNow;
        asset.AuditOutcome = item.Outcome;
        asset.Condition = item.Condition;
        lifecycle.RecordHistory(asset.AssetId, "SelfConfirmation", $"Remote confirmation: {item.Outcome}.", CurrentUserId);
        if (mismatch)
            lifecycle.Notify(Roles.FixedAssets, "TamperAlert", "Tamper alert", $"{asset.AssetNo} was confirmed with serial {request.SerialNumber}, registered as {asset.SerialNumber}.", asset.AssetId);

        await dbContext.SaveChangesAsync();
        return Ok(Success(ToItemDto(item, asset.AssetNo)));
    }

    // BR-8.12-04: discrepancies are resolved with a permanent record.
    [HttpPost("{auditId}/items/{itemId}/resolve")]
    [Authorize(Roles = Roles.FixedAssets + "," + Roles.Administrator)]
    public async Task<ActionResult<ApiResponse<AuditScanResponseDto>>> Resolve(string auditId, string itemId, ResolveAuditItemRequest request)
    {
        var (item, asset) = await FindItemAsync(auditId, itemId);
        if (item is null) return NotFoundFailure("AUDIT_ITEM_NOT_FOUND", "audit item");
        if (item.ResolvedAt is not null) return Failure(409, "ALREADY_RESOLVED", "This discrepancy is already resolved.");
        if (item.Outcome is null || item.Outcome == nameof(AuditOutcome.Confirmed))
            return Failure(409, "NOTHING_TO_RESOLVE", "This item has no discrepancy.");

        item.Resolution = request.Resolution;
        item.ResolvedBy = CurrentUserId;
        item.ResolvedAt = DateTime.UtcNow;
        if (asset is not null)
        {
            asset.AuditOutcome = nameof(AuditOutcome.Confirmed);
            lifecycle.RecordHistory(asset.AssetId, "AuditDiscrepancyResolved", $"{item.Outcome} resolved: {request.Resolution}", CurrentUserId);
        }

        await dbContext.SaveChangesAsync();
        return Ok(Success(ToItemDto(item, asset?.AssetNo)));
    }

    [HttpPost("{auditId}/close")]
    [Authorize(Roles = Auditors)]
    public async Task<ActionResult<ApiResponse<AuditDto>>> Close(string auditId)
    {
        var audit = await FindAsync(auditId);
        if (audit is null) return NotFoundFailure("AUDIT_NOT_FOUND", "audit");
        if (audit.Status == nameof(AuditStatus.Closed)) return Failure(409, "AUDIT_CLOSED", "This audit is already closed.");

        if (await dbContext.AuditItems.AnyAsync(i => i.AuditId == audit.AuditId && i.RequiresInvestigation && i.ResolvedAt == null))
            return Failure(409, "TAMPER_INVESTIGATION_OPEN", "Audit closure is blocked by an open tamper investigation.");

        // Anything not checked by the end of the audit is flagged (missing or unconfirmed).
        var pending = await dbContext.AuditItems
            .Where(i => i.AuditId == audit.AuditId && (i.Outcome == null || i.Outcome == nameof(AuditOutcome.AwaitingConfirmation)))
            .ToListAsync();
        var pendingAssetIds = pending.Where(i => i.AssetId != null).Select(i => i.AssetId!).ToList();
        var assets = await dbContext.Assets.Where(a => pendingAssetIds.Contains(a.AssetId)).ToDictionaryAsync(a => a.AssetId);
        foreach (var item in pending)
        {
            item.Outcome = (item.Method == nameof(AuditMethod.SelfConfirmation) ? AuditOutcome.Unconfirmed : AuditOutcome.NotFound).ToString();
            if (item.AssetId is not null && assets.TryGetValue(item.AssetId, out var asset))
            {
                asset.AuditOutcome = item.Outcome;
                lifecycle.RecordHistory(asset.AssetId, "AuditFlagged", $"Audit '{audit.AuditName}' closed: {item.Outcome}.", CurrentUserId);
            }
        }

        audit.Status = nameof(AuditStatus.Closed);
        audit.ClosedAt = DateTime.UtcNow;
        await dbContext.SaveChangesAsync();
        return Ok(Success(await ToDtoAsync(audit)));
    }

    // Exception-based scope by default: unconfirmed or flagged assets only (BR-8.12-01).
    private async Task<List<(AssetEntity Asset, string? Reason)>> SelectScopeAsync(CreateAuditRequest request)
    {
        var query = dbContext.Assets.AsNoTracking().Where(a => Auditable.Contains(a.LifecycleState));
        if (request.LocationIds is { Length: > 0 }) query = query.Where(a => a.LocationId != null && request.LocationIds.Contains(a.LocationId));
        if (request.DepartmentIds is { Length: > 0 }) query = query.Where(a => a.DepartmentId != null && request.DepartmentIds.Contains(a.DepartmentId));
        if (request.AssetTypes is { Length: > 0 })
        {
            var types = request.AssetTypes.Select(t => t.ToString()).ToArray();
            query = query.Where(a => types.Contains(a.AssetType));
        }

        var assets = await query.ToListAsync();
        var confirmedSince = DateTime.UtcNow.AddDays(-lifecycle.Rules.AuditConfirmationDays);
        return assets
            .Select(a => (Asset: a, Reason: ReasonFlagged(a, confirmedSince)))
            .Where(x => request.FullScope || x.Reason is not null)
            .ToList();
    }

    private static string? ReasonFlagged(AssetEntity asset, DateTime confirmedSince)
    {
        if (asset.LifecycleState == nameof(LifecycleState.UnderInvestigation)) return "Under investigation";
        if (asset.AuditOutcome is not null && asset.AuditOutcome != nameof(AuditOutcome.Confirmed)) return $"Previous outcome: {asset.AuditOutcome}";
        if (asset.LastAuditDate is null) return "Never confirmed";
        if (asset.LastAuditDate < confirmedSince) return $"Last confirmed {asset.LastAuditDate:dd MMM yyyy}";
        return null;
    }

    private async Task<AuditEntity?> FindAsync(string auditId)
    {
        var id = ParseId(auditId);
        return id is null ? null : await dbContext.Audits.FirstOrDefaultAsync(a => a.AuditId == id);
    }

    private async Task<(AuditItemEntity?, AssetEntity?)> FindItemAsync(string auditId, string itemId)
    {
        var audit = ParseId(auditId);
        var item = ParseId(itemId);
        if (audit is null || item is null) return (null, null);

        var entity = await dbContext.AuditItems.FirstOrDefaultAsync(i => i.AuditId == audit && i.AuditItemId == item);
        if (entity?.AssetId is null) return (entity, null);
        return (entity, await dbContext.Assets.FirstOrDefaultAsync(a => a.AssetId == entity.AssetId));
    }

    private async Task<AuditDto> ToDtoAsync(AuditEntity audit)
    {
        var rows = await dbContext.AuditItems.AsNoTracking()
            .Where(i => i.AuditId == audit.AuditId)
            .GroupJoin(dbContext.Assets, i => i.AssetId, a => a.AssetId, (i, a) => new { i, a })
            .SelectMany(x => x.a.DefaultIfEmpty(), (x, a) => new { Item = x.i, AssetNo = a != null ? a.AssetNo : null })
            .ToListAsync();

        var request = new CreateAuditRequest(audit.AuditName, Split(audit.LocationIds), Split(audit.DepartmentIds),
            Split(audit.AssetTypes)?.Select(Enums.Parse<AssetType>).ToArray(),
            DateOnly.FromDateTime(audit.ScheduledStartDate), DateOnly.FromDateTime(audit.ScheduledEndDate), audit.Notes, audit.FullScope);

        var items = rows.Select(r => ToItemDto(r.Item, r.AssetNo)).ToList();
        return new AuditDto(audit.AuditId.ToString(), Enums.Parse<AuditStatus>(audit.Status), request, items, audit.SelfConfirmationsSent,
            items.Count(i => i.RequiresInvestigation && !i.Resolved),
            items.Count(i => i.Outcome is not null and not AuditOutcome.Confirmed and not AuditOutcome.AwaitingConfirmation && !i.Resolved));
    }

    private static AuditScanResponseDto ToItemDto(AuditItemEntity i, string? assetNo)
    {
        var outcome = Enums.ParseOrNull<AuditOutcome>(i.Outcome);
        var message = outcome switch
        {
            null => "Not checked yet",
            AuditOutcome.Confirmed => "Asset confirmed",
            AuditOutcome.SerialMismatch => "Tamper alert: serial does not match the tag. Investigation opened.",
            AuditOutcome.AwaitingConfirmation => "Waiting for the employee to confirm",
            _ => $"Discrepancy recorded: {outcome}"
        };
        return new AuditScanResponseDto(i.AuditItemId.ToString(), i.AssetId, outcome, outcome == AuditOutcome.SerialMismatch,
            outcome == AuditOutcome.LocationMismatch, i.RequiresInvestigation, message, assetNo, Enums.Parse<AuditMethod>(i.Method),
            i.ReasonFlagged, i.ResolvedAt is not null, i.Resolution, i.AuditId.ToString());
    }

    private static string? Join(IEnumerable<string>? values) => values is null ? null : string.Join(',', values.Where(v => !string.IsNullOrWhiteSpace(v)));

    private static string[]? Split(string? value) => string.IsNullOrWhiteSpace(value) ? null : value.Split(',', StringSplitOptions.RemoveEmptyEntries);
}

[Route("api/v1/assets/{assetId}/documents")]
public sealed class AssetDocumentsController(ApplicationDbContext dbContext, AssetLifecycleService lifecycle, IWebHostEnvironment environment) : ApiControllerBase
{
    private static readonly string[] AllowedContentTypes = ["application/pdf", "image/jpeg", "image/png", "image/webp", "image/heic"];

    [HttpPost]
    [Consumes("multipart/form-data")]
    [RequestSizeLimit(10_000_000)]
    public async Task<ActionResult<ApiResponse<DocumentReferenceDto>>> Upload(string assetId, IFormFile file, [FromForm] DocumentType documentType, [FromForm] string? description, [FromForm] DateTimeOffset? capturedAt)
    {
        if (!await ScopeAssets(dbContext.Assets).AnyAsync(a => a.AssetId == assetId)) return NotFoundFailure("ASSET_NOT_FOUND", "requested asset");
        if (file.Length == 0) return Failure(422, "VALIDATION_ERROR", "The uploaded file is empty.", new ErrorDetail("file", "empty"));
        if (!AllowedContentTypes.Contains(file.ContentType, StringComparer.OrdinalIgnoreCase))
            return Failure(415, "UNSUPPORTED_FILE_TYPE", "Upload a PDF or an image (JPEG, PNG, WEBP or HEIC).");

        var document = new AssetDocumentEntity
        {
            AssetId = assetId,
            DocumentType = documentType.ToString(),
            FileName = Path.GetFileName(file.FileName),
            ContentType = file.ContentType,
            FileSizeBytes = file.Length,
            UploadedByUserId = CurrentUserId,
            Description = description,
            CapturedAt = capturedAt?.UtcDateTime
        };
        document.DownloadUrl = $"/api/v1/documents/{document.DocumentId}/download";

        var storageRoot = Path.Combine(environment.ContentRootPath, "object-storage");
        Directory.CreateDirectory(storageRoot);
        await using (var stream = System.IO.File.Create(Path.Combine(storageRoot, document.DocumentId)))
            await file.CopyToAsync(stream);

        dbContext.AssetDocuments.Add(document);
        lifecycle.RecordHistory(assetId, "DocumentUploaded", $"{documentType} uploaded: {document.FileName}.", CurrentUserId);
        await dbContext.SaveChangesAsync();
        return Created(document.DownloadUrl, Success(DocumentsController.ToDto(document)));
    }
}

[Route("api/v1/documents")]
public sealed class DocumentsController(ApplicationDbContext dbContext, IWebHostEnvironment environment) : ApiControllerBase
{
    [HttpGet("{documentId}/download")]
    public async Task<IActionResult> Download(string documentId)
    {
        var document = await dbContext.AssetDocuments.AsNoTracking().FirstOrDefaultAsync(d => d.DocumentId == documentId);
        if (document is null || !await ScopeAssets(dbContext.Assets).AnyAsync(a => a.AssetId == document.AssetId))
            return NotFoundFailure("DOCUMENT_NOT_FOUND", "document");

        // The stored file name is the document id, so the path cannot be influenced by the upload name.
        var path = Path.Combine(environment.ContentRootPath, "object-storage", document.DocumentId);
        return System.IO.File.Exists(path)
            ? PhysicalFile(path, document.ContentType, document.FileName)
            : Failure(404, "DOCUMENT_CONTENT_NOT_FOUND", "Document metadata exists but binary content is unavailable.");
    }

    internal static DocumentReferenceDto ToDto(AssetDocumentEntity d) => new(
        d.DocumentId, Enums.Parse<DocumentType>(d.DocumentType), d.FileName, d.ContentType, d.FileSizeBytes,
        AsUtc(d.UploadedAt), d.UploadedByUserId, d.DownloadUrl, d.Description, d.CapturedAt is null ? null : AsUtc(d.CapturedAt.Value));
}
