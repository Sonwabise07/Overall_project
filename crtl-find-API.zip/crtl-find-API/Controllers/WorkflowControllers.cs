using CtrlFind.Contracts;
using CtrlFind.Infrastructure.Persistence;
using CtrlFind.Infrastructure.Persistence.Entities;
using CtrlFind.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CtrlFind.Controllers;

[Route("api/v1/onboarding-cases")]
[Authorize(Roles = Roles.AssetOperators + "," + Roles.Hr)]
public sealed class OnboardingController(ApplicationDbContext dbContext, AssetLifecycleService lifecycle, OnboardingService onboarding) : ApiControllerBase
{
    private const string Recruitment = "Recruitment";
    private const string Oracle = "Oracle";

    [HttpGet]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<OnboardingCaseDto>>>> List([FromQuery] bool openOnly = true, [FromQuery] bool shortNoticeOnly = false)
    {
        var query = dbContext.OnboardingCases.AsNoTracking();
        if (openOnly) query = OnboardingService.OpenCases(query);
        if (shortNoticeOnly) query = query.Where(c => c.IsShortNotice);

        var cases = await query.OrderBy(c => c.StartDate).Take(200).ToListAsync();
        return Ok(Success(await ToDtosAsync(cases)));
    }

    [HttpGet("{caseId}")]
    public async Task<ActionResult<ApiResponse<OnboardingCaseDto>>> Get(string caseId)
    {
        var onboardingCase = await FindAsync(caseId, tracked: false);
        return onboardingCase is null
            ? NotFoundFailure("ONBOARDING_CASE_NOT_FOUND", "onboarding case")
            : Ok(Success((await ToDtosAsync([onboardingCase]))[0]));
    }

    // BR-8.4-02: recruitment creates a provisional case; Oracle confirms the same case.
    [HttpPost]
    public async Task<ActionResult<ApiResponse<OnboardingCaseDto>>> Create(CreateOnboardingCaseRequest request)
    {
        var source = request.Source.Trim();
        if (!source.Equals(Recruitment, StringComparison.OrdinalIgnoreCase) && !source.Equals(Oracle, StringComparison.OrdinalIgnoreCase))
            return Failure(422, "VALIDATION_ERROR", "Source must be Recruitment or Oracle.", new ErrorDetail("source", "invalid"));

        if (!await dbContext.Locations.AnyAsync(l => l.LocationId == request.LocationId))
            return Failure(422, "VALIDATION_ERROR", "The requested location was not found.", new ErrorDetail("locationId", "must identify an existing location"));

        if (!await dbContext.Departments.AnyAsync(d => d.DepartmentId == request.DepartmentId))
            return Failure(422, "VALIDATION_ERROR", "The requested department was not found.", new ErrorDetail("departmentId", "must identify an existing department"));

        var isOracle = source.Equals(Oracle, StringComparison.OrdinalIgnoreCase);
        await using var transaction = await dbContext.Database.BeginTransactionAsync();

        var existing = await OnboardingService.OpenCases(dbContext.OnboardingCases).FirstOrDefaultAsync(c => c.EmployeeId == request.EmployeeId);
        if (existing is not null && !isOracle)
            return Failure(409, "ONBOARDING_CASE_EXISTS", "An open onboarding case already exists for this employee.");

        var onboardingCase = existing ?? new OnboardingCaseEntity { EmployeeId = request.EmployeeId, CreatedAt = DateTime.UtcNow };
        onboardingCase.EmployeeName = request.EmployeeName;
        onboardingCase.DepartmentId = request.DepartmentId;
        onboardingCase.ManagerEmployeeId = request.ManagerEmployeeId;
        onboardingCase.JobRole = request.JobRole;
        onboardingCase.LocationId = request.LocationId;
        onboardingCase.StartDate = ToUtcDate(request.StartDate);
        onboardingCase.Notes = request.Notes ?? onboardingCase.Notes;
        onboardingCase.Status = nameof(CaseStatus.InProgress);

        if (isOracle && !onboardingCase.IsConfirmed)
        {
            // BR-8.4-03: notice is measured from the confirmed (Oracle) notification.
            onboardingCase.IsConfirmed = true;
            onboardingCase.ConfirmedAt = DateTime.UtcNow;
            onboardingCase.IsShortNotice = (onboardingCase.StartDate.Date - DateTime.UtcNow.Date).TotalDays < lifecycle.Rules.ShortNoticeDays;
            if (onboardingCase.IsShortNotice)
            {
                lifecycle.Notify(Roles.FixedAssets, "ShortNotice", "Short-notice new hire",
                    $"{onboardingCase.EmployeeName} starts {request.StartDate:dd MMM yyyy}, less than {lifecycle.Rules.ShortNoticeDays} days after confirmation.");
            }
        }

        if (existing is null) dbContext.OnboardingCases.Add(onboardingCase);
        await UpsertEmployeeAsync(request);
        await dbContext.SaveChangesAsync();

        if (!await dbContext.RoleKitItems.AnyAsync(k => k.JobRole == request.JobRole))
        {
            onboardingCase.Status = nameof(CaseStatus.Blocked);
            lifecycle.Notify(Roles.FixedAssets, "NoRoleKit", "No kit for job role", $"No standard kit is defined for {request.JobRole}. Onboarding of {request.EmployeeName} is waiting.");
        }
        else
        {
            var shortfalls = await onboarding.ReserveAsync(onboardingCase, CurrentUserId);
            onboarding.NotifyShortfall(onboardingCase, shortfalls);
        }

        await dbContext.SaveChangesAsync();
        await transaction.CommitAsync();

        var dto = (await ToDtosAsync([onboardingCase]))[0];
        return existing is null ? CreatedAtAction(nameof(Get), new { caseId = dto.CaseId }, Success(dto)) : Ok(Success(dto));
    }

    [HttpPost("{caseId}/reserve-stock")]
    public async Task<ActionResult<ApiResponse<OnboardingCaseDto>>> Reserve(string caseId)
    {
        var onboardingCase = await FindAsync(caseId, tracked: true);
        if (onboardingCase is null) return NotFoundFailure("ONBOARDING_CASE_NOT_FOUND", "onboarding case");
        if (!OnboardingService.IsOpen(onboardingCase)) return Failure(409, "CASE_CLOSED", "This onboarding case is closed.");

        var shortfalls = await onboarding.ReserveAsync(onboardingCase, CurrentUserId);
        onboarding.NotifyShortfall(onboardingCase, shortfalls);
        await dbContext.SaveChangesAsync();
        return Ok(Success((await ToDtosAsync([onboardingCase]))[0]));
    }

    // BR-8.4-06: custody agreement before laptop issue; status becomes Assigned.
    [HttpPost("{caseId}/issue-assets")]
    public async Task<ActionResult<ApiResponse<OnboardingCaseDto>>> Issue(string caseId, IssueOnboardingAssetsRequest request)
    {
        await using var transaction = await dbContext.Database.BeginTransactionAsync();

        var onboardingCase = await FindAsync(caseId, tracked: true);
        if (onboardingCase is null) return NotFoundFailure("ONBOARDING_CASE_NOT_FOUND", "onboarding case");
        if (!onboardingCase.IsConfirmed) return Failure(409, "CASE_NOT_CONFIRMED", "Assets are issued only after Oracle confirms the new hire.");

        var reservations = await dbContext.OnboardingReservations
            .Where(r => r.CaseId == onboardingCase.CaseId && r.ReleasedAt == null && r.IssuedAt == null)
            .ToListAsync();
        if (reservations.Count == 0) return Failure(409, "STOCK_UNAVAILABLE", "No reserved stock is waiting to be issued.");

        var employee = await dbContext.Employees.AsNoTracking().FirstAsync(e => e.EmployeeId == onboardingCase.EmployeeId);
        var location = await dbContext.Locations.AsNoTracking().FirstAsync(l => l.LocationId == onboardingCase.LocationId);
        var assetIds = reservations.Select(r => r.AssetId).ToList();
        var assets = await dbContext.Assets.Where(a => assetIds.Contains(a.AssetId)).ToDictionaryAsync(a => a.AssetId);

        var custodyDocuments = new Dictionary<string, string?>();
        foreach (var asset in assets.Values)
        {
            var documentId = await LatestCustodyAgreementAsync(asset.AssetId);
            var violation = await lifecycle.CheckLaptopReleaseAsync(asset, employee.EmployeeId, documentId, request.ManagerAcknowledged);
            if (violation is not null) return Failure(violation.Status, violation.Code, $"{asset.AssetNo}: {violation.Message}");
            custodyDocuments[asset.AssetId] = documentId;
        }

        foreach (var reservation in reservations)
        {
            var asset = assets[reservation.AssetId];
            lifecycle.Assign(asset, employee, location, DateOnly.FromDateTime(DateTime.UtcNow), custodyDocuments[asset.AssetId],
                null, Enums.ParseOrNull<ConditionStatus>(asset.Condition) ?? ConditionStatus.New, request.Notes ?? "Issued for onboarding", CurrentUserId);
            reservation.IssuedAt = DateTime.UtcNow;
        }

        var outstanding = (await onboarding.ShortfallsAsync([onboardingCase]))[onboardingCase.CaseId];
        if (outstanding.Count == 0)
        {
            onboardingCase.Status = nameof(CaseStatus.Completed);
            onboardingCase.CompletedAt = DateTime.UtcNow;
        }

        await dbContext.SaveChangesAsync();
        await transaction.CommitAsync();
        return Ok(Success((await ToDtosAsync([onboardingCase]))[0]));
    }

    private async Task<string?> LatestCustodyAgreementAsync(string assetId) =>
        await dbContext.AssetDocuments.AsNoTracking()
            .Where(d => d.AssetId == assetId && d.DocumentType == nameof(DocumentType.CustodyAgreement))
            .OrderByDescending(d => d.UploadedAt)
            .Select(d => d.DocumentId)
            .FirstOrDefaultAsync();

    private async Task UpsertEmployeeAsync(CreateOnboardingCaseRequest request)
    {
        var employee = await dbContext.Employees.FirstOrDefaultAsync(e => e.EmployeeId == request.EmployeeId);
        if (employee is null)
        {
            employee = new EmployeeEntity { EmployeeId = request.EmployeeId, IsActive = true };
            dbContext.Employees.Add(employee);
        }

        employee.FullName = request.EmployeeName;
        employee.DepartmentId = request.DepartmentId;
        employee.JobRole = request.JobRole;
        employee.ManagerEmployeeId = request.ManagerEmployeeId;
        employee.LocationId = request.LocationId;
    }

    private async Task<OnboardingCaseEntity?> FindAsync(string caseId, bool tracked)
    {
        var id = ParseId(caseId);
        if (id is null) return null;
        var query = tracked ? dbContext.OnboardingCases : dbContext.OnboardingCases.AsNoTracking();
        return await query.FirstOrDefaultAsync(c => c.CaseId == id);
    }

    private async Task<IReadOnlyList<OnboardingCaseDto>> ToDtosAsync(IReadOnlyList<OnboardingCaseEntity> cases)
    {
        var ids = cases.Select(c => c.CaseId).ToList();
        var reservations = await dbContext.OnboardingReservations.AsNoTracking()
            .Where(r => ids.Contains(r.CaseId) && r.ReleasedAt == null)
            .Join(dbContext.Assets, r => r.AssetId, a => a.AssetId, (r, a) => new { r.CaseId, r.ReservationId, r.AssetId, r.AssetType, a.AssetNo, r.IssuedAt })
            .ToListAsync();
        var shortfalls = await onboarding.ShortfallsAsync(cases);
        var roles = cases.Select(c => c.JobRole).Distinct().ToList();
        var rolesWithKits = await dbContext.RoleKitItems.Where(k => roles.Contains(k.JobRole)).Select(k => k.JobRole).Distinct().ToListAsync();

        return cases.Select(c =>
        {
            var reserved = reservations.Where(r => r.CaseId == c.CaseId)
                .Select(r => new ReservedAssetDto(r.AssetId, Enums.Parse<AssetType>(r.AssetType), r.ReservationId.ToString(), r.AssetNo, r.IssuedAt != null))
                .ToList();
            var missing = shortfalls[c.CaseId];
            var hasKit = rolesWithKits.Contains(c.JobRole);

            var blocking = new List<string>();
            if (!hasKit) blocking.Add($"No standard kit is defined for {c.JobRole}.");
            if (!c.IsConfirmed) blocking.Add("Waiting for Oracle confirmation.");
            blocking.AddRange(missing.Select(m => $"{m.Quantity} x {m.AssetType} not in stock."));

            var readiness = c.Status == nameof(CaseStatus.Completed) ? "Issued"
                : !hasKit ? "NoKitDefined"
                : missing.Count > 0 ? "AwaitingStock"
                : !c.IsConfirmed ? "Provisional"
                : "ReadyToIssue";

            return new OnboardingCaseDto(c.CaseId.ToString(), Enums.Parse<CaseStatus>(c.Status), c.EmployeeId, c.EmployeeName, c.JobRole,
                c.DepartmentId, c.LocationId, DateOnly.FromDateTime(c.StartDate), c.IsConfirmed, c.IsShortNotice, readiness,
                reserved, missing, blocking, AsUtc(c.CreatedAt), c.Notes);
        }).ToList();
    }
}

[Route("api/v1/offboarding-cases")]
[Authorize(Roles = Roles.AssetOperators + "," + Roles.Hr)]
public sealed class OffboardingController(ApplicationDbContext dbContext, AssetLifecycleService lifecycle) : ApiControllerBase
{
    private static readonly string[] CompletingResolutions =
        [nameof(OffboardingItemResolution.Returned), nameof(OffboardingItemResolution.HeldForReassignment), nameof(OffboardingItemResolution.AuthorisedException)];

    [HttpGet]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<OffboardingCaseDto>>>> List([FromQuery] bool openOnly = true)
    {
        var query = dbContext.OffboardingCases.AsNoTracking();
        if (openOnly) query = query.Where(c => c.Status != nameof(CaseStatus.Completed) && c.Status != nameof(CaseStatus.Cancelled));

        var cases = await query.OrderBy(c => c.ExitDate).Take(200).ToListAsync();
        var result = new List<OffboardingCaseDto>();
        foreach (var offboardingCase in cases) result.Add(await BuildAsync(offboardingCase));
        return Ok(Success<IReadOnlyList<OffboardingCaseDto>>(result));
    }

    [HttpGet("{caseId}")]
    public async Task<ActionResult<ApiResponse<OffboardingCaseDto>>> Get(string caseId)
    {
        var offboardingCase = await FindAsync(caseId);
        if (offboardingCase is null) return NotFoundFailure("OFFBOARDING_CASE_NOT_FOUND", "offboarding case");

        await SyncItemsAsync(offboardingCase);
        await dbContext.SaveChangesAsync();
        return Ok(Success(await BuildAsync(offboardingCase)));
    }

    // BR-8.11-01 and BR-8.11-02: one case per exit notice, listing every assigned asset.
    [HttpPost]
    public async Task<ActionResult<ApiResponse<OffboardingCaseDto>>> Create(CreateOffboardingCaseRequest request)
    {
        if (!await dbContext.Employees.AnyAsync(e => e.EmployeeId == request.EmployeeId))
            return Failure(422, "VALIDATION_ERROR", "The employee was not found.", new ErrorDetail("employeeId", "must identify an existing employee"));

        if (await dbContext.OffboardingCases.AnyAsync(c => c.EmployeeId == request.EmployeeId && c.Status != nameof(CaseStatus.Completed) && c.Status != nameof(CaseStatus.Cancelled)))
            return Failure(409, "OFFBOARDING_CASE_EXISTS", "An open offboarding case already exists for this employee.");

        var offboardingCase = new OffboardingCaseEntity
        {
            EmployeeId = request.EmployeeId,
            ExitDate = ToUtcDate(request.ExitDate),
            Source = request.Source,
            Reason = request.Reason,
            Notes = request.Notes,
            Status = nameof(CaseStatus.InProgress)
        };
        dbContext.OffboardingCases.Add(offboardingCase);
        await dbContext.SaveChangesAsync();

        await SyncItemsAsync(offboardingCase);
        await dbContext.SaveChangesAsync();
        var dto = await BuildAsync(offboardingCase);
        return CreatedAtAction(nameof(Get), new { caseId = dto.CaseId }, Success(dto));
    }

    // BR-8.11-03: returned to storeroom, held at desk, escalated if missing, or an authorised exception.
    [HttpPost("{caseId}/resolve-item")]
    public async Task<ActionResult<ApiResponse<OffboardingCaseDto>>> Resolve(string caseId, ResolveOffboardingItemRequest request)
    {
        await using var transaction = await dbContext.Database.BeginTransactionAsync();

        var offboardingCase = await FindAsync(caseId);
        if (offboardingCase is null) return NotFoundFailure("OFFBOARDING_CASE_NOT_FOUND", "offboarding case");
        if (offboardingCase.Status == nameof(CaseStatus.Completed)) return Failure(409, "CASE_CLOSED", "This offboarding case is complete.");

        var item = await dbContext.OffboardingItems.FirstOrDefaultAsync(i => i.CaseId == offboardingCase.CaseId && i.AssetId == request.AssetId);
        if (item is null) return NotFoundFailure("OFFBOARDING_ITEM_NOT_FOUND", "asset on this checklist");
        if (item.Resolution is not null && CompletingResolutions.Contains(item.Resolution))
            return Failure(409, "ITEM_ALREADY_RESOLVED", $"This asset is already resolved as {item.Resolution}.");

        var asset = await dbContext.Assets.FirstAsync(a => a.AssetId == request.AssetId);
        var needsCondition = request.Resolution is OffboardingItemResolution.Returned or OffboardingItemResolution.HeldForReassignment;
        if (needsCondition && request.ConditionStatus is null)
            return Failure(422, "VALIDATION_ERROR", "A condition check is required when an asset is returned.", new ErrorDetail("conditionStatus", "missing"));

        switch (request.Resolution)
        {
            case OffboardingItemResolution.Returned:
                var storeroom = request.StoreroomId is null ? null : await dbContext.Storerooms.AsNoTracking().FirstOrDefaultAsync(s => s.StoreroomId == request.StoreroomId);
                if (storeroom is null)
                    return Failure(422, "VALIDATION_ERROR", "Choose the storeroom the asset was returned to.", new ErrorDetail("storeroomId", "must identify an existing storeroom"));
                await lifecycle.ReturnToStorageAsync(asset, storeroom, request.ConditionStatus!.Value, CurrentUserId, "Recovered on exit.");
                break;

            case OffboardingItemResolution.HeldForReassignment:
                await lifecycle.CloseActiveAssignmentAsync(asset);
                asset.Condition = request.ConditionStatus!.Value.ToString();
                asset.HoldExpiresAt = DateTime.UtcNow.AddDays(lifecycle.Rules.HoldForReassignmentDays);
                lifecycle.ChangeState(asset, LifecycleState.HeldForReassignment, CurrentUserId, "Held at desk on exit for the replacement employee.");
                break;

            case OffboardingItemResolution.Escalated:
                lifecycle.ChangeState(asset, LifecycleState.UnderInvestigation, CurrentUserId, "Missing on exit. Escalated.");
                lifecycle.Notify(Roles.FixedAssets, "MissingOnExit", "Asset missing on exit", $"{asset.AssetNo} was not recovered from {offboardingCase.EmployeeId}.", asset.AssetId);
                lifecycle.Notify(Roles.Hr, "MissingOnExit", "Asset missing on exit", $"{asset.AssetNo} was not recovered from {offboardingCase.EmployeeId}.", asset.AssetId);
                break;

            case OffboardingItemResolution.AuthorisedException:
                if (!User.IsInRole(Roles.FixedAssets))
                    return Failure(403, "FORBIDDEN", "Only Fixed Assets can record an authorised exception.");
                if (string.IsNullOrWhiteSpace(request.Notes))
                    return Failure(422, "VALIDATION_ERROR", "Record the reason for the exception.", new ErrorDetail("notes", "required"));
                lifecycle.RecordHistory(asset.AssetId, "OffboardingException", request.Notes, CurrentUserId);
                break;
        }

        item.Resolution = request.Resolution.ToString();
        item.Condition = request.ConditionStatus?.ToString();
        item.Notes = request.Notes;
        item.ResolvedBy = CurrentUserId;
        item.ResolvedAt = DateTime.UtcNow;

        await dbContext.SaveChangesAsync();
        await transaction.CommitAsync();
        return Ok(Success(await BuildAsync(offboardingCase)));
    }

    // BR-8.11-04 and BR-8.3-06.
    [HttpPost("{caseId}/complete")]
    public async Task<ActionResult<ApiResponse<OffboardingCaseDto>>> Complete(string caseId)
    {
        var offboardingCase = await FindAsync(caseId);
        if (offboardingCase is null) return NotFoundFailure("OFFBOARDING_CASE_NOT_FOUND", "offboarding case");

        await SyncItemsAsync(offboardingCase);
        await dbContext.SaveChangesAsync();

        var dto = await BuildAsync(offboardingCase);
        if (!dto.CanComplete)
            return Failure(409, "OFFBOARDING_BLOCKED", "The recovery checklist is incomplete.", dto.BlockingReasons.Select(r => new ErrorDetail(null, r)).ToArray());

        offboardingCase.Status = nameof(CaseStatus.Completed);
        offboardingCase.CompletedAt = DateTime.UtcNow;
        await dbContext.SaveChangesAsync();
        return Ok(Success(dto with { Status = CaseStatus.Completed }));
    }

    // Keeps the checklist in line with the employee's current assets until the case is complete.
    private async Task SyncItemsAsync(OffboardingCaseEntity offboardingCase)
    {
        if (offboardingCase.Status == nameof(CaseStatus.Completed)) return;

        var assigned = await dbContext.Assets.Where(a => a.EmployeeId == offboardingCase.EmployeeId).Select(a => a.AssetId).ToListAsync();
        var items = await dbContext.OffboardingItems.Where(i => i.CaseId == offboardingCase.CaseId).ToListAsync();

        foreach (var assetId in assigned.Where(id => items.All(i => i.AssetId != id)))
            dbContext.OffboardingItems.Add(new OffboardingItemEntity { CaseId = offboardingCase.CaseId, AssetId = assetId });

        foreach (var stale in items.Where(i => i.Resolution is null && !assigned.Contains(i.AssetId)))
            dbContext.OffboardingItems.Remove(stale);
    }

    private async Task<OffboardingCaseEntity?> FindAsync(string caseId)
    {
        var id = ParseId(caseId);
        return id is null ? null : await dbContext.OffboardingCases.FirstOrDefaultAsync(c => c.CaseId == id);
    }

    private async Task<OffboardingCaseDto> BuildAsync(OffboardingCaseEntity c)
    {
        var rows = await dbContext.OffboardingItems.AsNoTracking()
            .Where(i => i.CaseId == c.CaseId)
            .Join(dbContext.Assets, i => i.AssetId, a => a.AssetId, (i, a) => new { Item = i, a.AssetNo, a.AssetType, a.Make, a.Model })
            .ToListAsync();
        var employeeName = await dbContext.Employees.Where(e => e.EmployeeId == c.EmployeeId).Select(e => e.FullName).FirstOrDefaultAsync();

        var items = rows.Select(r => new OffboardingItemDto(
            r.Item.AssetId, r.AssetNo, Enums.Parse<AssetType>(r.AssetType), r.AssetType == nameof(AssetType.Laptop),
            Enums.ParseOrNull<OffboardingItemResolution>(r.Item.Resolution), r.Item.ResolvedAt is null ? null : AsUtc(r.Item.ResolvedAt.Value),
            r.Make, r.Model, r.Item.Notes)).ToList();

        var open = rows.Where(r => r.Item.Resolution is null || !CompletingResolutions.Contains(r.Item.Resolution)).ToList();
        var reasons = open.Select(r => r.AssetType == nameof(AssetType.Laptop)
                ? $"Laptop {r.AssetNo} is not recovered. Laptop recovery is mandatory."
                : $"{r.AssetType} {r.AssetNo} is not resolved.")
            .ToList();
        var laptopRecovered = open.All(r => r.AssetType != nameof(AssetType.Laptop));

        var request = new CreateOffboardingCaseRequest(c.EmployeeId, DateOnly.FromDateTime(c.ExitDate), c.Source, c.Reason, c.Notes);
        return new OffboardingCaseDto(c.CaseId.ToString(), Enums.Parse<CaseStatus>(c.Status), c.EmployeeId, DateOnly.FromDateTime(c.ExitDate),
            items, reasons.Count == 0, reasons, request, employeeName, laptopRecovered);
    }
}

[Route("api/v1/stock")]
[Authorize(Roles = Roles.AssetOperators)]
public sealed class StockController(ApplicationDbContext dbContext, OnboardingService onboarding) : ApiControllerBase
{
    [HttpGet("items")]
    public async Task<ActionResult<PageResponse<StockItemDto>>> Items(
        [FromQuery] int page = 1, [FromQuery] int pageSize = 25, [FromQuery] StockState? state = null,
        [FromQuery] AssetType? assetType = null, [FromQuery] string? storeroomId = null)
    {
        page = Math.Max(page, 1);
        pageSize = Math.Clamp(pageSize, 1, 100);

        var query = AssetQueries.StockAssets(dbContext);
        if (assetType is not null)
        {
            var type = assetType.Value.ToString();
            query = query.Where(a => a.AssetType == type);
        }
        if (!string.IsNullOrWhiteSpace(storeroomId)) query = query.Where(a => a.StoreroomId == storeroomId);
        if (state is not null) query = FilterState(query, state.Value);

        var total = await query.CountAsync();
        var assets = await query.OrderBy(a => a.AssetType).ThenBy(a => a.AssetNo).Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();
        var reservedFor = await dbContext.OnboardingReservations.AsNoTracking()
            .Where(r => r.ReleasedAt == null && r.IssuedAt == null)
            .Select(r => new { r.AssetId, r.CaseId })
            .ToDictionaryAsync(r => r.AssetId, r => r.CaseId.ToString());

        var items = assets.Select(a => new StockItemDto(a.AssetId, a.AssetNo, Enums.Parse<AssetType>(a.AssetType), StateOf(a),
            Enums.ParseOrNull<ConditionStatus>(a.Condition), a.LocationId, a.StoreroomId, reservedFor.GetValueOrDefault(a.AssetId), a.Make, a.Model)).ToList();
        return Ok(Page(items, page, pageSize, total));
    }

    [HttpGet("summary")]
    public async Task<ActionResult<ApiResponse<StockSummaryDto>>> Summary()
    {
        var byType = await AssetQueries.SummariseStockByTypeAsync(dbContext);

        var storerooms = await dbContext.Storerooms.AsNoTracking()
            .GroupJoin(dbContext.Locations, s => s.LocationId, l => l.LocationId, (s, l) => new { s, l })
            .SelectMany(x => x.l.DefaultIfEmpty(), (x, l) => new { x.s.StoreroomId, x.s.Name, x.s.LocationId, Region = l != null ? l.Region : null, Building = l != null ? l.Building : null })
            .ToListAsync();
        var counts = await AssetQueries.StockAssets(dbContext)
            .GroupBy(a => new { a.StoreroomId, a.LifecycleState, Damaged = a.Condition == nameof(ConditionStatus.Damaged) })
            .Select(g => new { g.Key.StoreroomId, g.Key.LifecycleState, g.Key.Damaged, Count = g.Count() })
            .ToListAsync();

        var byStoreroom = storerooms.Select(s =>
        {
            var rows = counts.Where(c => c.StoreroomId == s.StoreroomId).ToList();
            var available = rows.Where(r => r.LifecycleState == nameof(LifecycleState.InStorage) && !r.Damaged).Sum(r => r.Count);
            var reserved = rows.Where(r => r.LifecycleState == nameof(LifecycleState.Reserved)).Sum(r => r.Count);
            var damaged = rows.Where(r => r.LifecycleState == nameof(LifecycleState.InStorage) && r.Damaged).Sum(r => r.Count);
            return new StoreroomStockDto(s.StoreroomId, s.Name, s.LocationId, s.Region, s.Building, available, reserved, damaged,
                available == 0 ? "NoStock" : available <= 5 ? "LowStock" : "Healthy");
        }).ToList();

        var openCases = await OnboardingService.OpenCases(dbContext.OnboardingCases.AsNoTracking()).Where(c => c.IsConfirmed).ToListAsync();
        var shortfalls = await onboarding.ShortfallsAsync(openCases);
        var demand = openCases
            .SelectMany(c => shortfalls[c.CaseId].Select(s => new UnfulfilledDemandDto(c.CaseId.ToString(), c.EmployeeName, s.AssetType, s.Quantity, s.NeededBy)))
            .OrderBy(d => d.NeededBy)
            .ToList();

        return Ok(Success(new StockSummaryDto(byType, byStoreroom, demand)));
    }

    [HttpGet("thresholds")]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<StockTypeSummaryDto>>>> Thresholds() =>
        Ok(Success(await AssetQueries.SummariseStockByTypeAsync(dbContext)));

    [HttpPut("thresholds/{assetType}")]
    [Authorize(Roles = Roles.FixedAssets + "," + Roles.Administrator)]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<StockTypeSummaryDto>>>> SetThreshold(AssetType assetType, SetStockThresholdRequest request)
    {
        var key = assetType.ToString();
        var threshold = await dbContext.StockThresholds.FirstOrDefaultAsync(t => t.AssetType == key);
        if (threshold is null) dbContext.StockThresholds.Add(new StockThresholdEntity { AssetType = key, MinimumAvailable = request.MinimumAvailable });
        else threshold.MinimumAvailable = request.MinimumAvailable;

        await dbContext.SaveChangesAsync();
        return Ok(Success(await AssetQueries.SummariseStockByTypeAsync(dbContext)));
    }

    // BR-8.7-03: opening and closing counts, stored with item conditions.
    [HttpPost("counts")]
    public async Task<ActionResult<ApiResponse<StockCountDto>>> Count(StockCountRequest request)
    {
        if (!await dbContext.Storerooms.AnyAsync(s => s.StoreroomId == request.StoreroomId))
            return Failure(422, "VALIDATION_ERROR", "The requested storeroom was not found.", new ErrorDetail("storeroomId", "must identify an existing storeroom"));

        var assetIds = request.Items.Select(i => i.AssetId).ToList();
        var assets = await dbContext.Assets.Where(a => assetIds.Contains(a.AssetId)).ToDictionaryAsync(a => a.AssetId);
        var unknown = assetIds.Where(id => !assets.ContainsKey(id)).ToList();
        if (unknown.Count > 0)
            return Failure(422, "VALIDATION_ERROR", "Some counted assets are not registered.", unknown.Select(id => new ErrorDetail("items", $"{id} not found")).ToArray());

        foreach (var item in request.Items) assets[item.AssetId].Condition = item.ConditionStatus.ToString();

        var count = new StockCountEntity
        {
            StoreroomId = request.StoreroomId,
            CountType = request.CountType.ToString(),
            CountDate = ToUtcDate(request.CountDate),
            CountedUnits = request.Items.Count,
            Notes = request.Notes,
            RecordedBy = CurrentUserId
        };
        dbContext.StockCounts.Add(count);
        await dbContext.SaveChangesAsync();

        return Created(string.Empty, Success(new StockCountDto(count.CountId.ToString(), count.StoreroomId, request.CountType, request.CountDate, count.CountedUnits, AsUtc(count.RecordedAt))));
    }

    [HttpGet("reconciliation")]
    public async Task<ActionResult<ApiResponse<StockReconciliationDto>>> Reconciliation([FromQuery] string storeroomId, [FromQuery] DateOnly? weekStart = null)
    {
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var monday = weekStart ?? today.AddDays(-(((int)today.DayOfWeek + 6) % 7));
        var from = ToUtcDate(monday);
        var to = from.AddDays(7);

        var counts = await dbContext.StockCounts.AsNoTracking()
            .Where(c => c.StoreroomId == storeroomId && c.CountDate >= from && c.CountDate < to)
            .ToListAsync();
        var opening = counts.Where(c => c.CountType == nameof(StockCountType.Opening)).OrderBy(c => c.CountDate).FirstOrDefault()?.CountedUnits;
        var closing = counts.Where(c => c.CountType == nameof(StockCountType.Closing)).OrderByDescending(c => c.CountDate).FirstOrDefault()?.CountedUnits;

        var movements = await dbContext.StockMovements.AsNoTracking()
            .Where(m => m.StoreroomId == storeroomId && m.MovedAt >= from && m.MovedAt < to)
            .GroupBy(m => m.Direction)
            .Select(g => new { Direction = g.Key, Count = g.Count() })
            .ToListAsync();
        var unitsOut = movements.Where(m => m.Direction == "Out").Sum(m => m.Count);
        var unitsIn = movements.Where(m => m.Direction == "In").Sum(m => m.Count);
        int? expected = opening is null ? null : opening - unitsOut + unitsIn;

        return Ok(Success(new StockReconciliationDto(storeroomId, monday, opening, unitsOut, unitsIn, expected, closing,
            closing is null || expected is null ? null : closing - expected)));
    }

    [HttpGet("alerts")]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<AlertDto>>>> Alerts() =>
        Ok(Success<IReadOnlyList<AlertDto>>(AssetQueries.StockAlerts(await AssetQueries.SummariseStockByTypeAsync(dbContext))));

    private static IQueryable<AssetEntity> FilterState(IQueryable<AssetEntity> query, StockState state) => state switch
    {
        StockState.Reserved => query.Where(a => a.LifecycleState == nameof(LifecycleState.Reserved)),
        StockState.Damaged => query.Where(a => a.LifecycleState == nameof(LifecycleState.InStorage) && a.Condition == nameof(ConditionStatus.Damaged)),
        _ => query.Where(a => a.LifecycleState == nameof(LifecycleState.InStorage) && (a.Condition == null || a.Condition != nameof(ConditionStatus.Damaged)))
    };

    private static StockState StateOf(AssetEntity asset) =>
        asset.LifecycleState == nameof(LifecycleState.Reserved) ? StockState.Reserved
        : asset.Condition == nameof(ConditionStatus.Damaged) ? StockState.Damaged
        : StockState.Available;
}

[Route("api/v1/maintenance-cases")]
[Authorize(Roles = Roles.HelpDesk + "," + Roles.FixedAssets + "," + Roles.Administrator)]
public sealed class MaintenanceController(ApplicationDbContext dbContext, AssetLifecycleService lifecycle) : ApiControllerBase
{
    [HttpGet]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<MaintenanceCaseDto>>>> List([FromQuery] bool openOnly = false, [FromQuery] FaultClassification? classification = null)
    {
        var query = dbContext.MaintenanceCases.AsNoTracking();
        if (openOnly) query = query.Where(c => c.Status != nameof(CaseStatus.Completed));
        if (classification is not null)
        {
            var value = classification.Value.ToString();
            query = query.Where(c => c.Classification == value);
        }

        var rows = await query.OrderByDescending(c => c.ReportedAt).Take(200)
            .Join(dbContext.Assets, c => c.AssetId, a => a.AssetId, (c, a) => new { Case = c, Asset = a })
            .ToListAsync();
        return Ok(Success<IReadOnlyList<MaintenanceCaseDto>>(rows.Select(r => ToDto(r.Case, r.Asset)).ToList()));
    }

    [HttpGet("{caseId}")]
    public async Task<ActionResult<ApiResponse<MaintenanceCaseDto>>> Get(string caseId)
    {
        var (maintenanceCase, asset) = await FindAsync(caseId);
        return maintenanceCase is null ? NotFoundFailure("MAINTENANCE_CASE_NOT_FOUND", "maintenance case") : Ok(Success(ToDto(maintenanceCase, asset!)));
    }

    // BR-8.8-01 and BR-8.8-02: every fault is classified and linked to a Zendesk ticket.
    [HttpPost]
    public async Task<ActionResult<ApiResponse<MaintenanceCaseDto>>> Create(CreateMaintenanceCaseRequest request)
    {
        var asset = await dbContext.Assets.AsNoTracking().FirstOrDefaultAsync(a => a.AssetId == request.AssetId);
        if (asset is null) return NotFoundFailure("ASSET_NOT_FOUND", "requested asset");

        if (await dbContext.MaintenanceCases.AnyAsync(c => c.AssetId == request.AssetId && c.Status != nameof(CaseStatus.Completed)))
            return Failure(409, "MAINTENANCE_CASE_OPEN", "This asset already has an open fault case.");

        var accidental = request.Classification == FaultClassification.AccidentalDamage;
        var maintenanceCase = new MaintenanceCaseEntity
        {
            AssetId = request.AssetId,
            Classification = request.Classification.ToString(),
            ReportedByEmployeeId = request.ReportedByEmployeeId,
            ZendeskTicketId = request.ZendeskTicketId.Trim(),
            Description = request.Description,
            ReportedAt = request.ReportedAt.UtcDateTime,
            CostRecoveryReview = accidental,
            Status = nameof(CaseStatus.Open)
        };
        dbContext.MaintenanceCases.Add(maintenanceCase);
        lifecycle.RecordHistory(asset.AssetId, "FaultReported", $"{request.Classification} reported on Zendesk {maintenanceCase.ZendeskTicketId}.", CurrentUserId,
            null, new { request.Classification, request.ZendeskTicketId, request.Description });
        if (accidental)
            lifecycle.Notify(Roles.FixedAssets, "CostRecoveryReview", "Accidental damage review", $"{asset.AssetNo} was damaged by the employee. Review for cost recovery.", asset.AssetId);

        await dbContext.SaveChangesAsync();
        return Created(string.Empty, Success(ToDto(maintenanceCase, asset)));
    }

    [HttpPost("{caseId}/diagnose")]
    [Authorize(Roles = Roles.HelpDesk + "," + Roles.Administrator)]
    public async Task<ActionResult<ApiResponse<MaintenanceCaseDto>>> Diagnose(string caseId, DiagnoseMaintenanceCaseRequest request)
    {
        var (maintenanceCase, asset) = await FindAsync(caseId);
        if (maintenanceCase is null) return NotFoundFailure("MAINTENANCE_CASE_NOT_FOUND", "maintenance case");
        if (maintenanceCase.Status == nameof(CaseStatus.Completed)) return Failure(409, "CASE_CLOSED", "This case is closed.");

        maintenanceCase.Diagnosis = request.Diagnosis;
        maintenanceCase.RepairabilityDecision = request.RepairabilityDecision.ToString();
        maintenanceCase.EstimatedRepairCost = request.EstimatedRepairCost;
        maintenanceCase.Notes = request.Notes;
        maintenanceCase.Status = nameof(CaseStatus.InProgress);
        lifecycle.RecordHistory(asset!.AssetId, "FaultDiagnosed", $"IT Help Desk: {request.RepairabilityDecision}.", CurrentUserId, null, request);

        await dbContext.SaveChangesAsync();
        return Ok(Success(ToDto(maintenanceCase, asset)));
    }

    // BR-8.8-03. Outcome mapping for the original asset is recorded in DEC-020.
    [HttpPost("{caseId}/outcome")]
    [Authorize(Roles = Roles.FixedAssets + "," + Roles.Administrator)]
    public async Task<ActionResult<ApiResponse<MaintenanceCaseDto>>> Outcome(string caseId, RecordFaultOutcomeRequest request)
    {
        await using var transaction = await dbContext.Database.BeginTransactionAsync();

        var (maintenanceCase, asset) = await FindAsync(caseId);
        if (maintenanceCase is null) return NotFoundFailure("MAINTENANCE_CASE_NOT_FOUND", "maintenance case");
        if (maintenanceCase.Outcome is not null) return Failure(409, "OUTCOME_RECORDED", $"Outcome {maintenanceCase.Outcome} is already recorded.");
        if (maintenanceCase.Diagnosis is null) return Failure(409, "DIAGNOSIS_REQUIRED", "IT Help Desk must diagnose the fault first.");

        var nonRepairable = maintenanceCase.RepairabilityDecision == nameof(RepairabilityDecision.NonRepairable);
        switch (request.Outcome)
        {
            case FaultOutcome.Repair:
                lifecycle.ChangeState(asset!, LifecycleState.InRepair, CurrentUserId, $"Sent for repair (Zendesk {maintenanceCase.ZendeskTicketId}).");
                maintenanceCase.Status = nameof(CaseStatus.InProgress);
                break;

            case FaultOutcome.WarrantyClaim:
                lifecycle.ChangeState(asset!, LifecycleState.WarrantyClaim, CurrentUserId, $"Warranty claim (Zendesk {maintenanceCase.ZendeskTicketId}).");
                maintenanceCase.Status = nameof(CaseStatus.InProgress);
                break;

            case FaultOutcome.Retire:
                if (!nonRepairable) return Failure(409, "NON_REPAIRABLE_CONFIRMATION_REQUIRED", "Retirement needs IT to confirm the asset cannot be repaired.");
                await lifecycle.RetireAsync(asset!, CurrentUserId, $"Retired after fault (Zendesk {maintenanceCase.ZendeskTicketId}).");
                Close(maintenanceCase);
                break;

            case FaultOutcome.Replace:
                if (!nonRepairable) return Failure(409, "NON_REPAIRABLE_CONFIRMATION_REQUIRED", "Replacement requires a confirmed non-repairable diagnosis.");
                var problem = await ReplaceAsync(maintenanceCase, asset!, request.ReplacementAssetId);
                if (problem is not null) return problem;
                Close(maintenanceCase);
                break;
        }

        maintenanceCase.Outcome = request.Outcome.ToString();
        maintenanceCase.Notes = request.Notes ?? maintenanceCase.Notes;
        await dbContext.SaveChangesAsync();
        await transaction.CommitAsync();
        return Ok(Success(ToDto(maintenanceCase, asset!)));
    }

    // Repair finished: the asset goes back to its holder or to storage.
    [HttpPost("{caseId}/close")]
    [Authorize(Roles = Roles.FixedAssets + "," + Roles.HelpDesk + "," + Roles.Administrator)]
    public async Task<ActionResult<ApiResponse<MaintenanceCaseDto>>> CloseRepair(string caseId)
    {
        var (maintenanceCase, asset) = await FindAsync(caseId);
        if (maintenanceCase is null) return NotFoundFailure("MAINTENANCE_CASE_NOT_FOUND", "maintenance case");
        if (maintenanceCase.Outcome != nameof(FaultOutcome.Repair))
            return Failure(409, "NOT_A_REPAIR", "Only repair cases are closed here. Warranty claims close from the claim.");
        if (maintenanceCase.Status == nameof(CaseStatus.Completed)) return Failure(409, "CASE_CLOSED", "This case is closed.");

        await lifecycle.RestoreAfterRepairAsync(asset!, CurrentUserId, "Repair completed.");
        Close(maintenanceCase);
        await dbContext.SaveChangesAsync();
        return Ok(Success(ToDto(maintenanceCase, asset!)));
    }

    private async Task<ObjectResult?> ReplaceAsync(MaintenanceCaseEntity maintenanceCase, AssetEntity original, string? replacementAssetId)
    {
        var inStorage = nameof(LifecycleState.InStorage);
        var replacement = replacementAssetId is not null
            ? await dbContext.Assets.FirstOrDefaultAsync(a => a.AssetId == replacementAssetId && a.LifecycleState == inStorage)
            : await dbContext.Assets.Where(a => a.AssetType == original.AssetType && a.LifecycleState == inStorage && a.Condition != nameof(ConditionStatus.Damaged))
                .OrderBy(a => a.Region == original.Region ? 0 : 1).ThenBy(a => a.AssetNo).FirstOrDefaultAsync();
        if (replacement is null) return Failure(409, "STOCK_UNAVAILABLE", "No matching replacement stock is available.");

        var assignment = await dbContext.AssetAssignments.AsNoTracking().FirstOrDefaultAsync(a => a.AssetId == original.AssetId && a.ReturnedAt == null);
        if (assignment is not null)
        {
            var employee = await dbContext.Employees.AsNoTracking().FirstAsync(e => e.EmployeeId == assignment.EmployeeId);
            var location = await dbContext.Locations.AsNoTracking().FirstAsync(l => l.LocationId == (original.LocationId ?? employee.LocationId));
            var custody = await dbContext.AssetDocuments.AsNoTracking()
                .Where(d => d.AssetId == replacement.AssetId && d.DocumentType == nameof(DocumentType.CustodyAgreement))
                .OrderByDescending(d => d.UploadedAt).Select(d => d.DocumentId).FirstOrDefaultAsync();

            var violation = await lifecycle.CheckLaptopReleaseAsync(replacement, employee.EmployeeId, custody, managerAcknowledged: true);
            if (violation is not null) return Failure(violation.Status, violation.Code, $"Replacement {replacement.AssetNo}: {violation.Message}");

            lifecycle.Assign(replacement, employee, location, DateOnly.FromDateTime(DateTime.UtcNow), custody, original.Desk,
                Enums.ParseOrNull<ConditionStatus>(replacement.Condition), $"Replacement for {original.AssetNo} (Zendesk {maintenanceCase.ZendeskTicketId})", CurrentUserId);
        }

        await lifecycle.RetireAsync(original, CurrentUserId, $"Replaced by {replacement.AssetNo} (Zendesk {maintenanceCase.ZendeskTicketId}).");
        lifecycle.RecordHistory(replacement.AssetId, "ReplacementIssued", $"Replaces {original.AssetNo} (Zendesk {maintenanceCase.ZendeskTicketId}).", CurrentUserId,
            null, new { OriginalAssetId = original.AssetId, assignment?.EmployeeId, maintenanceCase.ZendeskTicketId });
        maintenanceCase.ReplacementAssetId = replacement.AssetId;
        return null;
    }

    private static void Close(MaintenanceCaseEntity maintenanceCase)
    {
        maintenanceCase.Status = nameof(CaseStatus.Completed);
        maintenanceCase.ClosedAt = DateTime.UtcNow;
    }

    private async Task<(MaintenanceCaseEntity?, AssetEntity?)> FindAsync(string caseId)
    {
        var id = ParseId(caseId);
        var maintenanceCase = id is null ? null : await dbContext.MaintenanceCases.FirstOrDefaultAsync(c => c.CaseId == id);
        if (maintenanceCase is null) return (null, null);
        return (maintenanceCase, await dbContext.Assets.FirstAsync(a => a.AssetId == maintenanceCase.AssetId));
    }

    private static MaintenanceCaseDto ToDto(MaintenanceCaseEntity c, AssetEntity asset) => new(
        c.CaseId.ToString(), Enums.Parse<CaseStatus>(c.Status), c.AssetId, asset.AssetNo, Enums.Parse<FaultClassification>(c.Classification),
        c.ReportedByEmployeeId, c.ZendeskTicketId, c.Description, AsUtc(c.ReportedAt), c.CostRecoveryReview, c.Diagnosis,
        Enums.ParseOrNull<RepairabilityDecision>(c.RepairabilityDecision), c.EstimatedRepairCost, Enums.ParseOrNull<FaultOutcome>(c.Outcome),
        c.ReplacementAssetId, c.ClosedAt is null ? null : AsUtc(c.ClosedAt.Value), AssetStatusRules.Describe(asset));
}

// Claims are for operational roles; the expiry list and maintenance log are readable by anyone in scope.
[Route("api/v1/warranty-claims")]
public sealed class WarrantyController(ApplicationDbContext dbContext, AssetLifecycleService lifecycle) : ApiControllerBase
{
    [HttpGet]
    [Authorize(Roles = Roles.HelpDesk + "," + Roles.FixedAssets + "," + Roles.Administrator)]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<WarrantyClaimDto>>>> List([FromQuery] bool openOnly = false)
    {
        var query = dbContext.WarrantyClaims.AsNoTracking();
        if (openOnly) query = query.Where(c => c.Status != nameof(CaseStatus.Completed));

        var rows = await query.OrderByDescending(c => c.DispatchDate).Take(200)
            .Join(dbContext.Assets, c => c.AssetId, a => a.AssetId, (c, a) => new { Claim = c, a.AssetNo })
            .ToListAsync();
        return Ok(Success<IReadOnlyList<WarrantyClaimDto>>(rows.Select(r => ToDto(r.Claim, r.AssetNo)).ToList()));
    }

    // BR-8.9-03: while a claim is active the asset shows In Repair.
    [HttpPost]
    [Authorize(Roles = Roles.HelpDesk + "," + Roles.FixedAssets + "," + Roles.Administrator)]
    public async Task<ActionResult<ApiResponse<WarrantyClaimDto>>> Create(CreateWarrantyClaimRequest request)
    {
        var caseId = ParseId(request.MaintenanceCaseId);
        var maintenanceCase = caseId is null ? null : await dbContext.MaintenanceCases.FirstOrDefaultAsync(c => c.CaseId == caseId);
        if (maintenanceCase is null) return NotFoundFailure("MAINTENANCE_CASE_NOT_FOUND", "maintenance case");
        if (maintenanceCase.AssetId != request.AssetId) return Failure(422, "VALIDATION_ERROR", "The claim asset does not match the fault case.");
        if (await dbContext.WarrantyClaims.AnyAsync(c => c.MaintenanceCaseId == maintenanceCase.CaseId && c.Status != nameof(CaseStatus.Completed)))
            return Failure(409, "WARRANTY_CLAIM_OPEN", "This fault already has an open warranty claim.");

        var asset = await dbContext.Assets.FirstAsync(a => a.AssetId == request.AssetId);
        var claim = new WarrantyClaimEntity
        {
            AssetId = asset.AssetId,
            MaintenanceCaseId = maintenanceCase.CaseId,
            VendorName = request.VendorName,
            VendorReference = request.VendorReference,
            DispatchDate = ToUtcDate(request.DispatchDate),
            ExpectedReturnDate = request.ExpectedReturnDate is null ? null : ToUtcDate(request.ExpectedReturnDate.Value),
            Status = nameof(CaseStatus.InProgress)
        };
        dbContext.WarrantyClaims.Add(claim);

        maintenanceCase.Outcome ??= nameof(FaultOutcome.WarrantyClaim);
        maintenanceCase.Status = nameof(CaseStatus.InProgress);
        lifecycle.ChangeState(asset, LifecycleState.WarrantyClaim, CurrentUserId, $"Dispatched to {request.VendorName} under warranty.");

        await dbContext.SaveChangesAsync();
        return Created(string.Empty, Success(ToDto(claim, asset.AssetNo)));
    }

    [HttpPost("{claimId}/close")]
    [Authorize(Roles = Roles.HelpDesk + "," + Roles.FixedAssets + "," + Roles.Administrator)]
    public async Task<ActionResult<ApiResponse<WarrantyClaimDto>>> Close(string claimId, CloseWarrantyClaimRequest request)
    {
        var id = ParseId(claimId);
        var claim = id is null ? null : await dbContext.WarrantyClaims.FirstOrDefaultAsync(c => c.ClaimId == id);
        if (claim is null) return NotFoundFailure("WARRANTY_CLAIM_NOT_FOUND", "warranty claim");
        if (claim.Status == nameof(CaseStatus.Completed)) return Failure(409, "CASE_CLOSED", "This claim is closed.");

        var asset = await dbContext.Assets.FirstAsync(a => a.AssetId == claim.AssetId);
        var maintenanceCase = await dbContext.MaintenanceCases.FirstAsync(c => c.CaseId == claim.MaintenanceCaseId);

        claim.ActualReturnDate = ToUtcDate(request.ActualReturnDate);
        claim.Outcome = request.Outcome;
        claim.Status = nameof(CaseStatus.Completed);
        maintenanceCase.Status = nameof(CaseStatus.Completed);
        maintenanceCase.ClosedAt = DateTime.UtcNow;
        await lifecycle.RestoreAfterRepairAsync(asset, CurrentUserId, $"Returned from {claim.VendorName}: {request.Outcome}.");

        await dbContext.SaveChangesAsync();
        return Ok(Success(ToDto(claim, asset.AssetNo)));
    }

    // BR-8.9-02: alert stages at 90, 60 and 30 days.
    [HttpGet("~/api/v1/warranty/expiring")]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<WarrantyExpiryDto>>>> Expiring([FromQuery] int days = 90) =>
        Ok(Success(await AssetQueries.WarrantyExpiringAsync(ScopeAssets(dbContext.Assets.AsNoTracking()), Math.Clamp(days, 1, 365), lifecycle.Rules.WarrantyAlertDays)));

    [HttpGet("~/api/v1/assets/{assetId}/maintenance-log")]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<MaintenanceLogDto>>>> MaintenanceLog(string assetId)
    {
        if (!await ScopeAssets(dbContext.Assets).AnyAsync(a => a.AssetId == assetId)) return NotFoundFailure("ASSET_NOT_FOUND", "requested asset");

        var logs = await dbContext.MaintenanceLogs.AsNoTracking().Where(l => l.AssetId == assetId).OrderByDescending(l => l.LastServiceDate).ToListAsync();
        return Ok(Success<IReadOnlyList<MaintenanceLogDto>>(logs.Select(ToDto).ToList()));
    }

    // BR-8.9-04.
    [HttpPost("~/api/v1/assets/{assetId}/maintenance-log")]
    [Authorize(Roles = Roles.HelpDesk + "," + Roles.FixedAssets + "," + Roles.Administrator)]
    public async Task<ActionResult<ApiResponse<MaintenanceLogDto>>> AddMaintenanceLog(string assetId, CreateMaintenanceLogRequest request)
    {
        if (!await dbContext.Assets.AnyAsync(a => a.AssetId == assetId)) return NotFoundFailure("ASSET_NOT_FOUND", "requested asset");
        if (request.NextDueDate < request.LastServiceDate)
            return Failure(422, "VALIDATION_ERROR", "The next due date must be after the last service.", new ErrorDetail("nextDueDate", "before last service"));

        var log = new MaintenanceLogEntity
        {
            AssetId = assetId,
            LastServiceDate = ToUtcDate(request.LastServiceDate),
            NextDueDate = request.NextDueDate is null ? null : ToUtcDate(request.NextDueDate.Value),
            ServiceProvider = request.ServiceProvider,
            Notes = request.Notes
        };
        dbContext.MaintenanceLogs.Add(log);
        lifecycle.RecordHistory(assetId, "Serviced", $"Serviced by {request.ServiceProvider}.", CurrentUserId, null, request);
        await dbContext.SaveChangesAsync();
        return Created(string.Empty, Success(ToDto(log)));
    }

    private static WarrantyClaimDto ToDto(WarrantyClaimEntity c, string? assetNo) => new(
        c.ClaimId.ToString(), c.AssetId, assetNo, c.MaintenanceCaseId.ToString(), c.VendorName, c.VendorReference,
        DateOnly.FromDateTime(c.DispatchDate), c.ExpectedReturnDate is null ? null : DateOnly.FromDateTime(c.ExpectedReturnDate.Value),
        c.ActualReturnDate is null ? null : DateOnly.FromDateTime(c.ActualReturnDate.Value), c.Outcome, Enums.Parse<CaseStatus>(c.Status));

    private static MaintenanceLogDto ToDto(MaintenanceLogEntity l) => new(
        l.LogId.ToString(), l.AssetId, DateOnly.FromDateTime(l.LastServiceDate),
        l.NextDueDate is null ? null : DateOnly.FromDateTime(l.NextDueDate.Value), l.ServiceProvider, l.Notes, AsUtc(l.RecordedAt));
}
