using CtrlFind.Contracts;
using CtrlFind.Infrastructure.Persistence;
using CtrlFind.Infrastructure.Persistence.Entities;
using CtrlFind.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CtrlFind.Controllers;

[Route("api/v1/auth")]
public sealed class AuthController(ApplicationDbContext dbContext, TokenService tokens, IPasswordHasher<UserAccountEntity> hasher) : ApiControllerBase
{
    [AllowAnonymous]
    [HttpPost("login")]
    public async Task<ActionResult<ApiResponse<TokenResponse>>> Login(LoginRequest request)
    {
        var account = await dbContext.UserAccounts.FirstOrDefaultAsync(u => u.Email == request.Username.Trim() && u.IsActive);
        if (account is null || hasher.VerifyHashedPassword(account, account.PasswordHash, request.Password) == PasswordVerificationResult.Failed)
            return Failure(401, "INVALID_CREDENTIALS", "The username or password is invalid.");

        return Ok(Success(tokens.Issue(await ProfileAsync(account), request.RememberMe)));
    }

    [AllowAnonymous]
    [HttpPost("refresh")]
    public async Task<ActionResult<ApiResponse<TokenResponse>>> Refresh(RefreshRequest request)
    {
        var owner = tokens.Consume(request.RefreshToken);
        var account = owner is null ? null : await dbContext.UserAccounts.FirstOrDefaultAsync(u => u.UserId == owner.Value.UserId && u.IsActive);
        if (account is null)
            return Failure(401, "INVALID_REFRESH_TOKEN", "The refresh token is invalid, expired, reused, or revoked.");

        return Ok(Success(tokens.Issue(await ProfileAsync(account), familyId: owner!.Value.FamilyId) with { User = null }));
    }

    [HttpPost("logout")]
    public IActionResult Logout(LogoutRequest request)
    {
        tokens.Revoke(request.RefreshToken);
        return Ok(Success(new { revoked = true }));
    }

    [HttpGet("me")]
    public async Task<ActionResult<ApiResponse<UserProfile>>> Me()
    {
        var account = await dbContext.UserAccounts.AsNoTracking().FirstOrDefaultAsync(u => u.UserId == CurrentUserId);
        return account is null ? Failure(401, "UNAUTHORIZED", "The account no longer exists.") : Ok(Success(await ProfileAsync(account)));
    }

    private async Task<UserProfile> ProfileAsync(UserAccountEntity account)
    {
        var employee = await dbContext.Employees.AsNoTracking().FirstOrDefaultAsync(e => e.EmployeeId == account.EmployeeId);
        var locations = string.IsNullOrWhiteSpace(account.LocationIds)
            ? employee?.LocationId is null ? [] : new[] { employee.LocationId }
            : account.LocationIds.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

        return new UserProfile(account.UserId, account.EmployeeId, account.DisplayName, account.Email,
            account.Roles.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries),
            employee?.DepartmentId is null ? [] : [employee.DepartmentId], locations);
    }
}
