using CtrlFind.Infrastructure.Persistence;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CtrlFind.Controllers;

[ApiController]
[Route("api/v1/health")]
public sealed class HealthController(
    ApplicationDbContext dbContext) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Get(
        CancellationToken cancellationToken)
    {
        var canConnect = await dbContext.Database.CanConnectAsync(
            cancellationToken);

        if (!canConnect)
        {
            return StatusCode(StatusCodes.Status503ServiceUnavailable,
                new
                {
                    status = "error",
                    database = "unavailable"
                });
        }

        return Ok(new
        {
            status = "ok",
            database = "SqlServer"
        });
    }
}