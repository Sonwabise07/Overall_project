using CtrlFind.Contracts;
using CtrlFind.Infrastructure.Persistence;
using CtrlFind.Services;
using CtrlFind.Services.Assistant;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CtrlFind.Controllers;

// Natural-language Data Assistant (BRD 8.15). Answers only from this system's data, within the user's access.
[Route("api/v1/assistant")]
public sealed class AssistantController(ApplicationDbContext dbContext, AssistantService assistant) : ApiControllerBase
{
    [HttpPost("query")]
    public async Task<ActionResult<ApiResponse<AssistantQueryResponseDto>>> Query(AssistantQueryRequest request, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.Question))
            return Failure(422, "VALIDATION_ERROR", "Type a question first.", new ErrorDetail("question", "required"));

        var user = new AssistantUser(CurrentUserId, CurrentEmployeeId, User.FindAll("roles").Select(c => c.Value).ToArray());
        return Ok(Success(await assistant.AskAsync(request, ScopeAssets(dbContext.Assets.AsNoTracking()), user, cancellationToken)));
    }

    [HttpGet("catalog")]
    public ActionResult<ApiResponse<IReadOnlyList<AssistantQuestionTypeDto>>> Catalog() => Ok(Success(AssistantService.Catalogue));

    [HttpGet("conversations")]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<AssistantConversationSummaryDto>>>> Conversations() =>
        Ok(Success(await assistant.ConversationsAsync(CurrentUserId)));

    [HttpGet("conversations/{conversationId:guid}")]
    public async Task<ActionResult<ApiResponse<AssistantConversationDto>>> Conversation(Guid conversationId) =>
        await assistant.ConversationAsync(CurrentUserId, conversationId) is { } conversation
            ? Ok(Success(conversation))
            : NotFoundFailure("CONVERSATION_NOT_FOUND", "conversation");

    [HttpDelete("conversations/{conversationId:guid}")]
    public async Task<IActionResult> DeleteConversation(Guid conversationId) =>
        await assistant.DeleteConversationAsync(CurrentUserId, conversationId)
            ? Ok(Success(new { deleted = true }))
            : NotFoundFailure("CONVERSATION_NOT_FOUND", "conversation");

    [HttpPost("feedback")]
    public async Task<IActionResult> Feedback(AssistantFeedbackRequest request) =>
        await assistant.FeedbackAsync(CurrentUserId, request)
            ? Ok(Success(new { recorded = true }))
            : NotFoundFailure("MESSAGE_NOT_FOUND", "answer");

    [HttpGet("unanswered")]
    [Authorize(Roles = Roles.FixedAssets + "," + Roles.Administrator)]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<UnansweredQuestionDto>>>> Unanswered() =>
        Ok(Success(await assistant.UnansweredAsync()));
}
