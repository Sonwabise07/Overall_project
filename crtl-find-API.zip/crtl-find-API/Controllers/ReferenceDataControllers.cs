using CtrlFind.Contracts;
using CtrlFind.Infrastructure.Persistence;
using CtrlFind.Infrastructure.Persistence.Entities;
using CtrlFind.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CtrlFind.Controllers;

[Route("api/v1")]
public sealed class ReferenceDataController(ApplicationDbContext dbContext) : ApiControllerBase
{
    [HttpGet("departments")]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<DepartmentDto>>>> Departments() =>
        Ok(Success<IReadOnlyList<DepartmentDto>>(await dbContext.Departments.AsNoTracking().OrderBy(d => d.Name)
            .Select(d => new DepartmentDto(d.DepartmentId, d.Name)).ToListAsync()));

    [HttpGet("employees")]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<EmployeeDto>>>> Employees([FromQuery] string? search = null, [FromQuery] string? departmentId = null, [FromQuery] bool activeOnly = true)
    {
        var query = dbContext.Employees.AsNoTracking();
        if (activeOnly) query = query.Where(e => e.IsActive);
        if (!string.IsNullOrWhiteSpace(departmentId)) query = query.Where(e => e.DepartmentId == departmentId);
        if (!string.IsNullOrWhiteSpace(search)) query = query.Where(e => e.FullName.Contains(search) || e.EmployeeId.Contains(search));

        var employees = await query.OrderBy(e => e.FullName).Take(50).ToListAsync();
        return Ok(Success<IReadOnlyList<EmployeeDto>>(employees.Select(e => ToDto(e, 0)).ToList()));
    }

    // Includes the negligent-loss count surfaced before a laptop is released (BR-8.3-03).
    [HttpGet("employees/{employeeId}")]
    public async Task<ActionResult<ApiResponse<EmployeeDto>>> Employee(string employeeId)
    {
        var employee = await dbContext.Employees.AsNoTracking().FirstOrDefaultAsync(e => e.EmployeeId == employeeId);
        if (employee is null) return NotFoundFailure("EMPLOYEE_NOT_FOUND", "employee");

        var negligent = await dbContext.Incidents.CountAsync(i => i.ReportedByEmployeeId == employeeId && i.NegligenceStatus == nameof(NegligenceStatus.Negligent));
        return Ok(Success(ToDto(employee, negligent)));
    }

    [HttpGet("locations")]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<LocationSummaryDto>>>> Locations()
    {
        string[] active = [nameof(LifecycleState.Disposed), nameof(LifecycleState.Lost), nameof(LifecycleState.Stolen)];
        var locations = await dbContext.Locations.AsNoTracking()
            .OrderBy(l => l.Region).ThenBy(l => l.Name)
            .Select(l => new LocationSummaryDto(l.LocationId, l.Name, l.Region, l.Building, l.Floor,
                dbContext.Assets.Count(a => a.LocationId == l.LocationId && !active.Contains(a.LifecycleState)),
                dbContext.Storerooms.Count(s => s.LocationId == l.LocationId)))
            .ToListAsync();
        return Ok(Success<IReadOnlyList<LocationSummaryDto>>(locations));
    }

    [HttpGet("storerooms")]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<StoreroomDto>>>> Storerooms() =>
        Ok(Success<IReadOnlyList<StoreroomDto>>(await dbContext.Storerooms.AsNoTracking().OrderBy(s => s.Name)
            .Select(s => new StoreroomDto(s.StoreroomId, s.Name, s.LocationId)).ToListAsync()));

    // BR-8.4-01: standard kit per job role, maintained by Fixed Assets.
    [HttpGet("role-kits")]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<RoleKitDto>>>> RoleKits()
    {
        var items = await dbContext.RoleKitItems.AsNoTracking().OrderBy(k => k.JobRole).ToListAsync();
        return Ok(Success<IReadOnlyList<RoleKitDto>>(items.GroupBy(k => k.JobRole).Select(ToKit).ToList()));
    }

    [HttpPut("role-kits/{jobRole}")]
    [Authorize(Roles = Roles.FixedAssets + "," + Roles.Administrator)]
    public async Task<ActionResult<ApiResponse<RoleKitDto>>> SaveRoleKit(string jobRole, SaveRoleKitRequest request)
    {
        if (request.Items.Any(i => i.Quantity is < 1 or > 10))
            return Failure(422, "VALIDATION_ERROR", "Each kit item needs a quantity from 1 to 10.");
        if (request.Items.GroupBy(i => i.AssetType).Any(g => g.Count() > 1))
            return Failure(422, "VALIDATION_ERROR", "List each asset type once.");

        dbContext.RoleKitItems.RemoveRange(dbContext.RoleKitItems.Where(k => k.JobRole == jobRole));
        var items = request.Items.Select(i => new RoleKitItemEntity { JobRole = jobRole, AssetType = i.AssetType.ToString(), Quantity = i.Quantity }).ToList();
        dbContext.RoleKitItems.AddRange(items);
        await dbContext.SaveChangesAsync();
        return Ok(Success(ToKit(items.GroupBy(k => k.JobRole).Single())));
    }

    private static RoleKitDto ToKit(IGrouping<string, RoleKitItemEntity> group)
    {
        var items = group.Select(k => new RoleKitItemDto(Enums.Parse<AssetType>(k.AssetType), k.Quantity)).ToList();
        return new RoleKitDto(group.Key, items, items.Any(i => i.AssetType == AssetType.Laptop));
    }

    private static EmployeeDto ToDto(EmployeeEntity e, int negligent) =>
        new(e.EmployeeId, e.FullName, e.Email, e.DepartmentId, e.JobRole, e.ManagerEmployeeId, e.LocationId, e.IsActive, negligent);
}

[Route("api/v1/notifications")]
public sealed class NotificationsController(ApplicationDbContext dbContext) : ApiControllerBase
{
    [HttpGet]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<NotificationDto>>>> List([FromQuery] bool unreadOnly = false)
    {
        var query = Mine();
        if (unreadOnly) query = query.Where(n => n.ReadAt == null);
        var rows = await query.OrderByDescending(n => n.CreatedAt).Take(50).ToListAsync();
        return Ok(Success<IReadOnlyList<NotificationDto>>(rows.Select(n =>
            new NotificationDto(n.NotificationId.ToString(), n.Type, n.Title, n.Message, n.AssetId, AsUtc(n.CreatedAt), n.ReadAt is not null)).ToList()));
    }

    [HttpPost("{notificationId}/read")]
    public async Task<IActionResult> MarkRead(string notificationId)
    {
        var id = ParseId(notificationId);
        var notification = id is null ? null : await Mine(tracked: true).FirstOrDefaultAsync(n => n.NotificationId == id);
        if (notification is null) return NotFoundFailure("NOTIFICATION_NOT_FOUND", "notification");

        notification.ReadAt ??= DateTime.UtcNow;
        await dbContext.SaveChangesAsync();
        return Ok(Success(new { read = true }));
    }

    [HttpPost("read-all")]
    public async Task<IActionResult> MarkAllRead()
    {
        var now = DateTime.UtcNow;
        var updated = await Mine(tracked: true).Where(n => n.ReadAt == null).ExecuteUpdateAsync(s => s.SetProperty(n => n.ReadAt, now));
        return Ok(Success(new { updated }));
    }

    // Role-wide notifications are shared: reading one marks it read for that role.
    private IQueryable<NotificationEntity> Mine(bool tracked = false)
    {
        var audiences = User.FindAll("roles").Select(c => c.Value).ToList();
        if (CurrentEmployeeId is not null) audiences.Add(AssetLifecycleService.EmployeeAudience(CurrentEmployeeId));
        var query = tracked ? dbContext.Notifications : dbContext.Notifications.AsNoTracking();
        return query.Where(n => audiences.Contains(n.Audience));
    }
}

// Time-based alerts, calculated on request (DEC-007).
[Route("api/v1/alerts")]
public sealed class AlertsController(ApplicationDbContext dbContext, AlertService alerts) : ApiControllerBase
{
    [HttpGet]
    public async Task<ActionResult<ApiResponse<IReadOnlyList<AlertDto>>>> List() =>
        Ok(Success(await alerts.ListAsync(ScopeAssets(dbContext.Assets.AsNoTracking()),
            includeOperational: HasAnyRole(Roles.FixedAssets, Roles.OfficeManager, Roles.Administrator))));
}
