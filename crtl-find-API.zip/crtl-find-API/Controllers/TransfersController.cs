using CtrlFind.Contracts;
using CtrlFind.Infrastructure.Persistence;
using CtrlFind.Infrastructure.Persistence.Entities;
using CtrlFind.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CtrlFind.Controllers;

// BR-8.5-01 to BR-8.5-03. Approval rules per transfer type: DEC-014. Atom sync: DEC-015.
[Route("api/v1/transfers")]
public sealed class TransfersController(ApplicationDbContext dbContext, AssetLifecycleService lifecycle) : ApiControllerBase
{
    private const string AtomNotConfigured = "NotConfigured";

    [HttpGet]
    public async Task<ActionResult<PageResponse<TransferResponseDto>>> List([FromQuery] CaseStatus? status = null, [FromQuery] int page = 1, [FromQuery] int pageSize = 25)
    {
        page = Math.Max(1, page);
        pageSize = Math.Clamp(pageSize, 1, 100);

        var assets = ScopeAssets(dbContext.Assets.AsNoTracking());
        var query = dbContext.AssetTransfers.AsNoTracking().Where(t => assets.Any(a => a.AssetId == t.AssetId));
        if (status is not null)
        {
            var value = status.Value.ToString();
            query = query.Where(t => t.Status == value);
        }

        var total = await query.CountAsync();
        var rows = await query.OrderByDescending(t => t.RequestedAt)
            .Skip((page - 1) * pageSize).Take(pageSize)
            .Select(t => new { Transfer = t, AssetNo = dbContext.Assets.Where(a => a.AssetId == t.AssetId).Select(a => a.AssetNo).FirstOrDefault() })
            .ToListAsync();

        return Ok(Page(rows.Select(r => ToDto(r.Transfer, r.AssetNo)).ToList(), page, pageSize, total));
    }

    [HttpPost("~/api/v1/assets/{assetId}/transfers")]
    [Authorize(Roles = Roles.Employee + "," + Roles.Manager + "," + Roles.AssetOperators)]
    public async Task<ActionResult<ApiResponse<TransferResponseDto>>> Create(string assetId, CreateTransferRequest request)
    {
        await using var transaction = await dbContext.Database.BeginTransactionAsync();

        var asset = await ScopeAssets(dbContext.Assets).FirstOrDefaultAsync(a => a.AssetId == assetId);
        if (asset is null) return NotFoundFailure("ASSET_NOT_FOUND", "requested asset");

        var targetId = TargetOf(request);
        if (string.IsNullOrWhiteSpace(targetId))
            return Failure(422, "VALIDATION_ERROR", "The selected transfer type requires its matching target field.", new ErrorDetail("transferType", "target is missing"));

        var targetProblem = await ValidateTargetAsync(request.TransferType, targetId, asset);
        if (targetProblem is not null) return targetProblem;

        if (await dbContext.AssetTransfers.AnyAsync(t => t.AssetId == assetId && t.Status == nameof(CaseStatus.PendingApproval)))
            return Failure(409, "TRANSFER_PENDING", "This asset already has a transfer waiting for approval.");

        var requiresApproval = lifecycle.Rules.TransferTypesRequiringApproval.Contains(request.TransferType.ToString(), StringComparer.OrdinalIgnoreCase);

        if (request.TransferType == TransferType.Employee)
        {
            var violation = await lifecycle.CheckLaptopReleaseAsync(asset, targetId, request.CustodyAgreementDocumentId, managerAcknowledged: requiresApproval);
            if (violation is not null) return Failure(violation);
        }

        var transfer = new AssetTransferEntity
        {
            AssetId = assetId,
            TransferType = request.TransferType.ToString(),
            TargetId = targetId,
            FromValue = CurrentValueOf(asset, request.TransferType),
            Status = nameof(CaseStatus.PendingApproval),
            RequestedBy = CurrentUserId,
            Notes = string.Join(Environment.NewLine, new[] { request.Reason, request.Notes }.Where(s => !string.IsNullOrWhiteSpace(s))),
            CustodyAgreementDocumentId = request.CustodyAgreementDocumentId,
            RequestedAt = DateTime.UtcNow
        };
        dbContext.AssetTransfers.Add(transfer);
        lifecycle.RecordHistory(assetId, "TransferRequested", $"{request.TransferType} transfer requested.", CurrentUserId,
            new { transfer.FromValue }, new { request.TransferType, TargetId = targetId, request.RequestedDate, request.Reason });

        if (requiresApproval)
        {
            lifecycle.Notify(Roles.Manager, "TransferApproval", "Transfer awaiting approval",
                $"{asset.AssetNo}: {request.TransferType} transfer from {transfer.FromValue ?? "-"} to {targetId}.", assetId);
        }
        else
        {
            await ApplyAsync(transfer, asset);
        }

        await dbContext.SaveChangesAsync();
        await transaction.CommitAsync();
        return Accepted(Success(ToDto(transfer, asset.AssetNo)));
    }

    [HttpPost("{transferId}/approve")]
    [Authorize(Roles = Roles.Manager + "," + Roles.FixedAssets + "," + Roles.Administrator)]
    public async Task<ActionResult<ApiResponse<TransferResponseDto>>> Approve(string transferId, TransferDecisionRequest request)
    {
        await using var transaction = await dbContext.Database.BeginTransactionAsync();

        var (transfer, asset, problem) = await LoadPendingAsync(transferId);
        if (problem is not null) return problem;

        if (transfer!.TransferType == nameof(TransferType.Employee))
        {
            // The approving manager's decision counts as the acknowledgement required by BR-8.3-03.
            var violation = await lifecycle.CheckLaptopReleaseAsync(asset!, transfer.TargetId, transfer.CustodyAgreementDocumentId, managerAcknowledged: true);
            if (violation is not null) return Failure(violation);
        }

        transfer.DecisionReason = request.Reason;
        await ApplyAsync(transfer, asset!);
        await dbContext.SaveChangesAsync();
        await transaction.CommitAsync();
        return Ok(Success(ToDto(transfer, asset!.AssetNo)));
    }

    [HttpPost("{transferId}/decline")]
    [Authorize(Roles = Roles.Manager + "," + Roles.FixedAssets + "," + Roles.Administrator)]
    public async Task<ActionResult<ApiResponse<TransferResponseDto>>> Decline(string transferId, TransferDecisionRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Reason))
            return Failure(422, "VALIDATION_ERROR", "A reason is required when declining.", new ErrorDetail("reason", "required"));

        var (transfer, asset, problem) = await LoadPendingAsync(transferId);
        if (problem is not null) return problem;

        transfer!.Status = nameof(CaseStatus.Declined);
        transfer.DecidedBy = CurrentUserId;
        transfer.DecisionReason = request.Reason;
        transfer.CompletedAt = DateTime.UtcNow;
        lifecycle.RecordHistory(asset!.AssetId, "TransferDeclined", $"Transfer declined: {request.Reason}", CurrentUserId,
            null, new { transfer.TransferType, transfer.TargetId, request.Reason });

        await dbContext.SaveChangesAsync();
        return Ok(Success(ToDto(transfer, asset.AssetNo)));
    }

    private async Task<(AssetTransferEntity?, AssetEntity?, ObjectResult?)> LoadPendingAsync(string transferId)
    {
        var id = ParseId(transferId);
        var transfer = id is null ? null : await dbContext.AssetTransfers.FirstOrDefaultAsync(t => t.TransferId == id);
        if (transfer is null) return (null, null, NotFoundFailure("TRANSFER_NOT_FOUND", "transfer"));

        if (transfer.Status != nameof(CaseStatus.PendingApproval))
            return (null, null, Failure(409, "TRANSFER_NOT_PENDING", $"This transfer is already {transfer.Status}."));

        // Managers decide only for their own department.
        var asset = await ScopeAssets(dbContext.Assets).FirstOrDefaultAsync(a => a.AssetId == transfer.AssetId);
        if (asset is null) return (null, null, Failure(403, "FORBIDDEN", "This transfer is outside your area."));

        return (transfer, asset, null);
    }

    private async Task ApplyAsync(AssetTransferEntity transfer, AssetEntity asset)
    {
        var type = Enums.Parse<TransferType>(transfer.TransferType);
        switch (type)
        {
            case TransferType.Employee:
                var employee = await dbContext.Employees.AsNoTracking().FirstAsync(e => e.EmployeeId == transfer.TargetId);
                var locationId = asset.LocationId ?? employee.LocationId;
                var location = await dbContext.Locations.AsNoTracking().FirstAsync(l => l.LocationId == locationId);
                await lifecycle.CloseActiveAssignmentAsync(asset);
                lifecycle.Assign(asset, employee, location, DateOnly.FromDateTime(DateTime.UtcNow), transfer.CustodyAgreementDocumentId,
                    asset.Desk, Enums.ParseOrNull<ConditionStatus>(asset.Condition), "Person-to-person transfer", CurrentUserId);
                break;
            case TransferType.Department:
                asset.DepartmentId = transfer.TargetId;
                break;
            case TransferType.Location:
                AssetLifecycleService.ApplyLocation(asset, await dbContext.Locations.AsNoTracking().FirstAsync(l => l.LocationId == transfer.TargetId));
                asset.Desk = null;
                break;
            case TransferType.Desk:
                asset.Desk = transfer.TargetId;
                break;
            case TransferType.Storeroom:
                var storeroom = await dbContext.Storerooms.AsNoTracking().FirstAsync(s => s.StoreroomId == transfer.TargetId);
                await lifecycle.ReturnToStorageAsync(asset, storeroom, Enums.ParseOrNull<ConditionStatus>(asset.Condition) ?? ConditionStatus.Good,
                    CurrentUserId, $"Moved to {storeroom.Name} by transfer.");
                break;
        }

        asset.UpdatedAtUtc = DateTime.UtcNow;
        transfer.Status = nameof(CaseStatus.Completed);
        transfer.DecidedBy = CurrentUserId;
        transfer.CompletedAt = DateTime.UtcNow;
        transfer.AtomSyncStatus = AtomNotConfigured;
        lifecycle.RecordHistory(asset.AssetId, "TransferCompleted", $"{type} transfer completed.", CurrentUserId,
            new { From = transfer.FromValue }, new { To = transfer.TargetId, transfer.TransferType });
    }

    private async Task<ObjectResult?> ValidateTargetAsync(TransferType type, string targetId, AssetEntity asset)
    {
        var exists = type switch
        {
            TransferType.Employee => await dbContext.Employees.AnyAsync(e => e.EmployeeId == targetId && e.IsActive),
            TransferType.Department => await dbContext.Departments.AnyAsync(d => d.DepartmentId == targetId),
            TransferType.Location => await dbContext.Locations.AnyAsync(l => l.LocationId == targetId),
            TransferType.Storeroom => await dbContext.Storerooms.AnyAsync(s => s.StoreroomId == targetId),
            TransferType.Desk => true,
            _ => false
        };
        if (!exists)
            return Failure(422, "VALIDATION_ERROR", "The requested transfer target was not found.", new ErrorDetail("transferType", "target does not exist"));

        if (type == TransferType.Employee && asset.EmployeeId == targetId)
            return Failure(422, "VALIDATION_ERROR", "The asset is already assigned to this employee.");

        if (type is TransferType.Employee or TransferType.Desk && asset.EmployeeId is null)
            return Failure(409, "ASSET_NOT_ASSIGNED", "Only an assigned asset can move between people or desks. Use an assignment instead.");

        return null;
    }

    private static string? TargetOf(CreateTransferRequest request) => request.TransferType switch
    {
        TransferType.Employee => request.TargetEmployeeId,
        TransferType.Department => request.TargetDepartmentId,
        TransferType.Location => request.TargetLocationId,
        TransferType.Desk => request.TargetDesk,
        TransferType.Storeroom => request.TargetStoreroomId,
        _ => null
    };

    private static string? CurrentValueOf(AssetEntity asset, TransferType type) => type switch
    {
        TransferType.Employee => asset.EmployeeId,
        TransferType.Department => asset.DepartmentId,
        TransferType.Location => asset.LocationId,
        TransferType.Desk => asset.Desk,
        TransferType.Storeroom => asset.StoreroomId,
        _ => null
    };

    private static TransferResponseDto ToDto(AssetTransferEntity t, string? assetNo)
    {
        var type = Enums.Parse<TransferType>(t.TransferType);
        return new TransferResponseDto(
            t.TransferId.ToString(), t.AssetId, type, Enums.Parse<CaseStatus>(t.Status),
            type == TransferType.Employee ? t.FromValue : null,
            type == TransferType.Employee ? t.TargetId : null,
            type == TransferType.Location ? t.FromValue : null,
            type == TransferType.Location ? t.TargetId : null,
            t.RequestedBy ?? string.Empty, AsUtc(t.RequestedAt),
            assetNo, t.FromValue, t.TargetId, t.Notes, t.DecidedBy,
            t.CompletedAt is null ? null : AsUtc(t.CompletedAt.Value), t.DecisionReason, t.AtomSyncStatus);
    }
}
