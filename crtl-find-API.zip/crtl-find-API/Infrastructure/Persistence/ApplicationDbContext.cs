
using CtrlFind.Infrastructure.Persistence.Entities;
using Microsoft.EntityFrameworkCore;

namespace CtrlFind.Infrastructure.Persistence;

public sealed class ApplicationDbContext(
    DbContextOptions<ApplicationDbContext> options)
    : DbContext(options)
{
    public DbSet<AssetEntity> Assets => Set<AssetEntity>();
    public DbSet<EmployeeEntity> Employees => Set<EmployeeEntity>();
    public DbSet<DepartmentEntity> Departments => Set<DepartmentEntity>();
    public DbSet<LocationEntity> Locations => Set<LocationEntity>();
    public DbSet<StoreroomEntity> Storerooms => Set<StoreroomEntity>();
    public DbSet<AssetAssignmentEntity> AssetAssignments =>
        Set<AssetAssignmentEntity>();
    public DbSet<AssetHistoryEntity> AssetHistory =>
        Set<AssetHistoryEntity>();
    public DbSet<AssetTransferEntity> AssetTransfers =>
        Set<AssetTransferEntity>();
    public DbSet<AssetDocumentEntity> AssetDocuments =>
    Set<AssetDocumentEntity>();
    public DbSet<RoleKitItemEntity> RoleKitItems => Set<RoleKitItemEntity>();
    public DbSet<OnboardingCaseEntity> OnboardingCases => Set<OnboardingCaseEntity>();
    public DbSet<OnboardingReservationEntity> OnboardingReservations => Set<OnboardingReservationEntity>();
    public DbSet<OffboardingCaseEntity> OffboardingCases => Set<OffboardingCaseEntity>();
    public DbSet<OffboardingItemEntity> OffboardingItems => Set<OffboardingItemEntity>();
    public DbSet<MaintenanceCaseEntity> MaintenanceCases => Set<MaintenanceCaseEntity>();
    public DbSet<WarrantyClaimEntity> WarrantyClaims => Set<WarrantyClaimEntity>();
    public DbSet<MaintenanceLogEntity> MaintenanceLogs => Set<MaintenanceLogEntity>();
    public DbSet<IncidentEntity> Incidents => Set<IncidentEntity>();
    public DbSet<AodRecordEntity> AodRecords => Set<AodRecordEntity>();
    public DbSet<AodPaymentEntity> AodPayments => Set<AodPaymentEntity>();
    public DbSet<AuditEntity> Audits => Set<AuditEntity>();
    public DbSet<AuditItemEntity> AuditItems => Set<AuditItemEntity>();
    public DbSet<TakeHomeEntity> TakeHomes => Set<TakeHomeEntity>();
    public DbSet<EmergencySwapEntity> EmergencySwaps => Set<EmergencySwapEntity>();
    public DbSet<DisposalEntity> Disposals => Set<DisposalEntity>();
    public DbSet<StockThresholdEntity> StockThresholds => Set<StockThresholdEntity>();
    public DbSet<StockCountEntity> StockCounts => Set<StockCountEntity>();
    public DbSet<StockMovementEntity> StockMovements => Set<StockMovementEntity>();
    public DbSet<NotificationEntity> Notifications => Set<NotificationEntity>();
    public DbSet<UserAccountEntity> UserAccounts => Set<UserAccountEntity>();
    public DbSet<AssistantConversationEntity> AssistantConversations => Set<AssistantConversationEntity>();
    public DbSet<AssistantMessageEntity> AssistantMessages => Set<AssistantMessageEntity>();
    public DbSet<AssistantQuestionLogEntity> AssistantQuestionLog => Set<AssistantQuestionLogEntity>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        ConfigureReferenceEntities(modelBuilder);
        ConfigureAssets(modelBuilder);
        ConfigureAssignments(modelBuilder);
        ConfigureHistory(modelBuilder);
        ConfigureTransfers(modelBuilder);
        ConfigureOnboarding(modelBuilder);
        ConfigureCases(modelBuilder);
        ConfigureStockAndSystem(modelBuilder);
        ConfigureAssistant(modelBuilder);

        modelBuilder.HasSequence<long>("AssetNumbers").StartsAt(1000);


        modelBuilder.Entity<AssetDocumentEntity>(entity =>
        {
            entity.ToTable("AssetDocuments");
            entity.HasKey(x => x.DocumentId);

            entity.Property(x => x.DocumentId)
                .HasMaxLength(64);

            entity.Property(x => x.AssetId)
                .HasMaxLength(64)
                .IsRequired();

            entity.Property(x => x.DocumentType)
                .HasMaxLength(50)
                .IsRequired();

            entity.Property(x => x.FileName)
                .HasMaxLength(255)
                .IsRequired();

            entity.Property(x => x.ContentType)
                .HasMaxLength(150)
                .IsRequired();

            entity.Property(x => x.FileSizeBytes)
                .IsRequired();

            entity.Property(x => x.UploadedByUserId)
                .HasMaxLength(200)
                .IsRequired();

            entity.Property(x => x.DownloadUrl)
                .HasMaxLength(1000)
                .IsRequired();

            entity.Property(x => x.Description)
                .HasMaxLength(2000);

            entity.Property(x => x.UploadedAt)
                .HasColumnType("datetime2");

            entity.Property(x => x.CapturedAt)
                .HasColumnType("datetime2");

            entity.HasOne<AssetEntity>()
                .WithMany()
                .HasForeignKey(x => x.AssetId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasIndex(x => new
            {
                x.AssetId,
                x.UploadedAt
            });
        });



    }

    private static void ConfigureAssets(ModelBuilder modelBuilder)
    {
        var entity = modelBuilder.Entity<AssetEntity>();

        entity.ToTable("Assets");
        entity.HasKey(x => x.AssetId);

        entity.Property(x => x.AssetId).HasMaxLength(64);
        entity.Property(x => x.AssetNo).HasMaxLength(50).IsRequired();
        entity.Property(x => x.AssetTag).HasMaxLength(100);
        entity.Property(x => x.SerialNumber).HasMaxLength(150);
        entity.Property(x => x.AssetType).HasMaxLength(100).IsRequired();
        entity.Property(x => x.Make).HasMaxLength(100);
        entity.Property(x => x.Model).HasMaxLength(150);
        entity.Property(x => x.LifecycleState).HasMaxLength(50).IsRequired();
        entity.Property(x => x.OperationalStatus).HasMaxLength(50).IsRequired();
        entity.Property(x => x.EmployeeId).HasMaxLength(64);
        entity.Property(x => x.EmployeeName).HasMaxLength(200);
        entity.Property(x => x.LocationId).HasMaxLength(64);
        entity.Property(x => x.Region).HasMaxLength(100);
        entity.Property(x => x.Building).HasMaxLength(150);
        entity.Property(x => x.Floor).HasMaxLength(50);
        entity.Property(x => x.DepartmentId).HasMaxLength(64);
        entity.Property(x => x.StoreroomId).HasMaxLength(64);
        entity.Property(x => x.PurchaseCost).HasColumnType("decimal(18,2)");
        entity.Property(x => x.Category).HasMaxLength(100);
        entity.Property(x => x.CompanyEntity).HasMaxLength(150);
        entity.Property(x => x.CostCentre).HasMaxLength(50);

        entity.Property(x => x.PurchaseOrder).HasMaxLength(100);
        entity.Property(x => x.InvoiceReference).HasMaxLength(100);

        entity.Property(x => x.AuditOutcome).HasMaxLength(50);
        entity.Property(x => x.EncryptionStatus).HasMaxLength(50);

        entity.Property(x => x.Notes).HasMaxLength(2000);
        entity.Property(x => x.LocationSubStatus).HasMaxLength(20);
        entity.Property(x => x.Desk).HasMaxLength(50);
        entity.Property(x => x.WarrantyVendor).HasMaxLength(150);
        entity.Property(x => x.Condition).HasMaxLength(20);

        entity.Property(x => x.RowVersion)
            .IsRowVersion();

        entity.HasIndex(x => x.AssetNo)
            .IsUnique();

        entity.HasIndex(x => x.AssetTag);
        entity.HasIndex(x => x.SerialNumber);
        entity.HasIndex(x => x.EmployeeId);
        entity.HasIndex(x => new { x.LifecycleState, x.AssetType });

        entity.ToTable("Assets", table =>
            table.HasCheckConstraint(
                "CK_Assets_PurchaseCost_NonNegative",
                "[PurchaseCost] IS NULL OR [PurchaseCost] >= 0"));
    }
    private static void ConfigureReferenceEntities(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<EmployeeEntity>(entity =>
        {
            entity.ToTable("Employees");
            entity.HasKey(x => x.EmployeeId);

            entity.Property(x => x.EmployeeId).HasMaxLength(64);
            entity.Property(x => x.FullName).HasMaxLength(200).IsRequired();
            entity.Property(x => x.Email).HasMaxLength(320);
            entity.Property(x => x.DepartmentId).HasMaxLength(64);
            entity.Property(x => x.JobRole).HasMaxLength(100);
            entity.Property(x => x.ManagerEmployeeId).HasMaxLength(64);
            entity.Property(x => x.LocationId).HasMaxLength(64);
        });

        modelBuilder.Entity<DepartmentEntity>(entity =>
        {
            entity.ToTable("Departments");
            entity.HasKey(x => x.DepartmentId);

            entity.Property(x => x.DepartmentId).HasMaxLength(64);
            entity.Property(x => x.Name).HasMaxLength(200).IsRequired();
        });

        modelBuilder.Entity<LocationEntity>(entity =>
        {
            entity.ToTable("Locations");
            entity.HasKey(x => x.LocationId);

            entity.Property(x => x.LocationId).HasMaxLength(64);
            entity.Property(x => x.Name).HasMaxLength(200).IsRequired();
            entity.Property(x => x.Region).HasMaxLength(100);
            entity.Property(x => x.Building).HasMaxLength(150);
            entity.Property(x => x.Floor).HasMaxLength(50);
        });

        modelBuilder.Entity<StoreroomEntity>(entity =>
        {
            entity.ToTable("Storerooms");
            entity.HasKey(x => x.StoreroomId);

            entity.Property(x => x.StoreroomId).HasMaxLength(64);
            entity.Property(x => x.Name).HasMaxLength(200).IsRequired();
            entity.Property(x => x.LocationId).HasMaxLength(64);
        });
    }
    private static void ConfigureAssignments(ModelBuilder modelBuilder)
    {
        var entity = modelBuilder.Entity<AssetAssignmentEntity>();

        entity.ToTable("AssetAssignments");
        entity.HasKey(x => x.AssignmentId);

        entity.Property(x => x.AssetId).HasMaxLength(64).IsRequired();
        entity.Property(x => x.EmployeeId).HasMaxLength(64).IsRequired();
        entity.Property(x => x.EmployeeName).HasMaxLength(200);
        entity.Property(x => x.CustodyAgreementReference).HasMaxLength(200);
        entity.Property(x => x.AssignedBy).HasMaxLength(200);

        entity.HasOne<AssetEntity>()
            .WithMany()
            .HasForeignKey(x => x.AssetId)
            .OnDelete(DeleteBehavior.Restrict);

        entity.HasIndex(x => new { x.AssetId, x.AssignedAt });
        entity.Property(x => x.LocationId).HasMaxLength(64);
        entity.Property(x => x.Notes).HasMaxLength(2000);
    }

    private static void ConfigureHistory(ModelBuilder modelBuilder)
    {
        var entity = modelBuilder.Entity<AssetHistoryEntity>();

        entity.ToTable("AssetHistory");
        entity.HasKey(x => x.HistoryId);

        entity.Property(x => x.AssetId).HasMaxLength(64).IsRequired();
        entity.Property(x => x.Action).HasMaxLength(100).IsRequired();
        entity.Property(x => x.ChangedBy).HasMaxLength(200);
        entity.Property(x => x.Summary).HasMaxLength(2000);
        entity.Property(x => x.DetailsJson);

        entity.HasOne<AssetEntity>()
            .WithMany()
            .HasForeignKey(x => x.AssetId)
            .OnDelete(DeleteBehavior.Restrict);

        entity.HasIndex(x => new { x.AssetId, x.ChangedAt });
    }

    private static void ConfigureTransfers(ModelBuilder modelBuilder)
    {
        var entity = modelBuilder.Entity<AssetTransferEntity>();

        entity.ToTable("AssetTransfers");
        entity.HasKey(x => x.TransferId);

        entity.Property(x => x.AssetId).HasMaxLength(64).IsRequired();
        entity.Property(x => x.TransferType).HasMaxLength(50).IsRequired();
        entity.Property(x => x.TargetId).HasMaxLength(64).IsRequired();
        entity.Property(x => x.Status).HasMaxLength(50).IsRequired();
        entity.Property(x => x.RequestedBy).HasMaxLength(200);
        entity.Property(x => x.Notes).HasMaxLength(2000);
        entity.Property(x => x.FromValue).HasMaxLength(200);
        entity.Property(x => x.CustodyAgreementDocumentId).HasMaxLength(64);
        entity.Property(x => x.DecidedBy).HasMaxLength(200);
        entity.Property(x => x.DecisionReason).HasMaxLength(2000);
        entity.Property(x => x.AtomSyncStatus).HasMaxLength(30);

        entity.HasOne<AssetEntity>()
            .WithMany()
            .HasForeignKey(x => x.AssetId)
            .OnDelete(DeleteBehavior.Restrict);

        entity.HasIndex(x => new { x.AssetId, x.Status });
    }

    private static void ConfigureOnboarding(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<RoleKitItemEntity>(entity =>
        {
            entity.ToTable("RoleKitItems");
            entity.HasKey(x => x.RoleKitItemId);
            entity.Property(x => x.JobRole).HasMaxLength(100).IsRequired();
            entity.Property(x => x.AssetType).HasMaxLength(100).IsRequired();
            entity.HasIndex(x => new { x.JobRole, x.AssetType }).IsUnique();
        });

        modelBuilder.Entity<OnboardingCaseEntity>(entity =>
        {
            entity.ToTable("OnboardingCases");
            entity.HasKey(x => x.CaseId);
            entity.Property(x => x.EmployeeId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.EmployeeName).HasMaxLength(200).IsRequired();
            entity.Property(x => x.DepartmentId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.ManagerEmployeeId).HasMaxLength(64);
            entity.Property(x => x.JobRole).HasMaxLength(100).IsRequired();
            entity.Property(x => x.LocationId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.Status).HasMaxLength(30).IsRequired();
            entity.Property(x => x.Notes).HasMaxLength(2000);
            entity.HasIndex(x => x.EmployeeId);
        });

        modelBuilder.Entity<OnboardingReservationEntity>(entity =>
        {
            entity.ToTable("OnboardingReservations");
            entity.HasKey(x => x.ReservationId);
            entity.Property(x => x.AssetId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.AssetType).HasMaxLength(100).IsRequired();
            entity.HasOne<OnboardingCaseEntity>().WithMany().HasForeignKey(x => x.CaseId).OnDelete(DeleteBehavior.Cascade);
            entity.HasOne<AssetEntity>().WithMany().HasForeignKey(x => x.AssetId).OnDelete(DeleteBehavior.Restrict);
            // One open reservation per asset prevents double allocation (BR-8.4-04).
            entity.HasIndex(x => x.AssetId).IsUnique().HasFilter("[ReleasedAt] IS NULL AND [IssuedAt] IS NULL");
        });
    }

    private static void ConfigureCases(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<OffboardingCaseEntity>(entity =>
        {
            entity.ToTable("OffboardingCases");
            entity.HasKey(x => x.CaseId);
            entity.Property(x => x.EmployeeId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.Source).HasMaxLength(50).IsRequired();
            entity.Property(x => x.Reason).HasMaxLength(500).IsRequired();
            entity.Property(x => x.Notes).HasMaxLength(2000);
            entity.Property(x => x.Status).HasMaxLength(30).IsRequired();
            entity.HasIndex(x => x.EmployeeId);
        });

        modelBuilder.Entity<OffboardingItemEntity>(entity =>
        {
            entity.ToTable("OffboardingItems");
            entity.HasKey(x => x.ItemId);
            entity.Property(x => x.AssetId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.Resolution).HasMaxLength(30);
            entity.Property(x => x.Condition).HasMaxLength(20);
            entity.Property(x => x.Notes).HasMaxLength(2000);
            entity.Property(x => x.ResolvedBy).HasMaxLength(200);
            entity.HasOne<OffboardingCaseEntity>().WithMany().HasForeignKey(x => x.CaseId).OnDelete(DeleteBehavior.Cascade);
            entity.HasOne<AssetEntity>().WithMany().HasForeignKey(x => x.AssetId).OnDelete(DeleteBehavior.Restrict);
            entity.HasIndex(x => new { x.CaseId, x.AssetId }).IsUnique();
        });

        modelBuilder.Entity<MaintenanceCaseEntity>(entity =>
        {
            entity.ToTable("MaintenanceCases");
            entity.HasKey(x => x.CaseId);
            entity.Property(x => x.AssetId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.Classification).HasMaxLength(30).IsRequired();
            entity.Property(x => x.ReportedByEmployeeId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.ZendeskTicketId).HasMaxLength(50).IsRequired();
            entity.Property(x => x.Description).HasMaxLength(2000).IsRequired();
            entity.Property(x => x.Status).HasMaxLength(30).IsRequired();
            entity.Property(x => x.Diagnosis).HasMaxLength(2000);
            entity.Property(x => x.RepairabilityDecision).HasMaxLength(30);
            entity.Property(x => x.EstimatedRepairCost).HasColumnType("decimal(18,2)");
            entity.Property(x => x.Outcome).HasMaxLength(30);
            entity.Property(x => x.ReplacementAssetId).HasMaxLength(64);
            entity.Property(x => x.Notes).HasMaxLength(2000);
            entity.HasOne<AssetEntity>().WithMany().HasForeignKey(x => x.AssetId).OnDelete(DeleteBehavior.Restrict);
            entity.HasIndex(x => new { x.AssetId, x.Status });
        });

        modelBuilder.Entity<WarrantyClaimEntity>(entity =>
        {
            entity.ToTable("WarrantyClaims");
            entity.HasKey(x => x.ClaimId);
            entity.Property(x => x.AssetId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.VendorName).HasMaxLength(150).IsRequired();
            entity.Property(x => x.VendorReference).HasMaxLength(100);
            entity.Property(x => x.Outcome).HasMaxLength(500);
            entity.Property(x => x.Status).HasMaxLength(30).IsRequired();
            entity.HasOne<AssetEntity>().WithMany().HasForeignKey(x => x.AssetId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne<MaintenanceCaseEntity>().WithMany().HasForeignKey(x => x.MaintenanceCaseId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<MaintenanceLogEntity>(entity =>
        {
            entity.ToTable("MaintenanceLogs");
            entity.HasKey(x => x.LogId);
            entity.Property(x => x.AssetId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.ServiceProvider).HasMaxLength(150).IsRequired();
            entity.Property(x => x.Notes).HasMaxLength(2000);
            entity.HasOne<AssetEntity>().WithMany().HasForeignKey(x => x.AssetId).OnDelete(DeleteBehavior.Restrict);
            entity.HasIndex(x => new { x.AssetId, x.LastServiceDate });
        });

        modelBuilder.Entity<IncidentEntity>(entity =>
        {
            entity.ToTable("Incidents");
            entity.HasKey(x => x.IncidentId);
            entity.Property(x => x.AssetId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.IncidentType).HasMaxLength(20).IsRequired();
            entity.Property(x => x.ReportedByEmployeeId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.LocationDescription).HasMaxLength(500).IsRequired();
            entity.Property(x => x.Statement).HasMaxLength(4000).IsRequired();
            entity.Property(x => x.PoliceCaseNumber).HasMaxLength(50);
            entity.Property(x => x.NegligenceStatus).HasMaxLength(30).IsRequired();
            entity.Property(x => x.DecisionReason).HasMaxLength(2000);
            entity.Property(x => x.DecidedBy).HasMaxLength(200);
            entity.Property(x => x.Status).HasMaxLength(30).IsRequired();
            entity.HasOne<AssetEntity>().WithMany().HasForeignKey(x => x.AssetId).OnDelete(DeleteBehavior.Restrict);
            entity.HasIndex(x => x.ReportedByEmployeeId);
        });

        modelBuilder.Entity<AodRecordEntity>(entity =>
        {
            entity.ToTable("AodRecords");
            entity.HasKey(x => x.AodId);
            entity.Property(x => x.EmployeeId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.AssetId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.Amount).HasColumnType("decimal(18,2)");
            entity.Property(x => x.RecoveredAmount).HasColumnType("decimal(18,2)");
            entity.Property(x => x.RecoveryTerms).HasMaxLength(1000).IsRequired();
            entity.Property(x => x.Status).HasMaxLength(30).IsRequired();
            entity.HasOne<IncidentEntity>().WithMany().HasForeignKey(x => x.IncidentId).OnDelete(DeleteBehavior.Restrict);
            entity.HasIndex(x => x.IncidentId).IsUnique();
        });

        modelBuilder.Entity<AodPaymentEntity>(entity =>
        {
            entity.ToTable("AodPayments");
            entity.HasKey(x => x.PaymentId);
            entity.Property(x => x.Amount).HasColumnType("decimal(18,2)");
            entity.Property(x => x.Reference).HasMaxLength(100);
            entity.Property(x => x.RecordedBy).HasMaxLength(200).IsRequired();
            entity.HasOne<AodRecordEntity>().WithMany().HasForeignKey(x => x.AodId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<AuditEntity>(entity =>
        {
            entity.ToTable("Audits");
            entity.HasKey(x => x.AuditId);
            entity.Property(x => x.AuditName).HasMaxLength(200).IsRequired();
            entity.Property(x => x.LocationIds).HasMaxLength(1000);
            entity.Property(x => x.DepartmentIds).HasMaxLength(1000);
            entity.Property(x => x.AssetTypes).HasMaxLength(1000);
            entity.Property(x => x.Notes).HasMaxLength(2000);
            entity.Property(x => x.Status).HasMaxLength(30).IsRequired();
            entity.Property(x => x.CreatedBy).HasMaxLength(200).IsRequired();
        });

        modelBuilder.Entity<AuditItemEntity>(entity =>
        {
            entity.ToTable("AuditItems");
            entity.HasKey(x => x.AuditItemId);
            entity.Property(x => x.AssetId).HasMaxLength(64);
            entity.Property(x => x.Method).HasMaxLength(30).IsRequired();
            entity.Property(x => x.ReasonFlagged).HasMaxLength(200);
            entity.Property(x => x.Outcome).HasMaxLength(30);
            entity.Property(x => x.ScannedTag).HasMaxLength(100);
            entity.Property(x => x.ScannedSerial).HasMaxLength(150);
            entity.Property(x => x.ScannedLocationId).HasMaxLength(64);
            entity.Property(x => x.Condition).HasMaxLength(20);
            entity.Property(x => x.Resolution).HasMaxLength(2000);
            entity.Property(x => x.ResolvedBy).HasMaxLength(200);
            entity.Property(x => x.CheckedBy).HasMaxLength(200);
            entity.HasOne<AuditEntity>().WithMany().HasForeignKey(x => x.AuditId).OnDelete(DeleteBehavior.Cascade);
            entity.HasIndex(x => new { x.AuditId, x.AssetId });
        });

        modelBuilder.Entity<TakeHomeEntity>(entity =>
        {
            entity.ToTable("TakeHomes");
            entity.HasKey(x => x.TakeHomeId);
            entity.Property(x => x.AssetId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.EmployeeId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.IssueCondition).HasMaxLength(20).IsRequired();
            entity.Property(x => x.IssuePhotoDocumentId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.ReturnCondition).HasMaxLength(20);
            entity.Property(x => x.ReturnPhotoDocumentId).HasMaxLength(64);
            entity.Property(x => x.DamageReviewOutcome).HasMaxLength(2000);
            entity.Property(x => x.Notes).HasMaxLength(2000);
            entity.HasOne<AssetEntity>().WithMany().HasForeignKey(x => x.AssetId).OnDelete(DeleteBehavior.Restrict);
            entity.HasIndex(x => x.AssetId);
        });

        modelBuilder.Entity<EmergencySwapEntity>(entity =>
        {
            entity.ToTable("EmergencySwaps");
            entity.HasKey(x => x.SwapId);
            entity.Property(x => x.EmployeeId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.OriginalAssetId).HasMaxLength(64);
            entity.Property(x => x.TemporaryAssetId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.IssueDescription).HasMaxLength(2000).IsRequired();
            entity.Property(x => x.Status).HasMaxLength(30).IsRequired();
            entity.Property(x => x.Resolution).HasMaxLength(2000);
            entity.Property(x => x.CreatedBy).HasMaxLength(200).IsRequired();
            entity.HasOne<AssetEntity>().WithMany().HasForeignKey(x => x.TemporaryAssetId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<DisposalEntity>(entity =>
        {
            entity.ToTable("Disposals");
            entity.HasKey(x => x.DisposalId);
            entity.Property(x => x.AssetId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.Reason).HasMaxLength(500).IsRequired();
            entity.Property(x => x.Method).HasMaxLength(200).IsRequired();
            entity.Property(x => x.CertificateDocumentId).HasMaxLength(64);
            entity.Property(x => x.Notes).HasMaxLength(2000);
            entity.Property(x => x.RecordedBy).HasMaxLength(200).IsRequired();
            entity.HasOne<AssetEntity>().WithMany().HasForeignKey(x => x.AssetId).OnDelete(DeleteBehavior.Restrict);
            entity.HasIndex(x => x.AssetId).IsUnique();
        });
    }

    private static void ConfigureStockAndSystem(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<StockThresholdEntity>(entity =>
        {
            entity.ToTable("StockThresholds");
            entity.HasKey(x => x.AssetType);
            entity.Property(x => x.AssetType).HasMaxLength(100);
        });

        modelBuilder.Entity<StockCountEntity>(entity =>
        {
            entity.ToTable("StockCounts");
            entity.HasKey(x => x.CountId);
            entity.Property(x => x.StoreroomId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.CountType).HasMaxLength(20).IsRequired();
            entity.Property(x => x.Notes).HasMaxLength(2000);
            entity.Property(x => x.RecordedBy).HasMaxLength(200).IsRequired();
            entity.HasIndex(x => new { x.StoreroomId, x.CountDate });
        });

        modelBuilder.Entity<StockMovementEntity>(entity =>
        {
            entity.ToTable("StockMovements");
            entity.HasKey(x => x.MovementId);
            entity.Property(x => x.StoreroomId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.AssetId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.Direction).HasMaxLength(10).IsRequired();
            entity.Property(x => x.Reason).HasMaxLength(100).IsRequired();
            entity.HasIndex(x => new { x.StoreroomId, x.MovedAt });
        });

        modelBuilder.Entity<NotificationEntity>(entity =>
        {
            entity.ToTable("Notifications");
            entity.HasKey(x => x.NotificationId);
            entity.Property(x => x.Audience).HasMaxLength(100).IsRequired();
            entity.Property(x => x.Type).HasMaxLength(50).IsRequired();
            entity.Property(x => x.Title).HasMaxLength(200).IsRequired();
            entity.Property(x => x.Message).HasMaxLength(2000).IsRequired();
            entity.Property(x => x.AssetId).HasMaxLength(64);
            entity.HasIndex(x => new { x.Audience, x.CreatedAt });
        });

        modelBuilder.Entity<UserAccountEntity>(entity =>
        {
            entity.ToTable("UserAccounts");
            entity.HasKey(x => x.UserId);
            entity.Property(x => x.UserId).HasMaxLength(64);
            entity.Property(x => x.Email).HasMaxLength(320).IsRequired();
            entity.Property(x => x.DisplayName).HasMaxLength(200).IsRequired();
            entity.Property(x => x.PasswordHash).HasMaxLength(500).IsRequired();
            entity.Property(x => x.EmployeeId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.Roles).HasMaxLength(500).IsRequired();
            entity.Property(x => x.LocationIds).HasMaxLength(500);
            entity.HasIndex(x => x.Email).IsUnique();
        });
    }

    private static void ConfigureAssistant(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AssistantConversationEntity>(entity =>
        {
            entity.ToTable("Conversations", "assistant");
            entity.HasKey(x => x.ConversationId);
            entity.Property(x => x.OwnerId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.Title).HasMaxLength(200).IsRequired();
            entity.HasIndex(x => new { x.OwnerId, x.UpdatedAtUtc });
        });

        modelBuilder.Entity<AssistantMessageEntity>(entity =>
        {
            entity.ToTable("Messages", "assistant");
            entity.HasKey(x => x.MessageId);
            entity.Property(x => x.Role).HasMaxLength(12).IsRequired();
            entity.Property(x => x.Content).IsRequired();
            entity.HasOne<AssistantConversationEntity>().WithMany().HasForeignKey(x => x.ConversationId).OnDelete(DeleteBehavior.Cascade);
            entity.HasIndex(x => new { x.ConversationId, x.CreatedAtUtc });
        });

        modelBuilder.Entity<AssistantQuestionLogEntity>(entity =>
        {
            entity.ToTable("QuestionLog", "assistant");
            entity.HasKey(x => x.LogId);
            entity.Property(x => x.UserId).HasMaxLength(64).IsRequired();
            entity.Property(x => x.Question).HasMaxLength(500).IsRequired();
            entity.Property(x => x.Intent).HasMaxLength(50).IsRequired();
            entity.Property(x => x.Comment).HasMaxLength(500);
            entity.HasIndex(x => new { x.Answered, x.CreatedAtUtc });
        });
    }
}
