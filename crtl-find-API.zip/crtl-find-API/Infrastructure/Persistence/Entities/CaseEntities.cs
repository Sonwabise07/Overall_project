namespace CtrlFind.Infrastructure.Persistence.Entities;

public sealed class OffboardingCaseEntity
{
    public long CaseId { get; set; }
    public string EmployeeId { get; set; } = string.Empty;
    public DateTime ExitDate { get; set; }
    public string Source { get; set; } = string.Empty;
    public string Reason { get; set; } = string.Empty;
    public string? Notes { get; set; }
    public string Status { get; set; } = "InProgress";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? CompletedAt { get; set; }
}

public sealed class OffboardingItemEntity
{
    public long ItemId { get; set; }
    public long CaseId { get; set; }
    public string AssetId { get; set; } = string.Empty;
    public string? Resolution { get; set; }
    public string? Condition { get; set; }
    public string? Notes { get; set; }
    public string? ResolvedBy { get; set; }
    public DateTime? ResolvedAt { get; set; }
}

public sealed class MaintenanceCaseEntity
{
    public long CaseId { get; set; }
    public string AssetId { get; set; } = string.Empty;
    public string Classification { get; set; } = string.Empty;
    public string ReportedByEmployeeId { get; set; } = string.Empty;
    public string ZendeskTicketId { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public DateTime ReportedAt { get; set; }
    public bool CostRecoveryReview { get; set; }
    public string Status { get; set; } = "Open";
    public string? Diagnosis { get; set; }
    public string? RepairabilityDecision { get; set; }
    public decimal? EstimatedRepairCost { get; set; }
    public string? Outcome { get; set; }
    public string? ReplacementAssetId { get; set; }
    public string? Notes { get; set; }
    public DateTime? ClosedAt { get; set; }
}

public sealed class WarrantyClaimEntity
{
    public long ClaimId { get; set; }
    public string AssetId { get; set; } = string.Empty;
    public long MaintenanceCaseId { get; set; }
    public string VendorName { get; set; } = string.Empty;
    public string? VendorReference { get; set; }
    public DateTime DispatchDate { get; set; }
    public DateTime? ExpectedReturnDate { get; set; }
    public DateTime? ActualReturnDate { get; set; }
    public string? Outcome { get; set; }
    public string Status { get; set; } = "Open";
}

public sealed class MaintenanceLogEntity
{
    public long LogId { get; set; }
    public string AssetId { get; set; } = string.Empty;
    public DateTime LastServiceDate { get; set; }
    public DateTime? NextDueDate { get; set; }
    public string ServiceProvider { get; set; } = string.Empty;
    public string? Notes { get; set; }
    public DateTime RecordedAt { get; set; } = DateTime.UtcNow;
}

public sealed class IncidentEntity
{
    public long IncidentId { get; set; }
    public string AssetId { get; set; } = string.Empty;
    public string IncidentType { get; set; } = string.Empty;
    public string ReportedByEmployeeId { get; set; } = string.Empty;
    public DateTime IncidentDate { get; set; }
    public string LocationDescription { get; set; } = string.Empty;
    public string Statement { get; set; } = string.Empty;
    public string? PoliceCaseNumber { get; set; }
    public string NegligenceStatus { get; set; } = "UnderInvestigation";
    public string? DecisionReason { get; set; }
    public string? DecidedBy { get; set; }
    public string Status { get; set; } = "Open";
    public bool EscalatedToHr { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public sealed class AodRecordEntity
{
    public long AodId { get; set; }
    public long IncidentId { get; set; }
    public string EmployeeId { get; set; } = string.Empty;
    public string AssetId { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string RecoveryTerms { get; set; } = string.Empty;
    public decimal RecoveredAmount { get; set; }
    public string Status { get; set; } = "Open";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public sealed class AodPaymentEntity
{
    public long PaymentId { get; set; }
    public long AodId { get; set; }
    public decimal Amount { get; set; }
    public DateTime PaidOn { get; set; }
    public string? Reference { get; set; }
    public string RecordedBy { get; set; } = string.Empty;
    public DateTime RecordedAt { get; set; } = DateTime.UtcNow;
}

public sealed class AuditEntity
{
    public long AuditId { get; set; }
    public string AuditName { get; set; } = string.Empty;
    public string? LocationIds { get; set; }
    public string? DepartmentIds { get; set; }
    public string? AssetTypes { get; set; }
    public DateTime ScheduledStartDate { get; set; }
    public DateTime ScheduledEndDate { get; set; }
    public bool FullScope { get; set; }
    public string? Notes { get; set; }
    public string Status { get; set; } = "Scheduled";
    public bool SelfConfirmationsSent { get; set; }
    public string CreatedBy { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? ClosedAt { get; set; }
}

public sealed class AuditItemEntity
{
    public long AuditItemId { get; set; }
    public long AuditId { get; set; }
    public string? AssetId { get; set; }
    public string Method { get; set; } = "PhysicalScan";
    public string? ReasonFlagged { get; set; }
    public string? Outcome { get; set; }
    public string? ScannedTag { get; set; }
    public string? ScannedSerial { get; set; }
    public string? ScannedLocationId { get; set; }
    public string? Condition { get; set; }
    public bool RequiresInvestigation { get; set; }
    public string? Resolution { get; set; }
    public string? ResolvedBy { get; set; }
    public DateTime? ResolvedAt { get; set; }
    public string? CheckedBy { get; set; }
    public DateTime? CheckedAt { get; set; }
}

public sealed class TakeHomeEntity
{
    public long TakeHomeId { get; set; }
    public string AssetId { get; set; } = string.Empty;
    public string EmployeeId { get; set; } = string.Empty;
    public DateTime IssuedAt { get; set; } = DateTime.UtcNow;
    public string IssueCondition { get; set; } = string.Empty;
    public string IssuePhotoDocumentId { get; set; } = string.Empty;
    public DateTime AcknowledgedAt { get; set; }
    public DateTime? ReturnedAt { get; set; }
    public string? ReturnCondition { get; set; }
    public string? ReturnPhotoDocumentId { get; set; }
    public bool DamageReviewRequired { get; set; }
    public string? DamageReviewOutcome { get; set; }
    public string? Notes { get; set; }
}

public sealed class EmergencySwapEntity
{
    public long SwapId { get; set; }
    public string EmployeeId { get; set; } = string.Empty;
    public string? OriginalAssetId { get; set; }
    public string TemporaryAssetId { get; set; } = string.Empty;
    public string IssueDescription { get; set; } = string.Empty;
    public DateTime ReportedAt { get; set; }
    public DateTime ResolveBy { get; set; }
    public string Status { get; set; } = "Open";
    public string? Resolution { get; set; }
    public DateTime? ResolvedAt { get; set; }
    public string CreatedBy { get; set; } = string.Empty;
}

public sealed class DisposalEntity
{
    public long DisposalId { get; set; }
    public string AssetId { get; set; } = string.Empty;
    public string Reason { get; set; } = string.Empty;
    public string Method { get; set; } = string.Empty;
    public bool DataWipeConfirmed { get; set; }
    public string? CertificateDocumentId { get; set; }
    public DateTime DisposedOn { get; set; }
    public string? Notes { get; set; }
    public string RecordedBy { get; set; } = string.Empty;
    public DateTime RecordedAt { get; set; } = DateTime.UtcNow;
}
