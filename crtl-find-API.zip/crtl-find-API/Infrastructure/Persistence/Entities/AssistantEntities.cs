namespace CtrlFind.Infrastructure.Persistence.Entities;

// Data Assistant tables live in the "assistant" schema, separate from asset data.
public sealed class AssistantConversationEntity
{
    public Guid ConversationId { get; set; }
    public string OwnerId { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string? ContextJson { get; set; }
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAtUtc { get; set; } = DateTime.UtcNow;
}

public sealed class AssistantMessageEntity
{
    public long MessageId { get; set; }
    public Guid ConversationId { get; set; }
    public string Role { get; set; } = string.Empty;
    public string Content { get; set; } = string.Empty;
    public string? MetadataJson { get; set; }
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
}

// Every question asked, whether it was answered, and the user's thumbs up or down.
public sealed class AssistantQuestionLogEntity
{
    public long LogId { get; set; }
    public string UserId { get; set; } = string.Empty;
    public Guid ConversationId { get; set; }
    public string Question { get; set; } = string.Empty;
    public string Intent { get; set; } = string.Empty;
    public bool Answered { get; set; }
    public bool? Helpful { get; set; }
    public string? Comment { get; set; }
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
}
