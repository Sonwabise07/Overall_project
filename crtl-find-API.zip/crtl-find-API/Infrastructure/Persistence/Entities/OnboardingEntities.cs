namespace CtrlFind.Infrastructure.Persistence.Entities;

public sealed class RoleKitItemEntity
{
    public long RoleKitItemId { get; set; }
    public string JobRole { get; set; } = string.Empty;
    public string AssetType { get; set; } = string.Empty;
    public int Quantity { get; set; } = 1;
}

public sealed class OnboardingCaseEntity
{
    public long CaseId { get; set; }
    public string EmployeeId { get; set; } = string.Empty;
    public string EmployeeName { get; set; } = string.Empty;
    public string DepartmentId { get; set; } = string.Empty;
    public string? ManagerEmployeeId { get; set; }
    public string JobRole { get; set; } = string.Empty;
    public string LocationId { get; set; } = string.Empty;
    public DateTime StartDate { get; set; }
    public bool IsConfirmed { get; set; }
    public bool IsShortNotice { get; set; }
    public string Status { get; set; } = "Open";
    public string? Notes { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? ConfirmedAt { get; set; }
    public DateTime? CompletedAt { get; set; }
}

public sealed class OnboardingReservationEntity
{
    public long ReservationId { get; set; }
    public long CaseId { get; set; }
    public string AssetId { get; set; } = string.Empty;
    public string AssetType { get; set; } = string.Empty;
    public DateTime ReservedAt { get; set; } = DateTime.UtcNow;
    public DateTime? IssuedAt { get; set; }
    public DateTime? ReleasedAt { get; set; }
}
