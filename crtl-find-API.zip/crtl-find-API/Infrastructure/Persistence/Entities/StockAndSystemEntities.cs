namespace CtrlFind.Infrastructure.Persistence.Entities;

public sealed class StockThresholdEntity
{
    public string AssetType { get; set; } = string.Empty;
    public int MinimumAvailable { get; set; }
}

public sealed class StockCountEntity
{
    public long CountId { get; set; }
    public string StoreroomId { get; set; } = string.Empty;
    public string CountType { get; set; } = string.Empty;
    public DateTime CountDate { get; set; }
    public int CountedUnits { get; set; }
    public string? Notes { get; set; }
    public string RecordedBy { get; set; } = string.Empty;
    public DateTime RecordedAt { get; set; } = DateTime.UtcNow;
}

// One row each time an asset leaves or enters a storeroom (BR-8.7-03).
public sealed class StockMovementEntity
{
    public long MovementId { get; set; }
    public string StoreroomId { get; set; } = string.Empty;
    public string AssetId { get; set; } = string.Empty;
    public string Direction { get; set; } = string.Empty;
    public string Reason { get; set; } = string.Empty;
    public DateTime MovedAt { get; set; } = DateTime.UtcNow;
}

public sealed class NotificationEntity
{
    public long NotificationId { get; set; }
    public string Audience { get; set; } = string.Empty;
    public string Type { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
    public string? AssetId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? ReadAt { get; set; }
}

public sealed class UserAccountEntity
{
    public string UserId { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public string EmployeeId { get; set; } = string.Empty;
    public string Roles { get; set; } = string.Empty;
    public string? LocationIds { get; set; }
    public bool IsActive { get; set; } = true;
}
