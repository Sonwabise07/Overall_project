
namespace CtrlFind.Infrastructure.Persistence.Entities;

public sealed class AssetEntity
{
    public string AssetId { get; set; } = Guid.NewGuid().ToString("N");
    public string AssetNo { get; set; } = string.Empty;
    public string? AssetTag { get; set; }
    public string? SerialNumber { get; set; }
    public string AssetType { get; set; } = string.Empty;
    public string? Make { get; set; }
    public string? Model { get; set; }

    public string LifecycleState { get; set; } = string.Empty;
    public string OperationalStatus { get; set; } = string.Empty;

    public string? EmployeeId { get; set; }
    public string? EmployeeName { get; set; }

    public string? LocationId { get; set; }
    public string? Region { get; set; }
    public string? Building { get; set; }
    public string? Floor { get; set; }
    public string? DepartmentId { get; set; }
    public string? StoreroomId { get; set; }

    public DateTime? WarrantyEnd { get; set; }
    public decimal? PurchaseCost { get; set; }
    public DateTime? LastAuditDate { get; set; }

    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAtUtc { get; set; } = DateTime.UtcNow;

    // SQL Server generates this value and changes it on updates.
    public byte[] RowVersion { get; set; } = [];

    public string? Category { get; set; }
    public string? CompanyEntity { get; set; }
    public string? CostCentre { get; set; }

    public string? PurchaseOrder { get; set; }
    public string? InvoiceReference { get; set; }

    public DateTime? AcquisitionDate { get; set; }
    public DateTime? WarrantyStart { get; set; }

    public string? AuditOutcome { get; set; }

    public string? EncryptionStatus { get; set; }
    public bool CustodyAgreementSigned { get; set; }

    public string? Notes { get; set; }

    public string? LocationSubStatus { get; set; }
    public string? Desk { get; set; }
    public string? WarrantyVendor { get; set; }
    public string? Condition { get; set; }
    public DateTime? HoldExpiresAt { get; set; }
}
