﻿namespace CtrlFind.Infrastructure.Persistence.Entities;

public sealed class AssetDocumentEntity
{
    public string DocumentId { get; set; } = Guid.NewGuid().ToString("N");
    public string AssetId { get; set; } = string.Empty;
    public string DocumentType { get; set; } = string.Empty;
    public string FileName { get; set; } = string.Empty;
    public string ContentType { get; set; } = string.Empty;
    public long FileSizeBytes { get; set; }
    public DateTime UploadedAt { get; set; } = DateTime.UtcNow;
    public string UploadedByUserId { get; set; } = string.Empty;
    public string DownloadUrl { get; set; } = string.Empty;
    public string? Description { get; set; }
    public DateTime? CapturedAt { get; set; }
}