
namespace CtrlFind.Infrastructure.Persistence.Entities;

public sealed class EmployeeEntity
{
    public string EmployeeId { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;
    public string? Email { get; set; }
    public string? DepartmentId { get; set; }
    public bool IsActive { get; set; } = true;
    public string? JobRole { get; set; }
    public string? ManagerEmployeeId { get; set; }
    public string? LocationId { get; set; }
}

public sealed class DepartmentEntity
{
    public string DepartmentId { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
}

public sealed class LocationEntity
{
    public string LocationId { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Region { get; set; }
    public string? Building { get; set; }
    public string? Floor { get; set; }
}

public sealed class StoreroomEntity
{
    public string StoreroomId { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? LocationId { get; set; }
}

public sealed class AssetAssignmentEntity
{
    public long AssignmentId { get; set; }
    public string AssetId { get; set; } = string.Empty;
    public string EmployeeId { get; set; } = string.Empty;
    public string? EmployeeName { get; set; }
    public DateTime AssignedAt { get; set; } = DateTime.UtcNow;
    public DateTime? ReturnedAt { get; set; }
    public string? CustodyAgreementReference { get; set; }
    public string? AssignedBy { get; set; }
    public string? LocationId { get; set; }
    public string? Notes { get; set; }
}

public sealed class AssetHistoryEntity
{
    public long HistoryId { get; set; }
    public string AssetId { get; set; } = string.Empty;
    public string Action { get; set; } = string.Empty;
    public string? Summary { get; set; }
    public string? DetailsJson { get; set; }
    public string? ChangedBy { get; set; }
    public DateTime ChangedAt { get; set; } = DateTime.UtcNow;
}

public sealed class AssetTransferEntity
{
    public long TransferId { get; set; }
    public string AssetId { get; set; } = string.Empty;
    public string TransferType { get; set; } = string.Empty;
    public string TargetId { get; set; } = string.Empty;
    public string Status { get; set; } = "PendingApproval";
    public string? RequestedBy { get; set; }
    public string? Notes { get; set; }
    public DateTime RequestedAt { get; set; } = DateTime.UtcNow;
    public DateTime? CompletedAt { get; set; }
    public string? FromValue { get; set; }
    public string? CustodyAgreementDocumentId { get; set; }
    public string? DecidedBy { get; set; }
    public string? DecisionReason { get; set; }
    public string? AtomSyncStatus { get; set; }
}
