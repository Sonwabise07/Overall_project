# Decision Log – CTRL + Find Asset Hub

This log records technical decisions taken during development, why they were taken, and which part of the requirements document (BRD) they support. Add new decisions at the bottom. Do not edit a past decision; add a new one that replaces it.

Status values: **Accepted** (in effect), **Pending confirmation** (in effect, but a business owner must confirm), **Replaced** (see the decision that replaces it).

---

## DEC-001 – `dbo` (EF Core) is the system of record

- **Decision:** All application data lives in the `dbo` tables managed by EF Core migrations in this repository. The `asset_management` schema in `AssetManagementWorking 1.sql` is not used by the API.
- **Reason:** The API and the Data Assistant already read and write `dbo`. The `asset_management` tables are empty apart from lookup lists. Keeping two asset models would mean every feature is built twice.
- **Impact:** The DB team reviews and owns the EF migrations instead of maintaining a separate schema. The `reporting` views can be rebuilt on top of `dbo` for Power BI.
- **Status:** Accepted

## DEC-002 – Remove the in-memory store

- **Decision:** `Services/AssetManagementStore.cs` is removed. Every controller uses `ApplicationDbContext`.
- **Reason:** Assets were stored in SQL Server, but onboarding, offboarding, stock, faults, incidents, audits, documents and reports read an in-memory list with one seeded asset. Real assets could not take part in any workflow, and data was lost on restart.
- **Status:** Accepted

## DEC-003 – Lifecycle states follow BRD Section 6.1 exactly

- **Decision:** `LifecycleState` has the 18 states from Section 6.1: Ordered, Received, Registered, InStorage, Reserved, Assigned, AtHome, OffSite, HeldForReassignment, UnderAudit, InRepair, WarrantyClaim, Lost, Stolen, UnderInvestigation, Retired, Disposed, InterEntityTransfer.
- **Data conversion:** `InStock` becomes `InStorage`. `UnderMaintenance` becomes `InRepair`. `InTransit` is removed (no rows use it).
- **BRD:** BR-6.1-01
- **Status:** Accepted

## DEC-004 – Operational status is derived from the lifecycle state

- **Decision:** `OperationalStatus` has the four BRD values: InUse, InStorage, InRepair, Retired. It is always calculated from the lifecycle state by `AssetStatusRules`. It is stored in the `Assets` table for reporting, but it is never sent by a client.
- **Mapping (answers OQ-03):**

| Operational status | Lifecycle states |
|---|---|
| InStorage | Ordered, Received, Registered, InStorage, Reserved |
| InUse | Assigned, AtHome, OffSite, HeldForReassignment, UnderAudit, UnderInvestigation, InterEntityTransfer |
| InRepair | InRepair, WarrantyClaim |
| Retired | Lost, Stolen, Retired, Disposed |

- **Reason:** BR-6.1-02 requires both values to always be present and consistent. Deriving one from the other makes inconsistency impossible.
- **Impact:** `operationalStatus` is removed from the create and update asset requests. Condition values that were mixed into the old status list (Faulty, Damaged) now live in the condition rating.
- **BRD:** BR-6.1-02, OQ-03
- **Status:** Pending confirmation (mapping must be confirmed by Fixed Assets)

## DEC-005 – One condition scale

- **Decision:** `ConditionStatus` uses the BRD scale only: New, Excellent, Good, Fair, Damaged. It is used for take-home screens, handovers, returns, offboarding, stock counts and audits.
- **BRD:** BR-8.2-01, BR-8.12-02
- **Status:** Accepted

## DEC-006 – Location sub-status and desk on the asset

- **Decision:** Assets carry `LocationSubStatus` (InOffice, AtHome) and `Desk`. Desk is free text on the asset (no Desks table).
- **Reason:** BR-6.2-01 needs the sub-status. BR-7-02 makes desk optional. A Desks table adds maintenance with no rule that needs it.
- **Status:** Accepted

## DEC-007 – Alerts are calculated when read, notifications are stored

- **Decision:**
  - Time-based alerts are calculated from current data each time they are requested: warranty expiry (90/60/30 days), hold-for-reassignment expiry, emergency swap past its resolution window, low or no stock, and short-notice onboarding.
  - Event-based messages are stored in a `Notifications` table when the event happens: stock shortfall for a new hire, emergency swap logged, damage review, tamper alert, repeat-incident escalation, AOD generated.
- **Reason:** Calculated alerts are always correct and need no scheduler or clean-up job. Events need a record of who was told and when.
- **BRD:** BR-8.4-05, BR-8.5-04, BR-8.6-02, BR-8.7-02, BR-8.9-02, BR-8.10-04
- **Status:** Accepted

## DEC-008 – Configurable periods live in `appsettings.json`

- **Decision:** Periods and thresholds the BRD calls "configurable" are read from the `AssetRules` section of `appsettings.json`: short-notice days (28), emergency swap resolution days, hold-for-reassignment days, repeat-incident threshold, warranty alert days (90, 60, 30), whether transfers need manager approval, and whether a prior negligent loss needs manager acknowledgement.
- **Reason:** These values change rarely and only by an administrator. A settings screen can be added later without changing the rules.
- **Status:** Accepted

## DEC-009 – AOD is generated automatically when a case is marked Negligent

- **Decision:** Negligence status is UnderInvestigation, Negligent or NotNegligent. Setting Negligent creates the AOD record automatically. The amount defaults to the asset's recorded purchase cost (from Pastel). If no cost is recorded, the decision must include an amount.
- **BRD:** BR-8.10-02, BR-8.10-03, BR-8.3-05
- **Status:** Accepted

## DEC-010 – Police case number is optional

- **Decision:** The API no longer rejects theft reports without a police case number.
- **BRD:** BR-8.10-01 (the team's earlier rule conflicted with it)
- **Status:** Accepted

## DEC-011 – Fault cases keep the `/maintenance-cases` route

- **Decision:** The existing route and table name stay. A case now records the BRD fault classification (HardwareFailure, AccidentalDamage, WearAndTear, Unknown) and outcome (Repair, Replace, WarrantyClaim, Retire). AccidentalDamage sets a cost-recovery review flag.
- **BRD:** BR-8.8-01 to BR-8.8-03
- **Status:** Accepted

## DEC-012 – Offboarding resolutions

- **Decision:** Each checklist item is resolved as Returned, HeldForReassignment, Escalated or AuthorisedException. Completion is allowed only when every item is Returned, HeldForReassignment or AuthorisedException. Escalated (missing) items block completion until resolved. Only Fixed Assets may record an AuthorisedException. An unrecovered laptop is reported as its own blocking reason.
- **BRD:** BR-8.11-03, BR-8.11-04, BR-8.3-06
- **Status:** Accepted

## DEC-013 – Audit closing is blocked by tamper investigations only

- **Decision:** A serial mismatch opens an investigation and blocks closing until it is resolved. Other discrepancies (not found, location mismatch, unconfirmed remote asset) are flagged and must be resolved with a note, but they do not need a tamper investigation.
- **Reason:** The old code opened an investigation for any condition other than Good, which blocked almost every audit.
- **BRD:** BR-8.12-03, BR-8.12-04
- **Status:** Accepted

## DEC-014 – Transfer approval is configurable per transfer type

- **Decision:** `AssetRules:TransferTypesRequiringApproval` lists the types that need manager approval (default: Employee, Department). Other types complete immediately. Approve and decline endpoints are added. `Storeroom` is kept as a transfer type because the team added it and it covers assigning to a storeroom (BR-8.5-01).
- **BRD:** BR-8.5-01 to BR-8.5-03
- **Status:** Pending confirmation (which types need approval)

## DEC-015 – Atom outbound sync is not sent

- **Decision:** Approved transfers are recorded with `AtomSyncStatus = NotConfigured`. Nothing is sent to Atom until OQ-04 is answered.
- **BRD:** BR-8.5-03 criterion 4, OQ-04
- **Status:** Pending confirmation

## DEC-016 – History is permanent

- **Decision:** `AssetHistory` rows are written in the same transaction as the change they describe. The API has no update or delete for history. A database trigger rejects updates and deletes on the table.
- **BRD:** BR-8.13-01, Section 8.17
- **Status:** Accepted

## DEC-017 – Development login uses a `UserAccounts` table

- **Decision:** The hard-coded demo user is replaced by a `UserAccounts` table (email, hashed password, roles, linked employee). Passwords are hashed with ASP.NET Core `PasswordHasher`. The seed script creates one user per BRD role for development. An enterprise identity provider can replace this later without changing the token format.
- **BRD:** Section 5 (roles)
- **Status:** Accepted

## DEC-018 – Data Assistant runs inside the API

- **Decision:** The Python prototype is ported to C# under `Services/Assistant` and served by `AssistantController` at `/api/v1/assistant/*`. It keeps the prototype's safety rules: application-owned, parameterised queries only, no generated SQL, plain "out of scope" answers, and no invented figures. The optional local Ollama model is only used to choose a supported question type, never to write SQL or answers.
- **Reason:** Same database, same login and roles, one deployment. The prototype's README already called for a trusted main-app backend.
- **BRD:** BR-8.15-01 to BR-8.15-04
- **Status:** Accepted

## DEC-019 – Registration states and asset numbers

- **Decision:** New assets are created only as Ordered, Received, Registered or InStorage. Every later state comes from its workflow (assignment, onboarding, faults, incidents, disposal) or, for simple steps, from `POST assets/{id}/lifecycle`. From Registered onwards the Section 7 mandatory fields are required, including the EXT tag, serial number and a storeroom; laptops also need an encryption status. When no asset number is sent, the API generates `AST-######` from the `AssetNumbers` database sequence, which also serves bulk registration.
- **BRD:** BR-7-01, BR-7-02, BR-8.1-01, BR-8.1-02, BR-8.3-01
- **Status:** Accepted

## DEC-020 – Fault outcome and the original asset

- **Decision:** BR-8.8-03 lists four outcomes and four asset states "respectively", but read in order the pairs do not make sense (Warranty Claim → In Storage). The API applies: Repair → InRepair (back to the holder or storage when closed), Replace → Retired and the replacement issued to the same employee, WarrantyClaim → WarrantyClaim (shows In Repair), Retire → Retired. Replace and Retire require IT to confirm the asset cannot be repaired.
- **BRD:** BR-8.8-02, BR-8.8-03, BR-8.9-03
- **Status:** Pending confirmation (Fixed Assets to confirm the mapping)

## DEC-021 – Take-home screens

- **Decision:** Applies to monitors only. Issue needs a photo uploaded against the asset, a condition rating and the employee's acknowledgement. If the screen is not yet assigned, it is assigned to the employee at the same time. No approval step is added because the BRD defines none (OQ-01).
- **BRD:** BR-8.1-04, BR-8.2-01 to BR-8.2-04
- **Status:** Pending confirmation (OQ-01)

## DEC-022 – Integrations

- **Decision:** `integrations/pastel/sync` sets the purchase cost of assets that match an invoice reference, so cost is read from Pastel rather than entered by hand. Oracle, Zendesk and Atom endpoints record what they receive until their interface specifications are agreed. Oracle-driven onboarding and exits use the normal onboarding and offboarding endpoints with `Source = Oracle`.
- **BRD:** Section 8.16, BR-7-01
- **Status:** Accepted

## DEC-023 – Data Assistant history and question log

- **Decision:** Context for follow-up questions is kept in memory for 30 minutes per user and conversation. Conversations are saved to the `assistant` schema only when the user switches saving on, and only the owner can list, open or delete them. Every question is logged with whether it was answered and the user's thumbs up or down, so `assistant/unanswered` shows which question types to add next.
- **Status:** Accepted

## DEC-024 – Laptop health and audit risk scoring

- **Decision:** Laptop health is calculated, not stored. It is Red when out of warranty or at least one year past the ageing threshold (default 3 years), Amber when the warranty ends within 90 days or the laptop has reached the threshold, and Green otherwise. The audit risk score adds points for age, purchase cost, the holder's incident history, home or off-site location, and a previous audit discrepancy: High at 4 or more, Medium at 2 to 3, Low otherwise.
- **BRD:** BR-8.3-04, dashboard "score factors"
- **Status:** Pending confirmation (thresholds)

## DEC-025 – Emergency swaps keep laptop controls

- **Decision:** A swap needs no prior approval, but a laptop issued as a temporary asset still needs a custody agreement for its serial number, and a prior negligent loss still needs manager acknowledgement. BR-8.3-02 has no exception, and a digital agreement can be signed at the moment of issue.
- **BRD:** BR-8.3-02, BR-8.3-03, BR-8.6-01
- **Status:** Accepted

## DEC-026 – Meaning of "unconfirmed"

- **Decision:** An asset in use is unconfirmed when it has not been confirmed within `AssetRules:AuditConfirmationDays` (default 90) or is waiting for a self-confirmation reply. The same definition drives exception-based audit scope and the Data Assistant.
- **BRD:** BR-8.12-01, BR-8.15 example question
- **Status:** Pending confirmation (window length)

## DEC-027 – Contract changes for the frontend

- **Decision:** These changes from the original contract were needed to follow the BRD:
  - `operationalStatus` removed from create and update asset requests (DEC-004).
  - Hold for reassignment takes an optional `expiresAt` (defaults from configuration).
  - `POST stock/reservations` removed; onboarding cases reserve stock themselves and link the reservation.
  - `POST maintenance-cases/{id}/replace` replaced by `POST maintenance-cases/{id}/outcome`.
  - Maintenance cases use `classification` instead of `maintenanceType`.
  - Laptop health is calculated, so the `HealthIndicator` column is dropped.
  - Assignments require a `condition` at handover (BR-8.12-02).
- **Status:** Accepted

## DEC-028 – Data scripts

- **Decision:** `Migrations/20261028200000_AlignStatusValuesWithBrd.cs` is a hand-written, data-only migration. It converts stored status values and adds the history trigger. The table changes go in a generated migration (`AddWorkflowPersistence`). `scripts/seed-dev-data.sql` loads development data shaped like the screen designs, plus one sign-in per role.
- **Status:** Accepted
