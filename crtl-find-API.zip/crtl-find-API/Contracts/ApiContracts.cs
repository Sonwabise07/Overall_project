using System.ComponentModel.DataAnnotations;

namespace CtrlFind.Contracts;

// Enumerations follow the requirements document (see docs/DECISIONS.md, DEC-003 to DEC-013).
public enum AssetType { Laptop, Desktop, Monitor, MobileDevice, Peripheral, NetworkEquipment, Printer, Other, DockingStation, Tablet, Keyboard, Headset }
public enum LifecycleState { Ordered, Received, Registered, InStorage, Reserved, Assigned, AtHome, OffSite, HeldForReassignment, UnderAudit, InRepair, WarrantyClaim, Lost, Stolen, UnderInvestigation, Retired, Disposed, InterEntityTransfer }
public enum OperationalStatus { InUse, InStorage, InRepair, Retired }
public enum LocationSubStatus { InOffice, AtHome }
public enum TransferType { Employee, Department, Location, Desk, Storeroom }
public enum CaseStatus { Draft, Open, PendingApproval, InProgress, Blocked, Completed, Cancelled, Declined }
public enum OffboardingItemResolution { Returned, HeldForReassignment, Escalated, AuthorisedException }
public enum ConditionStatus { New, Excellent, Good, Fair, Damaged }
public enum StockState { Available, Reserved, Damaged }
public enum StockCountType { Opening, Closing }
public enum FaultClassification { HardwareFailure, AccidentalDamage, WearAndTear, Unknown }
public enum FaultOutcome { Repair, Replace, WarrantyClaim, Retire }
public enum RepairabilityDecision { Repairable, NonRepairable, WarrantyClaimRequired, PendingVendorAssessment }
public enum IncidentType { Loss, Theft }
public enum NegligenceStatus { UnderInvestigation, Negligent, NotNegligent }
public enum AuditStatus { Draft, Scheduled, InProgress, UnderReview, Closed, Cancelled }
public enum AuditOutcome { Confirmed, NotFound, SerialMismatch, LocationMismatch, ConditionMismatch, AwaitingConfirmation, Unconfirmed }
public enum AuditMethod { PhysicalScan, SelfConfirmation }
public enum DocumentType { CustodyAgreement, Invoice, Warranty, ReturnForm, PoliceReport, Photo, DataWipeCertificate, Other }
public enum HealthIndicator { Green, Amber, Red }

// Envelopes
public sealed record ApiMeta(string CorrelationId, DateTimeOffset Timestamp);
public sealed record ApiResponse<T>(T Data, ApiMeta Meta);
public sealed record PageMeta(int Page, int PageSize, int TotalCount, int TotalPages, bool HasNextPage, bool HasPreviousPage, string CorrelationId, DateTimeOffset Timestamp);
public sealed record PageResponse<T>(IReadOnlyList<T> Data, PageMeta Meta);
public sealed record ErrorDetail(string? Field, string Issue);
public sealed record ErrorBody(string Code, string Message, IReadOnlyList<ErrorDetail> Details, string TraceId);
public sealed record ErrorResponse(ErrorBody Error);

// Authentication
public sealed record LoginRequest([Required] string Username, [Required] string Password, bool RememberMe = false);
public sealed record RefreshRequest([Required] string RefreshToken);
public sealed record LogoutRequest(string? RefreshToken);
public sealed record UserProfile(string UserId, string EmployeeId, string DisplayName, string Email, string[] Roles, string[] DepartmentIds, string[] LocationIds);
public sealed record TokenResponse(string AccessToken, string TokenType, int ExpiresIn, string RefreshToken, DateTimeOffset RefreshTokenExpiresAt, UserProfile? User = null);

// Assets
public sealed record LocationDto(string LocationId, string Region, string Building, string? Floor, string? DepartmentId, string? Desk, string? StoreroomId, LocationSubStatus? SubStatus);
public sealed record DocumentReferenceDto(string DocumentId, DocumentType DocumentType, string FileName, string ContentType, long FileSizeBytes, DateTimeOffset UploadedAt, string UploadedByUserId, string DownloadUrl, string? Description = null, DateTimeOffset? CapturedAt = null);
public sealed record AssignmentDto(string AssignmentId, string AssetId, string EmployeeId, string? EmployeeName, string LocationId, DateOnly AssignmentDate, string? CustodyAgreementDocumentId, string? Notes, DateTimeOffset? ReturnedAt = null, string? ManagerName = null);
public sealed record AssetStatusDto(LifecycleState LifecycleState, OperationalStatus OperationalStatus);
public sealed record FinancialDto(decimal? PurchaseCost, string? PurchaseOrder, string? InvoiceReference);
public sealed record LifecycleDto(DateOnly? AcquisitionDate, DateOnly? WarrantyStart, DateOnly? WarrantyEnd, string? WarrantyVendor = null);
public sealed record AuditDataDto(DateOnly? LastAuditDate, AuditOutcome? AuditOutcome);
public sealed record LaptopControlsDto(string EncryptionStatus, bool CustodyAgreementSigned, HealthIndicator HealthIndicator);

public sealed record AssetDto(
    string AssetId, string AssetNo, string? AssetTag, string? SerialNumber, AssetType AssetType,
    string? Category, string? Make, string? Model, string? CompanyEntity, string? CostCentre,
    string? Department, LocationDto? Location, AssignmentDto? Assignment, AssetStatusDto Status,
    FinancialDto Financial, LifecycleDto Lifecycle, AuditDataDto AuditData, LaptopControlsDto? LaptopControls,
    string? Notes, DateTimeOffset CreatedAt, DateTimeOffset UpdatedAt, int Version,
    ConditionStatus? Condition = null, DateTimeOffset? HoldExpiresAt = null);

// AssetNo is generated when it is not supplied. Operational status is derived (DEC-004).
public sealed record CreateAssetRequest(
    string? AssetNo, string? AssetTag, string? SerialNumber, AssetType AssetType,
    string? Category, string? Make, string? Model, string? CompanyEntity, string? CostCentre,
    string? DepartmentId, string? LocationId, LifecycleState? LifecycleState,
    decimal? PurchaseCost, string? PurchaseOrder, string? InvoiceReference, DateOnly? AcquisitionDate,
    DateOnly? WarrantyStart, DateOnly? WarrantyEnd, string? Notes,
    string? StoreroomId = null, string? Desk = null, string? WarrantyVendor = null,
    string? EncryptionStatus = null, ConditionStatus? Condition = null);

public sealed record BulkAssetUnit([Required] string AssetTag, [Required] string SerialNumber, string? AssetNo = null);
public sealed record BulkCreateAssetsRequest([Required] CreateAssetRequest Common, [Required, MinLength(1)] IReadOnlyList<BulkAssetUnit> Units);

public sealed record UpdateAssetRequest(
    string? AssetTag, string? DepartmentId, string? LocationId,
    DateOnly? WarrantyEnd, string? Notes,
    string? Desk = null, string? StoreroomId = null, string? WarrantyVendor = null,
    DateOnly? WarrantyStart = null, string? EncryptionStatus = null,
    string? Category = null, string? CompanyEntity = null, string? CostCentre = null);

public sealed record ChangeLifecycleRequest(LifecycleState LifecycleState, [Required] string Reason);

public sealed record AssetListItemDto(
    string AssetId, string AssetNo, string? AssetTag, string? SerialNumber, AssetType AssetType,
    string? Make, string? Model, LifecycleState LifecycleState, OperationalStatus OperationalStatus,
    string? AssignedEmployeeId, string? AssignedEmployeeName, string? LocationSummary,
    DateOnly? WarrantyEnd, DateOnly? LastAuditDate,
    LocationSubStatus? LocationSubStatus = null, AuditOutcome? AuditOutcome = null, string? Department = null);

public sealed record HistoryDto(string HistoryId, string AssetId, string ActionType, object? OldValue, object? NewValue, string UserId, DateTimeOffset ChangedAt, string? Summary = null);

public sealed record CreateAssignmentRequest(
    [Required] string EmployeeId, [Required] string LocationId, DateOnly AssignmentDate,
    string? CustodyAgreementDocumentId, string? Notes,
    string? Desk = null, ConditionStatus? Condition = null, bool ManagerAcknowledged = false);

public sealed record ReturnAssetRequest([Required] string StoreroomId, ConditionStatus Condition, string? Notes);
public sealed record HoldForReassignmentRequest(DateTimeOffset? ExpiresAt, string? Reason);

// Transfers
public sealed record CreateTransferRequest(
    TransferType TransferType,
    string? TargetEmployeeId,
    string? TargetDepartmentId,
    string? TargetLocationId,
    string? TargetDesk,
    DateOnly RequestedDate,
    [Required] string Reason,
    string? Notes,
    string? TargetStoreroomId = null,
    string? CustodyAgreementDocumentId = null);
public sealed record TransferResponseDto(
    string TransferId, string AssetId, TransferType TransferType, CaseStatus Status,
    string? FromEmployeeId, string? ToEmployeeId, string? FromLocationId, string? ToLocationId,
    string RequestedByUserId, DateTimeOffset RequestedAt,
    string? AssetNo = null, string? FromValue = null, string? ToValue = null, string? Reason = null,
    string? DecidedByUserId = null, DateTimeOffset? DecidedAt = null, string? DecisionReason = null,
    string? AtomSyncStatus = null);
public sealed record TransferDecisionRequest(string? Reason);

// Onboarding
public sealed record RoleKitItemDto(AssetType AssetType, int Quantity);
public sealed record RoleKitDto(string JobRole, IReadOnlyList<RoleKitItemDto> Items, bool CustodyAgreementRequired);
public sealed record SaveRoleKitRequest([Required, MinLength(1)] IReadOnlyList<RoleKitItemDto> Items);

public sealed record CreateOnboardingCaseRequest(
    [Required] string EmployeeId, [Required] string EmployeeName, [Required] string DepartmentId,
    string? ManagerEmployeeId, DateOnly StartDate, [Required] string JobRole, [Required] string LocationId,
    [Required] string Source, string? Notes);
public sealed record ReservedAssetDto(string AssetId, AssetType AssetType, string ReservationId, string? AssetNo = null, bool Issued = false);
public sealed record StockShortfallDto(AssetType AssetType, int Quantity, DateOnly NeededBy);
public sealed record OnboardingCaseDto(
    string CaseId, CaseStatus Status, string EmployeeId, string EmployeeName, string JobRole,
    string DepartmentId, string LocationId, DateOnly StartDate, bool IsConfirmed, bool IsShortNotice,
    string ReadinessState, IReadOnlyList<ReservedAssetDto> ReservedAssets, IReadOnlyList<StockShortfallDto> Shortfalls,
    IReadOnlyList<string> BlockingItems, DateTimeOffset CreatedAt, string? Notes);
public sealed record IssueOnboardingAssetsRequest(bool ManagerAcknowledged = false, string? Notes = null);

// Offboarding
public sealed record CreateOffboardingCaseRequest([Required] string EmployeeId, DateOnly ExitDate, [Required] string Source, [Required] string Reason, string? Notes);
public sealed record ResolveOffboardingItemRequest(
    [Required] string AssetId, OffboardingItemResolution Resolution, ConditionStatus? ConditionStatus,
    DateOnly? ReturnedDate, string? StoreroomId, string[]? DocumentIds, string? Notes);
public sealed record OffboardingItemDto(string AssetId, string AssetNo, AssetType AssetType, bool RequiredForCompletion, OffboardingItemResolution? Resolution, DateTimeOffset? ResolvedAt, string? Make = null, string? Model = null, string? Notes = null);
public sealed record OffboardingCaseDto(
    string CaseId, CaseStatus Status, string EmployeeId, DateOnly ExitDate, IReadOnlyList<OffboardingItemDto> Items,
    bool CanComplete, IReadOnlyList<string> BlockingReasons, CreateOffboardingCaseRequest Request,
    string? EmployeeName = null, bool LaptopRecovered = true);

// Stock
public sealed record CreateStockReservationRequest(AssetType AssetType, [Required] string LocationId, [Required] string ReservedForType, [Required] string ReservedForId, [Range(1, 100)] int Quantity, DateOnly RequiredByDate);
public sealed record StockItemDto(string AssetId, string AssetNo, AssetType AssetType, StockState StockState, ConditionStatus? ConditionStatus, string? LocationId, string? StoreroomId, string? ReservedForId, string? Make = null, string? Model = null);
public sealed record StockCountRequest([Required] string StoreroomId, StockCountType CountType, DateOnly CountDate, IReadOnlyList<StockCountItem> Items, string? Notes = null);
public sealed record StockCountItem([Required] string AssetId, ConditionStatus ConditionStatus);
public sealed record StockCountDto(string CountId, string StoreroomId, StockCountType CountType, DateOnly CountDate, int CountedUnits, DateTimeOffset RecordedAt);
public sealed record StockTypeSummaryDto(AssetType AssetType, int Available, int Reserved, int Damaged, int? MinimumThreshold, string Alert);
public sealed record StoreroomStockDto(string StoreroomId, string Name, string? LocationId, string? Region, string? Building, int Available, int Reserved, int Damaged, string Alert);
public sealed record UnfulfilledDemandDto(string CaseId, string EmployeeName, AssetType AssetType, int Quantity, DateOnly NeededBy);
public sealed record StockSummaryDto(IReadOnlyList<StockTypeSummaryDto> ByType, IReadOnlyList<StoreroomStockDto> ByStoreroom, IReadOnlyList<UnfulfilledDemandDto> UnfulfilledDemand);
public sealed record StockReconciliationDto(string StoreroomId, DateOnly WeekStart, int? OpeningCount, int UnitsOut, int UnitsIn, int? ExpectedClosing, int? ClosingCount, int? Discrepancy);
public sealed record SetStockThresholdRequest([Range(0, 10000)] int MinimumAvailable);

// Faults, repairs and warranty
public sealed record CreateMaintenanceCaseRequest(
    [Required] string AssetId, FaultClassification Classification, [Required] string ReportedByEmployeeId,
    [Required] string ZendeskTicketId, [Required] string Description, DateTimeOffset ReportedAt);
public sealed record DiagnoseMaintenanceCaseRequest([Required] string Diagnosis, RepairabilityDecision RepairabilityDecision, decimal? EstimatedRepairCost, string? Notes);
public sealed record RecordFaultOutcomeRequest(FaultOutcome Outcome, string? ReplacementAssetId, string? Notes);
public sealed record MaintenanceCaseDto(
    string CaseId, CaseStatus Status, string AssetId, string? AssetNo, FaultClassification Classification,
    string ReportedByEmployeeId, string ZendeskTicketId, string Description, DateTimeOffset ReportedAt,
    bool CostRecoveryReview, string? Diagnosis, RepairabilityDecision? RepairabilityDecision, decimal? EstimatedRepairCost,
    FaultOutcome? Outcome, string? ReplacementAssetId, DateTimeOffset? ClosedAt, string? AssetDescription = null);

public sealed record CreateWarrantyClaimRequest(
    [Required] string AssetId, [Required] string MaintenanceCaseId, [Required] string VendorName, string? VendorReference,
    DateOnly DispatchDate, DateOnly? ExpectedReturnDate, string[]? SupportingDocumentIds);
public sealed record CloseWarrantyClaimRequest(DateOnly ActualReturnDate, [Required] string Outcome, string? Notes);
public sealed record WarrantyClaimDto(
    string ClaimId, string AssetId, string? AssetNo, string MaintenanceCaseId, string VendorName, string? VendorReference,
    DateOnly DispatchDate, DateOnly? ExpectedReturnDate, DateOnly? ActualReturnDate, string? Outcome, CaseStatus Status);
public sealed record WarrantyExpiryDto(string AssetId, string AssetNo, string? Make, string? Model, string? Vendor, DateOnly WarrantyEnd, int DaysLeft, string AlertStage);
public sealed record CreateMaintenanceLogRequest(DateOnly LastServiceDate, DateOnly? NextDueDate, [Required] string ServiceProvider, string? Notes);
public sealed record MaintenanceLogDto(string LogId, string AssetId, DateOnly LastServiceDate, DateOnly? NextDueDate, string ServiceProvider, string? Notes, DateTimeOffset RecordedAt);

// Loss, theft and AOD
public sealed record CreateIncidentRequest(
    [Required] string AssetId, IncidentType IncidentType, [Required] string ReportedByEmployeeId, DateOnly IncidentDate,
    [Required] string LocationDescription, [Required] string Description, string? PoliceCaseNumber, string[]? DocumentIds);
public sealed record NegligenceDecisionRequest(NegligenceStatus NegligenceStatus, [Required] string DecisionReason, decimal? AodAmount, string? RecoveryTerms);
public sealed record IncidentDto(
    string IncidentId, string AssetId, IncidentType IncidentType, CaseStatus Status, NegligenceStatus NegligenceStatus,
    string? PoliceCaseNumber, string? AodId, DateTimeOffset CreatedAt, CreateIncidentRequest Request,
    string? AssetNo = null, string? AssetDescription = null, string? EmployeeName = null,
    decimal? RecordedPurchaseCost = null, bool EscalatedToHr = false, int EmployeeIncidentCount = 0);
public sealed record AodDto(string AodId, string IncidentId, decimal Amount, string RecoveryTerms, decimal RecoveredAmount, string Status, string? EmployeeId = null, string? AssetId = null);
public sealed record RecordAodPaymentRequest([Range(0.01, 10_000_000)] decimal Amount, DateOnly PaidOn, string? Reference);

// Audits
public sealed record CreateAuditRequest(
    [Required] string AuditName, string[]? LocationIds, string[]? DepartmentIds, AssetType[]? AssetTypes,
    DateOnly ScheduledStartDate, DateOnly ScheduledEndDate, string? Notes, bool FullScope = false);
public sealed record AuditScanRequest([Required] string AssetTag, [Required] string SerialNumber, [Required] string ScannedLocationId, ConditionStatus ConditionStatus, DateTimeOffset ScannedAt, string? Notes);
public sealed record SelfConfirmationRequest([Required] string SerialNumber, ConditionStatus ConditionStatus, string? Notes);
public sealed record ResolveAuditItemRequest([Required] string Resolution);
public sealed record AuditScanResponseDto(
    string AuditItemId, string? AssetId, AuditOutcome? Outcome, bool SerialMismatch, bool LocationMismatch, bool RequiresInvestigation, string Message,
    string? AssetNo = null, AuditMethod Method = AuditMethod.PhysicalScan, string? ReasonFlagged = null, bool Resolved = false, string? Resolution = null,
    string? AuditId = null);
public sealed record AuditDto(
    string AuditId, AuditStatus Status, CreateAuditRequest Request, IReadOnlyList<AuditScanResponseDto> Items, bool SelfConfirmationsSent,
    int OpenInvestigations = 0, int OpenDiscrepancies = 0);

// Take-home screens (Section 8.2)
public sealed record TakeHomeIssueRequest([Required] string AssetId, [Required] string EmployeeId, [Required] string IssuePhotoDocumentId, ConditionStatus IssueCondition, bool EmployeeAcknowledged, string? Notes);
public sealed record TakeHomeReturnRequest([Required] string ReturnPhotoDocumentId, ConditionStatus ReturnCondition, string? Notes);
public sealed record ResolveDamageReviewRequest([Required] string Outcome);
public sealed record TakeHomeDto(
    string TakeHomeId, string AssetId, string? AssetNo, string? AssetDescription, string EmployeeId, string? EmployeeName,
    DateTimeOffset IssuedAt, ConditionStatus IssueCondition, string IssuePhotoDocumentId, DateTimeOffset AcknowledgedAt,
    DateTimeOffset? ReturnedAt, ConditionStatus? ReturnCondition, string? ReturnPhotoDocumentId,
    bool DamageReviewRequired, string? DamageReviewOutcome, string Status);

// Emergency swaps (Section 8.6)
public sealed record CreateEmergencySwapRequest([Required] string EmployeeId, string? OriginalAssetId, [Required] string TemporaryAssetId, [Required] string IssueDescription, DateTimeOffset ReportedAt, string? CustodyAgreementDocumentId);
public sealed record ResolveEmergencySwapRequest([Required] string Resolution);
public sealed record EmergencySwapDto(
    string SwapId, string EmployeeId, string? EmployeeName, string? OriginalAssetId, string TemporaryAssetId, string? TemporaryAssetNo,
    string IssueDescription, DateTimeOffset ReportedAt, DateTimeOffset ResolveBy, CaseStatus Status, bool IsEscalated,
    string? Resolution, DateTimeOffset? ResolvedAt, bool FixedAssetsNotified);

// Disposal
public sealed record CreateDisposalRequest([Required] string AssetId, [Required] string Reason, [Required] string Method, bool DataWipeConfirmed, string? CertificateDocumentId, DateOnly DisposedOn, string? Notes);
public sealed record DisposalDto(string DisposalId, string AssetId, string? AssetNo, string? AssetDescription, string Reason, string Method, bool DataWipeConfirmed, DateOnly DisposedOn, string RecordedByUserId);
public sealed record PendingDispositionDto(string AssetId, string AssetNo, string? AssetDescription, string Reason, DateTimeOffset Since);

// Reference data
public sealed record DepartmentDto(string DepartmentId, string Name);
public sealed record EmployeeDto(string EmployeeId, string FullName, string? Email, string? DepartmentId, string? JobRole, string? ManagerEmployeeId, string? LocationId, bool IsActive, int NegligentIncidents = 0);
public sealed record StoreroomDto(string StoreroomId, string Name, string? LocationId);
public sealed record LocationSummaryDto(string LocationId, string Name, string? Region, string? Building, string? Floor, int AssetCount, int StoreroomCount);

// Alerts and notifications (DEC-007)
public sealed record AlertDto(string Type, string Severity, string Title, string Detail, string? AssetId, DateOnly? DueDate);
public sealed record NotificationDto(string NotificationId, string Type, string Title, string Message, string? AssetId, DateTimeOffset CreatedAt, bool IsRead);

// Dashboards (BR-8.14-01 to BR-8.14-04)
public sealed record CountByLabelDto(string Label, int Count);
public sealed record RiskDistributionDto(int High, int Medium, int Low, int Total);
public sealed record OnboardingReadinessDto(int OpenCases, int KitsFullyReserved, int ShortNotice, int WithShortfall);
public sealed record OffboardingRecoveryDto(int OpenCases, int CompletedThisMonth, int LaptopRecoveriesOutstanding);
public sealed record RecentActivityDto(string AssetId, string AssetNo, string? AssetDescription, string Event, string? Summary, string? Employee, DateTimeOffset At);
public sealed record TrendPointDto(string Period, decimal Value);
public sealed record FlaggedItemDto(string AssetId, string AssetNo, string? AssetDescription, string Reason, string? PhotoUrl);
public sealed record OperationalDashboardDto(
    int TotalAssets, int AddedThisMonth, int FlaggedForAudit, int AssetsAtHome, int OverdueWarrantyOrMaintenance,
    IReadOnlyList<CountByLabelDto> ByOperationalStatus, IReadOnlyList<CountByLabelDto> ByAssetType, IReadOnlyList<StockTypeSummaryDto> StockLevels,
    OnboardingReadinessDto Onboarding, OffboardingRecoveryDto Offboarding,
    int OpenIncidents, decimal LossExposure, int WarrantyAlerts, int ActiveWarrantyClaims, int OpenRepairs,
    int OpenAuditDiscrepancies, int ResolvedAuditDiscrepancies, decimal UtilisationPercent,
    RiskDistributionDto AuditRisk, IReadOnlyList<RecentActivityDto> RecentActivity);
public sealed record ManagementDashboardDto(
    RiskDistributionDto Risk, IReadOnlyList<TrendPointDto> IncidentTrend, IReadOnlyList<TrendPointDto> ConfirmationComplianceTrend,
    IReadOnlyList<CountByLabelDto> IncidentsByEmployee, IReadOnlyList<CountByLabelDto> IncidentsByLocation, IReadOnlyList<CountByLabelDto> IncidentsByAssetType,
    decimal TotalAssetValue, decimal LostOrStolenValue, decimal OpenAodValue, decimal RecoveredAodValue,
    int EmployeesWithRepeatIncidents, int LaptopsOffSite, IReadOnlyList<FlaggedItemDto> FlaggedItems);

// Data assistant
public sealed record AssistantContext(string[]? DepartmentIds, string[]? LocationIds, AssetType[]? AssetTypes);
public sealed record AssistantQueryRequest([Required, MaxLength(500)] string Question, AssistantContext? Context, string? ConversationId = null, bool SaveHistory = false);
public sealed record AssistantSource(string SourceType, string SourceId, string Label);
public sealed record AssistantChartPoint(string Label, decimal Value);
public sealed record AssistantChart(string Type, string Title, string ValueLabel, IReadOnlyList<AssistantChartPoint> Points);
public sealed record AssistantTable(IReadOnlyList<string> Columns, IReadOnlyList<IReadOnlyList<string?>> Rows, int TotalRows);
public sealed record AssistantQueryResponseDto(
    string Answer, IReadOnlyList<AssistantSource> Sources, bool Unsupported,
    string? Intent = null, AssistantTable? Table = null, AssistantChart? Chart = null,
    IReadOnlyList<string>? Suggestions = null, string? ConversationId = null, string? Evidence = null, string? MessageId = null);
public sealed record AssistantFeedbackRequest([Required] string MessageId, bool Helpful, [MaxLength(500)] string? Comment);
public sealed record AssistantQuestionTypeDto(string Name, string Description, IReadOnlyList<string> Examples);
public sealed record AssistantConversationSummaryDto(string ConversationId, string Title, DateTimeOffset UpdatedAt);
public sealed record AssistantMessageDto(string Role, string Content, AssistantQueryResponseDto? Response, DateTimeOffset CreatedAt);
public sealed record AssistantConversationDto(string ConversationId, string Title, IReadOnlyList<AssistantMessageDto> Messages);
public sealed record UnansweredQuestionDto(string Question, int Times, int MarkedNotHelpful, DateTimeOffset LastAsked);

public sealed record IntegrationRequest(string? SourceReference, Dictionary<string, object?> Data);
