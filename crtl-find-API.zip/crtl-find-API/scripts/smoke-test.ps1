$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$exe = Join-Path $root 'bin\Debug\net10.0\CtrlFind.exe'
if (-not (Test-Path $exe)) { throw 'Build the API before running this check.' }

$previousUrls = $env:ASPNETCORE_URLS
$previousEnvironment = $env:ASPNETCORE_ENVIRONMENT
$env:ASPNETCORE_URLS = 'http://localhost:5112'
$env:ASPNETCORE_ENVIRONMENT = 'Development'
$process = Start-Process -FilePath $exe -WorkingDirectory $root -WindowStyle Hidden -PassThru

try {
    $base = 'http://localhost:5112'
    for ($attempt = 0; $attempt -lt 30; $attempt++) {
        try { Invoke-WebRequest -SkipHttpErrorCheck "$base/openapi/v1.json" | Out-Null; break }
        catch { Start-Sleep -Milliseconds 200 }
    }

    # Needs the development database with scripts/seed-dev-data.sql loaded.
    $health = Invoke-WebRequest -Uri "$base/api/v1/health" -Headers @{ Origin = 'http://localhost:8081' }
    $login = Invoke-RestMethod -Method Post -Uri "$base/api/v1/auth/login" -ContentType 'application/json' -Body '{"username":"naledi.mokoena@ctrlfind.test","password":"AssetHub!2026"}'
    $headers = @{ Authorization = "Bearer $($login.data.accessToken)" }
    $assets = Invoke-RestMethod -Uri "$base/api/v1/assets?assetType=Laptop" -Headers $headers
    $unauthorized = Invoke-WebRequest -SkipHttpErrorCheck -Uri "$base/api/v1/assets"
    $invalid = Invoke-WebRequest -SkipHttpErrorCheck -Method Post -Uri "$base/api/v1/assets" -Headers $headers -ContentType 'application/json' -Body '{"assetType":"Laptop"}'
    $suffix = Get-Random -Maximum 999999
    $body = @{
        assetTag = "EXT-SMOKE-$suffix"; serialNumber = "SMOKE-$suffix"; assetType = 'Laptop'; category = 'End User Device'; make = 'Dell'; model = 'Latitude 5440'
        companyEntity = 'Group Holdings (Pty) Ltd'; costCentre = 'CC-2201'; storeroomId = 'JHB-STORE-A'; lifecycleState = 'InStorage'; purchaseOrder = "PO-$suffix"
        invoiceReference = "INV-$suffix"; acquisitionDate = '2026-10-01'; warrantyStart = '2026-10-01'; warrantyEnd = '2029-10-01'; encryptionStatus = 'BitLocker - Enabled'
    } | ConvertTo-Json
    $created = Invoke-RestMethod -Method Post -Uri "$base/api/v1/assets" -Headers $headers -ContentType 'application/json' -Body $body
    $custodyBlock = Invoke-WebRequest -SkipHttpErrorCheck -Method Post -Uri "$base/api/v1/assets/$($created.data.assetId)/assignments" -Headers $headers -ContentType 'application/json' -Body '{"employeeId":"EMP-01003","locationId":"JHB-SDN","assignmentDate":"2026-10-19","condition":"New"}'
    $answer = Invoke-RestMethod -Method Post -Uri "$base/api/v1/assistant/query" -Headers $headers -ContentType 'application/json' -Body '{"question":"How many laptops are currently unconfirmed?"}'

    if (($health.Content | ConvertFrom-Json).status -ne 'ok') { throw 'Health endpoint failed.' }
    if ($health.Headers['Access-Control-Allow-Origin'] -ne '*') { throw 'Development CORS failed.' }
    if ($login.data.tokenType -ne 'Bearer') { throw 'JWT login failed.' }
    if ($assets.meta.totalCount -lt 1) { throw 'Asset filtering failed.' }
    if ($unauthorized.StatusCode -ne 401) { throw 'Authentication guard failed.' }
    if ($invalid.StatusCode -ne 422 -or ($invalid.Content | ConvertFrom-Json).error.code -ne 'ASSET_STATUS_INVALID') { throw 'Contract validation failed.' }
    if ($created.data.status.operationalStatus -ne 'InStorage') { throw 'Operational status was not derived from the lifecycle state.' }
    if ($custodyBlock.StatusCode -ne 409 -or ($custodyBlock.Content | ConvertFrom-Json).error.code -ne 'CUSTODY_AGREEMENT_REQUIRED') { throw 'Laptop custody rule failed.' }
    if ($answer.data.intent -ne 'UnconfirmedAssets' -or $answer.data.unsupported) { throw 'Data Assistant failed.' }
    Write-Host 'Contract smoke test passed.'
}
finally {
    if (-not $process.HasExited) { Stop-Process -Id $process.Id -Force }
    $env:ASPNETCORE_URLS = $previousUrls
    $env:ASPNETCORE_ENVIRONMENT = $previousEnvironment
}
