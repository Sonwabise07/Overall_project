﻿IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO

BEGIN TRANSACTION;
IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261022085401_InitialSqlServerSchema'
)
BEGIN
    CREATE TABLE [Assets] (
        [AssetId] nvarchar(64) NOT NULL,
        [AssetNo] nvarchar(50) NOT NULL,
        [AssetTag] nvarchar(100) NULL,
        [SerialNumber] nvarchar(150) NULL,
        [AssetType] nvarchar(100) NOT NULL,
        [Make] nvarchar(100) NULL,
        [Model] nvarchar(150) NULL,
        [LifecycleState] nvarchar(50) NOT NULL,
        [OperationalStatus] nvarchar(50) NOT NULL,
        [EmployeeId] nvarchar(64) NULL,
        [EmployeeName] nvarchar(200) NULL,
        [LocationId] nvarchar(64) NULL,
        [Region] nvarchar(100) NULL,
        [Building] nvarchar(150) NULL,
        [Floor] nvarchar(50) NULL,
        [DepartmentId] nvarchar(64) NULL,
        [StoreroomId] nvarchar(64) NULL,
        [WarrantyEnd] datetime2 NULL,
        [PurchaseCost] decimal(18,2) NULL,
        [LastAuditDate] datetime2 NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [UpdatedAtUtc] datetime2 NOT NULL,
        [RowVersion] rowversion NOT NULL,
        CONSTRAINT [PK_Assets] PRIMARY KEY ([AssetId]),
        CONSTRAINT [CK_Assets_PurchaseCost_NonNegative] CHECK ([PurchaseCost] IS NULL OR [PurchaseCost] >= 0)
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261022085401_InitialSqlServerSchema'
)
BEGIN
    CREATE TABLE [Departments] (
        [DepartmentId] nvarchar(64) NOT NULL,
        [Name] nvarchar(200) NOT NULL,
        CONSTRAINT [PK_Departments] PRIMARY KEY ([DepartmentId])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261022085401_InitialSqlServerSchema'
)
BEGIN
    CREATE TABLE [Employees] (
        [EmployeeId] nvarchar(64) NOT NULL,
        [FullName] nvarchar(200) NOT NULL,
        [Email] nvarchar(320) NULL,
        [DepartmentId] nvarchar(64) NULL,
        [IsActive] bit NOT NULL,
        CONSTRAINT [PK_Employees] PRIMARY KEY ([EmployeeId])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261022085401_InitialSqlServerSchema'
)
BEGIN
    CREATE TABLE [Locations] (
        [LocationId] nvarchar(64) NOT NULL,
        [Name] nvarchar(200) NOT NULL,
        [Region] nvarchar(100) NULL,
        [Building] nvarchar(150) NULL,
        [Floor] nvarchar(50) NULL,
        CONSTRAINT [PK_Locations] PRIMARY KEY ([LocationId])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261022085401_InitialSqlServerSchema'
)
BEGIN
    CREATE TABLE [Storerooms] (
        [StoreroomId] nvarchar(64) NOT NULL,
        [Name] nvarchar(200) NOT NULL,
        [LocationId] nvarchar(64) NULL,
        CONSTRAINT [PK_Storerooms] PRIMARY KEY ([StoreroomId])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261022085401_InitialSqlServerSchema'
)
BEGIN
    CREATE TABLE [AssetAssignments] (
        [AssignmentId] bigint NOT NULL IDENTITY,
        [AssetId] nvarchar(64) NOT NULL,
        [EmployeeId] nvarchar(64) NOT NULL,
        [EmployeeName] nvarchar(200) NULL,
        [AssignedAt] datetime2 NOT NULL,
        [ReturnedAt] datetime2 NULL,
        [CustodyAgreementReference] nvarchar(200) NULL,
        [AssignedBy] nvarchar(200) NULL,
        CONSTRAINT [PK_AssetAssignments] PRIMARY KEY ([AssignmentId]),
        CONSTRAINT [FK_AssetAssignments_Assets_AssetId] FOREIGN KEY ([AssetId]) REFERENCES [Assets] ([AssetId]) ON DELETE NO ACTION
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261022085401_InitialSqlServerSchema'
)
BEGIN
    CREATE TABLE [AssetHistory] (
        [HistoryId] bigint NOT NULL IDENTITY,
        [AssetId] nvarchar(64) NOT NULL,
        [Action] nvarchar(100) NOT NULL,
        [Summary] nvarchar(2000) NULL,
        [DetailsJson] nvarchar(max) NULL,
        [ChangedBy] nvarchar(200) NULL,
        [ChangedAt] datetime2 NOT NULL,
        CONSTRAINT [PK_AssetHistory] PRIMARY KEY ([HistoryId]),
        CONSTRAINT [FK_AssetHistory_Assets_AssetId] FOREIGN KEY ([AssetId]) REFERENCES [Assets] ([AssetId]) ON DELETE NO ACTION
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261022085401_InitialSqlServerSchema'
)
BEGIN
    CREATE TABLE [AssetTransfers] (
        [TransferId] bigint NOT NULL IDENTITY,
        [AssetId] nvarchar(64) NOT NULL,
        [TransferType] nvarchar(50) NOT NULL,
        [TargetId] nvarchar(64) NOT NULL,
        [Status] nvarchar(50) NOT NULL,
        [RequestedBy] nvarchar(200) NULL,
        [Notes] nvarchar(2000) NULL,
        [RequestedAt] datetime2 NOT NULL,
        [CompletedAt] datetime2 NULL,
        CONSTRAINT [PK_AssetTransfers] PRIMARY KEY ([TransferId]),
        CONSTRAINT [FK_AssetTransfers_Assets_AssetId] FOREIGN KEY ([AssetId]) REFERENCES [Assets] ([AssetId]) ON DELETE NO ACTION
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261022085401_InitialSqlServerSchema'
)
BEGIN
    CREATE INDEX [IX_AssetAssignments_AssetId_AssignedAt] ON [AssetAssignments] ([AssetId], [AssignedAt]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261022085401_InitialSqlServerSchema'
)
BEGIN
    CREATE INDEX [IX_AssetHistory_AssetId_ChangedAt] ON [AssetHistory] ([AssetId], [ChangedAt]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261022085401_InitialSqlServerSchema'
)
BEGIN
    CREATE UNIQUE INDEX [IX_Assets_AssetNo] ON [Assets] ([AssetNo]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261022085401_InitialSqlServerSchema'
)
BEGIN
    CREATE INDEX [IX_AssetTransfers_AssetId_Status] ON [AssetTransfers] ([AssetId], [Status]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261022085401_InitialSqlServerSchema'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20261022085401_InitialSqlServerSchema', N'10.0.9');
END;

COMMIT;
GO

